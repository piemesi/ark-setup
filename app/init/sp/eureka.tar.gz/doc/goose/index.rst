.. goose:

Generalized Online Occupancy State Estimator (GOOSE)
====================================================

.. automodule:: nestpy.goose
    :members:

Simulators
==========

.. automodule:: nestpy.goose.simulator

Random
------

.. automodule:: nestpy.goose.simulator.random

Discrete Event
--------------

.. automodule:: nestpy.goose.simulator.discrete_event

.. Hyperlinks

.. _simulator: https://docs.google.com/a/nestlabs.com/document/d/1qsAbGj-SRJx1cEoMWf929DsSSNfGdlTtjwfEoyPAGPo/edit#heading=h.mbfs85cpz703

