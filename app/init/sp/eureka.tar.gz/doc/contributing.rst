.. _contributing:

Contributing to Eureka
======================

Your work belongs in Eureka only if it is so well-tested, user-friendly, and
generally useful that it’s worth sharing with a bunch of other people whose
time is very valuable. In deciding whether to contribute something to Eureka,
you should ask yourself: Will others waste time duplicating my work if I
withhold it from Eureka? If the answer is anything but yes, then Eureka isn’t
the place for your work. You can always *store* your work in the `algorithms
repository`_; you only add it to the `eureka repository`_ if you want to *share*
it with the rest of the company.

Please have all of your work code-reviewed before submitting it. Kevin, Mark M., and
Mark S. are good candidates for code reviewers. Please keep in mind the
guidelines and policies below before putting your work up for review.

Contributing scripts to Eureka
------------------------------

Below are some guidelines that set a sort of standard for Eureka-worthy
scripts.

#. It should be plausible that someone else will need to run the script.

   If you are the only person you’d ever expect to use the script, keep it on
   your machine or store it in your folder in the algorithms repository.
   Putting such a script in the eureka repository will just create clutter;
   nobody else needs to see it.

#. Anyone else should be able to run your script without looking at its source.

   Most of us won’t bother spending much time trying to decipher what a script
   does and how to use it. Thankfully, the `argparse library`_ makes auto-
   generating usage text (in response to running a script with the -h option)
   exceedingly easy.

#. Your script should work as advertised.

   Eureka users should be able run any Eureka script without having to test it
   or spot-check the source code. Above all, Eureka users should be able to
   take results of a script “to the bank.” Otherwise, if people can’t trust
   scripts in Eureka, they’ll just write their own.

#. Your script should be easy for others to fix and extend.

   In many cases, a script won’t do exactly what a user wants it to do. Maybe a
   script computes a median instead of a mean, for example. Any competent
   Python coder should be able to amend and extend Eureka scripts as necessary.

Contributing to the NestPy library
----------------------------------

NestPy is meant to be a shared library, so please add materials you think would
be useful to the rest of the team!

Organization
~~~~~~~~~~~~

Since this package is meant to be fairly open, there are no strict requirements
for organizing classes. Of course, we request that contributors follow OOP best
practices.

If you are completely unsure how to library-ize your contribution, or where it
should belong, feel free to ask the `Nest Python Usergroup`_.

Testing
~~~~~~~

Unit tests are run automatically using the ``make test`` command, which in turn
calls the `Python unittest framework`_.

To include your unit test in the test suite performed by the ``make test``
command, simply prefix the filename with the word "test". It will be
automatically discovered and executed along with all other unit tests.

.. note:: Because unit testing is set up to run all files that start with "test",
   you should not start any non-test file with "test". If you do, it will be
   executed as a test during unit testing.

Documenting
~~~~~~~~~~~

Documenting software is an art form in and of itself, and NestPy is certainly
not bent on creating production-worthy refdocs. However, documentation should
satisfy at least some of these characteristics:

#. **Searchability.** Users must be able to find your contribution!
#. **Readability.** Others need to be able to look at your documentation and
   understand how your contribution can help them.

How does good documentation look? Check out this `beautiful documentation example`_.

For information on writing Sphinx documentation, check out these resources:

* `Sphinx ReStructuredText Primer`_
* `ReStructuredText Cheat Sheet`_

Style and Formatting
--------------------

Eureka uses the `Google Python Style Guide`_ conventions. The main formatting
requirements are:

* Class names are in CamelCase. Everything else (variables, class instances,
  methods) are snake_case.
* Try not to use sophisticated macros like ``lambda`` and ``map`` unless the
  operation is fairly simple or the speed improvement is worth the decreased
  readability.

We also recommend following `Best Practices for Classes`_, since it helps others
use your objects with minimal confusion and errors.


.. Hyperlinks

.. _algorithms repository: https://stash.nestlabs.com/projects/ALGORITHMS/repos/algorithms
.. _eureka repository: https://stash.nestlabs.com/projects/ALGORITHMS/repos/eureka
.. _argparse library: http://docs.python.org/dev/library/argparse.html
.. _Nest Python Usergroup: mailto:monty-python@nestlabs.com
.. _Python unittest framework: http://docs.python.org/2/library/unittest.html
.. _beautiful documentation example: http://pythonhosted.org/an_example_pypi_project/sphinx.html#full-code-example
.. _Sphinx ReStructuredText Primer: http://sphinx-doc.org/rest.html
.. _ReStructuredText Cheat Sheet: http://openalea.gforge.inria.fr/doc/openalea/doc/_build/html/source/tutorial/rest_syntax.html
.. _Google Python Style Guide: http://google-styleguide.googlecode.com/svn/trunk/pyguide.html
.. _Best Practices for Classes: https://speakerdeck.com/pyconslides/pythons-class-development-toolkit-by-raymond-hettinger
