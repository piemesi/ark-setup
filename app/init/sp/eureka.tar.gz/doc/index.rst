.. NestPy documentation master file, created by
   sphinx-quickstart on Tue Feb 26 20:08:13 2013.

Eureka: Nest Labs Data Toolbox
==============================

Welcome to Eureka, the Nest Labs repository for data tools!

.. seealso:: If this is your first time using Eureka, we recommend you start
   with the :ref:`getting_started` guide.

Table of Contents
-----------------

+-----------------------+---------------------------+--------------------------+
| General Topics        | NestPy Library            | Scripts                  |
+=======================+===========================+==========================+
| .. toctree::          | A well-organized,         | Application-specific     |
|    :maxdepth: 2       | extensively-documented,   | resources for gathering, |
|                       | regularly-tested Python   | processing, analyzing,   |
|    getting_started    | package containing core   | and plotting data.       |
|    installing_canopy  | utilities.                |                          |
|    reading_list       |                           | .. toctree::             |
|    contributing       | * :ref:`genindex`         |    :maxdepth: 2          |
|                       |                           |                          |
|                       | .. toctree::              |    gallery/index         |
|                       |    :maxdepth: 2           |                          |
|                       |                           |                          |
|                       |    structures/index       |                          |
|                       |    utilities/index        |                          |
|                       |    plotting               |                          |
|                       |    aws                    |                          |
|                       |    sql/index              |                          |
|                       |    modeling/index         |                          |
|                       |    goose/index            |                          |
+-----------------------+---------------------------+--------------------------+

This documentation focuses on the NestPy library, but we highly recommend you
visit the scripts folder to see what's available.
