.. _daily_consumption_models:

Daily Consumption Models
========================

.. automodule:: nestpy.modeling.daily_consumption_models
   :members:

Models
------

These classes implement Daily Consumption Models. The superclass, ConsumptionModel, dictates the interface of all
subclasses.  The module consumption_model_utilties provides methods that could be helpful when creating the input
or output for these consumption models.  The blame_engine module contains methods to generate blames from any
consumption model.

Consumption Model
~~~~~~~~~~~~~~~~~

.. autoclass:: nestpy.modeling.daily_consumption_models.ConsumptionModel
   :members:

Nonlinear Consumption Model
~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. autoclass:: nestpy.modeling.daily_consumption_models.NonlinearConsumptionModel
   :members:

Constant Float Consumption Model
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. autoclass:: nestpy.modeling.daily_consumption_models.ConstantFloatModel
   :members:

Dynamic Float Consumption Model
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. autoclass:: nestpy.modeling.daily_consumption_models.DynamicFloatModel
   :members:

Consumption Model Utilities
~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. automodule:: nestpy.modeling.daily_consumption_models.consumption_model_utilities
   :members:

Blame Engine
~~~~~~~~~~~~

.. automodule:: nestpy.modeling.daily_consumption_models.blame_engine
   :members:


