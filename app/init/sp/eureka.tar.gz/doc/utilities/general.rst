.. _general:

General Resources
=================

.. automodule:: nestpy
   :members:
