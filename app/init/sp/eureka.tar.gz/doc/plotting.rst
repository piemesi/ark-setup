.. _plotting:

Plotting
========

Matplotlib is great, but there are some areas where it's rough around the edges. 
NestPy incorporates several nice classes and functions to make plotting easier.

Utilities
---------

.. automodule:: nestpy.plotting
   :members:
