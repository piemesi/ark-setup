#Overview#
This pull request consists primarily of a module for mapping various shapes in a locally-generated HTML file that relies on the Google Maps Javascript API v3.  It is inspired by (and in many ways similar to) [pygmaps](https://code.google.com/p/pygmaps/), but adds a significant amount of functionality.


#Usage#
The mapping module is located within nestpy/geo.  To import simply use the following:

```
from nestpy.geo import NestGMaps
```

Once imported, create a new instance of the mapping object, passing in the latitude and longitude of the desired center of the map and the zoom level (a scale from 1 to 20).  For example:


    mymap = NestGMaps(37.428, -122.145, 16)


With the instance of the object, various shapes / objects can be added to the map (explained in detail next). After adding all shapes / objects, the output html file is generated using the draw_map command. For example:


    mymap.draw_map('/my/favorite/directory/ever/example_map.html')



##Shapes and Objects##
The following is a list of the shapes and objects that can be added to the map.

###External CSS###
External CSS code can be added to style the map and any added objects. The CSS to be added should be a list of CSS lines where each element of the list contains a dictionary where the key is the indent level and the value is the CSS line. Example:

    mymap.add_css(list_of_css)


###Circles###
Circles can be added to the map, where the inputs specify the center of the circle and its radius.  Optional parameters allow for changing the stroke color and width, as well as the color and opacity of the interior fill. The following example adds a circle with a radius of 50 meters at the CineArts in Palo Alto where the outline of the circle is white and the interior is black with an opacity of 25%.

    mymap.add_circle(lat=37.420478, lng=-122.141540, rad=50, stroke_color='#FFFFFF', stroke_width=4, fill_color='#000000', fill_opacity=0.25)


###HTML Overlays###
External HTML can be added to the map as an overlay.  This can be handy for adding extra information that floats over the top of the map such as a log.  Be cautious not to make it too big and cover the entire map!  As with the CSS, the HTML should be added a list of dictionaries where the key is the indent level and the value is the HTML line.  See the function docstring for details about the location parameter.  An example is as follows.

    mymap.add_html_overlay([{0: '<h1>My overlay</h1>'}], LEFT_BOTTOM)


###External Javascript###
As with CSS, external javascript can be added to the map.  Note that no validation is done, so inserting invalid javascript will cause the entire mapper to crash and burn and you'll have a bad time.  As with HTML and CSS, the javascript should be added a list of dictionaries where the key is the indent level and the value is the javascript line.  Example:

    mymap.add_js([{0: 'var myvar = 5;'}])


###Map Legend###
A legend can be added to the map to indicate what each type of marker is.  Note that a legend must be added before legend entries are (discussed next).  If intending to add entries to a legend, use the following:

    mymap.add_legend()


###Legend Entries###
After adding a legend to the map, individual entries can be added where each entry will show a maker icon as well as a text description as specified as a parameter of the add_marker_legend_entry() function.  The text for each type of marker in the legend will be turned into a link, which, upon clicking, will toggle the visibility of all markers within that group.  The example below adds a blue marker legend entry which is tied to the 'my_marker_group' group and will be titled as 'My Markers' on the legend.

    mymap.add_marker_legend_entry('#0000FF, 'my_marker_group', 'My Markers')


###Markers###
Simple markers (or pins) can be added to the map at a specified location.  The default google maps marker is utilized where the color can be varied.  Here's an example of a blue marker ![blue marker](http://chart.apis.google.com/chart?cht=mm&chs=12x16&chco=FFFFFF,0000FF,000000&ext=.png).  Optional parameters allow for specifying the group for the marker (useful for connecting to legend entries) as well as html blocks for infowindows that will be displayed when the marker is clicked. The following is an example of adding a Nest blue marker at 900 hansen way.

    mymap.add_marker(37.418033, -122.140983, "#2BB1D6")


###Paths###
Paths outlining a route can be added to the map by specifying a series of waypoints.  The waypoints should be passed to the function as list of tuples of latitudes and longitudes.  The example below adds a black path with 50% opacity around Hansen Way, Page Mill Rd, and El Camino Real.

    path = [(37.417308, -122.141043), (37.417187, -122.142392), (37.418806, -122.145504), (37.422649, -122.142146), (37.422734, -122.141534), (37.420954, -122.138240), (37.420709, -122.138219), (37.418546, -122.140005), (37.418958, -122.140814)]
    mymap.add_path(path, color="#000000", opacity=0.5)


###Rectangles###
Similar to circles, rectangles can be added to the map.  The southwest and northeast coordinates of the rectangle need to be specified, while the stroke color and width, and fill color and opacity can be optionally specified.  An example is below.

    mymap.add_rectangle(sw_lat=37.418773,  sw_lng=-122.139034, ne_lat=37.419255, ne_lng=-122.138458, stroke_color='#2BB1D6', stroke_width=2, fill_color='#000000', fill_opacity=0.0)


##Miscellaneous##
The following are other settable options for the output map.

###Auto Zoom###
The Google Maps Javascript API provides a method for zooming the map upon loading so that a collection of points are visible.  By specifying the southwest and northeast coordinates of a rectangle, this function will allow the resultant map to automatically zoom so that the rectangle is visible.  An example is below.

    mymap.set_auto_zoom(sw_lat=37.417169, sw_lng=-122.146944, ne_lat=37.423918, ne_lng=-122.132824)


###Maximum Window Height###
Info windows will be generated for each marker if given a non-None info parameter.  This function allows a maximum height in pixels to be set for all of the info windows on the map; the default is 300 px.  An example is as follows.

    mymap.set_max_info_window_height(350)

###Output Compression###
The output html file can be compressed by eliminating unnecessary whitespace.  The default is to include whitespace.

    mymap.set_output_compress(True)