.. _aws:

AWS Tools
=========

The ability to interact with Amazon Web Services (primarily S3 and EC2) is 
an important component of gathering and processing data. Python itself offers 
a fairly wide selection of AWS utilities through the boto_ and s3cmd_ libraries, 
but NestPy includes several tools optimized for working with Nest device data.

Data Downloader
---------------

.. autoclass:: nestpy.aws.DataDownloader
   :members:

.. Hyperlinks

.. _boto: http://docs.pythonboto.org/en/latest/
.. _s3cmd: http://s3tools.org/s3cmd
