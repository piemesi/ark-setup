.. _gallery:

Plotting Gallery
================

.. toctree::

Diamond HVAC Cycles
-------------------

Plots HVAC cycles of specific types.

.. plot::

   import logging
   import sys
   sys.path.append("../../scripts/Diamond")
   import cycle_plotter
   cycle_plotter.logger.setLevel(logging.WARN)
   cycle_plotter.generate_plot("../../resources/data/01AA01RA2612004P", "Stage1Cool")
   plt.show()

Topaz Sensor Measurements
-------------------------

Plots all data received from Topaz sensors in a specified time range.

.. plot::

   import dateutil
   import os
   import sys
   tvd_dir = "resources/data/18b43000001e84e5"
   os.chdir("../../")
   sys.path.append("scripts/Topaz")

   import s3_log_plotter

   start_date = dateutil.parser.parse("2013-07-25")
   end_date = dateutil.parser.parse("2013-07-30")

   device = s3_log_plotter.nestpy.Topaz.load(tvd_dir,
                                             start_date = start_date,
                                             end_date = end_date)

   s3_log_plotter.plot_topaz(device, start_date, end_date)

   # Cleanup cached event log files
   for data_file in os.listdir(tvd_dir):
       if not data_file.endswith(".log"):
           os.remove(os.path.join(tvd_dir, data_file))

   plt.show()

Thermal Model
-------------

Runs the specified thermal models on Diamond data and plots the resulting
temperature predictions and estimated usage.

.. plot::

   import datetime
   import logging
   import os
   import sys
   sys.path.append("../../scripts/Diamond")
   import run_models
   run_models.logger.setLevel(logging.WARN)

   start = run_models.nestpy.converters.get_tz_aware_datetime("2013-03-20T17:00PST")
   end = run_models.nestpy.converters.get_tz_aware_datetime("2013-03-20T21:00PST")

   run_models.evaluate(["../../resources/data/01AA01RA2612004P"],
                       start=start,
                       end=end,
                       model_names=["InitialRateStagedModel"],
                       generate_plots=True,
                       closed_loop=True,
                       training_interval=datetime.timedelta(days=1),
                       hvac_state="Stage1CoolState")

   plt.show()
