.. _getting_started:

Getting Started
===============

New to Eureka? Here's a short guide to help you get up and running.

Prerequisites
-------------

Before beginning the setup procedure, you will need the following items:

- A machine running Mac OSX or Debian Linux, or Goobuntu, and root access to that machine.
- If you don't have one yet, create an ssh key. For assistance, see this page: `Creating SSH Keys`_.
.. note::
    Currently, passphrase encrypted keys are not supported by Eureka. Please leave the passphrase field empty when generating your key.
- Access to the `Eureka repository`_. To get access, file an IT Jira asking for access.
- To get important notifications about the repository, join the `Eureka google group`_.
- If you would like to get commit messages for the repository, join the `Eureka changes list`_.

Cloning the Eureka repository
-----------------------------

Clone the Eureka repository on your machine:
If you've uploaded ssh keys to stash, you can use::

    $ git clone ssh://git@stash.nestlabs.com:7999/algorithms/eureka.git

Otherwise, you can use (changing "username" to be your login)::

    $ git clone https://username@stash.nestlabs.com/scm/algorithms/eureka.git

Configuring Python and Eureka
-----------------------------

These configuration steps are optional, but recommended.

Setting up Nest Python
~~~~~~~~~~~~~~~~~~~~~~

`Nest Python`_ is a python distribution that contains pre-compiled versions of the required packages for using Eureka.
While it is optional, it simplifies installation of several Python packages - specifically numpy, scipy, and matplotlib.
If you aren't familiar with managing a Python environment, using Nest Python is recommended.

The following instructions will download and install Nest Python, and set it up as your default python. The script
will then ask you several questions about your local setup.

.. topic:: Mac OSX El Capitan Upgrade

    If you have just upgraded to OSX El Capitan and encounter errors related to numpy, scipy or pandas, please reinstall the GNU C++ (gcc)
    on your system. In order to do so follow the steps for "Instructions for Mac OS 10.10 (Yosemite) with Xcode 6" mentioned in the link below:

    `Installing GCC on MAC OSX El Capitan`_

    The first step mentioned in the link should be replaced with upgrading XCode through the "Managed Software Center" on your Mac.
    Post this step, you should be able to see  lib* files in your ``/usr/local/lib`` directory.

.. warning::
    If you work on Sapphire, you do not want to set nest-python as your default Python because this will cause
    conflict when compiling Sapphire. If you would like to have the Eureka environment setup script (requires
    Nest-Python) added as an alias (``eurekadev``) to your profile, but not sourced by default, you may pass the `-n`
    flag to the following Nest Python install script.

From the Eureka source directory, run the script below. It will look for existing installation of nest-python and uninstall first.
To uninstall only, follow the steps mentioned in the next section ::

    $ ./bin/setup/nest_python.sh

To update your environment to use nest-python, you'll need to source your profile. If you chose the default profile,
you can run::

    $ source ~/.profile  # or your selected profile

Verification::

    $ which pip
    /usr/local/nest-python/bin/pip
    $ which python
    /usr/local/nest-python/bin/python


Uninstalling Nest Python
~~~~~~~~~~~~~~~~~~~~~~~~

In case you would like to reinstall nest-python and all dependant libraries, perform the following:

* Remove all existing directories with ``nest-python`` libraries::

    $sudo rm -r /usr/local/nest-python*
    $sudo rm -r /usr/local/lib/nest-python*
    $unset NESTPYTHONHOME

* Check your $PATH variable and remove nest python lib references from the path. For example::

    PATH=/usr/local/nest-python/bin:/usr/local/nest-python-local/bin:/usr/local/git/current/bin:/usr/local/bin:/usr/bin:/bin:/usr/local/sbin:/usr/sbin:/sbin

  should be replaced with a command line statement as::

    export PATH=/usr/local/git/current/bin:/usr/local/bin:/usr/bin:/bin:/usr/local/sbin:/usr/sbin:/sbin

Log caching and storage
~~~~~~~~~~~~~~~~~~~~~~~

One of the primary uses for Eureka is downloading, parsing and using Nest device data. Eureka caches the data it
downloads to avoid re-downloading and parsing the same information multiple times. To set the location that Eureka will
store the cached data, you can define an environment variable and create the directory for storing cached data::

    $ export EUREKA_CACHE="/my/eureka/cache/location/"
    $ mkdir -p $EUREKA_CACHE

You'll need to be sure to export the ``EUREKA_CACHE`` environment variable in your shell profile (``.profile``,
``.bash_profile``, etc.) so that it persists across terminal sessions.

By default, Eureka uses CSV files to cache downloaded and parsed logs. For larger logs, this becomes very inefficient,
so Eureka also supports using HDF5 as a log storage method.

The alternative is simple directoried event logging, which would create parsed raw log output in ``EUREKA_CACHE`` directory.
Event details, after being parsed from raw logs, are stored as their respective names in the ``EUREKA_CACHE`` directory.
However, it is highly recommended that you use HDF5 logging.

To install HDF5, run::

    $ ./bin/setup/hdf5.sh

Eureka decides which log format to use based on the existence of an environment variable. Be sure to add the following
line to your profile if you'd like to use HDF5 logs by default::

    $ export EUREKA_HDF5=

Remove the above statement in the ``~\.profile`` file, in case you need to switch back to directoried event logging.
Before switching between different log caching strategies, please remove all files in the ``EUREKA_CACHE`` directory.

Verifying your profile file
~~~~~~~~~~~~~~~~~~~~~~~~~~~

Ensure your ``.profile`` file consists of the following statements (remove or add export statements appropriately)::

    # Set up Eureka using Nest Python as the default environment
    source '/Users/<username>/eureka/bin/environment_setup.sh'

    # Set up Alias for switching to Eureka environment
    alias eurekadev='source '/Users/kokhandiar/eureka/bin/environment_setup.sh''
    alias mysql=/usr/local/mysql/bin/mysql

    export EUREKA_CACHE=/Users/<username>/eureka_cache/
    export EUREKA_HDF5=
    export EUREKA_TEST_S3=
    export EUREKA_TEST_DB=


Matplotlib Backends
~~~~~~~~~~~~~~~~~~~

Matplotlib requires a backend to save and display images. By default, it will use the ``agg`` backend. If you only
plan on using matplotlib in a non-interactive mode (i.e. to save images only), you should use this backend, and can skip
to the next section.

If you plan on using interactive plots (the `-p` option on many scripts), you will need to configure your system to
use an interactive backend.

The configuration file is located in a different location depending on whether you are using an OSX or Linux machine.
For OSX, you can find the file at ``~/.matplotlib/matplotlibrc``. For Linux, the file is located at
``~/.config/matplotlibrc``. On a new machine, this file may not exist, and you will need to create it.

Your choice of backend depends on the type of machine you are using. To select a specific backend, add the following
line to your `matplotlibrc` file::

    backend: my_backend

where `my_backend` is replaced with the backend you wish to use. Available backends can be found
`here <http://matplotlib.org/faq/usage_faq.html#what-is-a-backend>`_. Some recommendations are below.

Mac OSX
*******
OSX has the most difficulties with matplotlib backends. Popular choices include: ``tkagg``, ``qt4agg``, or ``macosx``.
If you choose QT4, you'll need to install the framework from `here <http://download.qt.io/official_releases/qt/4.8/>`_.
A script is also available to automate installing QT4 on OSX, located at ``./bin/setup/qt4.sh``. If you are having
problems getting things to work with the above options, it is recommended that you switch back to ``agg`` and simply
save your plots instead of using interactive mode.

Goobuntu
********
The current recommended backend for Goobuntu is ``qt4agg``. QT4 should already be installed on your system.

Amazon EC2
**********
Interactive backends are currently not recommended on EC2 machines. Setting your backend to ``agg`` and saving plots
is currently the best option.

Installing Eureka
-----------------

Be sure to source your profile to capture any of the changes you may have made above::

    $ source ~/.profile  # or your selected profile

To install Eureka::

    $ make install

This will perform all necessary setup procedures for you:

* Install all of the packages we use in Eureka into your Python distribution.
* Make the nestpy package in the Eureka repository available in your Python
  distribution. This configuration avoids the need to re-install nestpy each
  time you pull from the repository: all changes will be immediately available
  in Python after updating your checkout.

Configuring and Verifying Data Access
-------------------------------------
While Eureka may be used for general development, most of its useful tools require access to databases and S3 buckets.

Data Access Permissions
~~~~~~~~~~~~~~~~~~~~~~~

If you require access to Nest Data, please follow the steps below for the types of access you need.

- Keys to access AWS, the primary storage space for device logs. Please
  *carefully* follow the instructions on the `Service Access Policy wiki`_.
- To access the database for sql queries, upload your public ssh key to keyring,
  file a DevOps JIRA with component set to security, and request access to the
  production, ft, and analytics databases.
- To download Diamond logs from before March 1, 2013, you will need ssh access to the
  analytics bastion. To request access, upload your public ssh key to keyring (keyring.nestlabs.com),
  file a DevOps JIRA with component set to security, and ask for access to:
  analytics-production-c1-analytics-2.nest.com and
  analytics-ft-c1-analytics-2.nest.com

Data access configuration
~~~~~~~~~~~~~~~~~~~~~~~~~

To configure and verify S3 access:

Please do not "sudo" as "root" user to perform the below operations.
Install AWS CLI::

    $ pip install aws
    $ pip install awscli

After successful installation of the cli, run the following on the command line::

    $ aws configure

It should look something like this::

    $ aws configure
    AWS Access Key ID [****************SR2A]:
    AWS Secret Access Key [None]:

You will require to enter the access and secret key provided by DEVOPS (in valentine.corp.google.com), when prompted.
Skip through all the other prompts.

Verification::

    $ cat ~/.aws/credentials

This file should contain the access and secret key you entered, make sure you are the owner of the file with read/write/execute permissions.

To configure database access, please run::

    $ ./bin/setup/db_access.py

Using Eureka
------------

NestPy is a collection of Python libraries and applications (a.k.a. scripts), so there isn't a specific set of
instructions for using it. However, here are some things we recommend you take a look at:

* Downloading and plotting data using scripts from the :ref:`gallery`.
* Working with event logs using the :ref:`device_history` object.
* Generating beautiful plots using the :ref:`plotting` library.

.. _interactive_development:

Contributing to Eureka
----------------------

Developers should be able to find, use, and modify the tools in Eureka with
ease. They should also be able to count on the tools to work as advertised.
To ensure Eureka is useful to a broader audience in these ways, we've come up
with some guidelines you should read (in :ref:`contributing`) before contributing
code of your own.

Testing
-------

Eureka has an extensive test suite, including unit tests, integration tests, which require data access privileges, and
exhaustive tests.

Although not required, we recommend running ``make test`` when installing Eureka. This will execute
all unit tests by default, letting you know if you are missing any crucial packages. Running integration
tests will also ensure that you have sufficient access privileges.

To run tests, simply run::

    $ make test

For test options, such as which tests to run and whether to run integration and exhaustive tests, see the make help. At
the time of this writing, make help included the following documentation for ``make test``::

    $ make
    ...
    test               run all unit tests and perform test coverage analysis

                     Test options include:
                         EUREKA_TEST the module to test, defaults to nestpy
                         EUREKA_TEST_S3 whether to run S3 tests. Defaults to False
                         EUREKA_TEST_DB whether to run DB tests. Defaults to False
                         EUREKA_TEST_EXHAUSTIVE whether to run exhaustive tests. Defaults to False

                     For example, to run the normal suite of tests:
                         make test

                     and to run a single test module:
                         make EUREKA_TEST=./nestpy/test/goose test

                     and to run all tests, including S3 and DB-dependent tests:
                         make EUREKA_TEST_S3=True EUREKA_TEST_DB=True test
    ...


Building Documentation
----------------------

Documentation is generated using Sphinx_, which is available for download
from the `PyPi package center`_. Once installed, you can compile documentation
by going to top folder of your Eureka checkout and running any of the following
``make`` targets:

* ``html``, ``singlehtml``, or ``dirhtml`` - documentation as webpages.
* ``json`` - documentation as a JSON object.
* ``text`` - documentation as plain text.
* ``man`` - documentation as Unix-format man pages.

Interactive Development/Debugging
---------------------------------

Although the vanilla Python shell is available with any Python installation
(simply run ``python`` from the command-line), we suggest several other
development interfaces.

IPython Notebook
~~~~~~~~~~~~~~~~

IPython Notebook is an interactive Python shell that runs in your browser and
gives you a Mathematica-like environment. It runs on top of IPython, which is
essentially an extension of the Python shell that has some extremely useful
features:

* Superb auto-completion
* Interactive debugging using the ``import IPython; IPython.embed()`` macro in
  any Python program
* Color-annotated error and warning messages

IPython is particularly useful when working with NumPy, SciPy, and Pandas, as it
was developed by the same open-source community that maintains those packages.

For more information, please visit the `IPython homepage`_.

Reading List
------------

There are a lot of resources on working with data in Python - check out the
:ref:`reading_list` for some good places to start.

.. Hyperlinks
.. _`Creating SSH Keys`: https://confluence.atlassian.com/display/STASH/Creating+SSH+keys
.. _`Eureka repository`: https://stash.nestlabs.com/projects/ALGORITHMS/repos/eureka
.. _`Eureka google group`: https://groups.google.com/a/nestlabs.com/forum/#!forum/eureka
.. _`Eureka changes list`: https://groups.google.com/a/nestlabs.com/forum/?pli=1#!forum/eureka.changes
.. _`Nest Python`: https://wiki.nestlabs.com/display/NEST/Nest+Python+Distribution
.. _`Service Access Policy wiki`: https://wiki.nestlabs.com/pages/viewpage.action?title=Service+Access+Policy&spaceKey=OPS#ServiceAccessPolicy-AWSKeys
.. _`IPython homepage`: http://ipython.org/
.. _Sphinx: http://sphinx-doc.org/
.. _`PyPi package center`: https://pypi.python.org/pypi/Sphinx#downloads
.. _`Installing GCC on MAC OSX El Capitan`: https://wiki.helsinki.fi/display/HUGG/Installing+the+GNU+compilers+on+Mac+OS+X

