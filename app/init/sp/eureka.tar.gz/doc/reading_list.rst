.. _reading_list:

Reading List
============

Python has a lot of great learning resources on the web. Even if you've been 
using Python for a while, there are a lot of tricks and tips out there that can 
help make you a more productive coder!

Vanilla Python
--------------

* `Why Python is Awesome`_ - if you have coding experience but are brand new to 
  Python, watch this 45-minute video by one of Python's chief architects.

Classes
~~~~~~~

* `Best Practice for Classes`_ - if you are building classes, this video has 
  essential tips for making classes that are easy for others to use.
      
Numpy and Scipy
---------------

Numpy and Scipy are Python packages that give access to extremely fast linear 
algebra operations. They essentially provide MATLAB-level math functionality 
within the Python environment.

* `NumPy Tutorial`_ - this will give you an all-out introduction to NumPy's 
  features.
* `NumPy for MATLAB Users`_ - lists the primary differences between NumPy and 
  MATLAB (the biggest one being 0-based indexing).
* `Sorting, Searching, and Counting in NumPy`_

Pandas
------

Pandas is a newer packages that turns Numpy into a more general data object.

* `10 Minutes to Pandas`_ - a great introduction to Pandas, the premiere data 
  analysis library in Python.

Speed and Efficiency
--------------------

* `A Quick Introduction to Cython`_ - an introduction to writing and compiling 
  C code that you can call from Python.

.. Hyperlinks
.. _`Why Python is Awesome`: http://pyvideo.org/video/1669/keynote-3
.. _`Best Practice for Classes` : https://speakerdeck.com/pyconslides/pythons-class-development-toolkit-by-raymond-hettinger
.. _NumPy Tutorial: http://www.scipy.org/Tentative_NumPy_Tutorial
.. _NumPy for MATLAB Users: http://www.scipy.org/NumPy_for_Matlab_Users
.. _Sorting, Searching, and Counting in NumPy: http://docs.scipy.org/doc/numpy/reference/routines.sort.html
.. _`10 Minutes to Pandas`: http://pandas.pydata.org/pandas-docs/dev/10min.html
.. _`A Quick Introduction to Cython`: http://blog.perrygeo.net/2008/04/19/a-quick-cython-introduction/
