.. _device_history:

Device History
==============

This rich-functionality structure is built on top of the `Pandas DataFrame`_.
At the top level, it is essentially a dictionary from event types to DataFrames.
This means all event data for a given device is stored as a set of easily
managed tables within a single object.

To get to the DeviceHistory, use::

  >>> from nestpy.structures import DeviceHistory

Implementing Classes
--------------------

All objects that store histories for Nest devices are implemented as subclasses 
of DeviceHistory. Those classes are:

* :ref:`diamond`
* :ref:`topaz`

Functions
---------

.. autoclass:: nestpy.structures.DeviceHistory
   :members:
   
.. Hyperlinks
.. _overview: http://pandas.pydata.org/pandas-docs/dev/10min.html
.. _`Pandas DataFrame`: http://pandas.pydata.org/pandas-docs/stable/dsintro.html#dataframe
