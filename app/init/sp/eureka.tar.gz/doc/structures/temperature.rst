.. _temperature:

Temperature Object
==================

This object simplifies dealing with temperature conversions. To get to the 
Temperature structure, use::

  >>> from nestpy import Temperature

Usage
-----

To create a new Temperature object, provide the temperature to the 
constructor::

  >>> temp = nestpy.Temperature(20.0)
  >>> temp
      <nestpy.Temperature at 20.0C>

By default, temperatures are in Celsius. You can also use Fahrenheit::

  >>> temp = nestpy.Temperature(72.0, 'F')
  >>> temp
      <nestpy.Temperature at 22.2C>
      
or fixed point::
      
  >>> temp = nestpy.Temperature(1000000, 'fixed')
  >>> temp
      <nestpy.Temperature at 15.2C>
      
Performing operations on multiple temperatures is very easy. If you have two 
temperatures::

  >>> temp1 = nestpy.Temperature(20)
  >>> temp2 = nestpy.Temperature(40, 'F')

You can add them together::
  
  >>> temp1 + temp2
      <nestpy.Temperature at 24.4C>
      
You can subtract one from the other::

  >>> temp1 - temp2
      <nestpy.Temperature at 15.6C>
      
And you can compare them with any standard operator::

  >>> temp1 == temp2
      False
  >>> temp1 > temp2
      True

Functions
---------

.. autoclass:: nestpy.Temperature
   :members:
