.. _topaz:

Topaz History Object
====================

This history object is built on top of the :ref:`device_history` container. 
It works much like the :ref:`diamond`. To get to the Topaz structure, use::

  >>> from nestpy import Topaz

Functions
---------

.. autoclass:: nestpy.Topaz
   :members:
