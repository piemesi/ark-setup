.. _diamond:

Diamond History Object
======================

This history object is built on top of the :ref:`device_history` container. 
To get to the Diamond structure, use::

  >>> from nestpy import Diamond

Loading Event Logs
------------------

The easiest way to create a Diamond history object is to simply load it from
event logs. You can use raw event logs available on S3, raw event logs saved 
locally, or directoried event logs saved locally.

Direct from S3
~~~~~~~~~~~~~~

If you haven't yet downloaded device data to local storage, you can have the 
Diamond object get the data for you and populate itself. At base, you need to 
provide a MAC address, a date range, and the service tier on which the logs
reside::

  >>> dh = Diamond.load("18b4300aee7e", start_date='2013-04-01', end_date='2013-05-01', tier='production')

The above command will first download logs from the specified device for the
specified time range to a folder in the current directory whose name is the
device MAC address. It will then populate this folder with directoried logs.
Finally, it will load the data into a Diamond structure for easy access and
manipulation.

.. note:: This feature requires that an s3cmd configuration is present in the 
  user's home directory. The configuration provides the AWS access ID and 
  secret key to the downloader engine.

Using Raw Event Logs
~~~~~~~~~~~~~~~~~~~~

If you've already downloaded raw logs, you can generate the Diamond object 
directly from the raw logs (without parsing to directoried event logs using the 
original Perl scripts). Here we use event logs from the resources directory 
of the Eureka repository::

  >>> dh = Diamond.load("resources/data/01AA01RA2612004P.event")

The event log does not necessarily need to be uncompressed; the history can 
parse GZIP-compressed event logs as well::

  >>> dh = Diamond.load("resources/data/01AA01RA2612004P.event.gz")

Using Directoried Event Logs
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Many users already have logs that have been parsed to directoried event logs 
using the original Perl scripts. Loading from these logs is by far the fastest 
way to populate the Diamond history. Again, we give an example of using data 
from the resources directory of the Eureka repository::

  >>> dh = Diamond.load("resources/data/01AA01RA2612004P")

The individual event files do not necessarily need to be unzipped; the history 
can be generated from GZIP-compressed event files as well::

  >>> dh = Diamond.load("resources/data/01AA01RA2612004P-gz") 

Using Multiple Sources
~~~~~~~~~~~~~~~~~~~~~~

In some cases, users will be combining logs from multiple sources - for 
example, existing directoried event logs representing an older time frame, and 
raw event logs from later dates. To generate a single Diamond object containing 
all of this data, provide the sources to the ``load`` function as a list::

  >>> dh = Diamond.load(["resources/data/01AA01RA2612004P", "resources/data/01AA01RA2612004P.event.gz"])
  
Each source will be read from, and the appropriate event data will be 
concatenated together.

.. note:: The loader does not pay attention to the timestamps on the data being 
   appended. The user is responsible for dealing with overlapping timestamps 
   and gaps in the data.

Efficiency Recommendations
~~~~~~~~~~~~~~~~~~~~~~~~~~

Log loading is generally a time-intensive process, so we include here several 
recommendations for improving efficiency.

#. **Load from directoried logs as much as possible.** Loading from directoried 
   logs is an order of magnitude faster than parsing raw event logfiles. If you 
   are loading from raw logs and will need to reload multiple times (for
   example, when testing an algorithm multiple times), you can save significant
   time by saving the Diamond history to directoried logs after the first load::
  
     >>> dh = Diamond.load("resources/data/01AA01RA2612004P.event")
     >>> dh.to_directoried_event_logs("01AA01RA2612004P")
  
   This will generate the same directoried event logs that the original Perl 
   scripts create. After this, you can quickly reload the Diamond history 
   directly from the directoried logs on future runs::
  
     >>> dh = Diamond.load("01AA01RA2612004P")
  
#. **Load only the event types you need.** In many large-scale processing 
   operations, you will only need two or three event types. In these cases, you 
   can use the ``event_types`` field to tell the loader to ignore event types 
   you don't need::
   
     >>> dh = Diamond.load("resources/data/01AA01RA2612004P", event_types=["BufferedTemperature", "UpdateStateResults"])

   This can save an enormous amount of processing time and disk space.

#. **Decompress logfiles.** All loading methods support both uncompressed and 
   GZIP-compressed files, with the intention of letting users decide which is 
   more appropriate for their use. Generally, the rule of thumb is: uncompress 
   logs if you will be loading the Diamond history more than once.
   
   To decompress event logs downloaded from S3, set the ``uncompress_log`` 
   field to ``True``::
   
     >>> dh = Diamond.load("18b4300aee7e", start_date='2013-04-01', end_date='2013-05-01', uncompress_log=True)

   When saving a Diamond history to directoried event logs, compression is 
   disabled by default. We recommend not activating it, but you can compress 
   the individual event logs to save space::
   
     >>> dh.to_directoried_event_logs("01AA01RA2612004P", compressed=True)

Working with the History
------------------------

To print a short summary for a Diamond history, simply use the print command::

  >>> print dh
  01AA01RA2612004P (40 event types from 2013-03-19 23:04:37+00:00 to 2013-03-21 06:15:54+00:00)

To see what type of data is available in the history, inspect the ``events`` 
attribute::

  >>> dh.events
      ['BufferedTemperature', 'UpdateStateResults', ... ]

Access event data using either dictionary-like notation::

  >>> dh["BufferedTemperature"]

or by direct struct-like notation::

  >>> dh.BufferedTemperature
    <class 'pandas.core.frame.DataFrame'>
  DatetimeIndex: 3807 entries, 2013-03-19 23:04:37+00:00 to 2013-03-21 06:15:54+00:00
  Data columns:
  bucketTime     3807  non-null values
  humidity       3807  non-null values
  temperature    3807  non-null values
  dtypes: float64(2), object(1)

The data for each event is stored as a `Pandas DataFrame`_ (more on this 
later). To get to a particular field in an event type, use dot notation::

  >>> dh.BufferedTemperature.temperature
    t
  2013-03-19 23:04:37+00:00    26.98
  2013-03-19 23:04:37+00:00    26.98
  2013-03-19 23:04:37+00:00    26.97
  2013-03-19 23:04:37+00:00    26.96
  2013-03-19 23:04:37+00:00    26.95
  ...
  2013-03-21 06:15:54+00:00    25.84
  2013-03-21 06:15:54+00:00    25.84
  2013-03-21 06:15:54+00:00    25.85
  2013-03-21 06:15:54+00:00    25.85
  2013-03-21 06:15:54+00:00    25.86
  Name: temperature, Length: 3807

You can slice data using typical MATLAB-like indexing notation::

  >>> dh.BufferedTemperature.temperature[20]
      27.109999999999999
  >>> dh.BufferedTemperature.temperature[20:30]
    t
  2013-03-19 23:04:37+00:00    27.11
  2013-03-19 23:04:37+00:00    27.11
  2013-03-19 23:04:37+00:00    27.13
  2013-03-19 23:04:37+00:00    27.14
  2013-03-19 23:04:37+00:00    27.14
  2013-03-19 23:04:37+00:00    27.14
  2013-03-19 23:04:37+00:00    27.14
  2013-03-19 23:04:37+00:00    27.14
  2013-03-19 23:04:37+00:00    27.14
  2013-03-19 23:04:37+00:00    27.15
  Name: temperature

Selecting Time Ranges
~~~~~~~~~~~~~~~~~~~~~

The chief feature of the Diamond history object is its use of the `Pandas 
DataFrame`_, which allows easy filtering on any set of columns. If you've never 
used Pandas, we recommend you take 10 minutes to look at this overview_.

In the example above, we use direct numerical indexing to extract array values. 
In Pandas, however, you can slice event data directly using date ranges (or, for 
that matter, any desired criteria on one or more columns). 

To limit all event types to a particular time range::

  >>> dh["03/20/2013":"03/21/2013"]
    <nestpy.Diamond for 01AA01RA2612004P (40 event types from 2013-03-20 00:09:37+00:00 to 2013-03-21 06:15:54+00:00)>

To limit a single event type to a particular time range::

  >>> dh.BufferedTemperature['03/20/2013 16:00':'03/20/2013 17:00'].temperature
    t
  2013-03-20 16:15:01+00:00    22.93
  2013-03-20 16:15:01+00:00    22.92
  2013-03-20 16:15:01+00:00    22.91
  2013-03-20 16:15:01+00:00    22.91
  2013-03-20 16:15:01+00:00    22.90
  ...
  2013-03-20 16:52:57+00:00    23.45
  2013-03-20 16:52:57+00:00    23.45
  2013-03-20 16:53:58+00:00    23.45
  2013-03-20 16:53:58+00:00    23.45
  2013-03-20 16:54:03+00:00    23.46
  Name: temperature, Length: 122

This approach is generally recommended over numerical indexing, since it 
improves readability and reduces the risk of user error.
  
.. note::
  
   This syntax for date range indexing requires that the dates be in sorted
   order, which is not guaranteed since device crashes and reboots may cause
   out-of-order entries. To extract all entries in a time range, regardless of
   proper sorting, use MATLAB-like index access:

     >>> from datetime import datetime
     >>> bt = dh.BufferedTemperature
     >>> bt[(bt.index >= datetime(2013,03,25)) & (bt.index < datetime(2013,04,02))]
  
   Do **not** use the ``and`` or ``or`` syntax - it doesn't work for NumPy 
   indexing!

The timestamps within the Device History are set to UTC (GMT+00) time by 
default. To convert all of them to local time (based on the time zone stored in 
CurrentState), use ``to_local_time``::

  >>> dh.to_local_time()
  <nestpy.DeviceHistory for 01AA01RA2612004P (40 event types from 2013-03-19 
  16:04:37-07:00 to 2013-03-20 23:15:54-07:00)>

.. note::

   In addition to the index, the "bucketTime" and "FetchedAt" columns are also
   updated with the local timezone. No other columns are adjusted.

Plotting
--------

To plot events, use the ``plot`` function of the DataFrame::

  >>> dh.BufferedTemperature.plot(subplots=True)
  
To plot just a single column, specify the y attribute::

  >>> dh.BufferedTemperature.plot(x="bucketTime", y="temperature")
  
This function is equivalent to the following Matplotlib command::

  >>> matplotlib.pyplot.plot(dh.BufferedTemperature.bucketTime, 
      dh.BufferedTemperature.temperature)

However, as you may have realized, plot commands are much more succinct with 
the build-in plotting function.

Functions
---------

.. autoclass:: nestpy.Diamond
   :members:
   
.. Hyperlinks
.. _overview: http://pandas.pydata.org/pandas-docs/dev/10min.html
.. _`Pandas DataFrame`: http://pandas.pydata.org/pandas-docs/stable/dsintro.html#dataframe
