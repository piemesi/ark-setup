.. _hobo:

Hobo History Object
====================

This history object is built on top of the `Pandas DataFrame`_. 
It is an extension of the DataFrame to allow Hobo-specific methods
and properties. To get to the Hobo structure, use::

  >>> from nestpy import Hobo

Functions
---------

.. autoclass:: nestpy.Hobo
   :members:

.. _`Pandas DataFrame`: http://pandas.pydata.org/pandas-docs/stable/dsintro.html#dataframe
