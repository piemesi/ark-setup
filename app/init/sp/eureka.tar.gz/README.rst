Nest Labs Eureka Repository
===========================
Algorithms and Data Utilities

Nest Labs Algorithms Team

Welcome to Eureka!
------------------
This package contains utilities for analyzing Nest devices. It provides an
organized, unified, unit-tested, documented set of utilities for quickly
analyzing data and prototyping new features.

To get started, please visit the `Getting Started`_ page.

Documentation
-------------

Documentation for the latest version of Eureka is available at `Eureka Documentation`_.

.. hyperlinks:
.. _Getting Started: http://images.nestlabs.com/images/Eureka/builds/latest/doc/html/getting_started.html
.. _Eureka Documentation: http://images.nestlabs.com/images/Eureka/builds/latest/doc/html/
