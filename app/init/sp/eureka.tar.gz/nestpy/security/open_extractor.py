#!/usr/bin/env python
"""
This module contains functions to extract events from the raw Balsam device history.
"""
from datetime import timedelta, datetime
from dateutil import parser
import logging
from pandas import DataFrame
import pytz

from ..hiddenite import hiddenite_api_client as hac
from ..structures import PinnaProtoTether

logger = logging.getLogger(__name__)
PIR_ACCUMULATION_SECONDS = 5
SECONDS_TO_EXTRACT_BEFORE_OPEN = 30
SECONDS_TO_EXTRACT_AFTER_OPEN = 30
SECONDS_TO_EXTRACT_BEFORE_HIDDENITE_EVENT = 120
SECONDS_TO_EXTRACT_AFTER_HIDDENITE_EVENT = 120


# ----------------------------------------------------------------------------------------------------------------------
# Functions to create open extracts from device history parsed from TVD file
# ----------------------------------------------------------------------------------------------------------------------
def accumulated_pir_before_time(dh, timestamp, seconds_to_accumulate=PIR_ACCUMULATION_SECONDS):
    """
    Find the accumulated absolute value of the PIR N seconds before this time-stamp.
    :param dh: PinnaX device history.
    :param timestamp: Timestamp to integrate before.
    :param seconds_to_accumulate: Seconds to integrate before timestamp.
    :return:
    """
    start = timestamp-timedelta(seconds=seconds_to_accumulate)
    pir = dh.pir.ix[start:timestamp].abs()
    return pir.sum()


def _create_open_extract(dh, open_timestamp):
    """
    Create open extract by extracting data around the open timestamp.
    :param dh: Pinna device history.
    :param open_timestamp: Timestamp of open event.
    :return: Dictionary representing the open extract.
    """
    start = open_timestamp-timedelta(seconds=SECONDS_TO_EXTRACT_BEFORE_OPEN)
    end = open_timestamp+timedelta(seconds=SECONDS_TO_EXTRACT_AFTER_OPEN)
    event_metadata = {}

    # Key Data
    try:
        event_metadata['mac_address'] = dh.DeviceInfo.Value1.ix[0]
        event_metadata['sw_build'] = dh.DeviceInfo.Value2.ix[0]
    except AttributeError:
        event_metadata['mac_address'] = None
        event_metadata['sw_build'] = None

    event_metadata['tvd_timestamp'] = open_timestamp

    # Label Data
    event_metadata['approach_direction'] = None
    event_metadata['approach_angle'] = None
    event_metadata['approach_speed'] = None
    event_metadata['approach_pause'] = None
    event_metadata['existing_occupancy'] = None
    event_metadata['occlusion'] = None

    # Raw Data
    accum_pir = accumulated_pir_before_time(dh, open_timestamp)
    event_metadata['pir_before_array'] = dh.pir[(open_timestamp-timedelta(seconds=SECONDS_TO_EXTRACT_BEFORE_OPEN)):open_timestamp]
    event_metadata['accum_pir'] = accum_pir

    try:
        event_metadata['dh'] = dh[start:end]
    except:
        logger.info("Could not extract Pinna device history for open at {} for device {}.".format(open_timestamp, dh.DeviceInfo.Value1.ix[0]))
        event_metadata['dh'] = None

    return event_metadata


def create_open_extracts_from_tvd(dh):
    """
    Creates open extracts from all of the open events in the TVD log, i.e. as determined by the embedded algorithm on
    the Pinna.
    :param dh: PinnaProtoTether or PinnaTether device history.
    :return: List of open extract dictionaries.
    """
    open_list = []
    open_events = dh.kTVDEventHiddeniteOpen

    for open_time in open_events.index:
        event_metadata = _create_open_extract(dh, open_time)
        open_list.append(event_metadata)

    return open_list


# ----------------------------------------------------------------------------------------------------------------------
# Functions to create labelled open extracts from Hiddenite quizzes
# ----------------------------------------------------------------------------------------------------------------------
def get_open_direction_quizzes(structure_id=None, start_time=None, end_time=None):
    """
    Get the quiz responses for a particular structure and start_time-end_time.  If called with no structure then will
    get responses for ALL structures in Hiddenite.  Similarly if no time put, will get all responses, irrespective of
    time in Hiddenite.
    :param structure_id: Hiddenite structure id, e.g. DEY, HUTA1
    :param start_time: Time in any string format, e.g. "12-30-2014T15:12-08:00"
    :param end_time: Time in any string format, e.g. "12-30-2014T15:12-08:00"
    :return:  DataFrame of quiz results sorted by timestamp.
    """
    # Filter to structure
    if structure_id is not None:
        df = hac.HiddeniteAPIClient.get_quiz_responses(structureID=structure_id, group='unknown_opens')
    else:
        df = hac.HiddeniteAPIClient.get_quiz_responses(group='unknown_opens')

    # Filter only to times of interest
    if start_time is not None and end_time is not None:
        df['open_datetime'] = [pytz.utc.localize(datetime.utcfromtimestamp(x)) for x in df.createdDate]
        start_dt = parser.parse(start_time).astimezone(pytz.UTC)
        end_dt = parser.parse(end_time).astimezone(pytz.UTC)
        opens = df[(df['open_datetime'] > start_dt) & (df['open_datetime'] < end_dt)]
        #Sort by time
        opens = opens.sort(['open_datetime'])
        return opens
    else:
        return None


def _create_labelled_open_extract_from_quiz(quiz, cache_destination):
    """
    Create a single open extract from the Hiddenite quiz.
    :param quiz: Hiddenite quiz. Data from single row in quiz DataFrame/table.
    :param cache_destination: Destination to put parsed pinna logs. Defaults to current directory.
    :param pinna_type: Type of pinna. Defaults to PinnaProtoTether.
    :return: labelled open extract or None.  Will return None if finds no event, or finds too many events.
    """
    device_id = quiz.referenceDeviceID
    quiz_timestamp = quiz.open_datetime
    start_time = quiz_timestamp-timedelta(seconds=SECONDS_TO_EXTRACT_BEFORE_HIDDENITE_EVENT)
    end_time = quiz_timestamp+timedelta(seconds=SECONDS_TO_EXTRACT_BEFORE_HIDDENITE_EVENT)

    dh = PinnaProtoTether.load(device_id, start_time, end_time,
                               downsampling_enabled=False, cache_destination=cache_destination)

    extracted_opens_df = DataFrame(create_open_extracts_from_tvd(dh))

    filtered_opens_df = extracted_opens_df[(extracted_opens_df.tvd_timestamp > quiz_timestamp) &
                                           (extracted_opens_df.tvd_timestamp < quiz_timestamp + timedelta(seconds=30))]

    if len(filtered_opens_df) > 1:
        print "Found too many opens in range for quiz at {} for device {}. Returning None.".format(quiz_timestamp, device_id)
        event = None
    elif len(filtered_opens_df) == 0:
        print "Found no opens found in range for quiz at {} for device {}. Returning None.".format(quiz_timestamp, device_id)
        event = None
    else:
        event = filtered_opens_df.iloc[0].copy() #Take the first (and only) element in this filtered DataFrame
        event['hiddenite_timestamp'] = quiz_timestamp
        event['mac_address'] = device_id
        if quiz.response == 'Outside':
            event['approach_direction'] = 'outside'
        elif quiz.response == 'Inside':
            event['approach_direction'] = 'inside'

    return event


def create_labelled_open_extracts_from_quiz_list(quizzes, cache_destination):
    """
    Creates open extracts from each of the quizzes in the passed array of quizzes.
    :param quizzes: DataFrame of inside/outside quizzes from Hiddenite.
    :return: DataFrame of labelled open extracts.
    """
    labelled_opens = []
    for index, quiz_result in quizzes.iterrows():
        event = _create_labelled_open_extract_from_quiz(quiz_result, cache_destination)
        if event is not None:
            labelled_opens.append(event)

    labelled_df = DataFrame(labelled_opens)
    return labelled_df


def create_labelled_open_extracts_from_quizzes(structure_id=None, start_time=None, end_time=None,
                                               cache_destination='.'):
    """
    Creates open extracts for all the quizzes in a particular structure in a particular time range.
    :param structure_id: Hiddenite structure id, e.g. DEY, HUTA1
    :param start_time: Time in any string format, e.g. "12-30-2014T15:12-08:00"
    :param end_time: Time in any string format, e.g. "12-30-2014T15:12-08:00"
    :return:  DataFrame of open extracts labelled by direction, e.g. inside or outside.
    """
    quiz_opens = get_open_direction_quizzes(structure_id, start_time, end_time)
    labelled_df = create_labelled_open_extracts_from_quiz_list(quiz_opens, cache_destination=cache_destination)
    return labelled_df
