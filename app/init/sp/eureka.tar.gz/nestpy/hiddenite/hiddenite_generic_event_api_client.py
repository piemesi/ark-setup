import logging

from ..converters import datetime_to_epoch_time
from .hiddenite_api_client import HiddeniteAPIClient

logger = logging.getLogger(__name__)


class HiddeniteGenericEventAPIClient(object):

    @classmethod
    def get_generic_events(cls, structureID=None, deviceID=None, userID=None, identifier=None,
                           start_date=None, end_date=None, page_size=None):

        parameters = {}
        if structureID is not None:
            parameters.update({'structureID': structureID})
        if deviceID is not None:
            parameters.update({'deviceID': deviceID})
        if userID is not None:
            parameters.update({'userID': userID})
        if identifier is not None:
            parameters.update({'identifier': identifier})
        if start_date is not None:
            parameters.update({'startTime': float(datetime_to_epoch_time(start_date))})
        if end_date is not None:
            parameters.update({'endTime': float(datetime_to_epoch_time(end_date))})

        all_generic_events = []

        bookmark = None
        while True:

            if bookmark is not None:
                parameters['bookmark'] = bookmark

            if page_size is not None:
                parameters['page_size'] = page_size

            generic_events_api_results = HiddeniteAPIClient.call_api(command='get_generic_events',
                                                         parameters=parameters)

            incremental_generic_events = generic_events_api_results['generic_events']
            logger.info("Loaded incremental generic_events %s", len(incremental_generic_events))
            all_generic_events.extend(incremental_generic_events)

            bookmark = generic_events_api_results['next_bookmark']

            if bookmark is None:
                break

        return all_generic_events

