import logging
import pandas

from ..converters import datetime_to_epoch_time
from .hiddenite_api_client import HiddeniteAPIClient

logger = logging.getLogger(__name__)


class HiddeniteBLEScannerAPIClient(object):

    BLE_SCANNER_DEVICE_TYPE = 6

    @classmethod
    def has_ble_scanner(cls, hiddenite_structure_id):
        device_mappings = HiddeniteAPIClient.get_device_metadata(structureID=hiddenite_structure_id)
        return len(device_mappings) != 0 and \
               len(device_mappings[device_mappings.deviceType == cls.BLE_SCANNER_DEVICE_TYPE]) != 0

    @classmethod
    def get_ble_scan_results(cls, structureID, start_date, end_date, page_size=None):

        ble_scan_results_ = cls._load_paginated_ble_scan_results(structureID, start_date, end_date, page_size)

        df = pandas.DataFrame(ble_scan_results_)

        logger.debug("Increment from %s to %s, number of scan results %s", start_date, end_date, len(df))

        if len(df) > 0:
            df.set_index('scanTime', inplace=True)
            df.index = pandas.to_datetime(df.index, unit='s', utc=True)

        return df

    @staticmethod
    def _load_paginated_ble_scan_results(structureID, start_date, end_date, page_size=None):

        parameters = {'structureID': structureID}

        if start_date is not None:
            parameters.update({'startTime': float(datetime_to_epoch_time(start_date))})
        if end_date is not None:
            parameters.update({'endTime': float(datetime_to_epoch_time(end_date))})

        logger.info('Loading BLE scan results from the Hiddenite API for structure %s, start date %s, end date %s',
                    structureID, start_date, end_date)

        all_ble_scans = []

        bookmark = None
        while True:

            if bookmark is not None:
                parameters['bookmark'] = bookmark

            if page_size is not None:
                parameters['page_size'] = page_size

            ble_scan_results = HiddeniteAPIClient.call_api(command='paginated_ble_scan_results',
                                                           parameters=parameters)

            ble_scans = ble_scan_results['ble_scans']
            logger.info("Loaded incremental ble scans %s", len(ble_scans))
            all_ble_scans = all_ble_scans + ble_scans

            bookmark = ble_scan_results['next_bookmark']

            if bookmark is None:
                break

        return all_ble_scans

