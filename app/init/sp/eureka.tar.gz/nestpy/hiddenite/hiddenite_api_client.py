# pylint: disable=no-member
import calendar
import logging

import pandas
from datetime import datetime, date
from pandas.io.json import json_normalize
import requests

logger = logging.getLogger(__name__)


class HiddeniteAPIClient(object):

    API_ENDPOINT = "http://h19app.appspot.com/api/"
    BLE_SCANNER_DEVICE_TYPE = 6

    class ClipSubmissionState:
        RequestPending = 0
        Requested = 1
        Approved = 2

    @classmethod
    def call_api(cls, command, parameters, headers=None):
        if headers is None:
            headers = {}
        headers.update({'x-h19-auth': 'PKYv4BekH6FzQjdKi8eZkMM2'})
        request = requests.get('{0}{1}'.format(cls.API_ENDPOINT, command), params=parameters, headers=headers)
        request.raise_for_status()
        return request.json()

    @classmethod
    def get_structure_pairing(cls):
        if getattr(cls, '_STRUCTURE_PAIRING', None) is None:
            mappings = cls.call_api(command='get_device_table', parameters={})
            cls._STRUCTURE_PAIRING = mappings
        return cls._STRUCTURE_PAIRING

    @classmethod
    def get_mobile_structure_pairing(cls):
        structure_pairing = cls.get_structure_pairing()
        mobile_structure_pairing = json_normalize(structure_pairing, ['users', 'devices'], ['name', ['users', 'name']])
        mobile_structure_pairing = mobile_structure_pairing.rename(
            columns={
                0: "device_id",
                "users.name": "user",
                "name": "structure"
            })
        mobile_structure_pairing = mobile_structure_pairing.drop_duplicates(['structure', 'user', 'device_id'])
        logger.debug("Hiddenite mobile structure pairing: %s", mobile_structure_pairing)
        return mobile_structure_pairing[mobile_structure_pairing.structure != "null"]

    @classmethod
    def get_quiz_responses(cls, structureID=None, userID=None, group=None,
                           createdAfterTime=None):
        parameters = {}
        if structureID is not None:
            parameters.update({'structureID': structureID})
        if userID is not None:
            parameters.update({'userID': userID})
        if group is not None:
            parameters.update({'group': group})
        if createdAfterTime is not None:
            # type is either datetime, date (in UTC), or integer
            if type(createdAfterTime) in [datetime, date]:
                createdAfterTime = (createdAfterTime -
                                    datetime(1970, 1, 1)).total_seconds()
            parameters.update({'createdAfterTime': int(createdAfterTime)})
        return pandas.DataFrame(cls.call_api(command='get_quiz_responses',
                                             parameters=parameters))

    @classmethod
    def get_device_metadata(cls,
                            structureID=None,
                            deviceID=None,
                            forceFresh=False, # DEPRECATED
                            deviceType=None,
                            serviceTier=None):

        parameters = {}
        if structureID is not None:
            parameters['structureID'] = structureID
        if deviceID is not None:
            parameters['deviceID'] = deviceID
        if deviceType is not None:
            parameters['deviceType'] = deviceType
        if serviceTier is not None:
            parameters['serviceTier'] = serviceTier
        return pandas.DataFrame(cls.call_api(command='get_device',
                                             parameters=parameters))

    @classmethod
    def get_nest_device_to_structure_pairing(cls):
        structure_pairing = cls.get_structure_pairing()
        associated_devices = json_normalize(structure_pairing, ['associated_devices'], 'name')
        associated_devices = associated_devices.rename(columns={0: "device_id", "name": "structure"})
        logger.debug("Hiddenite associated devices: %s", associated_devices)
        return associated_devices

    @classmethod
    def register_device(cls, structureID, deviceID, deviceType, whereID, whatID, swVersion):
        return cls.call_api(command='register_device',
                            parameters={
                                'structureID': structureID,
                                'deviceID': deviceID,
                                'deviceType': deviceType,
                                'whereID': whereID,
                                'whatID': whatID,
                                'swVersion': swVersion
                            })

    @classmethod
    def generate_pending_clip_request(cls, cameraUUID, start, duration, note, clipType='Eureka'):
        return cls.call_api(command='generate_pending_clip_request',
                            parameters={
                                'cameraUUID': cameraUUID,
                                'start': calendar.timegm(start.utctimetuple()),
                                'duration': duration,
                                'note': note,
                                'clipType': clipType
                            })

    @classmethod
    def generate_pending_clip_request_for_structure(cls, structureID, start, duration, note, clipType='Eureka'):
        return cls.call_api(command='generate_pending_clip_request_for_structure',
                            parameters={
                                'structureID': structureID,
                                'start': calendar.timegm(start.utctimetuple()),
                                'duration': duration,
                                'note': note,
                                'clipType': clipType
                            })

    @classmethod
    def advance_clip_to_requested(cls, cameraUUID, requestID):
        return cls.call_api(command='advance_clip_to_requested',
                            parameters={
                                'cameraUUID': cameraUUID,
                                'requestID': requestID
                            })

    @classmethod
    def advance_clip_to_approved(cls, cameraUUID, requestID, clipUrl):
        return cls.call_api(command='advance_clip_to_approved',
                            parameters={
                                'cameraUUID': cameraUUID,
                                'requestID': requestID,
                                'clipUrl': clipUrl
                            })

    @classmethod
    def clip_request_failed(cls, cameraUUID, requestID):
        return cls.call_api(command='clip_request_failed',
                            parameters={
                                'cameraUUID': cameraUUID,
                                'requestID': requestID
                            })

    @classmethod
    def get_clip_requests(cls, cameraUUID=None, requestID=None, submissionState=None, note=None, clipType=None):
        parameters = {
            'cameraUUID': cameraUUID,
            'requestID': requestID,
            'submissionState': submissionState,
            'note': note,
            'clipType': clipType
        }

        # Drop unspecified parameters
        parameters = {k: v for k, v in parameters.iteritems() if v is not None}

        return cls.call_api(command='get_clip_requests',
                            parameters=parameters)

