import pandas as pd

from ..validation.type_validation import assert_is_type


def drop_consecutive_duplicates(frame, keep_last=False):
    """Drop consecutive duplicates in pandas DataFrame object

    :param frame:
        Pandas DataFrame object
    :type frame:
        pandas.DataFrame

    :param keep_last:
        Whether or not to keep the last row
    :type keep_last:
        bool

    :returns:
        Pandas DataFrame object without consecutive duplicates
    :rtype:
        pandas.DataFrame
    """
    assert_is_type(frame, pd.DataFrame)
    assert_is_type(keep_last, bool)
    frame_without_consecutive_duplicates = frame.loc[~(frame.shift(1) == frame).all(axis=1)]
    if keep_last and frame.index[-1] not in frame_without_consecutive_duplicates.index:
        frame_without_consecutive_duplicates = frame_without_consecutive_duplicates.append(frame[-1:])
    return frame_without_consecutive_duplicates


def filter_valid_range(frame, subset=None):
    """Filters out null values in data frame at start and end

    :param frame:
        Pandas data frame object
    :type frame:
        pandas.DataFrame

    :param subset:
        Subset of columns to consider
    :type subset:
        list

    :returns:
        Pandas data frame object without null values at start and end
    :rtype:
        pandas.DataFrame
    """
    assert_is_type(frame, pd.DataFrame)
    if subset is None:
        subset = frame.columns.tolist()
    return frame[
        (frame.index >= frame[subset].isnull().all(axis=1).argmin()) &
        (frame.index <= frame[subset][::-1].isnull().all(axis=1).argmin())
    ]


def set_unique_index(frame):
    """Set unique index for given pandas DataFrame object

    :param frame:
        Pandas data frame object
    :type frame:
        pandas.DataFrame

    :returns:
        Pandas data frame object with a unique index
    :rtype:
        pandas.DataFrame
    """
    assert_is_type(frame, pd.DataFrame)
    return frame.groupby(frame.index).last()
