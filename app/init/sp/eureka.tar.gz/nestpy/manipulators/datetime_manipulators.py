import datetime
import math

from ..validation.type_validation import assert_is_type


def _round_datetime(_datetime, timedelta, round_func):
    def localize_datetime(__datetime):
        if _datetime.tzinfo is not None:
            __datetime = _datetime.tzinfo.localize(__datetime)
        return __datetime
    beginning_of_datetime = localize_datetime(datetime.datetime.utcfromtimestamp(0))
    epoch_time = (_datetime - beginning_of_datetime).total_seconds()
    rounded_epoch_time = round_func(epoch_time / timedelta.total_seconds()) * timedelta.total_seconds()
    rounded_datetime = _datetime + datetime.timedelta(seconds=(rounded_epoch_time - epoch_time))
    return rounded_datetime


def floor_datetime(_datetime, floor_timedelta):
    """Compute floor of datetime object using specified timedelta

    :param _datetime:
        Datetime object to compute the floor for
    :type _datetime:
        datetime.datetime

    :param floor_timedelta:
        Timedelta used for taking the floor
    :type floor_timedelta:
        datetime.timedelta

    :returns:
        Floor of specified datetime object
    :rtype:
        datetime.datetime
    """
    assert_is_type(_datetime, datetime.datetime)
    assert_is_type(floor_timedelta, datetime.timedelta)
    floored_datetime = _round_datetime(_datetime, floor_timedelta, math.floor)
    return floored_datetime


def ceil_datetime(_datetime, ceil_timedelta):
    """Compute ceil of datetime object using specified timedelta

    :param _datetime:
        Datetime object to compute the ceil for
    :type _datetime:
        datetime.datetime

    :param ceil_timedelta:
        Timedelta used for taking the ceil
    :type ceil_timedelta:
        datetime.timedelta

    :returns:
        Ceil of specified datetime object
    :rtype:
        datetime.datetime
    """
    assert_is_type(_datetime, datetime.datetime)
    assert_is_type(ceil_timedelta, datetime.timedelta)
    ceiled_datetime = _round_datetime(_datetime, ceil_timedelta, math.ceil)
    return ceiled_datetime
