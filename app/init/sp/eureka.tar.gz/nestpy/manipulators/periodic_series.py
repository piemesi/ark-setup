import numpy as np
import pandas as pd

from ..validation.type_validation import assert_is_type, assert_index_dtype_in


class PeriodicSeries(object):
    """
    Allows a pandas Series object to behave as if it was periodical around the end/beginning of the series.

    Instanciated with a pandas series object and a period. Both the index of the series as the period need to be
    floats or integers. The series and index essentially wrap around the period. The index needs to be unique (even when
    'wrapped around' the period).

    The methods get_series and get_period return the pandas series object and the period respectively.

    Example:

    >>> import pandas as pd
    >>> ps = PeriodicSeries(pd.Series(data=[3, 4, 2, 1, 6], index=range(23, 28)), 5)
    >>> ps
    23    3
    24    4
    25    2
    26    1
    27    6
    dtype: int64
    period: 5

    The period may also be different than the number of items in a series. In the following case the next index with
    value '3' would be 23+8=31. Everything inbetween indices 27 and 31 is not defined.

    >>> ps2 = PeriodicSeries(pd.Series(data=[3, 4, 2, 1, 6], index=range(23, 28)), 8)
    23    3
    24    4
    25    2
    26    1
    27    6
    dtype: int64
    period: 8
    """

    def __init__(self, series, period):
        self._assert_valid_series(
            series,
            period
        )
        self._period = period
        self._series = series
        return

    def __repr__(self):
        return self._series.__str__() + "\nperiod: {}".format(self.get_period())

    def _key(self):
        return frozenset(self._series.iteritems()), self._period

    def __hash__(self):
        return hash(self._key())

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self._key() == other._key()

    def __ne__(self, other):
        return not self.__eq__(other)

    @staticmethod
    def _assert_valid_series(series, period):
        assert_is_type(series, pd.Series)
        assert_index_dtype_in(series.index, [float, int])
        assert len(set((series.index.values - series.index[0]) % period)) == len(series.index), "Index is not unique."
        return

    @staticmethod
    def _rebase(series, period, new_start_index):
        series_modular_sorted = pd.Series(
            data=series.values,
            index=series.index.values % period
        ).sort_index()
        index_as_series = pd.Series(series_modular_sorted.index)
        new_start_index_modular = new_start_index % period

        index_as_series_from_new_index = (
            index_as_series[(new_start_index_modular - index_as_series) <= 0] % period
        ).sort(inplace=False)
        if index_as_series_from_new_index.any():
            new_first_index = index_as_series_from_new_index.index[0]
            rebased_series = pd.Series(
                data=np.append(
                    series_modular_sorted.iloc[new_first_index:],
                    series_modular_sorted.iloc[:new_first_index]
                ),
                index=np.append(
                    index_as_series[new_first_index:].values,
                    index_as_series[:new_first_index].values + period
                ) - new_start_index_modular + new_start_index
            )
        else:
            rebased_series = pd.Series(
                data=series_modular_sorted.values,
                index=index_as_series - new_start_index_modular + new_start_index + period
            )
        return rebased_series

    def get_rebased_periodic_series(self, new_start_index=0):
        """
        As the series is periodical, it can be rebased at any index. If an index is not specified by
        a periodic series, the function will rebase at the next specified index.

        :param new_start_index:
            integer or float indicating start of periodic series (can also be negative), defaults to 0
        :type new_start_index:
            int, float

        :returns:
            PeriodicSeries object with same period, but starting at new_start_index
        :rtype:
            PeriodicSeries

        Example:

        >>> import pandas as pd
        >>> ps = PeriodicSeries(pd.Series(data=[3, 4, 2, 1, 6], index=range(23, 28)), 5)
        >>> ps
        23    3
        24    4
        25    2
        26    1
        27    6
        dtype: int64
        period: 5

        >>> ps.get_rebased_periodic_series(45)
        45    2
        46    1
        47    6
        48    3
        49    4
        dtype: int64
        period: 5

        >>> ps.get_rebased_periodic_series(-3.1)
        -3    6
        -2    3
        -1    4
         0    2
         1    1
        dtype: int64
        period: 5
        """
        return self.__class__(self._rebase(self._series, self._period, new_start_index), self._period)

    def roll(self, n):
        """
        Rolls the series up or down n positions.

        :param n:
            number of positions over which the series is rolled. Can be positive or negative.

        :returns:
            PeriodicSeries object with equal period, where the start index is n positions from the original
        :rtype:
            PeriodicSeries

        Example:

        >>> import pandas as pd
        >>> ps = PeriodicSeries(pd.Series(data=[3, 4, 2, 1, 6], index=range(23, 28)), 5)
        >>> ps
        23    3
        24    4
        25    2
        26    1
        27    6
        dtype: int64
        period: 5

        >>> ps.roll(2)
        25    2
        26    1
        27    6
        28    3
        29    4
        dtype: int64
        period: 5

        >>> ps.roll(-4)
        19    4
        20    2
        21    1
        22    6
        23    3
        dtype: int64
        period: 5
        """
        assert_is_type(
            n,
            int
        )
        index_shift = self.get_series().index.values + (n / len(self.get_series())) * self.get_period()
        return self.get_rebased_periodic_series(index_shift[n % len(self.get_series())])

    def apply_periodic_function(self, function, *args, **kwargs):
        """
        Applies a function to the periodic series.

        :param function:
            any function that takes a pandas.Series as a first argument
        :type function:
            function

        :param args:
            arguments to be passed to the function

        :param kwargs:
            keyworded arguments to be passed to the function

        :returns:
            Result of function as a PeriodicSeries object with equal period
        :rtype:
            PeriodicSeries

        Example:

        >>> import pandas as pd
        >>> ps = PeriodicSeries(pd.Series(data=[3, 4, 2, 1, 6], index=range(23, 28)), 5)
        >>> ps
        23    3
        24    4
        25    2
        26    1
        27    6
        dtype: int64
        period: 5

        >>> ps.apply_periodic_function(pd.Series.diff)
        23   -3
        24    1
        25   -2
        26   -1
        27    5
        dtype: int64
        period: 5

        >>> ps.apply_periodic_function(pd.rolling_median, 3, center=True)
        23    4
        24    3
        25    2
        26    2
        27    3
        dtype: int64
        period: 5
        """
        circular_series = pd.concat(
            [
                self._rebase(
                    self._series,
                    self._period,
                    -self._period + self._series.index[0]
                ),
                self._series,
                self._rebase(
                    self._series,
                    self._period,
                    self._period + self._series.index[0]
                )
            ],
            axis=0)
        return self.__class__(
            function(
                circular_series,
                *args,
                **kwargs
            ).loc[self._series.index].astype(self._series.dtype.type),
            self._period)

    def get_period(self):
        return self._period

    def get_series(self):
        return self._series
