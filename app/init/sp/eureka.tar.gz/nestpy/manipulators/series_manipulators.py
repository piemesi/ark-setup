import datetime
import numpy as np
import pandas as pd

from ..validation.type_validation import assert_is_type, assert_series_is_dtype


def _hold_resample(series, sample_time, **kwargs):
    if not series.empty:
        resampled_series = series.resample(rule='{}S'.format(int(sample_time.total_seconds())), **kwargs)
        hold_resampled_series = resampled_series.rename(lambda index: index + sample_time).astype(series.dtype)
    else:
        hold_resampled_series = series
    return hold_resampled_series


def any_hold_resample(series, sample_time):
    """Any hold resample a pandas Series object

    :param series:
        Pandas series object
    :type series:
        pandas.Series

    :param sample_time:
        Sample time
    :type sample_time:
        datetime.timedelta

    :returns:
        Any hold resampled pandas Series object
    :rtype:
        pandas.Series
    """
    assert_is_type(series, pd.Series)
    assert_is_type(sample_time, datetime.timedelta)
    any_hold_resampled_series = _hold_resample(
        series=series,
        sample_time=sample_time,
        how=np.any,
        closed='right'
    )
    return any_hold_resampled_series


def zero_order_hold_resample(series, sample_time):
    """Zero order hold resample a pandas Series object

    :param series:
        Pandas series object
    :type series:
        pandas.Series

    :param sample_time:
        Sample time
    :type sample_time:
        datetime.timedelta

    :returns:
        Zero order hold resampled pandas Series object
    :rtype:
        pandas.Series
    """
    assert_is_type(series, pd.Series)
    assert_is_type(sample_time, datetime.timedelta)
    zero_order_hold_resampled_series = _hold_resample(
        series=series,
        sample_time=sample_time,
        how='last',
        closed='right',
        fill_method='pad'
    )
    return zero_order_hold_resampled_series


def drop_consecutive_duplicates(series, keep_last=False):
    """Drop consecutive duplicates in pandas Series object

    :param series:
        Pandas series object
    :type series:
        pandas.Series

    :param keep_last:
        Whether or not to keep the last value
    :type keep_last:
        bool

    :returns:
        Pandas series object without consecutive duplicates
    :rtype:
        pandas.Series
    """
    assert_is_type(series, pd.Series)
    assert_is_type(keep_last, bool)
    if series.empty:
        series_without_consecutive_duplicates = series
    else:
        series_without_consecutive_duplicates = series.loc[
            (series.shift(1) != series) & ~(series.isnull().shift(1) & (series.isnull().shift(1) == series.isnull()))
        ]
        if keep_last and series.index[-1] not in series_without_consecutive_duplicates.index:
            series_without_consecutive_duplicates = series_without_consecutive_duplicates.append(series[-1:])
    return series_without_consecutive_duplicates


def compute_thresholded_series(series, threshold):
    """Compute thresholded series, from a numerical pandas Series object

    :param series:
        Pandas series object
    :type series:
        pandas.Series

    :param threshold:
        Threshold
    :type threshold:
        numeric

    :returns:
        Thresholded pandas series object
    :rtype:
        pandas.Series
    """
    assert_is_type(series, pd.Series)
    if series.empty:
        thresholded_series = pd.Series(dtype=bool)
    else:
        thresholded_series = series.apply(lambda x: x > threshold if not np.isnan(x) else np.nan)
    return thresholded_series


def compute_timedelta_series(datetime_index, offset=1):
    """Compute timedelta series, from a pandas DatetimeIndex object

    :param datetime_index:
        Pandas DatetimeIndex object
    :type datetime_index:
        pandas.DatetimeIndex

    :param offset:
        Number of rows to look forward
    :type offset:
        int

    :returns:
        Pandas series object that has timedelta values based on the indices
    :rtype:
        pandas.Series
    """
    if len(datetime_index) > 0:
        assert_is_type(datetime_index, pd.DatetimeIndex)
        datetime_series = pd.Series(index=datetime_index, data=datetime_index)
        timedelta_series = (datetime_series.shift(-offset) - datetime_series).fillna(datetime.timedelta(0))
    else:
        timedelta_series = pd.Series(index=datetime_index)
    return timedelta_series


def filter_valid_range(series):
    """Filters out null values in series at start and end

    :param series:
        Pandas series object
    :type series:
        pandas.Series

    :returns:
        Pandas series object without null values at start and end
    :rtype:
        pandas.Series
    """
    assert_is_type(series, pd.Series)
    return series[(series.index >= series.isnull().argmin()) & (series.index <= series[::-1].isnull().argmin())]


def set_unique_index(series):
    """Set unique index for given pandas Series object

    :param series:
        Pandas series object
    :type series:
        pandas.Series

    :returns:
        Pandas series object with a unique index
    :rtype:
        pandas.Series
    """
    assert_is_type(series, pd.Series)
    return series.groupby(series.index).last()


def compute_falsified_series(series):
    """Compute falsified series, from a boolean pandas Series object with only 'True' values

    :param series:
        Pandas series object
    :type series:
        pandas.Series

    :returns:
        Pandas series object with an additional 'False' value right after each index
    :rtype:
        pandas.Series
    """
    if not series.empty:
        assert_series_is_dtype(series, 'bool')
        if len(series[series]) != len(series):
            raise ValueError("Passed series may only contain 'True' values.")
        delay = datetime.timedelta(microseconds=1)
        false_series = pd.Series(index=series.index + delay, data=False)
        falsified_series = pd.concat([series, false_series], axis=0).sort_index()
        return falsified_series
    else:
        return series
