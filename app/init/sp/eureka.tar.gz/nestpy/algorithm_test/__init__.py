from .Topaz.smoke_algorithm_1_1 import SmokeAlgorithm
from . import Topaz
