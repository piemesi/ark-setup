"""
The official specification for the Dolomite 1.1 Smoke algorithm can be found at
https://wiki.nestlabs.com/display/NEST/Dolomite+1.1+Smoke+Algorithm

This file represents an implementation of the above specification, and is
provided for testing the on-device implementation.

There are 2 state machines for Dolomite 1.1, the KL16 and the K60. The interaction
between the state machine occurs via a defined communication set. The restrictions in
communication are adhered to as much as possible in this implementation.

DRI:
Design: Kevin Peterson
Implementation: Harpreet Sangha
QA: Gopal Iyer
"""
# pylint: disable=no-member,attribute-defined-outside-init

import pandas as pd
import numpy as np

MINIMUM_TIME_RESOLUTION = 0.001  # s

SAMPLE_RATE_HIGH = 2000  # ms
SAMPLE_RATE_LOW = 10000  # ms

# KL State Machine:
IDLE_MONITOR_SAMPLES = 1
MONITOR_ALARM_SAMPLES = 5
ALARM_MONITOR_SAMPLES = 4
MONITOR_IDLE_SAMPLES = 2

UNHUSHABLE_FILTER_N = 3
UNHUSHABLE_FILTER_D = 128
UNHUSHABLE_INPUT_MAX = 200  # mdBm
UNHUSHABLE_OUTPUT_MAX = 115 * UNHUSHABLE_FILTER_D

# Thresholds:
SMOKE_T_BASE = 50  # mdBm
SMOKE_T_LOW = 60  # mdBm
SMOKE_T_MID = 80  # mdBm
SMOKE_T_HIGH = 110  # mdBm
UNHUSHABLE_THRESHOLD = SMOKE_T_HIGH * UNHUSHABLE_FILTER_D
UNHUSHABLE_1_0_MODE = False

# K60 State Machine:
MONITOR_PREALARM_SAMPLES = 2
PREALARM_MONITOR_SAMPLES = 2

MINIMUM_HUSH_TIME = 5.5 * 60 * 1000 # ms
MAXIMUM_HUSH_TIME = 9.5 * 60 * 1000 # ms
HOLDING_TIME = 2 * 60 *1000  # ms

# Steam Rejection Thresholds:
STEAM_REJECTION_ACTIVE = True
STEAM_REJECTION_FORCED_ON = False
ACCELERATED_HUMIDITY_GAIN = 3
ACCELERATED_HUMIDITY_FILTER_N = 1
ACCELERATED_HUMIDITY_FILTER_D = 128
ACCELERATED_HUMIDITY_THRESHOLD = 1000 * ACCELERATED_HUMIDITY_FILTER_D
HUMIDITY_THRESHOLD = 850  # %RH*10
STEAM_REJECTION_HOLDOFF = 20 * 1000  # ms
STEAM_REJECTION_CO_THRESHOLD = 10  # ppm
STEAM_REJECTION_HOLDOFF_HOLDOFF_TIME = 4 * 60 * 1000  # ms

# Smoke based steam detection
SMOKE_STEAM_SIGNAL_DISABLE = False
SMOKE_STEAM_SIGNAL_THRESHOLD = -30  # mdBm

# Multicriteria:
CO_THRESHOLD = 10  # ppm

def c_style_integer_division(a, b):
    return -(-a // b) if a < 0 else a // b


# Convert data from the format in Eureka to the device format.
def eureka_to_device(df):
    # Multiply smoke values by 1000 to convert from dBm to mdBm
    df.Smoke = (df.Smoke * 1000).astype(int)
    # Multiply Humidity by 10 to convert it to Dolo format:
    df.Humidity = (df.Humidity * 10).astype(int)
    return df


# Convert data from the device format to the Eureka format.
def device_to_eureka(df):
    # Divide smoke values by 1000 to convert from mdBm to dBm
    df.Smoke = (df.Smoke / 1000.)
    # Divide Humidity by 10 to convert it to eureka format:
    df.Humidity = (df.Humidity / 10.)
    return df


class SmokeAlgorithm(object):

    ALGORITHM_SENSORS = ['Smoke', 'Humidity', 'Carbonmonoxide', 'Heat']
    ALGORITHM_FILTERS = ['unhushable_filter', 'accelerated_humidity_filter', 'accelerated_humidity_output', 'derivative', 'derivative_consecutive_samples']

    def __init__(self, **sensors):

        # Initialize Variables:
        # Sensors passed should be in the device scale (mdBm), not Eureka scale (dBm)

        # Accessible by both KL and K60
        self.time = 0
        self.next_sample = 10000
        self.KL_state = 'nlAll_Clear'
        self.hush = False
        self.sensors = {}
        for key in SmokeAlgorithm.ALGORITHM_SENSORS:
            if key in sensors:
                self.sensors[key] = sensors[key]
            else:
                self.sensors[key] = 0

        self.smoke_t_cur = SMOKE_T_MID
        # This is the request from the K60 to the KL to hold off shower steam
        self.shower_steam_alarm_request = False

        # Accessible by only KL
        self.KL_variables = {'consecutive_mid_samples': 0,  # Number of consecutive samples above alarm threshold.
                             'consecutive_low_samples': 0,
                             'consecutive_base_samples': 0,
                             'monitor_start_time': 0,  # Time monitor mode was entered.
                             'unhushable_filter': 0,
                             'smoke_prev': 0,
                             'hush_time': 0,
                             'shower_steam_alarm': False,
                             'steam_holdoff_holdoff_time': -STEAM_REJECTION_HOLDOFF_HOLDOFF_TIME,
                             'steam_holdoff_holdoff': False
        }

        # Accessible by only K60
        self.K60_variables = {'accelerated_humidity_filter': None,
                              'accelerated_humidity_output': 0,
                              'K60_state': 'nlStandby_State_Smoke',
                              'hush_time': 0,
                              'consecutive_high_samples': 0,
                              'consecutive_low_samples': 0,
                              'derivative': 0,
                              'derivative_consecutive_samples': 0,
                              'co_criteria': False,
                              'humidity_criteria': False,
                              'smoke_criteria': False,
                              'shower_steam_prealarm': False,
        }

        # Initialize data structures:
        self.sensor_data = {}
        self.set_up_logging()

        # Data structure to store input file if run from a CSV
        self.input = None

    @classmethod
    def run_csv(cls, df, break_when=None):
        # Given a csv compiled from data history, run the state machine through all samples and return a
        # Eureka compatible data structure. This file handles converting between the device scaling
        # and the data history scaling.

        # Create a list of time steps:
        df_copy = df.copy()
        df_copy = eureka_to_device(df_copy)

        sa = cls(Humidity=df_copy['Humidity'].values[0])
        sa.input = df

        timesteps = np.diff(df_copy.index.values)
        df_copy = df_copy.iloc[1:]

        for ts, (index, row) in zip(timesteps, df_copy.iterrows()):

            sa.advance_time(ts - MINIMUM_TIME_RESOLUTION)
            sa.set_sensors(**row)
            if 'Hush' in row and row['Hush'] == 1:
                sa.send_hush_signal()
            sa.advance_time(MINIMUM_TIME_RESOLUTION)

            if break_when is not None and sa.get_K60_state() == break_when:
                return sa

        return sa

    def write_csv(self, filename):
        output = {}
        comment_present = None

        # Log filter data from device:
        for key in self.filter_data:
            output[key] = self.filter_data[key]

        # Log device states:
        output['K60_State'] = self.states
        output['KL_State'] = self.KL_states

        # Convert to dataframe, and convert index to seconds from milliseconds
        df = pd.DataFrame(output)
        df.index = df.index/1000.

        output = {}
        # Log input data if present:
        if self.input is not None:
            for column in self.input:
                if 'omment' not in column:
                    output[column] = self.input[column]
                else:
                    comment_present = column

        # Join state machine data with input data
        df = df.join(pd.DataFrame(output))

        # Add sampled sensor data to the dataframe:
        df_sensor = pd.DataFrame(self.sensor_data).T
        df_sensor.index = df_sensor.index / 1000.
        df = df.fillna(method='pad').join(df_sensor, rsuffix='_sampled')

        # Append any comments from input file:
        if comment_present is not None:
            df = df.join(pd.DataFrame(self.input[comment_present]))

        df.to_csv(filename, index_label='Seconds')

    def advance_time(self, seconds):
        # Run the algorithm forward by the number of seconds passed.
        end_time = self.time + seconds*1000
        while self.time < end_time:
            if end_time < self.next_sample:
                self.time = end_time
            else:
                self.time = self.next_sample
            self.state_machine()
            self.log_data()

    def set_sensors(self, **kwargs):
        # Update sensor values
        for key in kwargs:
            if key in SmokeAlgorithm.ALGORITHM_SENSORS:
                self.sensors[key] = kwargs[key]

    def send_hush_signal(self):
        self.hush = True

    def set_filters(self, **kwargs):
        # Set filter values
        for key in kwargs:
            if key in self.K60_variables:
                self.K60_variables[key] = kwargs[key]
            elif key in self.KL_variables:
                self.KL_variables[key] = kwargs[key]
            else:
                print 'ERROR!'

    def get_K60_state(self):
        return self.K60_variables['K60_state']

    def get_KL_state(self):
        return self.KL_state

    def state_machine(self):

        # Initialize the Humidity filter with the first value it receives
        if self.K60_variables['accelerated_humidity_filter'] is None:
            self.K60_variables['accelerated_humidity_filter'] = self.sensors['Humidity']*ACCELERATED_HUMIDITY_FILTER_D

        # The state machine keeps track of the sampling rate,
        # and knows what time the next sample should occur
        if self.time < self.next_sample:
            return

        # Set hush flag here. This may or may not cause a hush, depending on the state machine.
        hush_event = self.hush
        self.hush = False

        # Keep track of which sensors the algorithm actually samples
        self.sensor_data[self.time] = dict(self.sensors)

        smoke_n0 = self.sensors['Smoke']

        # KL16 ####################################################################################

        # KL16 Computation:
        self._unhushable_filter()

        # KL16 STATE MACHINE

        # Compute consecutive samples for switching states:
        if smoke_n0 >= SMOKE_T_LOW:
            self.KL_variables['consecutive_low_samples'] += 1
        else:
            self.KL_variables['consecutive_low_samples'] = 0

        if smoke_n0 >= SMOKE_T_MID:
            self.KL_variables['consecutive_mid_samples'] += 1
        else:
            self.KL_variables['consecutive_mid_samples'] = 0

        if smoke_n0 < SMOKE_T_BASE:
            self.KL_variables['consecutive_base_samples'] += 1
        else:
            self.KL_variables['consecutive_base_samples'] = 0

        if self.shower_steam_alarm_request:
            # The KL keeps track of the hold-off hold-off to decide whether to acknowledge the request.
            if not self.KL_variables['steam_holdoff_holdoff']:
                self.KL_variables['shower_steam_alarm'] = True
                self.KL_variables['steam_holdoff_holdoff_time'] = self.time
                self.KL_variables['steam_holdoff_holdoff'] = True
        else:
            self.KL_variables['shower_steam_alarm'] = False

        # Clear the holdoff at the appropriate time
        if self.time - self.KL_variables['steam_holdoff_holdoff_time'] >= STEAM_REJECTION_HOLDOFF_HOLDOFF_TIME:
            self.KL_variables['steam_holdoff_holdoff'] = False

        if self.KL_state == 'nlAll_Clear':

            self.KL_variables['shower_steam_alarm'] = False

            # Transition KL16_1, K60_8
            if self.KL_variables['consecutive_low_samples'] >= IDLE_MONITOR_SAMPLES:
                self.KL_state = 'nlMonitor'
                self._clear_kl_counters()
                self.KL_variables['monitor_start_time'] = self.time

        elif self.KL_state == 'nlMonitor':

            # Transition KL16_2, K60_1
            # Compute the alarm determination based on the threshold:
            if self.smoke_t_cur == SMOKE_T_LOW:
                alarm_signal = self.KL_variables['consecutive_low_samples'] >= MONITOR_ALARM_SAMPLES
            elif self.smoke_t_cur == SMOKE_T_MID:
                alarm_signal = self.KL_variables['consecutive_mid_samples'] >= MONITOR_ALARM_SAMPLES
            elif self.smoke_t_cur == SMOKE_T_HIGH:
                alarm_signal = self._is_unhushable()
            else:
                raise ValueError

            if (alarm_signal and
                    (not self.KL_variables['shower_steam_alarm'] or
                     self.time - self.KL_variables['monitor_start_time'] > STEAM_REJECTION_HOLDOFF)):
                self.KL_state = 'nlAlarm'
                self._clear_kl_counters()

            # Transition KL16_7
            if self.KL_variables['consecutive_base_samples'] >= MONITOR_IDLE_SAMPLES:
                self.KL_state = 'nlAll_Clear'
                self._clear_kl_counters()

        elif self.KL_state == 'nlAlarm':

            # Transition KL16_3
            if hush_event and self.KL_variables['unhushable_filter'] < UNHUSHABLE_THRESHOLD:
                self.KL_variables['hush_time'] = self.time
                self._clear_kl_counters()
                self.KL_state = 'nlHushed'

            # Transition KL16_6
            elif self.KL_variables['consecutive_base_samples'] >= ALARM_MONITOR_SAMPLES:
                self.KL_state = 'nlMonitor'
                self.KL_variables['unhushable_filter'] = 0
                self._clear_kl_counters()

        elif self.KL_state == 'nlHushed':

            # Transition KL16_4, K60_1
            if (self.time - self.KL_variables['hush_time'] >= MAXIMUM_HUSH_TIME or
                    self._is_unhushable()):
                self.KL_state = 'nlAlarm'
                self._clear_kl_counters()

            # Transition KL16_5
            elif (self.time - self.KL_variables['hush_time'] >= MINIMUM_HUSH_TIME and
                            self.KL_variables['consecutive_base_samples'] >= ALARM_MONITOR_SAMPLES):
                self.KL_state = 'nlMonitor'
                self.KL_variables['unhushable_filter'] = 0
                self._clear_kl_counters()

        # K60 #####################################################################################
        # K60 Computation:

        # Compute the Humidity detection filter:
        humidity = self.sensors['Humidity']
        self.K60_variables['accelerated_humidity_filter'] += humidity * ACCELERATED_HUMIDITY_FILTER_N \
                   - c_style_integer_division(self.K60_variables['accelerated_humidity_filter'] * ACCELERATED_HUMIDITY_FILTER_N, ACCELERATED_HUMIDITY_FILTER_D)
        # Not really a filter, but storing it here lets us log it automatically
        self.K60_variables['accelerated_humidity_output'] = ACCELERATED_HUMIDITY_FILTER_D*humidity + ACCELERATED_HUMIDITY_GAIN \
                    * max(0,ACCELERATED_HUMIDITY_FILTER_D*humidity - self.K60_variables['accelerated_humidity_filter'])

        # Keep a record of last time sample was over base threshold for exiting holding:
        if self.sensors['Smoke'] >= SMOKE_T_BASE:
            self.K60_variables['hold_time'] = self.time

        # K60 STATE MACHINE
        if self.K60_variables['K60_state'] == 'nlStandby_State_Smoke':

            self.K60_variables['smoke_criteria'] = False
            self.K60_variables['humidity_criteria'] = False
            self.K60_variables['co_criteria'] = False
            self.shower_steam_alarm_request = False
            self.smoke_t_cur = SMOKE_T_MID

            # K60_8 Controlled by KL16 - To Monitor Mode
            if self.KL_state == 'nlMonitor':
                self.K60_variables['K60_state'] = 'nlMonitor_State_Smoke'
                self._clear_k60_counters()

        elif self.K60_variables['K60_state'] == 'nlMonitor_State_Smoke':

            # Multicriteria:
            if self.sensors['Carbonmonoxide'] >= CO_THRESHOLD:
                self.smoke_t_cur = SMOKE_T_LOW

            self._k60_shower_steam()

            # K60_1 Controlled by KL16 - To Alarm Mode
            if self.KL_state == 'nlAlarm':
                self.K60_variables['K60_state'] = 'nlAlarm_Smoke'

            # K60_2 To PreAlarm1
            if self.sensors['Smoke'] >= SMOKE_T_LOW:
                self.K60_variables['consecutive_high_samples'] += 1
            else:
                self.K60_variables['consecutive_high_samples'] = 0

            if (self.K60_variables['consecutive_high_samples'] >= MONITOR_PREALARM_SAMPLES and
                (not self.K60_variables['shower_steam_prealarm'])):
                self.K60_variables['K60_state'] = 'nlPreAlarm1_Smoke'
                self._clear_k60_counters()

            # K60_9 Controlled by KL16 - To Standby
            if self.KL_state == 'nlAll_Clear':
                self.K60_variables['K60_state'] = 'nlStandby_State_Smoke'

        elif self.K60_variables['K60_state'] == 'nlPreAlarm1_Smoke':

            # Multicriteria:
            if self.sensors['Carbonmonoxide'] >= CO_THRESHOLD:
                self.smoke_t_cur = SMOKE_T_LOW

            self._k60_shower_steam()

            if self.sensors['Smoke'] < SMOKE_T_BASE:
                self.K60_variables['consecutive_low_samples'] += 1
            else:
                self.K60_variables['consecutive_low_samples'] = 0

            # K60_1 Controlled by KL16 - To Alarm Mode
            if self.KL_state == 'nlAlarm':
                self.K60_variables['K60_state'] = 'nlAlarm_Smoke'

            # K60_3 To PreAlarm2 - Not Implemented

            # K60_10 To Hushed
            if hush_event:
                self.K60_variables['hush_time'] = self.time
                self.K60_variables['K60_state'] = 'nlPreAlarm_Hushed_Smoke'
                self.smoke_t_cur = SMOKE_T_HIGH
                self._clear_k60_counters()

            # K60_6 To Monitor Mode
            if self.K60_variables['consecutive_low_samples'] >= PREALARM_MONITOR_SAMPLES:
                self.K60_variables['K60_state'] = 'nlMonitor_State_Smoke'
                self._clear_k60_counters()

        elif self.K60_variables['K60_state'] == 'nlPreAlarm_Hushed_Smoke':

            if self.sensors['Smoke'] < SMOKE_T_BASE:
                self.K60_variables['consecutive_low_samples'] += 1
            else:
                self.K60_variables['consecutive_low_samples'] = 0

            # K60_1 Controlled by KL16 - To Alarm Mode
            if self.KL_state == 'nlAlarm':
                self.K60_variables['K60_state'] = 'nlAlarm_Smoke'
                self._clear_k60_counters()

            # K60_4 To PreAlarm2
            if self.time - self.K60_variables['hush_time'] >= MAXIMUM_HUSH_TIME:
                self.K60_variables['K60_state'] = 'nlPreAlarm2_Smoke'
                self._clear_k60_counters()
                self.smoke_t_cur = SMOKE_T_MID

            # K60_12 To Monitor
            if self.KL_state == 'nlAll_Clear':
                self.K60_variables['K60_state'] = 'nlMonitor_State_Smoke'
                self._clear_k60_counters()
                self.smoke_t_cur = SMOKE_T_MID

        elif self.K60_variables['K60_state'] == 'nlPreAlarm2_Smoke':

            # Multicriteria:
            if self.sensors['Carbonmonoxide'] >= CO_THRESHOLD:
                self.smoke_t_cur = SMOKE_T_LOW

            if self.sensors['Smoke'] < SMOKE_T_BASE:
                self.K60_variables['consecutive_low_samples'] += 1
            else:
                self.K60_variables['consecutive_low_samples'] = 0

            # K60_1 Controlled by KL16 - To Alarm Mode
            if self.KL_state == 'nlAlarm':
                self.K60_variables['K60_state'] = 'nlAlarm_Smoke'
                self._clear_k60_counters()

            # K60_10 To Hushed
            if hush_event:
                self.K60_variables['hush_time'] = self.time
                self._clear_k60_counters()
                self.K60_variables['K60_state'] = 'nlPreAlarm_Hushed_Smoke'
                self.smoke_t_cur = SMOKE_T_HIGH

            # K60_6 To Monitor
            if self.K60_variables['consecutive_low_samples'] >= PREALARM_MONITOR_SAMPLES:
                self.K60_variables['K60_state'] = 'nlMonitor_State_Smoke'
                self._clear_k60_counters()

        elif self.K60_variables['K60_state'] in ['nlAlarm_Smoke', 'nlUnhushableAlarm_Smoke']:
            # Unhushable State is for analysis/logging purposes, and does not exist on the device:
            if self._is_unhushable():
                self.K60_variables['K60_state'] = 'nlUnhushableAlarm_Smoke'
            else:
                self.K60_variables['K60_state'] = 'nlAlarm_Smoke'

            # K60_7 Controlled by KL16 - To Holding
            if self.KL_state == 'nlMonitor':
                self.K60_variables['K60_state'] = 'nlHolding_State_Smoke'
                self.smoke_t_cur = SMOKE_T_MID

            # K60_11 Controlled by KL16 - To Alarm Hushed
            if self.KL_state == 'nlHushed':
                self.K60_variables['K60_state'] = 'nlAlarm_Hushed_Smoke'

        elif self.K60_variables['K60_state'] == 'nlAlarm_Hushed_Smoke':
            # K60_5 Controlled by KL16 - To Alarm
            if self.KL_state == 'nlAlarm':
                self.K60_variables['K60_state'] = 'nlAlarm_Smoke'

            # K60_7 Controlled by KL16 - To Holding
            if self.KL_state == 'nlMonitor':
                self.K60_variables['K60_state'] = 'nlHolding_State_Smoke'
                self.smoke_t_cur = SMOKE_T_MID

        elif self.K60_variables['K60_state'] == 'nlHolding_State_Smoke':
            if self.KL_state == 'nlAlarm':
                self.K60_variables['K60_state'] = 'nlAlarm_Smoke'
            # K60_13,9
            if self.time - self.K60_variables['hold_time'] >= HOLDING_TIME:
                self.K60_variables['K60_state'] = 'nlAlarmMonitor_State_Smoke'

        elif self.K60_variables['K60_state'] == 'nlAlarmMonitor_State_Smoke':
            if self.KL_state == 'nlAlarm':
                self.K60_variables['K60_state'] = 'nlAlarm_Smoke'

        # If KL in Idle, K60 doesn't stay in monitor mode.
        if self.K60_variables['K60_state'] in ['nlMonitor_State_Smoke', 'nlAlarmMonitor_State_Smoke'] and self.KL_state == 'nlAll_Clear':
            self.K60_variables['K60_state'] = 'nlStandby_State_Smoke'

        # Determine the time the next sample is expected based on the state machine
        if self.KL_state == 'nlAll_Clear' and self.sensors['Smoke'] < SMOKE_T_LOW:
            self.next_sample = self.time + SAMPLE_RATE_LOW
        else:
            self.next_sample = self.time + SAMPLE_RATE_HIGH

        self.KL_variables['smoke_prev'] = smoke_n0

    def _clear_kl_counters(self):
        self.KL_variables['consecutive_mid_samples'] = 0
        self.KL_variables['consecutive_base_samples'] = 0
        self.KL_variables['consecutive_low_samples'] = 0

    def _clear_k60_counters(self):
        self.K60_variables['consecutive_low_samples'] = 0
        self.K60_variables['consecutive_high_samples'] = 0

    def _k60_shower_steam(self):
        self.K60_variables['derivative'] = (self.sensors['Smoke'] - self.KL_variables['smoke_prev'])

        if self.K60_variables['derivative'] < SMOKE_STEAM_SIGNAL_THRESHOLD or SMOKE_STEAM_SIGNAL_DISABLE:
            self.K60_variables['smoke_criteria'] = True

        if (self.K60_variables['accelerated_humidity_output'] >= ACCELERATED_HUMIDITY_THRESHOLD or
                    self.sensors['Humidity'] >= HUMIDITY_THRESHOLD):
            self.K60_variables['humidity_criteria'] = True

        if self.sensors['Carbonmonoxide'] >= STEAM_REJECTION_CO_THRESHOLD:
            self.K60_variables['co_criteria'] = True

        # The K60 will only wakeup to request the shower steam holdoff when this condition is met.
        if ((self.smoke_t_cur == SMOKE_T_MID and self.KL_variables['consecutive_mid_samples'] >= 4) or
             (self.smoke_t_cur == SMOKE_T_LOW and self.KL_variables['consecutive_low_samples'] >= 4)):
            shower_steam_wakeup = True
        else:
            shower_steam_wakeup = False

        if (self.K60_variables['smoke_criteria'] and
           self.K60_variables['humidity_criteria'] and not
           self.K60_variables['co_criteria'] and
           shower_steam_wakeup):
            self.shower_steam_alarm_request = True
        else:
            self.shower_steam_alarm_request = False

        if (self.K60_variables['humidity_criteria'] and
           not self.K60_variables['co_criteria']):
            self.K60_variables['shower_steam_prealarm'] = True
        else:
            self.K60_variables['shower_steam_prealarm'] = False

        if not STEAM_REJECTION_ACTIVE:
            self.shower_steam_alarm_request = False
            self.K60_variables['shower_steam_prealarm'] = False

        if STEAM_REJECTION_FORCED_ON:
            self.shower_steam_alarm_request = True
            self.K60_variables['shower_steam_prealarm'] = True

    def _unhushable_filter(self):
        # Compute the No Hush detection filter:
        self.KL_variables['unhushable_filter'] += (min(self.sensors['Smoke'], UNHUSHABLE_INPUT_MAX) * UNHUSHABLE_FILTER_N -
                         c_style_integer_division(self.KL_variables['unhushable_filter'] * UNHUSHABLE_FILTER_N,  UNHUSHABLE_FILTER_D))

        self.KL_variables['unhushable_filter'] = min(UNHUSHABLE_OUTPUT_MAX, self.KL_variables['unhushable_filter'])

    def _is_unhushable(self):
        if UNHUSHABLE_1_0_MODE:
            if self.sensors['Smoke'] >= 140 and self.KL_variables['smoke_prev'] >= 140:
                return True
            else:
                return False
        else:
            if self.KL_variables['unhushable_filter'] >= UNHUSHABLE_THRESHOLD:
                return True
            else:
                return False

    def set_up_logging(self):
        # Create structures to hold data for logging purposes
        self.current_mode = 'Default'
        self.prev_mode = self.current_mode
        self.K60_state_prev = 'nlStandby_State_Smoke'
        self.KL_state_prev = 'nlAll_Clear'
        self.states = {self.time: 'nlStandby_State_Smoke'}
        self.KL_states = {self.time: 'nlAll_Clear'}
        self.modes = {self.time: 'Default'}

        self.filter_data = {}
        for key in SmokeAlgorithm.ALGORITHM_FILTERS:
            self.filter_data[key] = {}

    def log_data(self):
        # Called after each iteration through the state machine to record data
        if self.K60_variables['K60_state'] != self.K60_state_prev:
            self.states[self.time] = self.K60_variables['K60_state']
        if self.KL_state != self.KL_state_prev:
            self.KL_states[self.time] = self.KL_state
        if self.current_mode != self.prev_mode:
            self.modes[self.time] = self.current_mode

        # Log filter values
        for key in SmokeAlgorithm.ALGORITHM_FILTERS:
            if key in self.KL_variables:
                self.filter_data[key][self.time] = self.KL_variables[key]
            elif key in self.K60_variables:
                self.filter_data[key][self.time] = self.K60_variables[key]

        self.K60_state_prev = self.K60_variables['K60_state']
        self.KL_state_prev = self.KL_state
        self.prev_mode = self.current_mode

    def get_eureka_logs(self):\
        # Create Eureka compatible structure:
        # Time is stored in seconds in Eureka file.
        output = {}
        output['events'] = ['event', 'KL_event']

        if self.sensor_data is not None:
            df = pd.DataFrame(self.sensor_data).T
            df.index = df.index / 1000.
            df = device_to_eureka(df)
            for column in df:
                output[column] = pd.DataFrame(df[column]).sort()
                output[column].columns = ['Value0']
                output['events'].append(column)

        key = None
        for key in self.filter_data:
            df = pd.DataFrame.from_dict(self.filter_data[key], orient='index').sort()
            df.index = df.index / 1000.
            output[key] = df
            output[key].columns = ['Value0']
            output['events'].append(key)

        # Find the end of the data and append the idle state
        end = output[key].index[-1]*1000 + MINIMUM_TIME_RESOLUTION

        self.states[end] = 'nlStandby_State_Smoke'
        df = pd.DataFrame.from_dict(self.states, orient='index').sort()
        df.index = df.index / 1000.
        output['event'] = df
        output['event'].columns = ['name']

        self.KL_states[end] = 'nlAll_Clear'
        df = pd.DataFrame.from_dict(self.KL_states, orient='index').sort()
        df.index = df.index / 1000.
        output['KL_event'] = df
        output['KL_event'].columns = ['name']

        self.modes[end] = 'Default'
        df = pd.DataFrame.from_dict(self.modes, orient='index').sort()
        df.index = df.index / 1000.
        output['modes'] = df
        output['modes'].columns = ['name']

        return output
