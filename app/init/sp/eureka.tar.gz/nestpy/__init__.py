import os
import logging as logging
import matplotlib

matplotlib.use("AGG")

_log = logging.getLogger(__name__)

try:
    from . import scripts
    from . import algorithm_test
    from . import avrosupport
    from . import aws
    from . import communication
    from . import credentials
    from . import converters
    from . import dropcam
    from . import fileutils
    from .frames import DiamondFrame
    from . import geo
    from . import logger
    from . import modeling
    from . import parsing
    from . import reporting
    from . import scriptutils
    from . import sql
    from . import hiddenite
    from . import security
    from .cache import Cache
    from .groups import DeviceGroup
    from .groups import DeviceGroupLookup
    from .reporting import RushHourRewards
    from .reporting import SeasonalSavings
    from .scriptutils import ArgumentParser
    from .structures import DeviceHistory
    from .structures import AIRTether
    from .structures import Amber
    from .structures import Balsam
    from .structures import Diamond
    from .structures import Flintstone
    from .structures import Hiddenite
    from .structures import Hobo
    from .structures import Lithium
    from .structures import NGS
    from .structures import Pinna
    from .structures import PinnaTether
    from .structures import PinnaProtoTether
    from .structures import Structure
    from .structures import Temperature
    from .structures import TahitiBridge
    from .structures import Topaz
    from .structures import Transit
    from .structures import Weather
    from .structures import WeatherForecast
    from .structures import WMSScanner
    from .summarization import EventSummarizer
    from .summarization import EventSummaryCacher
    from .summarization import EventSummaryGroupCacher
    from .version import get_git_version
    from . import goose

    if 'DISABLE_MATPLOTLIB' not in os.environ:
        from . import plotting
    else:
        _log.info('Disabling Matplotlib due to "DISABLE_MATPLOTLIB" environment variable.')

except ImportError:
    _log.error('Error importing nestpy. This is likely due to a new package dependency. Try running'
               ' "make install" to update dependencies.')
    raise

try:
    __version__ = get_git_version()
except ValueError:
    _log.info('Unable to find version number.')
    __version__ = None

# Legacy code from when NestPy contained argparse. Most users are now using
# Python 2.7, which comes with argparse by default.
import argparse

from signal import signal, SIGPIPE, SIG_DFL


def setup():
    """
    Sets up a program to run with useful settings.

    * Sets SIG_PIPE properly so that piping stdin or stdout from command-line
      does not throw a useless exception message.

    Not all programs need to run this function, but its functionality is quite
    useful in many cases.
    """

    # Ignore SIG_PIPE and don't throw exceptions on it.
    # (http://docs.python.org/library/signal.html)
    signal(SIGPIPE, SIG_DFL)


# DeprecationWarnings are set to "ignore" by default. Switch them to "default" so that we log them at least once.
import warnings
warnings.filterwarnings('default', category=DeprecationWarning)


# Usage statistics:
def send_analytics():
    import urllib2
    import getpass

    EUREKA_ANALYTICS_KEY = 'nviopae90jio4q349ero9ajfd0'
    EUREKA_ANALYTICS_ADDRESS = 'http://nest-algo.appspot.com/eureka_analytics/1/{username}/{scriptname}/{key}/'

    url_dict = {'key': EUREKA_ANALYTICS_KEY}

    try:
        # This code gets the name of the script that imported nestpy. It won't work if
        # nestpy was imported from an interactive session, so we try/except it.
        import __main__ as main
        url_dict['scriptname'] = os.path.basename(main.__file__)
    except:
        url_dict['scriptname'] = 'interactive'

    url_dict['username'] = getpass.getuser()
    url = EUREKA_ANALYTICS_ADDRESS.format(**url_dict)

    try:
        urllib2.urlopen(url)
    except:
        # Catch any failures to connect to the analytics engine and just return
        return

# Analytics are run in a separate thread to avoid blocking if the internet is having problems
import threading

t = threading.Thread(target=send_analytics)
t.start()
