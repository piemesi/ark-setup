import logging
import os

logger = logging.getLogger(__name__)


def data_source(default='AWS'):
    source = os.environ.get('EUREKA_SOURCE')

    if source == 'AWS':
        out = source
    elif source == 'GPC':
        out = source
    else:
        out = default

    if data_source.log_message:
        logger.info('Data source is {}'.format(out))

    return out

data_source.log_message = True