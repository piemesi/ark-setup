import logging
import os

logger = logging.getLogger(__name__)


def hdf5_enabled():
    if os.environ.get('EUREKA_HDF5') is not None:
        if hdf5_enabled.log_message:
            logger.warning('Using HDF5 logs. Some functions may not work properly.')
            hdf5_enabled.log_message = False
        return True
    else:
        return False

hdf5_enabled.log_message = True
