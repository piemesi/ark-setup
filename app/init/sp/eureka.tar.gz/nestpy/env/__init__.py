"""
Environment configuration for the Eureka project.

For example, to retrieve the environment cache:

>>> cache_destination = env.cache.destination()
"""

from .cache import cache_destination
from .hdf5 import hdf5_enabled
from .source import data_source

if __name__ == "__main__":
    # Run doctest when run as main script.
    import doctest
    doctest.testmod()

