from os import getcwd, getenv


def cache_destination():
    """Cache directory that Eureka uses for data files.

    Used as the default cache location for several data loading routines. E.g. DeviceHistory.load
    To configure the cache directory, use the 'EUREKA_CACHE' environment variable.
    """
    return getenv("EUREKA_CACHE", getcwd())
