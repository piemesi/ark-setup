import logging


def get_script_logger(script_file):
    """Generates a logger for the given script file name

    >>> import nestpy
    >>> log = nestpy.scripts.get_script_logger(__file__)
    >>> log.info("Logging from a script.")

    :param script_file: the script file. E.g. "do_stuff.py"
    :return: a Python logger
    """
    return logging.getLogger(".".join([__name__, script_file]))

