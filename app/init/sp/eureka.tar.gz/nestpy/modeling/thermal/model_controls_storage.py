# pylint: disable=no-member

from itertools import chain, combinations
import numpy as np
import pandas as pd


def powerset(iterable):
    """
    Converts a list into the equivalent powerset of all possible combinations.

    Example::

        powerset([1,2,3]) --> () (1,) (2,) (3,) (1,2) (1,3) (2,3) (1,2,3)
    """
    s = list(iterable)
    return chain.from_iterable(combinations(s, r) for r in range(len(s)+1))


class ModelControlsStorage(object):
    '''
    We anticipate that there will be Models that care about certain controls
    and don't care about others. They may train different parameters for each
    distinct arrangement of care controls, and would like to store information
    about the state of don't care controls. This provides a framework for such
    Models.

    Example use of ModelControlsStorage training::

      mcs = ModelControlsStorage()
      mcs.set_care_controls(["Stage1CoolState", "Stage1HeatState"])
      mcs.process_training_usr(usr)

      for bit_code in mcs.get_bit_codes():
          training_set_for_bit_code = pd.merge(bt, pd.DataFrame(index=mcs.get_bit_code_data(bit_code, "time_index", True)), left_index=True, right_index=True)
          params = train_an_awesome_model(training_set_for_bit_code)
          mcs.set_bit_code_data(bit_code, "params", params)

    The ``usr`` and ``bt`` values are assumed to be training UpdateStateResults
    and BufferedTemperature DataFrames with the same index, cleaned using
    extract_clean_thermodynamics_data.

    At this point, we have information about the datasets for each bit_code.
    The ``self.model_params`` member variable is a dict with keys being
    bit_codes of controls we care about. Those bit_codes index into another
    dictionary containing "time_index" and "dont_care_control_states".

    The ``time_index`` value is a list of all row times in usr that belong to
    the bit_code.

    The ``dont_care_control_states`` value is a dictionary mapping the
    don't-care controls to their state. Those states can be 0, 1, or 2:

    - 0 or 1 means we only saw 0 or 1 for the dont care control.
    - 2 means we saw mixed data for the dont care control.

    At this point, we're fully trained and self.model_params contains a model
    for all bit_codes!

    To run prediction::

    for i in range(len(usr)):
        params = mcs.process_prediction_usr_row(usr.iloc[i], "coefficients", ["Stage1CoolState", "Stage1HeatState"])

        if params != None:
            make_an_awesome_prediction(params, bt.iloc[i])
        else:
            logger.info("We couldn't find an appropriate model for timestep %d.", i)

    usr and bt are assumed to be prediction UpdateStateResults and
    BufferedTemperature DataFrames with the same index, cleaned using
    extract_clean_thermodynamics_data.

    See :ref:`nestpy.modeling.thermal.InitialRateStagedModel` as an example of
    the above.
    '''

    CONTROLS_BIT_PLACE_DICT = {
        "FanState" : 0,
        "FanCoolingState" : 1,
        "Stage1CoolState" : 2,
        "Stage2CoolState" : 3,
        "Stage1HeatState" : 4,
        "Stage2HeatState" : 5,
        "Stage3HeatState" : 6,
        "Stage1AltHeatState" : 7,
        "Stage2AltHeatState" : 8,
        "AuxHeatState" : 9,
        "EmerHeatState" : 10,
        #"OB_BIT" : 11, # Not in UpdateStateResults
        "HumidifierState" : 12,
        "DehumidifierState" : 13,
        "AutoDehumState" : 14,
    }

    def __init__(self):
        self.model_params = {}
        self.care_controls = None
        self.dont_care_controls = None

    def __str__(self):
        states = []
        for state_index in self.model_params.keys():
            try:
                state_name = (key for key, value in self.CONTROLS_BIT_PLACE_DICT.items() if value==state_index).next()
                states.append("  %20s: %s" % (state_name, self.get_learned_params_for_state(state_name)))
            except:
                # This should never happen.
                raise RuntimeError("State index %d not understood." % state_index)

        return "\n".join(states)

    def get_learned_params_for_state(self, state):
        """
        Gets the model params for the requested state.

        Throws a ValueError if the state is not recognized or has not been
        learned.

        :param state:
            the model state (Stage1CoolState, FanState, etc.)
        :type state:
            str

        :return:
            the params for the state.
        :rtype:
            numpy.array
        """

        if state not in self.CONTROLS_BIT_PLACE_DICT:
            raise ValueError("State '%s' not recognized." % state)

        state_index = self.CONTROLS_BIT_PLACE_DICT[state]
        if state_index not in self.model_params:
            raise ValueError("State '%s' has not been learned." % state)

        return self.model_params[state_index]["coefficients"]

    def get_care_controls(self):
        return self.care_controls

    def get_bit_codes(self):
        return self.model_params.keys()

    def get_bit_code_data(self, bit_code, attr, pop=False):
        return self.model_params[bit_code].pop(attr) if pop else self.model_params[bit_code][attr]

    def set_bit_code_data(self, bit_code, attr, obj):
        self.model_params[bit_code][attr] = obj

    def set_care_controls(self, care_controls):
        '''
        care_controls should be set before training!

        :param care_controls:
        list of controls that we care about
        :type care_controls:
        list
        '''
        self.care_controls = care_controls
        self.dont_care_controls = np.setdiff1d(self.CONTROLS_BIT_PLACE_DICT.keys(), care_controls, assume_unique=True)

    def process_fit_rows(self, rows, param_name="coefficients", param_cols=None):
        '''
        Translates Joseph's bit magic into python framework. If param_name and
        param_cols are left blank, it can be used to pull data from
        InitialRateStagedModelFit event logs
        '''

        if param_cols == None:
            param_cols = ["mDecayingEffectiveness", "mOutdoorTemperatureDependence", "mStructureTemperatureDependence", "mTimeOfDayDependence", "mOffset"]

        care_controls = []
        for row in rows.iterrows():
            row_data = row[1]
            bit_code = 0
            dont_care_control_states = {}
            # figure out cares and don't care states for python data structure
            for control in self.CONTROLS_BIT_PLACE_DICT:
                control_bit_place = self.CONTROLS_BIT_PLACE_DICT[control]
                control_mask_either = (int(row_data["mStagesBitFieldMaskEither"]) >> control_bit_place) & 1
                control_both = (int(row_data["mStagesBitFieldBoth"]) >> control_bit_place) & 1
                control_on = (int(row_data["mStagesBitFieldOn"]) >> control_bit_place) & 1
                if control_mask_either:
                    dont_care_control_states[control] = 2 if control_both else control_on
                else:
                    if control not in care_controls:
                        care_controls.append(control)
                    bit_code |= control_on << control_bit_place
            self.model_params[bit_code] = {
                "dont_care_control_states": dont_care_control_states,
                param_name: [row_data[col] for col in param_cols]
            }
        self.set_care_controls(care_controls)

    def process_training_usr(self, usr):
        """
        Takes an entire UpdateStateResults DataFrame and extracts model bit
        logic.

        :param usr:
            an UpdateStateResults DataFrame
        :type usr:
            pandas.DataFrame
        """
        on_off_dict = {
            control:{
                "on_index": set(np.where(usr[control]==1)[0]),
                "off_index": set(np.where(usr[control]==0)[0]),
            }
            for control in self.care_controls
        }

        for on_care_controls in powerset(self.care_controls):
            off_care_controls = np.setdiff1d(self.care_controls, on_care_controls, assume_unique=True)
            all_indexes = [on_off_dict[control]["on_index"] for control in on_care_controls] + [on_off_dict[control]["off_index"] for control in off_care_controls]
            time_index = usr.index[list(set.intersection(*all_indexes))]
            if len(time_index) > 0:
                bit_code = sum([1 << self.CONTROLS_BIT_PLACE_DICT[control] for control in on_care_controls])

                states = []
                for control in self.dont_care_controls:
                    if control not in usr:
                        continue
                    elif len(usr[control].unique()) == 1:
                        states.append(usr[control].unique()[0])
                    else:
                        states.append(2)

                self.model_params[bit_code] = {
                    "time_index" : time_index,
                    "dont_care_control_states" : {control : states}
                }

    def process_training_usr_row(self, row):
        '''
        Takes a row from UpdateStateResults, finds its corresponding
        model_params entry, adds the row's time to time_index, and updates the
        appropriate dont_care_control_states.

        If you are going row by row it's going to be extremely slow, so the
        preferred method is to use process_training_usr.

        :param row:
            a row of UpdateStateResults
        :type row:
            pandas.Series
        '''
        bit_code = sum([int(row[control]) << self.CONTROLS_BIT_PLACE_DICT[control] for control in self.care_controls])
        if bit_code not in self.model_params:
            # for each arrangement of care controls, we have a corresponding
            # time_index and dont_care_control_states. time_index is a list of
            # all times such that the data at that time corresponds to the
            # arrangement. dont_care_control_states records whether or not the
            #data for the don't care controls are mixed.
            self.model_params[bit_code] = {"time_index":[], "dont_care_control_states":{}}

        model_data = self.model_params[bit_code]
        model_data["time_index"].append(row.name)
        # key for dont_care_control_states: 2 means we have seen 'mixed'
        # (includes 1 and 0) data for this control.
        # - 1 means we have only seen '1' for this control
        # - 0 means we have only seen '0' for this control
        for control in self.dont_care_controls:
            model_data["dont_care_control_states"][control] = 2 if control in model_data["dont_care_control_states"] and model_data["dont_care_control_states"][control] != row[control] else row[control]

    def process_prediction_usr(self, usr, attr="coefficients", predict_care_controls=None):
        '''
        takes an UpdateStateResults DataFrame and adds model params as columns

        :param usr:
            UpdateStateResults DataFrame
        :type usr:
            pandas.DataFrame

        :returns:
            DataFrame with model params as columns
        :rtype:
            pandas.DataFrame
        '''
        if predict_care_controls == None:
            predict_care_controls = self.care_controls

        both_care_controls = np.intersect1d(predict_care_controls, self.care_controls, assume_unique=True) # these are the controls that both training and prediction care about
        only_predict_care_controls = np.setdiff1d(predict_care_controls, both_care_controls, assume_unique=True) # these are the controls that only the prediction cares about

        usr_controls_dict = {usr.columns[i]:i for i in range(len(usr.columns))}
        num_usr_cols = len(usr.columns)

        attr_cols = ["c"+str(i) for i in range(len(self.model_params[self.model_params.keys()[0]][attr]))]
        num_attr_cols = len(attr_cols)
        for col in attr_cols:
            usr[col] = np.nan

        for (row) in np.nditer(usr, flags=["external_loop", "refs_ok"], order="C", op_flags=["readwrite"]):
            candidate_bit_codes = [bit_code for bit_code in self.model_params.keys()
                if all([row[usr_controls_dict[control]] == (bit_code & (1 << self.CONTROLS_BIT_PLACE_DICT[control])) >> self.CONTROLS_BIT_PLACE_DICT[control] for control in both_care_controls])
                and all([row[usr_controls_dict[control]] == self.model_params[bit_code]["dont_care_control_states"][control] for control in only_predict_care_controls])]
            if len(candidate_bit_codes) == 1:
                row[...] = np.append(row[:num_usr_cols], np.array([self.model_params[candidate_bit_codes[0]][attr][i] for i in range(num_attr_cols)]))

    def process_prediction_usr_row(self, row, attr="coefficients", predict_care_controls=None):
        '''
        Takes a row, return a model if we have one that matches or None if
        we don't

        :param row:
            either a row of UpdateStateResults or a dictionary mapping
            keys=care control -> values=control on/off
        :type row:
            pandas.Series or dict
        '''
        if type(row) == pd.Series:
            if predict_care_controls == None:
                predict_care_controls = self.care_controls
        elif type(row) == dict:
            predict_care_controls = row.keys()
        else:
            raise Exception("Type not recognized!")

        # these are the controls that both training and prediction care about
        both_care_controls = np.intersect1d(predict_care_controls, self.care_controls, assume_unique=True)

        # these are the controls that only the prediction cares about
        only_predict_care_controls = np.setdiff1d(predict_care_controls, both_care_controls, assume_unique=True)

        candidate_bit_codes = [bit_code for bit_code in self.model_params.keys()
            if all([row[control] == (bit_code & (1 << self.CONTROLS_BIT_PLACE_DICT[control])) >> self.CONTROLS_BIT_PLACE_DICT[control] for control in both_care_controls])
            and all([row[control] == self.model_params[bit_code]["dont_care_control_states"][control] for control in only_predict_care_controls])]

        # if len(candidate_bit_codes) == 1, all available data that fit this
        # model was used to train, meaning that training data was not mixed for
        # prediction don't cares and training cares
        return self.model_params[candidate_bit_codes[0]][attr] if len(candidate_bit_codes) == 1 else None
