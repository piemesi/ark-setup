# pylint: disable=no-member
import copy
import logging

import numpy as np
import pandas as pd

from ...converters import convert_time_units
from . import model, model_controls_storage

logger = logging.getLogger(__name__)


class InitialRateStagedModel(model.Model):

    # important constants for InitialRateStagedModel
    T_STEADY_STATE = convert_time_units(5, "minutes", "seconds")
    GAMMA = convert_time_units(1000.0, "seconds", "days")
    SIGMA = convert_time_units(60.0, "seconds", "days")
    STRUCTURE_INDOOR_ALPHA = (0.0125)
    STRUCTURE_OUTDOOR_BETA = (0.005)
    STRUCTURE_KEEP_ALPHA = (1.0 - (STRUCTURE_OUTDOOR_BETA + STRUCTURE_INDOOR_ALPHA))
    TIME_STEP_SECS = convert_time_units(5, "minutes", "seconds")
    MAX_LOG_WEIGHT = np.log(convert_time_units(2, "hours", "days") + 1)
    BELOW_LIMIT = ABOVE_LIMIT = 0.56

    regression_dims = ["decaying_effectiveness", "outdoor_temperature_dependence", "structure_temperature_dependence", "time_of_day_dependence", "constant"]

    def __init__(self):
        super(InitialRateStagedModel, self).__init__()
        self.mcs = model_controls_storage.ModelControlsStorage()

    def __str__(self):
        return "InitialRateStagedModel"

    def __repr__(self):
        if self.trained:
            return "%s with %d states:\n%s" % (str(self), len(self.mcs.model_params), str(self.mcs))
        else:
            return "%s (untrained)" % str(self)

    def get_learned_params_for_state(self, state):
        """
        Gets the model params for the requested state.

        Throws a ValueError if the state is not recognized or has not been
        learned.

        :param state:
            the model state (Stage1CoolState, FanState, etc.)
        :type state:
            str

        :return:
            the params for the state.
        :rtype:
            numpy.array
        """
        return self.mcs.get_learned_params_for_state(state)

    def g(self, t_cycle):
        return 1.0 / (1.0 + np.exp(-self.GAMMA * (t_cycle - self.T_STEADY_STATE)))

    def train_with_log(self, rows):
        '''
        Expects a row from InitalRateStagedModelFit event log
        '''
        self.mcs.process_fit_rows(rows)
        self.trained = True

    def train(self, tset, gaps=None, care_controls=None):
        super(InitialRateStagedModel, self).train(tset)

        training_set = copy.deepcopy(tset)
        training_set.add_event_data("linear_regression", pd.DataFrame(np.nan, index=training_set.BufferedTemperature.index,
            columns=["dTin", "T_structure", "time", "t_cycle", "continued_temperature_change", "decaying_effectiveness", "outdoor_temperature_dependence", "structure_temperature_dependence", "time_of_day_dependence", "constant", "weight"]))
        training_set.linear_regression["temp_diff_to_predict"] = np.append(training_set.BufferedTemperature.temperature.diff()[1:], np.nan)

        if not care_controls:
            care_controls = ["Stage1CoolState", "Stage1HeatState"]

        lr = training_set.linear_regression
        lr_idx = lr.index.astype(np.int64)
        bt = training_set.BufferedTemperature
        w = training_set.Weather
        usr = training_set.UpdateStateResults
        cs = training_set.CurrentState

        self.mcs.set_care_controls(care_controls)

        #self.mcs.process_training_usr(usr.loc[np.setdiff1d(usr.index.to_pydatetime(), gaps, assume_unique=True)].iloc[:-1])
        self.mcs.process_training_usr(usr.iloc[:-1])

        # compute dTin and t_cycle
        usr_cycle_change_idx = np.where(usr[care_controls].diff().any(axis=1))[0]
        cumsum_time_diff = np.append([0.0], np.cumsum(np.diff(convert_time_units(lr_idx, "nanoseconds", "seconds"))))
        if len(usr_cycle_change_idx) > 0:
            first_cycle = usr_cycle_change_idx[0]
            lr.dTin[:first_cycle] = 0.0
            lr.t_cycle[:first_cycle] = cumsum_time_diff[:first_cycle]
            for i in range(len(usr_cycle_change_idx)-1):
                start_of_cycle = usr_cycle_change_idx[i]
                end_of_cycle = usr_cycle_change_idx[i+1]
                lr.dTin[start_of_cycle:end_of_cycle] = lr.temp_diff_to_predict[start_of_cycle-1]
                lr.t_cycle[start_of_cycle:end_of_cycle] = cumsum_time_diff[start_of_cycle:end_of_cycle] - cumsum_time_diff[start_of_cycle]
            last_cycle = usr_cycle_change_idx[-1]
            lr.dTin[last_cycle:] = lr.temp_diff_to_predict[last_cycle-1]
            lr.t_cycle[last_cycle:] = cumsum_time_diff[last_cycle:] - cumsum_time_diff[last_cycle]
        else:
            lr.dTin = 0.0
            lr.t_cycle = cumsum_time_diff

        # compute time offset into day
        local_offset = convert_time_units(cs.UTCOffset[-1] + cs.DSTOffset[-1], "minutes", "days")
        lr.time = (convert_time_units(lr_idx, "nanoseconds", "days") + local_offset) % 1.0

        # compute T_structure
        lr.T_structure[0] = T_structure_keep = bt.temperature[0]
        Tin_update = self.STRUCTURE_INDOOR_ALPHA * bt.temperature
        Tout_update = self.STRUCTURE_OUTDOOR_BETA * w.Temperature
        for (Tin_u, Tout_u, T_structure) in np.nditer([Tin_update[1:], Tout_update[1:], lr.T_structure[1:]], op_flags=["readwrite"]):
            T_structure_keep = self.STRUCTURE_KEEP_ALPHA * T_structure_keep + Tin_u + Tout_u
            T_structure[...] = T_structure_keep

        # compute dimensions for linear regression
        lr.continued_temperature_change = (1-self.g(lr.t_cycle)) * lr.dTin
        lr.decaying_effectiveness = self.g(lr.t_cycle) * np.exp(-self.SIGMA * lr.t_cycle)
        lr.outdoor_temperature_dependence = w.Temperature - bt.temperature
        lr.structure_temperature_dependence = lr.T_structure - bt.temperature
        lr.time_of_day_dependence = np.sin(2*np.pi*(lr.time))
        lr.constant = 1.0
        lr.weight = np.sqrt(np.minimum(np.log(convert_time_units(lr.t_cycle, "seconds", "days")+1), self.MAX_LOG_WEIGHT))

        for bit_code in self.mcs.get_bit_codes():
            training_set_for_bit_code = pd.merge(lr, pd.DataFrame(index=self.mcs.get_bit_code_data(bit_code, "time_index", True)), left_index=True, right_index=True)

            # I wasn't able to find an established python library that supports
            # weighted least squares, so I kinda hacked it.
            #
            # Weighted least squares seeks to minimize:
            #
            #   (b-A*x)'*diag(w)*(b-A*x)
            #         = (b-A*x)'*diag(sqrt(w))*diag(sqrt(w))*(b-A*x)
            #         = (b0-A0*x)'*(b0-A0*x)
            #
            # where b0 = b.*sqrt(w) and A0 is A with each row
            # A0_i = A_i.*sqrt(w)
            #
            # Note that the sqrt was already taken above
            A0 = training_set_for_bit_code[self.regression_dims].mul(training_set_for_bit_code.weight, axis=0).values
            b0 = np.multiply(np.array(training_set_for_bit_code.temp_diff_to_predict) - np.array(training_set_for_bit_code.continued_temperature_change), np.array(training_set_for_bit_code.weight))

            self.mcs.set_bit_code_data(bit_code, "coefficients", np.linalg.lstsq(A0, b0)[0])

    def predict(self, pset, prediction_type, control=None, predict_care_controls=None):
        super(InitialRateStagedModel, self).predict(pset, prediction_type, control)

        prediction_set = copy.deepcopy(pset)

        prediction_set.BufferedTemperature["predicted_temperature"] = np.nan
        prediction_set.add_event_data("precompute", pd.DataFrame(np.nan, index=prediction_set.BufferedTemperature.index,
            columns=["t_cycle", "continued_temperature_change_multiplier", "decaying_effectiveness", "time_of_day_dependence", "constant"] if prediction_type=="open"
            else ["time_of_day_dependence", "constant"]))

        cs = prediction_set.CurrentState
        pre = prediction_set.precompute
        pre_idx = pre.index.astype(np.int64)
        local_offset = convert_time_units(cs.UTCOffset[-1] + cs.DSTOffset[-1], "minutes", "days")
        pre.time_of_day_dependence = np.sin(2*np.pi*((convert_time_units(pre_idx, "nanoseconds", "days") + local_offset) % 1.0))
        pre.constant = 1.0

        if prediction_type == "open":
            return self.open_predict(prediction_set, predict_care_controls)
        else:
            return self.close_predict(prediction_set, control)

    def open_predict(self, prediction_set, predict_care_controls):
        if not predict_care_controls:
            predict_care_controls = self.mcs.get_care_controls()

        bt = prediction_set.BufferedTemperature
        w = prediction_set.Weather.Temperature
        usr = prediction_set.UpdateStateResults
        pre = prediction_set.precompute
        pre_idx = pre.index.astype(np.int64)

        self.mcs.process_prediction_usr(usr)

        usr_cycle_change = usr[predict_care_controls].diff().any(axis=1)
        usr_cycle_change_idx = np.where(usr_cycle_change)[0]
        cumsum_time_diff = np.append([0.0], np.cumsum(np.diff(convert_time_units(pre_idx, "nanoseconds", "seconds"))))

        if len(usr_cycle_change_idx) > 0:
            first_cycle = usr_cycle_change_idx[0]
            pre.t_cycle[:first_cycle] = cumsum_time_diff[:first_cycle]

            for i in range(len(usr_cycle_change_idx)-1):
                start_of_cycle = usr_cycle_change_idx[i]
                end_of_cycle = usr_cycle_change_idx[i+1]
                pre.t_cycle[start_of_cycle:end_of_cycle] = cumsum_time_diff[start_of_cycle:end_of_cycle] - cumsum_time_diff[start_of_cycle]
            last_cycle = usr_cycle_change_idx[-1]
            pre.t_cycle[last_cycle:] = cumsum_time_diff[last_cycle:] - cumsum_time_diff[last_cycle]
        else:
            pre.t_cycle = cumsum_time_diff

        pre.continued_temperature_change_multiplier = (1-self.g(pre.t_cycle))
        pre.decaying_effectiveness = self.g(pre.t_cycle) * np.exp(-self.SIGMA * pre.t_cycle)
        Tout_update = w * self.STRUCTURE_OUTDOOR_BETA

        T_structure_keep = ((1 - self.STRUCTURE_INDOOR_ALPHA) * bt.temperature[0] - Tout_update[0]) / self.STRUCTURE_KEEP_ALPHA
        predicted_Tin_keep = bt.temperature[0]
        Tdiff_keep = dTin_keep = 0.0

        for (Tout, Tout_u, change, c0, c1, c2, c3, c4, continued_temperature_change_multiplier, decaying_effectiveness, time_of_day_dependence, constant, predicted_Tin) in \
            np.nditer([w, Tout_update, usr_cycle_change, usr.c0, usr.c1, usr.c2, usr.c3, usr.c4, pre.continued_temperature_change_multiplier, pre.decaying_effectiveness, pre.time_of_day_dependence, pre.constant, bt.predicted_temperature], op_flags=["readwrite"]):
            predicted_Tin[...] = predicted_Tin_keep = predicted_Tin_keep + Tdiff_keep
            T_structure_keep = self.STRUCTURE_KEEP_ALPHA * T_structure_keep + self.STRUCTURE_INDOOR_ALPHA * predicted_Tin_keep + Tout_u

            if change:
                dTin_keep = Tdiff_keep

            coeff_vector = [c0, c1, c2, c3, c4]

            if not np.isnan(coeff_vector).any():
                vector = [
                    decaying_effectiveness,
                    Tout - predicted_Tin_keep,
                    T_structure_keep - predicted_Tin_keep,
                    time_of_day_dependence,
                    constant # constant
                ]
                Tdiff_keep = np.dot(coeff_vector, vector) + continued_temperature_change_multiplier * dTin_keep
            else:
                logger.info("No appropriate models found for timestep.")
                Tdiff_keep = 0.0
        return prediction_set

    def close_predict(self, prediction_set, control):
        prediction_set.add_event_data("predicted_usage", pd.DataFrame(0, index=prediction_set.UpdateStateResults.index, columns=[control]))

        bt = prediction_set.BufferedTemperature
        w = prediction_set.Weather.Temperature
        usr = prediction_set.UpdateStateResults
        pre = prediction_set.precompute
        pred_usage = prediction_set.predicted_usage[control]
        target = prediction_set.RethinkStateResults.TargetTemperature

        lower = target - self.BELOW_LIMIT
        above = target + self.ABOVE_LIMIT

        Tout_update = w * self.STRUCTURE_OUTDOOR_BETA

        t_cycle_increments = np.append(np.diff(convert_time_units(bt.index.astype(np.int64), "nanoseconds", "seconds")), [0.0])

        T_structure_keep = ((1 - self.STRUCTURE_INDOOR_ALPHA) * bt.temperature[0] - Tout_update[0]) / self.STRUCTURE_KEEP_ALPHA
        predicted_Tin_keep = bt.temperature[0]
        t_cycle_keep = Tdiff_keep = dTin_keep = 0.0
        predicted_usage_keep = usr[control][0]
        min_cycle = convert_time_units(10.0, "minutes", "seconds")

        for (Tout, Tout_u, l, a, t_cycle_increment, time_of_day_dependence, constant, predicted_usage, predicted_Tin) in \
            np.nditer([w, Tout_update, lower, above, t_cycle_increments, pre.time_of_day_dependence, pre.constant, pred_usage, bt.predicted_temperature], op_flags=["readwrite"]):
            predicted_Tin[...] = predicted_Tin_keep = predicted_Tin_keep + Tdiff_keep
            T_structure_keep = self.STRUCTURE_KEEP_ALPHA * T_structure_keep + self.STRUCTURE_INDOOR_ALPHA * predicted_Tin_keep + Tout_u

            if control == "Stage1CoolState" and \
                ((predicted_usage_keep and predicted_Tin_keep < l and t_cycle_keep >= min_cycle) or (not predicted_usage_keep and predicted_Tin_keep > a)):
                predicted_usage_keep = not predicted_usage_keep
                t_cycle_keep = 0.0
                dTin_keep = Tdiff_keep
            elif control == "Stage1HeatState" and \
                ((predicted_usage_keep and predicted_Tin_keep > a and t_cycle_keep >= min_cycle) or (not predicted_usage_keep and predicted_Tin_keep < l)):
                predicted_usage_keep = not predicted_usage_keep
                t_cycle_keep = 0.0
                dTin_keep = Tdiff_keep

            predicted_usage[...] = predicted_usage_keep

            # find the model that supports this point, make prediction using that model
            coeff_vector = self.mcs.process_prediction_usr_row({control:predicted_usage_keep}, "coefficients")

            if coeff_vector is not None:
                vector = [
                    self.g(t_cycle_keep) * np.exp(-self.SIGMA * t_cycle_keep),
                    Tout - predicted_Tin_keep,
                    T_structure_keep - predicted_Tin_keep,
                    time_of_day_dependence,
                    constant # constant
                ]
                Tdiff_keep = np.dot(coeff_vector, vector) + (1-self.g(t_cycle_keep)) * dTin_keep
            else:
                logger.info("No appropriate models found for timestep.")
                Tdiff_keep = 0.0
            t_cycle_keep += t_cycle_increment

        return prediction_set
