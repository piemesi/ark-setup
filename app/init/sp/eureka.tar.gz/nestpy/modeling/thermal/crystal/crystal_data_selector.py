import datetime
import pandas as pd
import logging

from ....converters import get_tz_aware_datetime
from ....groups.function_applicators import device_history_loader
from ....sql import lookup_device

logger = logging.getLogger(__name__)


class CrystalDataSelector(object):

    EVENT_TYPES = ['BufferedTemperature',
                   'CurrentState',
                   'UpdateStateResults',
                   'NewSetPoint',
                   'Weather']
    
    SAMPLE_TIME = datetime.timedelta(seconds=1)

    INDOOR_TEMPERATURE = 'IndoorTemperature'
    OUTDOOR_TEMPERATURE = 'OutdoorTemperature'
    HVAC_STATES = ['Stage1CoolState',
                   'Stage2CoolState',
                   'Stage1HeatState',
                   'Stage2HeatState',
                   'Stage3HeatState',
                   'Stage1AltHeatState',
                   'Stage2AltHeatState',
                   'AuxHeatState']

    def __init__(self, device, start_date, end_date):

        if isinstance(device, pd.Series):
            self.device = device
        else:
            self.device = lookup_device(device)
        self.start_date = start_date
        if self.start_date is not None:
            self.start_date = get_tz_aware_datetime(start_date)
        self.end_date = end_date
        if self.end_date is not None:
            self.end_date = get_tz_aware_datetime(end_date)

        self._data = None
        self._extract_data()

    def __repr__(self):
        return "<nestpy.CrystalDataSelector for '{}'>".format(self.device.mac_address)

    @staticmethod
    def _resample_and_fill_nan(data, sample_time, interpolation_method):

        if interpolation_method == 'time':
            data = data.resample('1S').interpolate(method='time')

        resampled_data = data.resample('{}S'.format(sample_time),
                                       how='last',
                                       closed='right').shift(1)[1:]

        if interpolation_method == 'zero':
            resampled_data = resampled_data.fillna(method='pad')

        return resampled_data

    def _extract_data(self):

        logger.info('{}: Loading and extracting data'.format(self.device.mac_address))

        if self._data is None:
            device_history = device_history_loader(self.device,
                                                   start_date=self.start_date,
                                                   end_date=self.end_date,
                                                   event_types=self.EVENT_TYPES,
                                                   index_by_sample_time=True,
                                                   to_local_time=True)

            if device_history is not None:
                indoor_temp = self._resample_and_fill_nan(device_history.BufferedTemperature.temperature,
                                                          sample_time=self.SAMPLE_TIME,
                                                          interpolation_method='time')
                indoor_temp.name = self.INDOOR_TEMPERATURE
                hvac_states = self._resample_and_fill_nan(device_history.UpdateStateResults[self.HVAC_STATES],
                                                          sample_time=self.SAMPLE_TIME,
                                                          interpolation_method='zero')

                outdoor_temp = self._resample_and_fill_nan(device_history.Weather.Temperature,
                                                           sample_time=self.SAMPLE_TIME,
                                                           interpolation_method='time')
                outdoor_temp.name = self.OUTDOOR_TEMPERATURE

                data = pd.concat([indoor_temp, hvac_states, outdoor_temp], axis=1)

                first_valid_index = max(min(device_history.BufferedTemperature.index),
                                        min(device_history.UpdateStateResults.index),
                                        min(device_history.Weather.index))
                last_valid_index = min(max(device_history.BufferedTemperature.index),
                                       max(device_history.UpdateStateResults.index),
                                       max(device_history.Weather.index))

                data = data[(data.index > first_valid_index) & (data.index < last_valid_index)]

                self._data = data[(data.index >= self.start_date) & (data.index < self.end_date)]

    def select_data(self, timestamp):
        return self._data.loc[timestamp]

    def select_input_data(self, timestamp):
        return self._data.loc[timestamp, self.HVAC_STATES + [self.OUTDOOR_TEMPERATURE]]

    def select_output_data(self, timestamp):
        return self._data.loc[timestamp, [self.INDOOR_TEMPERATURE]]
