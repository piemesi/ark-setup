import pandas as pd
import copy
import random

from .model import Model

import logging
logger = logging.getLogger(__name__)


class DummyModel(Model):
    """
    A simple implementation of the Model class.
    """

    def __init__(self):
        super(DummyModel, self).__init__()

    def __str__(self):
        return "Dummy Model"

    def train(self, training_set, gaps=None):
        super(DummyModel, self).train(training_set)

    def predict(self, prediction_set, prediction_type, control=None):
        super(DummyModel, self).predict(prediction_set, prediction_type, control)
        prediction_set_copy = copy.deepcopy(prediction_set)

        if prediction_type == "open":
            return self.open_loop_predict(prediction_set_copy)
        else:
            return self.close_loop_predict(prediction_set_copy, control)

    def open_loop_predict(self, prediction_set):
        temps = prediction_set.BufferedTemperature
        temps["predicted_temperature"] = None
        temps.predicted_temperature[0] = temps.temperature[0]

        states = prediction_set.UpdateStateResults

        for i in range(len(temps) - 1):
            if states.Stage1CoolState[i] == 1:
                temps.predicted_temperature[i + 1] = temps.predicted_temperature[i] - 0.1
            elif states.Stage1HeatState[i] == 1:
                temps.predicted_temperature[i + 1] = temps.predicted_temperature[i] + 0.1
            else:
                temps.predicted_temperature[i + 1] = temps.predicted_temperature[i]

        return prediction_set

    def close_loop_predict(self, prediction_set, control):
        prediction_set.BufferedTemperature["predicted_temperature"] = None
        prediction_set.BufferedTemperature.predicted_temperature[0] = \
            prediction_set.BufferedTemperature.temperature[0]

        event_data = pd.DataFrame(0,
                                  index=prediction_set.UpdateStateResults.index,
                                  columns=[control])

        prediction_set.add_event_data("predicted_usage", event_data)

        for i in range(len(prediction_set.BufferedTemperature) - 1):
            if control == "Stage1CoolState":
                if prediction_set.BufferedTemperature.predicted_temperature[i] < 20:
                    prediction_set.predicted_usage.Stage1CoolState[i] = 0
                elif prediction_set.BufferedTemperature.predicted_temperature[i] > 25:
                    prediction_set.predicted_usage.Stage1CoolState[i] = 1
                else:
                    if i != 0:
                        prediction_set.predicted_usage.Stage1CoolState[i] = \
                            prediction_set.predicted_usage.Stage1CoolState[i - 1]
                    else:
                        prediction_set.predicted_usage.Stage1CoolState[i] = 0
            elif control == "Stage1HeatState":
                if prediction_set.BufferedTemperature.predicted_temperature[i] < 20:
                    prediction_set.predicted_usage.Stage1HeatState[i] = 1
                elif prediction_set.BufferedTemperature.predicted_temperature[i] > 25:
                    prediction_set.predicted_usage.Stage1HeatState[i] = 0
                else:
                    if i != 0:
                        prediction_set.predicted_usage.Stage1HeatState[i] = \
                            prediction_set.predicted_usage.Stage1CoolState[i - 1]
                    else:
                        prediction_set.predicted_usage.Stage1HeatState[i] = 0
            else:
                logger.info("%s has no close loop prediction capability", control)
                prediction_set.usage_prediction[control][i] = 0

            prediction_set.BufferedTemperature.predicted_temperature[i + 1] = \
                prediction_set.BufferedTemperature.predicted_temperature[i] + \
                random.uniform(-0.5, 0.5)

        return prediction_set
