"""
Implementations of models for temperature prediction.

Also includes functions for pre-processing data into learnable states.
"""
import preprocessing

from .dummy_model import DummyModel
from .initial_rate_staged_model import InitialRateStagedModel
from .model import Model
from .model_controls_storage import ModelControlsStorage


def get_models():
    """
    Gets a list of available models.
    """
    return ["DummyModel", "InitialRateStagedModel"]
