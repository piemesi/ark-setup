"""
Functions for preprocessing event log data.
"""
# pylint: disable=no-member

import datetime
import numpy as np
import pandas as pd
import pytz
import scipy.interpolate

DEFAULT_EARLIEST_DATE = datetime.datetime(2011, 1, 1, tzinfo=pytz.utc)
DEFAULT_LATEST_DATE = datetime.datetime(2014, 1, 1, tzinfo=pytz.utc)
MIN_TIME_DELTA = datetime.timedelta(minutes=0)
UNSKEWED_TIME_STEP = datetime.timedelta(minutes=1)
MIN_GAP_LENGTH = datetime.timedelta(minutes=10)
DEFAULT_RESOLUTION_IN_MINUTES = 5 # minutes


# TODO: use TimeChanged or TimeShifted event logs to determine exactly how much
# skew was corrected
def linearize_times(device_data,
                    strategy="reskew",
                    time_column=None):
    """
    Linearizes times into a monotonically increasing series.

    This function is mainly useful for dealing with device data that may have
    been de-skewed by clock shifts, such that timestamps later in the data are
    chronologically before timestamps that appeared earlier in the data. This
    causes issues for reinterpolation.

    :param device_data:
        device data to reskew
    :type device_data:
        pandas.DataFrame

    :param strategy:
        the strategy to use when linearizing. Available strategies include:

        * reskew: re-skews time steps by shifting earlier times to be 1 minute
          after the most recent timestep. This strategy avoids losing data, but
          may cause data to be shifted from the actual time that it
          occurred.
        * drop: drops all times that overlap future times. Data is lost, but
          no timestamps are actually modified, thus the times that remain are
          as close as possible to the actual time the events occurred.

    :param time_column:
        the name of the column containing the times to linearize. If None, the
        current index column will be used.
    :type time_column:
        string
    """

    if time_column is not None:
        device_data = device_data.set_index(time_column)

    if strategy == "reskew":

        index_datetime = device_data.index.to_pydatetime()

        time_differences = np.diff(index_datetime)
        time_differences_reskew = time_differences - UNSKEWED_TIME_STEP
        time_differences_reskew[time_differences > MIN_TIME_DELTA] = datetime.timedelta(minutes=0)
        index_datetime[1:] = index_datetime[1:] - np.cumsum(time_differences_reskew)

        device_data = device_data.set_index(index_datetime)

    elif strategy == "drop":
        index_as_int = device_data.index.astype(np.int64)
        time_discontinuities = np.where(np.diff(index_as_int) <= 0)[0]

        if len(time_discontinuities) > 0:
            bad_index = np.hstack([
                np.where((index_as_int[:disc+1] <= index_as_int[disc]) & (index_as_int[:disc+1] >= index_as_int[disc+1]))[0]
                for disc in time_discontinuities
            ])
            device_data = device_data.drop(device_data.index[bad_index])

    else:
        raise RuntimeError("linearization strategy '%s' not understood/supported" % strategy)

    return device_data

def get_gap_intervals(bt_t, usr_t):
    """
    Determines where gaps occurred in the provided data.
    """

    gap_indexes = np.nonzero(np.diff(np.array(bt_t.astype(object))) > MIN_GAP_LENGTH)[0]
    return [(bt_t[gi], usr_t[usr_t > bt_t[gi+1]][0]) for gi in gap_indexes]

def extract_clean_thermodynamics_data(data,
                                      start_date=DEFAULT_EARLIEST_DATE,
                                      end_date=DEFAULT_LATEST_DATE,
                                      resolution_in_minutes=DEFAULT_RESOLUTION_IN_MINUTES):
    """
    Extracts and cleans Diamond thermodynamics data, such that it is ready for
    training and prediction.

    The operations performed include:

    * extract data between the specified start date and end date, with a buffer
      on each side
    * linearize temperature, HVAC control, and weather times
    * resample data to the specified resolution
    * find intervals where data was lost ("gaps")

    :return:
        a tuple containing:

        * a Diamond object that has been extracted and cleaned
        * a numpy array containing gap intervals

    :rtype:
        (Diamond, numpy.array)
    """

    start_early = start_date - datetime.timedelta(days=2)
    end_late = end_date + datetime.timedelta(days=2)

    # Linearize buffered temperatures
    bt = data.BufferedTemperature[start_early:end_late]

    if len(bt) == 0:
        raise ValueError("No buffered temperatures found in selected time range.")

    data.BufferedTemperature = linearize_times(bt, time_column="bucketTime")

    # Linearize HVAC states
    usr = data.UpdateStateResults[start_early:end_late]

    if len(usr) == 0:
        raise ValueError("No HVAC states found in selected time range.")

    data.UpdateStateResults = linearize_times(usr)

    # Linearize target temperatures
    rsr = data.RethinkStateResults[start_early:end_late]

    if len(rsr) == 0:
        raise ValueError("No target temperatures found in selected time range.")

    data.RethinkStateResults = linearize_times(rsr)

    # Linearize weather
    weather = data.Weather[start_early:end_late]

    if len(weather) == 0:
        raise ValueError("No weather data found in selected time range.")

    data.Weather = linearize_times(weather)

    # Find gaps where data was lost/is unavailable
    gaps = get_gap_intervals(data.BufferedTemperature.index, data.UpdateStateResults.index)

    gap_t = np.array([])
    bt = data.BufferedTemperature
    for g in gaps:
        gap_t = np.append(gap_t, bt.index[(bt.index > max(g[0], start_date)) & (bt.index < min(g[1], end_date))].to_pydatetime())

    resolution_as_string = str(resolution_in_minutes) + "T"
    data.BufferedTemperature = data.BufferedTemperature.resample(resolution_as_string, fill_method="pad", how="last", label="right")
    data.UpdateStateResults = data.UpdateStateResults.resample(resolution_as_string, fill_method="pad", how="last", label="right")

    data.RethinkStateResults = data.RethinkStateResults.resample(resolution_as_string, fill_method="pad", how="last", label="right")

    start_day = datetime.datetime(data.Weather.index[0].year, data.Weather.index[0].month, data.Weather.index[0].day)
    end_day = datetime.datetime(data.Weather.index[-1].year, data.Weather.index[-1].month, data.Weather.index[-1].day+1)

    weather_index_epoch = data.Weather.index.astype(np.int64)

    f1 = scipy.interpolate.interp1d(weather_index_epoch, data.Weather.Temperature, kind="nearest", bounds_error=False)

    weather_index_resampled_30_min_epoch = pd.date_range(start_day, end_day, freq="30Min", tz=data.Weather.index.tz).astype(np.int64)

    weather_resampled_30_min = f1(weather_index_resampled_30_min_epoch)

    f2 = scipy.interpolate.interp1d(weather_index_resampled_30_min_epoch, weather_resampled_30_min, kind="nearest", bounds_error=False)

    data.Weather = pd.DataFrame(index=data.BufferedTemperature.index)
    weather_index_resampled_5_min_epoch = data.Weather.index.astype(np.int64)

    data.Weather["Temperature"] = f2(weather_index_resampled_5_min_epoch)

    return data, gap_t
