class Model(object):
    """
    A base class for thermal models. All model implementations are expected
    to implement the train() and predict() functions.
    """

    def __init__(self):
        self.trained = False

    def train(self, training_set, gaps=None):
        """
        Trains the model using the providing training dataset.

        :param training_set: Diamond object containing data to train on
        :type training_set: nestpy.Diamond
        :param gaps: times at which the data contains gaps
        """
        self.trained = True

    def predict(self, prediction_set, prediction_type, control=None):
        """
        Predicts temperature and/or HVAC profiles throughout the provided
        prediction time using the existing trained model.

        The returned Diamond object should contain a BufferedTemperature
        DataFrame, which must contain a column named 'predicted_temperature',
        which is our estimate for the temperature at those times.

        If prediction_type == "close", the returned Diamond object must also
        contain a usage_prediction DataFrame, which must contain a column
        named param control, which is our prediction for the control at that
        time.

        This base implementation should be called at the beginning of the
        predict() function in implementing classes.

        :param prediction_set: prediction set of data
        :type prediction_set: nestpy.Diamond
        :param prediction_type: prediction type
        :type prediction_type: string ("open" or "close")
        :param control: the control type we are predicting (for close loop)
        :type control: string
        :returns: data containing predictions
        :rtype: Diamond
        """
        if not self.trained:
            raise Exception("Model has not been trained.")
        if prediction_type not in ["open", "close"]:
            raise Exception("prediction type '%s' not recognized." % (prediction_type))
