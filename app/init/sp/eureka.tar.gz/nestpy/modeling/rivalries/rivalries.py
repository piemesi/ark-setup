#!/usr/bin/env python
"""
Outputs energy usage summaries for rival metropolitan areas.

Given a configured list of areas, each of which is defined by a set of counties in states,
retrieve device_averages data (i.e. MICA Energy Reports), writing the resulting data
to a CSV file.


TODO: Optimize the number of queries by adding "where edition in (1, 2, 3)...group by edition"
"""
import os
from dateutil.relativedelta import relativedelta
import math

import pandas as pd
from matplotlib import pyplot as plt

from ... import sql
from ...geo.metropolitan_areas import MetropolitanAreas
from ... import fileutils

import logging
logger = logging.getLogger(__name__)


class Rivalries(object):

    def __init__(self, start_month, end_month, method='device'):
        self.db = sql.ProductionAnalyticsDatabase()
        self.start_month = start_month
        self.end_month = end_month
        self.areas = MetropolitanAreas().areas
        self.method = method

        logger.info("Calculating rivalry data for areas %s and month range [%s, %s]",
                    sorted(self.areas.keys()),
                    self.format_month(self.start_month),
                    self.format_month(self.end_month))

    def __str__(self):
        return "Rivalries calculator for areas %s and month range [%s, %s]" % (
            sorted(self.areas.keys()),
            self.format_month(self.start_month),
            self.format_month(self.end_month)
        )

    def query(self, name, **kwargs):
        query = open(fileutils.resource_path('rivalries', name)).read().format(**kwargs)
        logger.info("Running query: [%s]", query)
        return self.db.query(query)

    def get_devices_for_area(self, area_name):
        area_where_clause = self.area_where_clause(self.areas[area_name])
        return self.query("area_devices.sql", area_where_clause=area_where_clause, area=area_name)

    def get_device_averages_for_area(self, area, report_editions):
        """
        Loads device_averages data for a single area and the given report editions.
        """
        area_where_clause = self.area_where_clause(self.areas[area])
        return self.query("%s_averages.sql" % self.method,
                          editions=', '.join([str(edition_id) for edition_id in report_editions.id]),
                          area_where_clause=area_where_clause)

    def get_months(self):
        months = []
        month = self.start_month + relativedelta(months=0)
        while month <= self.end_month:
            months.append(month)
            month = month + relativedelta(months=1)
        return months

    def get_editions(self, months):
        logger.info("Finding report editions for months %s", [format(month) for month in months])
        editions = self.query('editions.sql',
                              months=', '.join(['"%s"' % str(month) for month in months]))
        return editions.drop_duplicates('start_date')

    def calculate_rivalry_data(self, area_white_list=None):
        """
        Loads device_averages data for each area.
        :param: area_white_list override the list of areas for which to calculate rivalries
        :return: rivalry summaries
        """

        area_summaries = None
        months = self.get_months()
        editions = self.get_editions(months)

        logger.debug("Using report editions %s", editions)
        if area_white_list is not None:
            area_names = area_white_list
        else:
            area_names = sorted(self.areas.keys())

        for area_name in area_names:
            logger.info("Calculating rivalry data for area %s", area_name)
            area_month_data = self.get_device_averages_for_area(area_name, editions)
            area_month_summary = pd.DataFrame(area_month_data)
            area_month_summary['area'] = area_name
            area_summaries = pd.concat([area_summaries, area_month_summary])

        # Convert temperatures to Fahrenheit
        for temperature_field in ['heating_night_setback',
                                  'outside_temp',
                                  'away_temperature_low',
                                  'heating_temp',
                                  'heating_min_temp',
                                  'heating_max_temp']:
            area_summaries[temperature_field] = area_summaries[temperature_field] * 9/5 + 32

        return area_summaries

    @staticmethod
    def plot_rivalry_summaries(area_summaries, ylim=[60, 80], output_path=None):

        for start_date, group in area_summaries.groupby('start_date'):
            title = "%s" % start_date
            low = min([group.heating_night_setback.min(), group.outside_temp.min()])
            high = max([group.heating_night_setback.max(), group.outside_temp.max()])

            axes = group[['area', 'heating_night_setback', 'outside_temp']].plot(kind='bar',
                                                                                 x='area',
                                                                                 subplots=True,
                                                                                 title=title)
            for ax in axes:
                ax.legend().set_visible(False)
                ax.set_ylim([math.ceil(low - 0.5 * (high - low)), math.ceil(high + 0.5 * (high - low))])

            if output_path is not None:
                plt.savefig(os.path.join(output_path, 'rivalries_%s.png' % start_date), bbox_inches='tight')

    @staticmethod
    def format_month(date):
        return date.strftime("%Y-%m")

    @staticmethod
    def area_where_clause(area):
        return " or ".join(
            [
                '(postal_codes.state_code="%s" and postal_codes.county in ("%s"))' % (
                    state_counties['state'],
                    '","'.join(state_counties['counties'])
                )
                for state_counties in area
            ]
        )

