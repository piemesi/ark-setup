# pylint: disable=maybe-no-member, no-member

import datetime
import numpy as np
import os
import pandas as pd
import matplotlib.pyplot as plt


TIER_LIST = ['ft', 'production']
_OFF_MODE_HEATING_TARGET_F = 40
_OFF_MODE_COOLING_TARGET_F = 105
_DEFAULT_HEATING_SCHEDULE_TEMP_F = 68
_DEFAULT_COOLING_SCHEDULE_TEMP_F = 75.2
_SAMPLING_RATE = '1min'

MIN_EARTH_TEMP = -127.
MAX_EARTH_TEMP = 135.

ALLOWABLE_MISSING_MINS = 30
MINUTES_PER_HOUR = 60.0


def extract_daily_hvac_runtimes(device_history, discard=True):
    """
    Extract the HVAC runtime for cooling and heating from the device history. The data coming out is index
    deduped. Only one entry per day.

    :param device_history: The device history to extract HVAC runtime for
    :param discard: Boolean for whether or not to discard days with missing EnergySummary data
    :returns: DataFrame that has columns for total cooling and heating time per day. Indexed by date.
    """
    energy_summary = device_history.EnergySummary
    energy_summary.index = pd.to_datetime(energy_summary.Today, unit='s', utc=True)
    energy_summary = energy_summary.tz_localize('UTC')
    energy_summary = energy_summary.tz_convert(energy_summary.TimeZoneFile[0])
    energy_summary['date'] = [x.date() for x in energy_summary.index]
    energy_summary = energy_summary.set_index('date')

    if discard:
        # Discard any days with 30 minutes or more of missing data.
        if any(energy_summary.MissingSeconds/MINUTES_PER_HOUR >= ALLOWABLE_MISSING_MINS):
            print('\nWarning: one or more days missing data in EnergySummary.')
            print(energy_summary.MissingSeconds[energy_summary.MissingSeconds/MINUTES_PER_HOUR >= ALLOWABLE_MISSING_MINS])
            print('\n')
        energy_summary = energy_summary[energy_summary.MissingSeconds/MINUTES_PER_HOUR < ALLOWABLE_MISSING_MINS]

    # TODO: this should be timezone aware. Need to fix this and propogate the change through the model.

    heat_runtime = energy_summary.TotalHeatOnTime/MINUTES_PER_HOUR  # Converting heat on time to minutes.
    cool_runtime = energy_summary.TotalCoolOnTime/MINUTES_PER_HOUR  # Converting cool on time to minutes.

    runtimes = pd.concat([heat_runtime, cool_runtime],
                         axis=1,
                         keys=['heating_minutes', 'cooling_minutes']).dropna()

    runtimes['index'] = runtimes.index
    runtimes = runtimes.drop_duplicates('index', take_last=True)
    del runtimes['index']

    return runtimes


def extract_all_time_series(device_history):
    """
    This creates a uniformly minute-sampled array of the relevant parameters of the device history.

    :param device_history: The device history to resample. Must be already converted to local time.
    :type device_history: nestpy.structures.diamond.Diamond
    :returns: Minute-sampled parameters of the device history.
    :rtype: pd.DataFrame
    """

    # Resample Outdoor Temp to the minute using linear interpolation. Filtering of bogus values done in Weather
    # structure device history.
    outdoor_temp = device_history.WeatherUndergroundHourly.Temperature
    outdoor_temp_1min = outdoor_temp.resample(_SAMPLING_RATE).interpolate()

    # Get the device weather outdoor temp. Have to filter out bogus values.
    def outdoor_temp_filter(temperature):
        if MIN_EARTH_TEMP < temperature < MAX_EARTH_TEMP:
            return temperature
        else:
            return np.nan

    filtered_device_outdoor_temp = device_history.Weather.Temperature.map(outdoor_temp_filter)
    device_outdoor_temp_1min = filtered_device_outdoor_temp.resample(_SAMPLING_RATE).interpolate()

    # Down-sample Indoor Temp to the minute.
    indoor_temp = pd.Series(device_history.BufferedTemperature.temperature.values,
                            index=device_history.BufferedTemperature.bucketTime.values)
    indoor_temp_1min = indoor_temp.resample(_SAMPLING_RATE).interpolate()

    # Resample and create all the heating time series.
    heating_df = _extract_mode_time_series(device_history, 'Heating')
    heating_df.columns = ['heating_{}'.format(x) for x in heating_df.columns]

    # Resample and create all the cooling time series.
    cooling_df = _extract_mode_time_series(device_history, 'Cooling')
    cooling_df.columns = ['cooling_{}'.format(x) for x in cooling_df.columns]

    non_mode_time_series_df = pd.concat([outdoor_temp_1min, device_outdoor_temp_1min, indoor_temp_1min],
                                        axis=1,
                                        keys=['outdoor_temp', 'outdoor_device_temp', 'indoor_temp'])
    all_time_series_df = pd.concat([non_mode_time_series_df, heating_df, cooling_df], axis=1)

    return all_time_series_df


def _extract_mode_time_series(device_history, hvac_mode='Heating'):
    """
    Helper function that extracts out the feature time-series from a device history.

    :param device_history: Diamond device history.
    :param hvac_mode:  Mode for which to extract time series for. Valid values are "Heating" and "Cooling"
    :return: A dataframe with all the relevant feature time series including target temperature, scheduled temp,
    adhoc target temperature, away target temperature, etc.
    """

    assert hvac_mode in ['Heating', 'Cooling']

    # Set mode-dependent constants.
    if hvac_mode == 'Heating':
        default_schedule_temp = _DEFAULT_HEATING_SCHEDULE_TEMP_F
        away_col = 'AwayTemperatureLow'
        off_target_temp = _OFF_MODE_HEATING_TARGET_F
        hvac_state = device_history.UpdateStateResults.Stage1HeatState
    elif hvac_mode == 'Cooling':
        default_schedule_temp = _DEFAULT_COOLING_SCHEDULE_TEMP_F
        away_col = 'AwayTemperatureHigh'
        off_target_temp = _OFF_MODE_COOLING_TARGET_F
        hvac_state = device_history.UpdateStateResults.Stage1CoolState

    # --------------------------------------------------------------------------------------------------------------
    # Create the scheduled temperature resampled time series.
    # --------------------------------------------------------------------------------------------------------------
    if hasattr(device_history, 'SetPoints'):
        sched_temp = device_history.SetPoints[device_history.SetPoints.Category == 'Schedule'][hvac_mode]
        # Set first schedule setpoint in case there isn't one.
        sched_temp = sched_temp.append(pd.Series(default_schedule_temp, index=[device_history.earliest_date]))
    else:
        sched_temp = pd.Series([default_schedule_temp, default_schedule_temp],
                               index=[device_history.earliest_date, device_history.latest_date])

    sched_temp_1min = fillforward_series_and_cover_extent(sched_temp,
                                                           device_history.earliest_date,
                                                           device_history.latest_date)
    # Fix the last setpoint.
    sched_temp_1min.iloc[-1] = sched_temp_1min[-2]

    # --------------------------------------------------------------------------------------------------------------
    # Create the adhoc target time series.
    # --------------------------------------------------------------------------------------------------------------
    if hasattr(device_history, 'SetPoints'):
        setpoints_df = device_history.SetPoints.copy()
        setpoints_df['Category'] = setpoints_df['Category'].fillna('Dial')
        setpoints_df.loc[setpoints_df[(setpoints_df.Category != 'Thermozilla') &
                                      (setpoints_df.Category != 'Dial')].index, hvac_mode] = 0.
        adhoc_target_temp = setpoints_df[hvac_mode]
    else:
        adhoc_target_temp = pd.Series([np.nan, np.nan],
                                      index=[device_history.earliest_date, device_history.latest_date])
    adhoc_target_temp_1min = fillforward_series_and_cover_extent(adhoc_target_temp,
                                                                  device_history.earliest_date,
                                                                  device_history.latest_date)
    adhoc_target_temp_1min[adhoc_target_temp_1min == 0] = np.nan

    # --------------------------------------------------------------------------------------------------------------
    # Create the away target temp time series.
    # --------------------------------------------------------------------------------------------------------------
    # Note: 1 is manual away, 2 is auto away
    away_target_temp = device_history.CurrentState[['AwayMode', away_col]]
    away_target_temp_1min = fillforward_series_and_cover_extent(away_target_temp[away_col],
                                                                 device_history.earliest_date,
                                                                 device_history.latest_date)
    away_type_1min = fillforward_series_and_cover_extent(away_target_temp['AwayMode'],
                                                          device_history.earliest_date,
                                                          device_history.latest_date)
    away_type_1min[away_type_1min == 0] = np.nan

    # Fill in target temp as NaN when not in away mode.
    away_target_temp_1min[away_type_1min[pd.isnull(away_type_1min)].index] = np.nan

    # --------------------------------------------------------------------------------------------------------------
    # Create the off mode target temp time series.
    # --------------------------------------------------------------------------------------------------------------
    # Note: 1 is on, 0 is off
    off_mode = device_history.CurrentState['SystemMode']
    off_mode_1min = fillforward_series_and_cover_extent(off_mode,
                                                         device_history.earliest_date,
                                                         device_history.latest_date)

    off_target_temp_1min = pd.Series([off_target_temp] * len(off_mode_1min))
    off_target_temp_1min.index = off_mode_1min.index
    off_target_temp_1min[off_mode_1min[off_mode_1min == 1].index] = np.nan
    off_target_temp_1min[pd.isnull(off_mode_1min)] = np.nan

    # --------------------------------------------------------------------------------------------------------------
    # Create the resampled HVAC consumption.
    # --------------------------------------------------------------------------------------------------------------
    hvac_1min = fillforward_series_and_cover_extent(hvac_state,
                                                     device_history.earliest_date,
                                                     device_history.latest_date)

    # --------------------------------------------------------------------------------------------------------------
    # Create the schedule mask, create the return dataframe, and mask appropriately
    # --------------------------------------------------------------------------------------------------------------
    schedule_mode = device_history.CurrentState['ScheduleMode']
    schedule_mode_1min = fillforward_series_and_cover_extent(schedule_mode,
                                                              device_history.earliest_date,
                                                              device_history.latest_date)
    # This is an array of NaNs that we'll fill with 1's where the heating or cooling schedule is valid
    schedule_mask_1min = pd.Series([np.nan] * len(schedule_mode_1min), index=schedule_mode_1min.index)

    if hvac_mode == 'Heating':
        schedule_mask_1min[(schedule_mode_1min == 0) | (schedule_mode_1min == 2)] = 1.
    if hvac_mode == 'Cooling':
        schedule_mask_1min[(schedule_mode_1min == 1) | (schedule_mode_1min == 2)] = 1.

    mode_time_series_df = pd.concat([sched_temp_1min, adhoc_target_temp_1min, away_target_temp_1min,
                                     off_target_temp_1min, hvac_1min, away_type_1min],
                                    axis=1, keys=['scheduled_temp', 'adhoc_target', 'away_target', 'off_target',
                                                  'hvac', 'away_type'])

    mode_time_series_df = mode_time_series_df*schedule_mask_1min

    return mode_time_series_df


def fillforward_series_and_cover_extent(timeseries, earliest_date, latest_date):
    """
    Helper method that resamples the time series by filling forward and also ensures that it extends from
    the earliest date to the latest date.  The latest date is made by filling the last value forward till the end.
    The beginning of the time series is padded with NaNs.

    :param timeseries: DataFrame or Series object to fill forward.
    :param earliest_date: Earliest date to put in series.  The series is padded with NaNs until the first value.
    :param latest_date: Latest date to put in series.  The final value is filled forward until this date.
    :return:
    """
    if earliest_date not in timeseries.index:
        timeseries = timeseries.append(pd.Series(np.nan, index=[earliest_date]))

    # Gotta sort by index before extending last point to end
    timeseries = timeseries.sort_index()
    timeseries = timeseries.append(pd.Series(timeseries.iloc[-1], index=[latest_date]))

    timeseries = timeseries.astype(float)
    ts_1min = timeseries.resample(_SAMPLING_RATE, fill_method='ffill', how='last')
    return ts_1min


def calculate_target_temp(all_time_series_df):
    """
    Method to create the target temperature resampled time series from existing data frame of time series. Target
    temperature will be the adhoc, away, or off target temperatures when in one of those modes, and schedule otherwise.
    If in two modes simultaneously, off takes precedence over away and adhoc, and away takes precedence over adhoc.

    :param all_time_series_df: DataFrame object returned from extract_all_time_series.
    :return: Time series for heating and cooling target temperatures.
    """
    mode_prefixes = ['heating_', 'cooling_']
    return_df = pd.DataFrame()

    for prefix in mode_prefixes:

        # Initialize target to scheduled temp.
        target_temp_1min = (all_time_series_df[prefix + 'scheduled_temp']).copy()

        adhoc_target_temp_1min = all_time_series_df[prefix + 'adhoc_target']
        away_target_temp_1min = all_time_series_df[prefix + 'away_target']
        off_target_temp_1min = all_time_series_df[prefix + 'off_target']

        adhoc_times = adhoc_target_temp_1min[pd.notnull(adhoc_target_temp_1min)]
        away_times = away_target_temp_1min[pd.notnull(away_target_temp_1min)]
        off_times = off_target_temp_1min[pd.notnull(off_target_temp_1min)]

        # Overwrite target (currently scheduled) temp when in a different modes, in order of precedence (low to high).
        target_temp_1min[adhoc_times.index] = adhoc_times
        target_temp_1min[away_times.index] = away_times
        target_temp_1min[off_times.index] = off_times

        return_df[prefix + 'target_temp'] = target_temp_1min.copy()

    return return_df


def clip_series_to_date_range(time_series, start_date, end_date):
    """
    Method to pare down a time series Series or DataFrame to a specific time range.

    :param time_series: The time series to be clipped.
    :type time_series: pd.Series or pd.DataFrame
    :param start_date: Start of date range.
    :type start_date: str
    :param end_date: End of date range.
    :type end_date: str
    :returns: time_series with indices within inputted range
    :rtype: pd.DataFrame
    """
    start_date = pd.to_datetime(start_date)
    end_date = pd.to_datetime(end_date) + datetime.timedelta(1)
    # If the indices are times, localize the start and end times with the timezone. This is the case for the standard
    # time series data.
    if type(time_series.index[0]) != datetime.date:
        tz = time_series.index[0].tz
        start_date = start_date.tz_localize(tz)
        end_date = end_date.tz_localize(tz)
    # If we are clipping the hvac runtime time series, don't need to localize, as it is already aggregated by day.
    else:
        time_series.index = pd.to_datetime(time_series.index)
    clipped_time_series = time_series[time_series.index >= start_date]
    clipped_time_series = clipped_time_series[clipped_time_series.index < end_date]

    return clipped_time_series


def get_hvac_mode_data(time_series_df, hvac_mode):
    """
    Return time series data for only particular mode.
    :param time_series_df: Full time series DataFrame.
    :param hvac_mode: Requested mode.
    :return: Time series DataFrame for which device is in hvac_mode.
    """
    assert hvac_mode in ['Heating', 'Cooling', 'Range']
    if hvac_mode == 'Heating':
        hvac_mode_data_df = time_series_df[pd.notnull(time_series_df['heating_scheduled_temp']) &
                                           pd.isnull(time_series_df['cooling_scheduled_temp'])]
    elif hvac_mode == 'Cooling':
        hvac_mode_data_df = time_series_df[pd.notnull(time_series_df['cooling_scheduled_temp']) &
                                           pd.isnull(time_series_df['heating_scheduled_temp'])]
    elif hvac_mode == 'Range':
        hvac_mode_data_df = time_series_df[pd.notnull(time_series_df['cooling_scheduled_temp']) &
                                           pd.notnull(time_series_df['heating_scheduled_temp'])]
    return hvac_mode_data_df


def assign_range_mode(range_df):
    """
    Assign range mode observations to either heating or cooling mode based on distance to heating / cooling targets.
    :param range_df: Time series DataFrame of observations in range mode
    :return: Two time series DataFrames correspond to heating and cooling.
    """
    range_targets = calculate_target_temp(range_df)
    range_targets['indoor_temp'] = range_df.loc[range_targets.index]['indoor_temp']

    # Compare indoor temperature to target temperatures to make appropriate assignment
    range_targets['midpoint'] = (range_targets.cooling_target_temp + range_targets.heating_target_temp) / 2
    cooling_targets = range_targets[range_targets.indoor_temp >= range_targets.midpoint]
    heating_targets = range_targets[range_targets.indoor_temp < range_targets.midpoint]

    assert (len(cooling_targets) + len(heating_targets)) == len(range_targets)

    heating_df = range_df.loc[heating_targets.index]
    cooling_df = range_df.loc[cooling_targets.index]

    # NaN out data for other mode.
    for col in ['scheduled_temp', 'adhoc_target', 'away_target', 'off_target', 'away_type']:
        heating_df['cooling_' + col] = np.nan
        cooling_df['heating_' + col] = np.nan

    assert (len(cooling_df) + len(heating_df)) == len(range_df)
    assert len(heating_df[pd.notnull(heating_df.heating_scheduled_temp) &
                          pd.notnull(heating_df.cooling_scheduled_temp)]) == 0
    assert len(cooling_df[pd.notnull(cooling_df.heating_scheduled_temp) &
                          pd.notnull(cooling_df.cooling_scheduled_temp)]) == 0

    return heating_df, cooling_df


def split_heat_cool_and_assign_range_mode(time_series):
    """
    Split time series DataFrame into two DataFrames corresponding to heating and cooling modes. Range mode is assigned
    to one or the other.
    """
    time_series_df = time_series.copy()
    # Get rid of observations that are in neither heating or cooling mode.
    time_series_df = time_series_df[pd.notnull(time_series_df.heating_scheduled_temp) |
                                    pd.notnull(time_series_df.cooling_scheduled_temp)]

    # Separate time series by mode
    heating_df = get_hvac_mode_data(time_series_df, 'Heating')
    cooling_df = get_hvac_mode_data(time_series_df, 'Cooling')
    range_df = get_hvac_mode_data(time_series_df, 'Range')
    heating_from_range_df, cooling_from_range_df = assign_range_mode(range_df)

    # Aggregate heating and cooling data frames
    heating_df = combine_and_sort_df(heating_df, heating_from_range_df)
    cooling_df = combine_and_sort_df(cooling_df, cooling_from_range_df)

    assert (len(heating_df) + len(cooling_df)) == len(time_series_df)

    return heating_df, cooling_df


def combine_and_sort_df(df_1, df_2):
    """
    Combine two DataFrames of observations.
    (Common use case: combine heating and cooling DataFrames into single time series DataFrame.)
    """
    return_df = pd.concat([df_1, df_2])
    return_df = return_df.sort()
    return return_df


def eliminate_range_mode(time_series_df):
    """
    Eliminate range mode from full time series DataFrame, and return full time series DataFrame.
    """
    heating_df, cooling_df = split_heat_cool_and_assign_range_mode(time_series_df)
    return_time_series_df = combine_and_sort_df(heating_df, cooling_df)

    return return_time_series_df

def events_to_load():
    """Return the list of events needed to analyze the actions for this device."""
    return ['Weather', 'BufferedTemperature', 'CurrentState', 'UpdateStateResults', 'EnergySummary', 'NewSetPoint']

def plot_time_series(time_series, mac_address, start_date, end_date, save_dir=None, temps_in_f=True):
    """
    Plot time series data (returned from extract_all_time_series) for given date range (without blames). Time series
    must also include target temperatures (returned from calculate_target_temp).
    :param time_series: Time series DataFrame with data for both cooling and heating. Must include the target temps.
    :param mac_address: Device mac address.
    :param start_date: Start of date range.
    :param end_date: End of date range.
    :param save_dir: Directory where plots should be saved. If none provided, plot is displayed instead.
    :param temps_in_f: whether or not time series temperature data is in Fahrenheit; assumed true if not specified.
    :return:
    """
    plt.figure(figsize=(20, 7))
    regular_fields = ['outdoor_temp', 'indoor_temp', 'heating_scheduled_temp', 'heating_target_temp',
                      'cooling_scheduled_temp', 'cooling_target_temp']
    bold_fields = ['outdoor_temp', 'heating_target_temp', 'cooling_target_temp']

    plt.suptitle(mac_address + ' (' + start_date + ', ' + end_date + ')', fontsize=12)

    for f in regular_fields:
            if f in bold_fields:
                lw = 2
            else:
                lw = 1
            plt.plot(time_series.index, time_series[f], label=f, linewidth=lw)

    if temps_in_f:
        temp_range = [-20, 100]
    else:
        temp_range = [-30, 40]

    schedule_mode_constant = 2
    adjustment_mode_constant = 4
    alpha = 0.2

    plt.fill_between(time_series.index,
                     temp_range[0],
                     temp_range[1],
                     where=(time_series['heating_hvac'] == 1),
                     color='Red',
                     label='heat_stage1',
                     alpha=alpha)
    plt.fill_between(time_series.index,
                     temp_range[0],
                     temp_range[1],
                     where=(time_series['cooling_hvac'] == 1),
                     color='Blue',
                     label='cool_stage1',
                     alpha=alpha)
    plt.fill_between(time_series.index,
                     temp_range[0],
                     temp_range[0] + adjustment_mode_constant,
                     where=(pd.notnull(time_series['cooling_adhoc_target'])) | pd.notnull(time_series['heating_adhoc_target']),
                     color='Gold')
    plt.fill_between(time_series.index,
                     temp_range[0],
                     temp_range[0] + adjustment_mode_constant,
                     where=(time_series['heating_away_type'] == 1),
                     color='DarkGray')
    plt.fill_between(time_series.index,
                     temp_range[0],
                     temp_range[0] + adjustment_mode_constant,
                     where=(time_series['cooling_away_type'] == 1),
                     color='DarkGray')
    plt.fill_between(time_series.index,
                     temp_range[0],
                     temp_range[0] + adjustment_mode_constant,
                     where=(time_series['heating_away_type'] == 2),
                     color='Gray')
    plt.fill_between(time_series.index,
                     temp_range[0],
                     temp_range[0] + adjustment_mode_constant,
                     where=(time_series['cooling_away_type'] == 2),
                     color='Gray')
    plt.fill_between(time_series.index,
                     temp_range[0],
                     temp_range[0] + adjustment_mode_constant,
                     where=(pd.notnull(time_series['heating_off_target']) |
                      pd.notnull(time_series['cooling_off_target'])),
                     color='Black')
    plt.fill_between(time_series.index,
                     temp_range[0],
                     temp_range[0] + schedule_mode_constant,
                     where=(pd.notnull(time_series['cooling_scheduled_temp'])),
                     color='LightBlue')
    plt.fill_between(time_series.index,
                     temp_range[0],
                     temp_range[0] + schedule_mode_constant,
                     where=(pd.notnull(time_series['heating_scheduled_temp'])),
                     color='IndianRed')
    plt.fill_between(time_series.index,
                     temp_range[0],
                     temp_range[0] + schedule_mode_constant,
                     where=(pd.notnull(time_series['heating_scheduled_temp']) & pd.notnull(time_series['cooling_scheduled_temp'])),
                     color='Purple')

    plt.ylim(temp_range)

    plt.legend(bbox_to_anchor=(1.01, 1), loc=2, borderaxespad=0., fontsize=8)

    plt.text(0.96, 0.24, "Off", color='Black', transform=plt.gcf().transFigure)
    plt.text(0.96, 0.22, "Adhoc", color='Gold', transform=plt.gcf().transFigure)
    plt.text(0.96, 0.20, "Manual away", color='DarkGray', transform=plt.gcf().transFigure)
    plt.text(0.96, 0.18, "Auto away", color='Gray', transform=plt.gcf().transFigure)
    plt.text(0.96, 0.16, "Cooling", color='LightBlue', transform=plt.gcf().transFigure)
    plt.text(0.96, 0.14, "Heating", color='IndianRed', transform=plt.gcf().transFigure)

    if save_dir is not None:
        plt.savefig(os.path.join(save_dir, 'time_series_{}_{}_{}.png'.format(mac_address, start_date, end_date)),
                    bbox_inches='tight')
    else:
        plt.show()
    plt.close()
