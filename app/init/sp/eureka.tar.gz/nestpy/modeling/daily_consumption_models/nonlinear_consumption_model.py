# pylint: disable=maybe-no-member, no-member, no-name-in-module

import os
import numpy as np
from pandas import DataFrame, Series
from scipy.optimize import minimize
import statsmodels.api as sm
import matplotlib.pyplot as plt

from consumption_model import ConsumptionModel
import consumption_model_utilities as cmu

MAX_FLOAT = 15
MINUTES_IN_DAY = 60*24


class NonlinearConsumptionModel(ConsumptionModel):

    def __init__(self, heating_coefficients, cooling_coefficients, training_results):
        super(NonlinearConsumptionModel, self).__init__(heating_coefficients, cooling_coefficients, training_results)

    @classmethod
    def create_trained_model(cls, features, runtimes):
        """
        Factory method to create a trained nonlinear model from a training set.
        :param features: Time series as created by consumption_model_utilities.extract_all_time_series()
        :param runtimes: Time series of heating and cooling minutes as created by
        consumption_model_utilities.extract_daily_hvac_runtimes()
        :return: ConsumptionModel
        """
        # Up front calculations: get the target temp and create a date column
        target_temp = cmu.calculate_target_temp(features)
        features['date'] = features.index.date
        # Cut to same indices
        indices = set(features.date).intersection(set(runtimes.index))
        criterion = features['date'].apply(lambda x: x in indices)
        features = features[criterion]

        # Get features and runtimes for heating and cooling
        heating_feature_df = NonlinearConsumptionModel._create_daily_heating_features(features, target_temp)
        cooling_feature_df = NonlinearConsumptionModel._create_daily_cooling_features(features, target_temp)

        # Cut to same indices as feature_dfs.
        heating_runtime_df = runtimes.ix[set(runtimes.index).intersection(set(heating_feature_df.index))].sort()
        cooling_runtime_df = runtimes.ix[set(runtimes.index).intersection(set(cooling_feature_df.index))].sort()

        training_results = {}

        # Fitting of nonlinear model for heating. Initialize the parameters using linear fit.
        heating_features = heating_feature_df['positive_heating_demand']
        heating_features = sm.add_constant(heating_features)
        heating_model = sm.OLS(heating_runtime_df['heating_minutes'], heating_features).fit()
        theta0 = heating_model.params

        # If the OLS fails and gives NaNs for some reason, then initialize to zero
        if np.any(np.isnan(theta0)):
            theta0 = Series({'const': 0, 'positive_heating_demand': 0})

        # Objective function for optimization.
        def heating_mse(theta):
            err = (heating_runtime_df['heating_minutes'] -
                   NonlinearConsumptionModel._predict_heating_from_features(theta, heating_features))
            mse = np.square(err).sum()
            return mse

        # Call to scipy optimization toolbox to fine optimal coefficients.
        heating_results = minimize(heating_mse, theta0, method='L-BFGS-B', options={'disp': True})
        heating_theta_star = heating_results.x

        # Store Heating Training Parameters
        training_results['heating_nonzero_obs'] = heating_features[heating_features.positive_heating_demand > 0].count().ix[0]
        training_results['heating_training_mse'] = heating_results.fun
        training_results['heating_training_features'] = heating_features
        training_results['heating_training_obs'] = heating_runtime_df['heating_minutes']
        training_results['heating_training_predictions'] =\
            NonlinearConsumptionModel._predict_heating_from_features(heating_theta_star, heating_features)
        training_results['heating_wMAPE'] = (sum(abs(training_results['heating_training_predictions'] -
                                                     training_results['heating_training_obs']))
                                             / sum(abs(training_results['heating_training_obs'])))
        training_results['heating_thetas'] = heating_theta_star

        # Fitting of nonlinear model for cooling. Initialize the parameters using linear fit.
        cooling_features = cooling_feature_df['positive_cooling_demand']
        cooling_features = sm.add_constant(cooling_features)
        cooling_model = sm.OLS(cooling_runtime_df['cooling_minutes'], cooling_features).fit()
        theta0 = cooling_model.params

        # If the OLS fails and gives NaNs for some reason, then initialize to zero
        if np.any(np.isnan(theta0)):
            theta0 = Series({'const': 0, 'positive_cooling_demand': 0})

        def cooling_mse(theta):
            err = (cooling_runtime_df['cooling_minutes'] -
                   NonlinearConsumptionModel._predict_cooling_from_features(theta, cooling_features))
            mse = np.square(err).sum()
            return mse

        cooling_results = minimize(cooling_mse, theta0, method='L-BFGS-B', options={'disp': True})
        cooling_theta_star = cooling_results.x

        # Store Cooling Training Parameters
        training_results['cooling_nonzero_obs'] = cooling_features[cooling_features.positive_cooling_demand > 0].count().ix[0]
        training_results['cooling_training_mse'] = cooling_results.fun
        training_results['cooling_training_features'] = cooling_features
        training_results['cooling_training_obs'] = cooling_runtime_df['cooling_minutes']
        training_results['cooling_training_predictions'] =\
            NonlinearConsumptionModel._predict_cooling_from_features(cooling_theta_star, cooling_features)
        training_results['cooling_wMAPE'] = (sum(abs(training_results['cooling_training_predictions']
                                                     - training_results['cooling_training_obs']))
                                             / sum(abs(training_results['cooling_training_obs'])))
        training_results['cooling_thetas'] = cooling_theta_star

        cm = NonlinearConsumptionModel(heating_theta_star, cooling_theta_star, training_results)
        return cm

    @classmethod
    def _create_daily_heating_features(cls, multiday_time_series, target_temp=None, heating_constant_float=0,):
        """
        Class method to create the daily heating features from a set of time series.
        :param multiday_time_series: Time series for multiple days as generated by the consumption model utilities.
        :param target_temp: target temperatures from cmu.calculate_target_temp
        :param heating_constant_float: heating float term to use for device
        :return: DataFrame with date as index and columns for each of the computed features.  Feature names should match
        the the parameter names in the model.
        """
        if target_temp is None:
            target_temp = cmu.calculate_target_temp(multiday_time_series)

        # Compute the positive and negative heating consumption per day.
        heating_demand = target_temp.heating_target_temp - (multiday_time_series.outdoor_temp + heating_constant_float)
        positive_heating_demand = heating_demand.apply(lambda x: x if x >= 0 else 0)

        # Compute total demand for each day and create DataFrame to return.
        heating_demand = DataFrame({'positive_heating_demand': positive_heating_demand,
                                    'date': multiday_time_series.date})
        features = heating_demand.groupby('date').sum()

        # Filter to only the days we have complete data for
        num_minutes = heating_demand.groupby('date').count()['positive_heating_demand']
        dates_with_enough_data = num_minutes[num_minutes >= MINUTES_IN_DAY].index

        return features.ix[dates_with_enough_data]

    @classmethod
    def _create_daily_cooling_features(cls, multiday_time_series, target_temp=None, cooling_constant_float=MAX_FLOAT):
        """
        Class method to create the daily cooling features from a set of time series.
        :param multiday_time_series: Time series for multiple days as generated by the consumption model utilities.
        :param target_temp: target temperatures from cmu.calculate_target_temp
        :param cooling_constant_float: heating float term to use for device
        :return: DataFrame with date as index and columns for each of the computed features.  Feature names should match
        the the parameter names in the model.
        """
        if target_temp is None:
            target_temp = cmu.calculate_target_temp(multiday_time_series)

        # Compute the positive and negative heating consumption per day.
        cooling_demand = (multiday_time_series.outdoor_temp + cooling_constant_float) - target_temp.cooling_target_temp
        positive_cooling_demand = cooling_demand.apply(lambda x: x if x >= 0 else 0)

        # Compute total demand for each day and create DataFrame to return.
        cooling_demand = DataFrame({'positive_cooling_demand': positive_cooling_demand,
                                    'date': multiday_time_series.date})
        features = cooling_demand.groupby('date').sum()

        # Filter to only the days we have complete data for
        num_minutes = cooling_demand.groupby('date').count()['positive_cooling_demand']
        dates_with_enough_data = num_minutes[num_minutes >= MINUTES_IN_DAY].index

        return features.ix[dates_with_enough_data]

    @classmethod
    def _predict_heating_from_features(cls, theta_heating, features):
        """
        Class method that predicts the heating minutes using the given parameters and features.
        :param theta_heating: Array of parameters for heating model.
        :param features: Series of heating features.
        :return: Series of predicted cooling minutes.
        """
        predicted_heating_minutes = np.maximum(theta_heating[0]
                                               + theta_heating[1] * features['positive_heating_demand'], 0)
        return predicted_heating_minutes

    @classmethod
    def _predict_cooling_from_features(cls, theta_cooling, features):
        """
        Class method that predicts the cooling minutes using the given parameters and features.
        :param theta_cooling: Array of parameters.
        :param features: Series of features.
        :return: Series of predicted cooling minutes.
        """
        predicted_cooling_minutes = np.maximum(theta_cooling[0]
                                               + theta_cooling[1] * features['positive_cooling_demand'], 0)
        return predicted_cooling_minutes

    def predict_consumption(self, multiday_time_series, target_temp=None):
        """
        Predicts heating and cooling consumption for multiple contiguous days.
        :param multiday_time_series: Time series that includes all the days of interest.
        :return: DataFrame with date as index and two columns "heating" and "cooling" representing the consumption
        in minutes.  There will be multiple rows for multiple dates.
        """
        # TODO: Check that the multiday time-series contains entire days and no partial days.

        if 'date' not in multiday_time_series:
            multiday_time_series['date'] = multiday_time_series.index.date

        if target_temp is None:
            target_temp = cmu.calculate_target_temp(multiday_time_series)

        assert all(target_temp.index == multiday_time_series.index)

        # Create the features
        heating_feature_df = NonlinearConsumptionModel._create_daily_heating_features(multiday_time_series, target_temp)
        cooling_feature_df = NonlinearConsumptionModel._create_daily_cooling_features(multiday_time_series, target_temp)

        # Predict Heating
        heating_features = heating_feature_df['positive_heating_demand']
        heating_features = sm.add_constant(heating_features)
        predicted_heat = NonlinearConsumptionModel._predict_heating_from_features(self.heating_coefficients,
                                                                                  heating_features)

        # Predict Cooling
        cooling_features = cooling_feature_df['positive_cooling_demand']
        cooling_features = sm.add_constant(cooling_features)
        predicted_cool = NonlinearConsumptionModel._predict_cooling_from_features(self.cooling_coefficients,
                                                                                  cooling_features)

        # Stitch together the heating and cooling predictions into the expected DataFrame and return
        return_df = DataFrame({'heating': predicted_heat, 'cooling': predicted_cool})
        return return_df

    def plot_training_results(self, device_id, output_folder):
        """
        Plot the results of training.  This creates appropriate scatter plots of predicted vs. observed data for heating
        and cooling.
        :param device_id: Device id for the model.
        :param output_folder: Output folder to save the figure to.
        :return: None.
        """
        # Plotting for debug
        plt.figure()
        plt.plot(self.training_results['heating_training_features']['positive_heating_demand'],
                 self.training_results['heating_training_obs'], 'x')
        plt.plot(self.training_results['heating_training_features']['positive_heating_demand'],
                 self.training_results['heating_training_predictions'], 'o')
        plt.grid('on')
        plt.xlabel('Positive Heating Demand')
        plt.ylabel('Heating Minutes')
        plt.savefig(os.path.join(output_folder, "{}_heating.png".format(device_id)))

        # Plotting for debug
        plt.figure()
        plt.plot(self.training_results['cooling_training_features']['positive_cooling_demand'],
                 self.training_results['cooling_training_obs'], 'x')
        plt.plot(self.training_results['cooling_training_features']['positive_cooling_demand'],
                 self.training_results['cooling_training_predictions'], 'o')
        plt.grid('on')
        plt.xlabel('Positive Cooling Demand')
        plt.ylabel('Cooling Minutes')
        plt.savefig(os.path.join(output_folder, "{}_cooling.png".format(device_id)))
        plt.close('all')
