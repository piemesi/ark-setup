# pylint: disable=maybe-no-member, no-member, no-name-in-module

import numpy as np
from pandas import DataFrame, Series
from scipy.optimize import minimize
import statsmodels.api as sm

from .nonlinear_consumption_model import NonlinearConsumptionModel
from . import consumption_model_utilities as cmu

INITIAL_FLOAT_VALUE = 15
MINUTES_IN_DAY = 60*24


class ConstantFloatModel(NonlinearConsumptionModel):

    def __init__(self, heating_coefficients, cooling_coefficients, training_results):
        super(ConstantFloatModel, self).__init__(heating_coefficients, cooling_coefficients, training_results)

    @classmethod
    def _initialize_theta(cls, runtimes, features, mode='heating'):
        """Initialize the demand coefficient"""
        model = sm.OLS(runtimes, features).fit()
        theta0 = model.params
        if np.any(np.isnan(theta0)):
            theta0 = Series({'positive_' + mode + '_demand': 0})
        return theta0

    @classmethod
    def _create_results_dictionary(cls, runtimes, features, optimization_results, mode='heating'):
        """Create the results dictionary"""
        training_results = dict()
        training_results[mode + '_nonzero_obs'] = features[features > 0].count()
        training_results[mode + '_training_mse'] = optimization_results.fun
        training_results[mode + '_training_features'] = DataFrame(features)
        training_results[mode + '_training_obs'] = runtimes
        if mode == 'heating':
            training_results[mode + '_training_predictions'] = cls._predict_heating_from_features(optimization_results.x,
                                                                                                  features)
        elif mode == 'cooling':
            training_results[mode + '_training_predictions'] = cls._predict_cooling_from_features(optimization_results.x,
                                                                                                  features)

        training_results[mode + '_wMAPE'] = (sum(abs(training_results[mode + '_training_predictions'] -
                                                     training_results[mode + '_training_obs'])) /
                                             sum(abs(training_results[mode + '_training_obs'])))
        training_results[mode + '_thetas'] = optimization_results.x

        return training_results

    @classmethod
    def _add_model_specific_series(cls, time_series):
        time_series['date'] = time_series.index.date
        return time_series

    @classmethod
    def create_trained_model(cls, features, runtimes):
        """
        Factory method to create a trained nonlinear model from a training set.
        :param features: Time series as created by consumption_model_utilities.extract_all_time_series()
        :param runtimes: Time series of heating and cooling minutes as created by
        consumption_model_utilities.extract_daily_hvac_runtimes()
        :return: ConsumptionModel
        """

        # Up front calculations: get the target temp and create a date column
        target_temp = cmu.calculate_target_temp(features)

        features = cls._add_model_specific_series(features)
        features['date'] = features.index.date
        # Cut to same indices
        indices = set(features.date).intersection(set(runtimes.index))
        criterion = features['date'].apply(lambda x: x in indices)
        features = features[criterion]

        # Get features and runtimes for heating and cooling
        heating_feature_df = NonlinearConsumptionModel._create_daily_heating_features(features, target_temp, INITIAL_FLOAT_VALUE)
        cooling_feature_df = NonlinearConsumptionModel._create_daily_cooling_features(features, target_temp, INITIAL_FLOAT_VALUE)

        # Cut to same indices as feature_dfs.
        heating_runtime_df = runtimes.ix[set(runtimes.index).intersection(set(heating_feature_df.index))].sort()
        cooling_runtime_df = runtimes.ix[set(runtimes.index).intersection(set(cooling_feature_df.index))].sort()

        training_results = {}

        # --------------------------------------------------------------------------------------------------------------
        # Initialize the heating parameters.
        # --------------------------------------------------------------------------------------------------------------
        theta0 = ConstantFloatModel._initialize_theta(heating_runtime_df['heating_minutes'],
                                                      heating_feature_df['positive_heating_demand'],
                                                      mode='heating')
        theta0['heating_constant_float'] = INITIAL_FLOAT_VALUE

        # --------------------------------------------------------------------------------------------------------------
        # Use optimization to find heating parameters.
        # --------------------------------------------------------------------------------------------------------------
        # Objective function for optimization.
        def heating_mse(theta):
            # Recalculate features using new float constant
            heating_features = NonlinearConsumptionModel._create_daily_heating_features(features,
                                                                                        target_temp,
                                                                                        theta[1])['positive_heating_demand']
            err = (heating_runtime_df['heating_minutes'] -
                   ConstantFloatModel._predict_heating_from_features(theta, heating_features))
            mse = np.square(err).sum()
            return mse

        heating_results = minimize(heating_mse, theta0, method='L-BFGS-B', options={'disp': True})
        heating_theta_star = heating_results.x

        # --------------------------------------------------------------------------------------------------------------
        # Create heating training parameters dictionary for debug/test purposes.
        # --------------------------------------------------------------------------------------------------------------
        # Calculate final heating features for storing
        heating_features = NonlinearConsumptionModel._create_daily_heating_features(features,
                                                                                    target_temp,
                                                                                    heating_theta_star[1])['positive_heating_demand']
        heating_training_results = ConstantFloatModel._create_results_dictionary(heating_runtime_df['heating_minutes'],
                                                                                 heating_features,
                                                                                 heating_results,
                                                                                 mode='heating')
        training_results.update(heating_training_results)

        # --------------------------------------------------------------------------------------------------------------
        # Initialize the cooling parameters.
        # --------------------------------------------------------------------------------------------------------------
        theta0 = ConstantFloatModel._initialize_theta(cooling_runtime_df['cooling_minutes'],
                                                      cooling_feature_df['positive_cooling_demand'],
                                                      mode='cooling')
        theta0['cooling_constant_float'] = INITIAL_FLOAT_VALUE

        # --------------------------------------------------------------------------------------------------------------
        # Use optimization to find cooling parameters.
        # --------------------------------------------------------------------------------------------------------------
        def cooling_mse(theta):
            # Recalculate features using new float constant
            cooling_features = NonlinearConsumptionModel._create_daily_cooling_features(features,
                                                                                        target_temp,
                                                                                        theta[1])['positive_cooling_demand']
            err = (cooling_runtime_df['cooling_minutes']
                   - ConstantFloatModel._predict_cooling_from_features(theta, cooling_features))
            mse = np.square(err).sum()
            return mse

        cooling_results = minimize(cooling_mse, theta0, method='L-BFGS-B', options={'disp': True})
        cooling_theta_star = cooling_results.x

        # --------------------------------------------------------------------------------------------------------------
        # Create cooling training parameters dictionary for debug/test purposes.
        # --------------------------------------------------------------------------------------------------------------
        # Calculate final cooling features for storing
        cooling_features = NonlinearConsumptionModel._create_daily_cooling_features(features,
                                                                                    target_temp,
                                                                                    cooling_theta_star[1])['positive_cooling_demand']
        cooling_training_results = ConstantFloatModel._create_results_dictionary(cooling_runtime_df['cooling_minutes'],
                                                                                 cooling_features,
                                                                                 cooling_results, mode='cooling')
        training_results.update(cooling_training_results)

        # Construct the model to be returned.
        cm = ConstantFloatModel(heating_theta_star, cooling_theta_star, training_results)
        return cm

    @classmethod
    def _predict_heating_from_features(cls, theta_heating, features):
        """
        Class method that predicts the heating minutes using the given parameters and features.
        :param theta_heating: Array of parameters for heating model.
        :param features: Series of heating features.
        :return: Series of predicted cooling minutes.
        """
        predicted_heating_minutes = np.maximum(theta_heating[0] * features, 0)
        return predicted_heating_minutes

    @classmethod
    def _predict_cooling_from_features(cls, theta_cooling, features):
        """
        Class method that predicts the cooling minutes using the given parameters and features.
        :param theta_cooling: Array of parameters.
        :param features: Series of features.
        :return: Series of predicted cooling minutes.
        """
        predicted_cooling_minutes = np.maximum(theta_cooling[0] * features, 0)
        return predicted_cooling_minutes

    def predict_consumption(self, multiday_time_series, target_temp=None):
        """
        Predicts heating and cooling consumption for multiple contiguous days.
        :param multiday_time_series: Time series that includes all the days of interest.
        :return: DataFrame with date as index and two columns "heating" and "cooling" representing the consumption
        in minutes.  There will be multiple rows for multiple dates.
        """
        # TODO: Check that the multiday time-series contains entire days and no partial days.

        if target_temp is None:
            target_temp = cmu.calculate_target_temp(multiday_time_series)

        multiday_time_series = self._add_model_specific_series(multiday_time_series)

        assert 'date' in multiday_time_series.columns
        assert all(target_temp.index == multiday_time_series.index)

        # Create the features
        heating_feature_df = NonlinearConsumptionModel._create_daily_heating_features(multiday_time_series,
                                                                                      target_temp,
                                                                                      self.training_results['heating_thetas'][1])
        cooling_feature_df = NonlinearConsumptionModel._create_daily_cooling_features(multiday_time_series,
                                                                                      target_temp,
                                                                                      self.training_results['cooling_thetas'][1])

        # Predict Heating
        heating_features = heating_feature_df['positive_heating_demand']
        predicted_heat = ConstantFloatModel._predict_heating_from_features(self.heating_coefficients,
                                                                           heating_features)

        # Predict Cooling
        cooling_features = cooling_feature_df['positive_cooling_demand']
        predicted_cool = ConstantFloatModel._predict_cooling_from_features(self.cooling_coefficients,
                                                                           cooling_features)

        # Stitch together the heating and cooling predictions into the expected DataFrame and return
        return_df = DataFrame({'heating': predicted_heat, 'cooling': predicted_cool})
        return return_df

