# pylint: disable=no-member

import numpy as np
import os
import pandas as pd
import matplotlib.pyplot as plt
from nestpy.modeling.daily_consumption_models import consumption_model_utilities as util


def calculate_all_deltas(compare, current, trained_model, compare_hvac_times, current_hvac_times):
    """
    Top level function that calculates the blames between the current and compare periods.
    :param compare: Time-series of compare period.
    :param current: Time-series of current period.
    :param trained_model: Trained consumption model.
    :param compare_hvac_times: Vector of compare period HVAC consumptions.
    :param current_hvac_times: Vector of current period HVAC consumptions.
    :return:
    """
    # Break if we don't have run_time data for a day in current / compare
    assert(set(compare_hvac_times.index.date) == set(compare.index.date))
    assert(set(current_hvac_times.index.date) == set(current.index.date))

    # For now, check that the compare and current time periods are of the same length.
    assert len(compare) == len(current)
    compare_df = compare.copy()
    current_df = current.copy()
    current_predicted_consumption = trained_model.predict_consumption(current_df)
    compare_predicted_consumption = trained_model.predict_consumption(compare_df)

    blame_categories = ['schedule', 'adhoc', 'away', 'off', 'outdoor', 'mode_switch']
    predicted_consumption_names = ['predicted_' + x + '_consumption' for x in blame_categories]

    consumption_delta_names = [x + '_delta' for x in blame_categories]
    blame_names = [x + '_blame' for x in blame_categories]

    deltas_columns = ['heating', 'cooling']
    deltas_rows = predicted_consumption_names + consumption_delta_names + blame_names + ['current_predicted_consumption',
                                                                                         'current_actual_consumption',
                                                                                         'compare_predicted_consumption',
                                                                                         'compare_actual_consumption',
                                                                                         'predicted_consumption_delta',
                                                                                         'actual_consumption_delta']
    deltas = pd.DataFrame(columns=deltas_columns, index=deltas_rows)

    deltas.loc['current_predicted_consumption'] = [current_predicted_consumption.heating.sum(), current_predicted_consumption.cooling.sum()]
    deltas.loc['current_actual_consumption'] = [current_hvac_times.heating_minutes.sum(), current_hvac_times.cooling_minutes.sum()]
    deltas.loc['compare_predicted_consumption'] = [compare_predicted_consumption.heating.sum(), compare_predicted_consumption.cooling.sum()]
    deltas.loc['compare_actual_consumption'] = [compare_hvac_times.heating_minutes.sum(), compare_hvac_times.cooling_minutes.sum()]
    deltas.loc['actual_consumption_delta'] = deltas.loc['current_actual_consumption'] - deltas.loc['compare_actual_consumption']
    deltas.loc['predicted_consumption_delta'] = deltas.loc['current_predicted_consumption'] - deltas.loc['compare_predicted_consumption']

    # Calculate delta for each blame time series
    for col in blame_categories:
        # Complete appropriate swap, and predict usage from model.
        if col == 'mode_switch':
            current_swapped_df = mode_switch_operation(compare_df, current_df)
        else:
            if col == 'schedule':
                swap_col = 'scheduled_temp'
            elif col == 'outdoor':
                swap_col = 'outdoor_temp'
            else:
                swap_col = col + '_target'
            current_swapped_df = swap_time_series(compare_df, current_df, swap_col)
        predicted_consumption = trained_model.predict_consumption(current_swapped_df)
        deltas.loc['predicted_' + col + '_consumption'] = [predicted_consumption.heating.sum(), predicted_consumption.cooling.sum()]

        # Calculate delta: predicted baseline consumption - predicted consumption attributed to blame time series.
        consumption_delta = deltas.loc['current_predicted_consumption'] - [predicted_consumption.heating.sum(), predicted_consumption.cooling.sum()]
        deltas.loc[col + '_delta'] = consumption_delta

    predicted_delta_sum = deltas.loc[consumption_delta_names].sum()

    # Scale deltas to blames -- i.e., to sum to actual delta consumption.
    scaling_coeff = deltas.loc['actual_consumption_delta'] / predicted_delta_sum
    # TODO: check that deltas.loc['actual_consumption_delta'] and deltas.loc['predicted_consumption_delta'] are same sign.
    # Otherwise, we need to handle this because re-scaling changes the sign of all the blames.
    deltas.loc[blame_names, 'heating'] = (deltas.loc[consumption_delta_names, 'heating'] * scaling_coeff.loc['heating']).tolist()
    deltas.loc[blame_names, 'cooling'] = (deltas.loc[consumption_delta_names, 'cooling'] * scaling_coeff.loc['cooling']).tolist()

    return deltas

def _mode_switch_same_mode(compare_mode, current_mode):
    """
    Function for comparing same mode time series data for the mode switch operation. No substitution is done here, but
    observations are marked as used when they have been matched up with an observation from the other time period.
    """
    compare_mode_df = compare_mode.copy()
    current_mode_df = current_mode.copy()
    if len(current_mode_df) >= len(compare_mode_df):
        # Make sure observations have not been used
        assert all(current_mode_df.iloc[0:len(compare_mode_df)]['obs_used'] == 0)
        assert all(compare_mode_df['obs_used'] == 0)
        
        # Use the observations
        current_mode_df.iloc[0:len(compare_mode_df)]['obs_used'] = 1
        compare_mode_df['obs_used'] = 1
        
        # Make sure all possible observations have been used
        assert all(compare_mode_df['obs_used'] == 1)
        
    elif len(current_mode_df) < len(compare_mode_df):
        # Make sure observations have not been used
        assert all(current_mode_df['obs_used'] == 0)
        assert all(compare_mode_df.iloc[0:len(current_mode_df)]['obs_used'] == 0)
        
        # Use the observations
        current_mode_df['obs_used'] = 1
        compare_mode_df.iloc[0:len(current_mode_df)]['obs_used'] = 1
        # Make sure all possible observations have been used
        assert all(current_mode_df['obs_used'] == 1)
    
    return compare_mode_df, current_mode_df


def _mode_switch_diff_mode(compare_mode, current_mode, compare_other_mode, current_other_mode, hvac_mode):
    """
    Function for comparing different mode time series data for the mode switch operation. Substitute data for one mode
    in the compare period for the other mode in the current period. This is necessary when the modes are different.
    :param compare_mode: DataFrame for compare period; mode corresponds to mode left in current period.
    :param current_mode: DataFrame for current period; mode corresponds to mode left in current period.
    :param compare_other_mode: DataFrame for compare period; mode corresponds to mode left in compare period.
    :param current_other_mode: DataFrame for current period; mode corresponds to mode left in compare period.
    :param current_mode: 
    :return: DataFrames with mode switch substitutions and observations marked as used.
    """
    compare_mode_df = compare_mode.copy()
    current_mode_df = current_mode.copy()
    compare_other_mode_df = compare_other_mode.copy()
    current_other_mode_df = current_other_mode.copy()
    # Find observations that have not been used yet. Make sure we have the same number for both periods.
    unused_compare = compare_other_mode_df[compare_other_mode_df.obs_used == 0]
    unused_current = current_mode_df[current_mode_df.obs_used == 0]
    assert len(unused_compare) == len(unused_current)

    # Keep only the observations we've already used. The unused ones will be added back after substitutions.
    current_mode_df = current_mode_df[current_mode_df.obs_used == 1]
    current_other_mode_df = current_other_mode_df[current_other_mode_df.obs_used == 1]
    compare_mode_df = compare_mode_df[compare_mode_df.obs_used == 1]
    compare_other_mode_df = compare_other_mode_df[compare_other_mode_df.obs_used == 1]

    # Define columns needed for substitution
    columns_to_replace = ['scheduled_temp', 'adhoc_target', 'away_target', 'off_target', 'away_type']
    heating_columns_to_replace = ['heating_{}'.format(x) for x in columns_to_replace]
    cooling_columns_to_replace = ['cooling_{}'.format(x) for x in columns_to_replace]

    if hvac_mode == 'Heating':
        mode_columns = heating_columns_to_replace
        other_mode_columns = cooling_columns_to_replace
    elif hvac_mode == 'Cooling':
        mode_columns = cooling_columns_to_replace
        other_mode_columns = heating_columns_to_replace

    # NaN out the data for the current mode, since we are substituting in the other mode
    unused_current[mode_columns] = np.nan
    # Substitute in the data from the other mode
    for col in other_mode_columns:
        unused_current = _swap_time_series_single_mode(unused_compare, unused_current, col)

    # Mark observations as used.
    unused_current['obs_used'] = 1
    unused_compare['obs_used'] = 1

    # Re-combine the two sets, now that everything has been used.
    current_other_mode_df = util.combine_and_sort_df(current_other_mode_df, unused_current)
    compare_other_mode_df = util.combine_and_sort_df(compare_other_mode_df, unused_compare)

    # Make sure the substitution occurred. current_other_mode_df should contain only the correct type of data.
    # (Here, schedule is checked.)
    assert all(pd.notnull(current_other_mode_df[other_mode_columns[0]]))
    assert all(pd.isnull(current_other_mode_df[mode_columns[0]]))

    # Make sure all observations have now been used.
    assert all(current_other_mode_df['obs_used'] == 1)
    assert all(current_mode_df['obs_used'] == 1)
    assert all(compare_other_mode_df['obs_used'] == 1)
    assert all(compare_mode_df['obs_used'] == 1)

    return compare_mode_df, current_mode_df, compare_other_mode_df, current_other_mode_df


def mode_switch_operation(compare, current):
    """
    Function to compute a time_series with mode substitutions. This is done by first finding where there is heating in
    both the current and compare periods, and using the values for the compare period. The same is done with cooling.
    Whatever observations have not been used after this must therefore be in different modes; there will either be
    heating observations in the current period and cooling observations in the compare period, or cooling observations in
    the current period and heating observations in the compare period. We then substitute all device data from the compare
    period into the current period, simulating that the current data was in that mode for that period of time. There will
    only be a mode blame if there is differing amounts of time in heating and cooling between the two periods.
    :param current: Time series DataFrame for the current period.
    :param compare: Time series DataFrame for the compare period.
    :return: DataFrame for the current period with mode switch substitutions done.
    """

    compare_df = compare.copy()
    current_df = current.copy()

    # Variable to keep track of which observations have already been used (i.e., matched with an observation from the
    # other time period).
    compare_df['obs_used'] = 0
    current_df['obs_used'] = 0

    compare_heating_df, compare_cooling_df = util.split_heat_cool_and_assign_range_mode(compare_df)
    current_heating_df, current_cooling_df = util.split_heat_cool_and_assign_range_mode(current_df)

    assert len(current_heating_df) + len(current_cooling_df) == len(current_df)
    assert len(compare_heating_df) + len(compare_cooling_df) == len(compare_df)

    # First, try to match heating with heating, cooling with cooling
    compare_heating_df, current_heating_df = _mode_switch_same_mode(compare_heating_df, current_heating_df)
    compare_cooling_df, current_cooling_df = _mode_switch_same_mode(compare_cooling_df, current_cooling_df)

    # Now, we are in one of two scenarios:
    # 1. The only unmatched observations in the current period are heating and the only unmatched observations in the
    # compare period are cooling.
    # 2. The only unmatched observations in the current period are cooling and the only unmatched observations in the
    # compare period are heating.
    # This must be true -- otherwise, more observations would have been matched in the previous steps.
    # Now we simulate the device being in the opposite mode for these observations.
    if len(current_heating_df[current_heating_df.obs_used == 0]) > 0:
        compare_heating_df, current_heating_df, compare_cooling_df, current_cooling_df = \
            _mode_switch_diff_mode(compare_heating_df, current_heating_df, compare_cooling_df, current_cooling_df, 'Heating')
    elif len(current_cooling_df[current_cooling_df.obs_used == 0]) > 0:
        compare_cooling_df, current_cooling_df, compare_heating_df, current_heating_df = \
            _mode_switch_diff_mode(compare_cooling_df, current_cooling_df, compare_heating_df, current_heating_df, 'Cooling')


    # Assert that indices only appear in either heating or cooling.
    assert compare_heating_df.index not in compare_cooling_df.index
    assert current_heating_df.index not in current_cooling_df.index

    # Re-combine heating and cooling
    return_compare_df = util.combine_and_sort_df(compare_heating_df, compare_cooling_df)
    return_current_df = util.combine_and_sort_df(current_heating_df, current_cooling_df)

    # Check that non-mode-related time series were left untouched in substitution.
    assert all(return_compare_df.indoor_temp == compare_df.indoor_temp)
    assert all(return_current_df.indoor_temp == current_df.indoor_temp)

    assert all(return_compare_df.outdoor_temp == compare_df.outdoor_temp)
    assert all(return_current_df.outdoor_temp == current_df.outdoor_temp)

    # Drop the obs_used columns
    return_current_df = return_current_df.drop('obs_used', axis=1)

    return return_current_df


def _swap_time_series_single_mode(compare, current, column_name):
    """
    Swap current period time series values with compare period time series values for a single mode (i.e., heating or cooling).
    :param compare: Heating or cooling DataFrame for compare period.
    :param current: Heating or cooling DataFrame for current period.
    :param column_name: Name of time series / column to swap.
    :return:
    """
    current_mode_df = current.copy()
    compare_mode_df = compare.copy()

    # If in mode for more time in current period, replace as much as possible of current period with all of compare period.
    if len(current_mode_df) >= len(compare_mode_df):
        current_mode_df.iloc[0:len(compare_mode_df)][column_name] = compare_mode_df.iloc[0:][column_name].tolist()

    # If in mode for less time in current period, replace all of current period with as much as possible from compare period.
    elif len(current_mode_df) < len(compare_mode_df):
        current_mode_df.iloc[0:][column_name] = compare_mode_df.iloc[0:len(current_mode_df)][column_name].tolist()

    return current_mode_df


def swap_time_series(compare, current, column_name):
    """
    Swap in a given time series from compare_df into the corresponding time series in current_df for both heating and
    cooling modes.
    :param current: The full time series DataFrame for the current period.
    :param compare: The full time series DataFrame for the compare period.
    :param column_name: The name of the column to be swapped, without the heating_ or cooling_ prefix.
    :return: current_df DataFrame with compare_df data swapped in.
    """
    compare_df = compare.copy()
    current_df = current.copy()

    # If swapping outdoor temp, can substitute directly.
    if column_name == 'outdoor_temp':
        current_df['outdoor_temp'] = compare_df['outdoor_temp'].tolist()
    else:
        # Split into mode-specific DataFrames.
        compare_heating_df, compare_cooling_df = util.split_heat_cool_and_assign_range_mode(compare_df)
        current_heating_df, current_cooling_df = util.split_heat_cool_and_assign_range_mode(current_df)

        # Complete swaps for both modes.
        current_heating_df = _swap_time_series_single_mode(compare_heating_df, current_heating_df, 'heating_' + column_name)
        current_cooling_df = _swap_time_series_single_mode(compare_cooling_df, current_cooling_df, 'cooling_' + column_name)

        # Merge the swapped data back in.
        current_df.loc[current_heating_df.index.tolist(), 'heating_' + column_name] = \
            current_heating_df['heating_' + column_name]
        current_df.loc[current_cooling_df.index.tolist(), 'cooling_' + column_name] = \
            current_cooling_df['cooling_' + column_name]

    return current_df

def plot_blame(compare_df, current_df, time_series, deltas, mac_address, compare_start, compare_end, current_start, current_end, save_dir=None):
    """
    Plot the information that went into generating the given blames.
    If save_dir is not None, save the figure to the given directory.
    Otherwise show the plot.

    :param blames: Blame information, returned from calculate_blame.
    :type blames: pd.Series
    :param hulling: indicates whether model uses indoor hulling
    :param diamond_load_dir: the directory to load/save Diamond data from/to
    :type diamond_load_dir: str corresponding to directory
    :param note: an annotation to place on the plot.
    :type note: str
    :param save_dir: the directory to save to. If None, the plot is shown instead.
        Format of filename: blame_MACADDRESS_COMPARERANGESTART_CURRRANGESTART_NUMDAYS.png.
        Having the numdays allows us to reconstruct the date range without having an absurd filename
    :type save_dir: str corresponding to directory
    :param resampled_device_history: Resampled time series, generated in daily_consumption_model.
    :type resampled_device_history: pd.DataFrame
    """

    plt.figure(figsize=(13, 7))

    ### Plots ###
    regular_fields = ['outdoor_temp', 'indoor_temp', 'heating_scheduled_temp', 'heating_target_temp', 'cooling_scheduled_temp', 'cooling_target_temp']
    bold_fields = ['outdoor_temp', 'heating_target_temp', 'cooling_target_temp']
    plot_list = [('Compare', compare_df, (compare_start, compare_end)),
                 ('Current', current_df, (current_start, current_end))]

    plt.suptitle(mac_address, fontsize=12)

    for plt_num in range(2):
        ax = plt.subplot(1, 3, plt_num+1)
        (plot_name, time_series, date_range) = plot_list[plt_num]

        for f in regular_fields:
            if f in bold_fields:
                lw = 2
            else:
                lw = 1

            plt.plot(time_series.index, time_series[f], label=f, linewidth=lw)

        # The magic numbers aren't very nice - they'll have to be tweaked if we change the plots. But currently the
        # gain of generalizing this is outweighed by the cost.
        plt.step(time_series.index, time_series['heating_hvac']*10+15,
                 where='post', label='heat_stage1', color='Red')
        plt.step(time_series.index, time_series['cooling_hvac']*10+15,
                 where='post', label='cool_stage1', color='Blue')
        plt.fill_between(time_series.index, -21, (pd.notnull(time_series['cooling_adhoc_target']))*4-21,
                         color='Gold')
        plt.fill_between(time_series.index, -21, (pd.notnull(time_series['heating_adhoc_target']))*4-21,
                         color='Gold')
        plt.fill_between(time_series.index, -21, (time_series['heating_away_type'] == 1)*4-21,
                         color='DarkGray')
        plt.fill_between(time_series.index, -21, (time_series['cooling_away_type'] == 1)*4-21,
                         color='DarkGray')
        plt.fill_between(time_series.index, -21, (time_series['heating_away_type'] == 2)*4-21,
                         color='Gray')
        plt.fill_between(time_series.index, -21, (time_series['cooling_away_type'] == 2)*4-21,
                         color='Gray')
        plt.fill_between(time_series.index, -21, (pd.notnull(time_series['heating_off_target']) | pd.notnull(time_series['cooling_off_target']))*4-21,
                         color='Black')
        plt.fill_between(time_series.index, -21, (pd.notnull(time_series['cooling_scheduled_temp']))*2-21,
                         color='LightBlue')
        plt.fill_between(time_series.index, -21, (pd.notnull(time_series['heating_scheduled_temp']))*2-21,
                         color='IndianRed')

        plt.ylim([-20, 100])
        plt.title('{}: {}'.format(plot_name, date_range))

        # Add extra stuff on the second time through
        if plt_num == 1:
            plt.legend(bbox_to_anchor=(0, 0, 0.9, 0.9), bbox_transform=plt.gcf().transFigure, loc='upper right',
                       fontsize=8)
            #plt.text(0.95, 0.95, note, transform=plt.gcf().transFigure, ha='right', va='top')  # right-align
            # "Legend" for the away section
            plt.text(1.05, 0.12, "Off", color='Black', transform=ax.transAxes)
            plt.text(1.05, 0.09, "Adhoc", color='Gold', transform=ax.transAxes)
            plt.text(1.05, 0.06, "Manual away", color='DarkGray', transform=ax.transAxes)
            plt.text(1.05, 0.03, "Auto away", color='Gray', transform=ax.transAxes)
            plt.text(1.05, 0, "Cooling", color='LightBlue', transform=ax.transAxes)
            plt.text(1.05, -.03, "Heating", color='IndianRed', transform=ax.transAxes)


    ### Tables ###
    ax = plt.subplot(1, 3, 3)

    blame_column_labels = ["Heating", "Cooling"]
    blame_row_labels = ["Actual Usage Delta",
                        "Predicted Usage Delta",
                        "Outdoor Blame",
                        "Schedule Blame",
                        "Away Blame",
                        "Ad-Hoc Blame",
                        "Off Mode Blame",
                        "Mode Switch Blame",
                        "Unscaled Outdoor Blame",
                        "Unscaled Schedule Blame",
                        "Unscaled Away Blame",
                        "Unscaled Ad-Hoc Blame",
                        "Unscaled Off Mode Blame",
                        "Unscaled Mode Switch Blame"]

    blame_fields = ['actual_consumption_delta',
                    'predicted_consumption_delta',
                    'outdoor_blame',
                    'schedule_blame',
                    'away_blame',
                    'adhoc_blame',
                    'off_blame',
                    'mode_switch_blame',
                    'outdoor_delta',
                    'schedule_delta',
                    'away_delta',
                    'adhoc_delta',
                    'off_delta',
                    'mode_switch_delta']

    blame_heating_data = ['{:.4f}'.format(deltas.heating[f]) for f in blame_fields]
    blame_cooling_data = ['{:.4f}'.format(deltas.cooling[f]) for f in blame_fields]
    ax.axis('off')

    blame_colors = ['yellow', 'yellow', 'white', 'white', 'white', 'white', 'white', 'white',
                    'LightYellow', 'LightYellow', 'LightYellow', 'LightYellow', 'LightYellow', 'LightYellow']

    # reformat colors array to apply to cells: need 1 array per row
    blame_colors_cell = [[c]*len(blame_column_labels) for c in blame_colors]
    blame_text = zip(blame_heating_data, blame_cooling_data)
    blame_text = [list(c) for c in blame_text]
    blame_table = ax.table(cellText=blame_text,
                           colLabels=blame_column_labels,
                           rowLabels=blame_row_labels,
                           colWidths=[0.25, 0.25],
                           loc='center right',
                           cellLoc='center',
                           rowColours=blame_colors,
                           cellColours=blame_colors_cell)

    if save_dir is not None:
        plt.savefig(os.path.join(save_dir, 'blame_{}_{}_{}.png'.format(mac_address, compare_start,
                                                                          current_end)),
                    bbox_inches='tight')

    plt.close()
