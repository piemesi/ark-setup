class ConsumptionModel(object):
    """
    The ConsumptionModel class contains the parameters and predict methods for a given HVAC consumption model:

    It contains methods common to all ConsumptionModels, and stubs out functions
    that specific models must implement.
    """

    def __init__(self, heating_coefficients, cooling_coefficients, training_results):
        """
        Initialize coefficients of model.
        :param coefficients: Model parameters stored as key/value pairs.
        :type coefficients: dict
        """
        self.heating_coefficients = heating_coefficients
        self.cooling_coefficients = cooling_coefficients
        self.training_results = training_results

    @classmethod
    def create_trained_model(cls, input_training_set, output_training_set):
        """
        Factory method to create a trained nonlinear model from a training set.
        :param input_training_set: Time series as created by consumption_model_utilities.extract_all_time_series()
        :param output_training_set: Time series of heating and cooling minutes as created by
        consumption_model_utilities.extract_daily_hvac_runtimes()
        :return: ConsumptionModel
        """
        raise NotImplementedError('ConsumptionModel.create_trained_model must be overloaded by derived class.')

    @classmethod
    def _create_daily_heating_features(cls, multiday_time_series, target_temp, heating_float):
        """
        Creates the model specific features from the time series.
        :param multiday_time_series: Time series for the days that to create features for.
        :param target_temp: DataFrame of heating and cooling target temperatures.
        :param heating_float: Float delta for heating.
        :return: DataFrame with date as index and columns for each of the computed features.  Feature names should match
        the the parameter names in the model.
        """
        raise NotImplementedError('ConsumptionModel.create_daily_heating_features must be overloaded by derived class.')

    @classmethod
    def _create_daily_cooling_features(cls, multiday_time_series, target_temp, cooling_float):
        """
        Creates the model specific features from the time series.
        :param multiday_time_series: Time series for the days that to create features for.
        :param target_temp: DataFrame of heating and cooling target temperatures.
        :param cooling_float: Float delta for cooling.
        :return: DataFrame with date as index and columns for each of the computed features.  Feature names should match
        the the parameter names in the model.
        """
        raise NotImplementedError('ConsumptionModel.create_daily_cooling_features must be overloaded by derived class.')

    def predict_consumption(self, multiday_time_series):
        """
        Predicts heating and cooling consumption for multiple contiguous days.
        :param multiday_time_series: Time series that includes all the days of interest.
        :return: DataFrame with date as index and two columns "heating" and "cooling" representing the consumption
        in minutes.  There will be multiple rows for multiple dates.
        """
        raise NotImplementedError('predict_consumption must be overloaded by derived class.')

    def plot_training_results(self, device_id, output_folder):
        """
        Plot the results of training.  This creates appropriate scatter plots of predicted vs. observed data for heating
        and cooling.
        :param device_id: Device id for the model.
        :param output_folder: Output folder to save the figure to.
        :return: None.
        """
        raise NotImplementedError('plotting must be overloaded by derived class.')
