# pylint: disable=maybe-no-member, no-member, no-name-in-module

import math
import numpy as np
from pandas import DataFrame
from scipy.optimize import minimize

from constant_float_model import ConstantFloatModel
import consumption_model_utilities as cmu

INITIAL_CONSTANT_FLOAT_VALUE = 4
INITIAL_DYNAMIC_FLOAT_VALUE = 11

MINUTES_IN_DAY = 60*24


class DynamicFloatModel(ConstantFloatModel):

    def __init__(self, heating_coefficients, cooling_coefficients, training_results):
        super(DynamicFloatModel, self).__init__(heating_coefficients, cooling_coefficients, training_results)

    @classmethod
    def _add_model_specific_series(cls, time_series):
        time_series['date'] = time_series.index.date
        time_series['sin_hour'] = [math.sin(x * math.pi / 24) for x in time_series.index.hour]
        return time_series

    @classmethod
    def create_trained_model(cls, features, runtimes):
        """
        Factory method to create a trained nonlinear model from a training set.
        :param features: Time series as created by consumption_model_utilities.extract_all_time_series()
        :param runtimes: Time series of heating and cooling minutes as created by
        consumption_model_utilities.extract_daily_hvac_runtimes()
        :return: ConsumptionModel
        """
        # Up front calculations: get the target temp and create a date column
        target_temp = cmu.calculate_target_temp(features)
        features = cls._add_model_specific_series(features)
        # Cut to same indices
        indices = set(features.date).intersection(set(runtimes.index))
        criterion = features['date'].apply(lambda x: x in indices)
        features = features[criterion]

        # Get features and runtimes for heating and cooling
        heating_feature_df = DynamicFloatModel._create_daily_heating_features(features, target_temp,
                                                                             INITIAL_CONSTANT_FLOAT_VALUE,
                                                                             INITIAL_DYNAMIC_FLOAT_VALUE)
        cooling_feature_df = DynamicFloatModel._create_daily_cooling_features(features, target_temp,
                                                                             INITIAL_CONSTANT_FLOAT_VALUE,
                                                                             INITIAL_DYNAMIC_FLOAT_VALUE)
        # Cut to same indices as feature_dfs.
        heating_runtime_df = runtimes.ix[set(runtimes.index).intersection(set(heating_feature_df.index))].sort()
        cooling_runtime_df = runtimes.ix[set(runtimes.index).intersection(set(cooling_feature_df.index))].sort()

        training_results = {}

        # --------------------------------------------------------------------------------------------------------------
        # Initialize the heating parameters.
        # --------------------------------------------------------------------------------------------------------------
        theta0 = ConstantFloatModel._initialize_theta(heating_runtime_df['heating_minutes'],
                                                     heating_feature_df['positive_heating_demand'], mode='heating')
        theta0['heating_constant_float'] = INITIAL_CONSTANT_FLOAT_VALUE
        theta0['heating_dynamic_float'] = INITIAL_DYNAMIC_FLOAT_VALUE

        # --------------------------------------------------------------------------------------------------------------
        # Use optimization to find heating parameters.
        # --------------------------------------------------------------------------------------------------------------
        # Objective function for optimization.
        def heating_mse(theta):
            # Recalculate features using new float constant
            heating_features = DynamicFloatModel._create_daily_heating_features(features, target_temp,
                                                                                       theta[1],
                                                                                       theta[2])['positive_heating_demand']
            err = heating_runtime_df['heating_minutes'] \
                  - DynamicFloatModel._predict_heating_from_features(theta, heating_features)
            mse = np.square(err).sum()
            return mse

        heating_results = minimize(heating_mse, theta0, method='L-BFGS-B', options={'disp': True})
        heating_theta_star = heating_results.x

        # --------------------------------------------------------------------------------------------------------------
        # Create heating training parameters dictionary for debug/test purposes.
        # --------------------------------------------------------------------------------------------------------------
        # Calculate final heating features for storing
        heating_features = DynamicFloatModel._create_daily_heating_features(features, target_temp,
                                                                                   heating_theta_star[1],
                                                                                   heating_theta_star[2])['positive_heating_demand']

        heating_training_results = ConstantFloatModel._create_results_dictionary(heating_runtime_df['heating_minutes'],
                                                                                heating_features,
                                                                                heating_results, mode='heating')
        training_results.update(heating_training_results)

        # --------------------------------------------------------------------------------------------------------------
        # Initialize the cooling parameters.
        # --------------------------------------------------------------------------------------------------------------
        theta0 = ConstantFloatModel._initialize_theta(cooling_runtime_df['cooling_minutes'],
                                                     cooling_feature_df['positive_cooling_demand'], mode='cooling')
        theta0['cooling_constant_float'] = INITIAL_CONSTANT_FLOAT_VALUE
        theta0['cooling_dynamic_float'] = INITIAL_DYNAMIC_FLOAT_VALUE

        # --------------------------------------------------------------------------------------------------------------
        # Use optimization to find cooling parameters.
        # --------------------------------------------------------------------------------------------------------------
        def cooling_mse(theta):
            # Recalculate features using new float constant
            cooling_features = DynamicFloatModel._create_daily_cooling_features(features, target_temp,
                                                                                       theta[1],
                                                                                       theta[2])['positive_cooling_demand']
            err = cooling_runtime_df['cooling_minutes'] \
                  - DynamicFloatModel._predict_cooling_from_features(theta, cooling_features)
            mse = np.square(err).sum()
            return mse

        cooling_results = minimize(cooling_mse, theta0, method='L-BFGS-B', options={'disp': True})
        cooling_theta_star = cooling_results.x

        # --------------------------------------------------------------------------------------------------------------
        # Create cooling training parameters dictionary for debug/test purposes.
        # --------------------------------------------------------------------------------------------------------------
        # Calculate final cooling features for storing
        cooling_features = DynamicFloatModel._create_daily_cooling_features(features, target_temp,
                                                                                   cooling_theta_star[1],
                                                                                   cooling_theta_star[2])['positive_cooling_demand']

        cooling_training_results = ConstantFloatModel._create_results_dictionary(cooling_runtime_df['cooling_minutes'],
                                                                                cooling_features,
                                                                                cooling_results, mode='cooling')
        training_results.update(cooling_training_results)

        cm = DynamicFloatModel(heating_theta_star, cooling_theta_star, training_results)
        return cm

    def predict_consumption(self, multiday_time_series, target_temp=None):
        """
        Predicts heating and cooling consumption for multiple contiguous days.
        :param multiday_time_series: Time series that includes all the days of interest.
        :return: DataFrame with date as index and two columns "heating" and "cooling" representing the consumption
        in minutes.  There will be multiple rows for multiple dates.
        """
        # TODO: Check that the multiday time-series contains entire days and no partial days.

        # Up front calculations
        if target_temp is None:
            target_temp = cmu.calculate_target_temp(multiday_time_series)
        multiday_time_series = self._add_model_specific_series(multiday_time_series)

        assert 'date' in multiday_time_series.columns
        assert 'sin_hour' in multiday_time_series.columns
        assert all(target_temp.index == multiday_time_series.index)

        # Create the features
        heating_feature_df = DynamicFloatModel._create_daily_heating_features(multiday_time_series,
                                                                                     target_temp,
                                                                                     self.training_results['heating_thetas'][1],
                                                                                     self.training_results['heating_thetas'][2])
        cooling_feature_df = DynamicFloatModel._create_daily_cooling_features(multiday_time_series,
                                                                                     target_temp,
                                                                                     self.training_results['cooling_thetas'][1],
                                                                                     self.training_results['cooling_thetas'][2])

        # Predict Heating
        heating_features = heating_feature_df['positive_heating_demand']
        predicted_heat = ConstantFloatModel._predict_heating_from_features(self.heating_coefficients,
                                                                                  heating_features)

        # Predict Cooling
        cooling_features = cooling_feature_df['positive_cooling_demand']
        predicted_cool = ConstantFloatModel._predict_cooling_from_features(self.cooling_coefficients,
                                                                                  cooling_features)

        # Stitch together the heating and cooling predictions into the expected DataFrame and return
        return_df = DataFrame({'heating': predicted_heat, 'cooling': predicted_cool})
        return return_df
    
    @classmethod
    def _create_daily_heating_features(cls, multiday_time_series, target_temp=None,
                                      heating_constant_float=INITIAL_CONSTANT_FLOAT_VALUE,
                                      heating_dynamic_float=INITIAL_DYNAMIC_FLOAT_VALUE):
        """
        Class method to create the daily heating features from a set of time series.
        :param multiday_time_series: Time series for multiple days as generated by the consumption model utilities.
        :param target_temp: target temperatures from cmu.calculate_target_temp
        :param heating_constant_float: heating float term to use for device
        :return: DataFrame with date as index and columns for each of the computed features.  Feature names should match
        the the parameter names in the model.
        """
        if target_temp is None:
            target_temp = cmu.calculate_target_temp(multiday_time_series)

        # Compute the positive and negative heating consumption per day.
        heating_demand = target_temp.heating_target_temp - (multiday_time_series.outdoor_temp + heating_constant_float +
                                                            (heating_dynamic_float * multiday_time_series['sin_hour']))
        positive_heating_demand = heating_demand.apply(lambda x: x if x >= 0 else 0)

        # Compute total demand for each day and create DataFrame to return.
        heating_demand = DataFrame({'positive_heating_demand': positive_heating_demand,
                                    'date': multiday_time_series.date})
        features = heating_demand.groupby('date').sum()

        # Filter to only the days we have complete data for
        num_minutes = heating_demand.groupby('date').count()['positive_heating_demand']
        dates_with_enough_data = num_minutes[num_minutes >= MINUTES_IN_DAY].index

        return features.ix[dates_with_enough_data]

    @classmethod
    def _create_daily_cooling_features(cls, multiday_time_series, target_temp=None,
                                      cooling_constant_float=INITIAL_CONSTANT_FLOAT_VALUE,
                                      cooling_dynamic_float=INITIAL_DYNAMIC_FLOAT_VALUE):
        """
        Class method to create the daily cooling features from a set of time series.
        :param multiday_time_series: Time series for multiple days as generated by the consumption model utilities.
        :param target_temp: target temperatures from cmu.calculate_target_temp
        :param cooling_constant_float: heating float term to use for device
        :return: DataFrame with date as index and columns for each of the computed features.  Feature names should match
        the the parameter names in the model.
        """
        if target_temp is None:
            target_temp = cmu.calculate_target_temp(multiday_time_series)

        # Compute the positive and negative heating consumption per day.
        cooling_demand = (multiday_time_series.outdoor_temp + cooling_constant_float +
                          (cooling_dynamic_float * multiday_time_series['sin_hour'])) - \
                         target_temp.cooling_target_temp
        positive_cooling_demand = cooling_demand.apply(lambda x: x if x >= 0 else 0)


        # Compute total demand for each day and create DataFrame to return.
        cooling_demand = DataFrame({'positive_cooling_demand': positive_cooling_demand,
                                    'date': multiday_time_series.date})
        features = cooling_demand.groupby('date').sum()

        # Filter to only the days we have complete data for
        num_minutes = cooling_demand.groupby('date').count()['positive_cooling_demand']
        dates_with_enough_data = num_minutes[num_minutes >= MINUTES_IN_DAY].index

        return features.ix[dates_with_enough_data]


