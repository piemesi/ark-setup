"""
This file provides a user interface into keyring for securely storing credentials to nestlabs resources.
"""

import getpass
import os

import keyring


NEST_USERNAME = 'nest_username'
FT_DB_PASSWORD = 'nest_ft_db_password'
PROD_DB_PASSWORD = 'nest_prod_db_password'

S3_CONFIG_FILE = os.path.expanduser("~/.aws/credentials")

def get_nestlabs_username():

    return keyring.get_password(NEST_USERNAME, getpass.getuser())


def set_nestlabs_username():

    username = raw_input('Enter your NestLabs username (everything before the @nestlabs.com in your email address): ')
    if username != "":
        keyring.set_password(NEST_USERNAME, getpass.getuser(), username)


def get_ft_db_password():

    return keyring.get_password(FT_DB_PASSWORD, getpass.getuser())


def set_ft_db_password():

    password = getpass.getpass('Enter the FT DB password (from https://valentine.corp.google.com/): ')
    if password != "":
        keyring.set_password(FT_DB_PASSWORD, getpass.getuser(), password)


def get_production_db_password():

    return keyring.get_password(PROD_DB_PASSWORD, getpass.getuser())


def set_production_db_password():

    password = getpass.getpass('Enter the Production DB password (from https://valentine.corp.google.com/): ')
    if password != "":
        keyring.set_password(PROD_DB_PASSWORD, getpass.getuser(), password)
