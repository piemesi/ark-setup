"""
Converters for temperature and humidity.
"""
# pylint: disable=no-member

import numpy as np


def c2f(a):
    """Converts Celsius to Fahrenheit."""
    return a / 5.0 * 9.0 + 32.0


def f2c(a):
    """Convert Fahrenheit to Celsius."""
    return (a - 32.0) / 9.0 * 5.0


def c2frelative(a):
    """Convert Celsius offset to Fahrenheit."""
    return a / 5.0 * 9.0


def f2crelative(a):
    """Convert Fahrenheit offset to Celsius."""
    return a / 9.0 * 5.0


def c2fixed(a):
    """Convert Celsius to fixed-length integer."""
    return long(a * 2 ** 16)


def fixed2c(a):
    """Convert fixed-length integer to Celsius."""
    return float(a) / 2 ** 16


def f2fixed(a):
    """Convert Fahrenheit to fixed-length integer."""
    return c2fixed(f2c(a))


def fixed2f(a):
    """Convert fixed-length integer to Fahrenheit."""
    return c2f(fixed2c(a))


def get_dew_point(temperature, humidity):
    """Gets the dew point for a given temperature and humidity to
    dew point (degrees Celsius)

    :param temperature:
        the temperature in degrees Celcius
    :type temperature:
        float

    :param humidity:
        the humidity as a percent from 0 to 100
    :type humidity:
        float

    :returns:
        the dew point in degrees Celcius
    :rtype:
        float
    """
    b = 17.67
    c = 243.5
    gamma = np.log(humidity / 100.0) + (b * temperature) / (c + temperature)

    return (c * gamma) / (b - gamma)
