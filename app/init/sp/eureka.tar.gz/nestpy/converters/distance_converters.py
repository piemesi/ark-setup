"""
Converters for distances.
"""

FEET_PER_MM = 0.00328084


def mm_to_feet(distance_in_mm):
    """Convert a distance in millimeters to a distance in feet."""
    return distance_in_mm * FEET_PER_MM


def feet_to_mm(distance_in_feet):
    """Convert a distance in feet to a distance in millimeters."""
    return distance_in_feet / FEET_PER_MM

