"""
Converters for commonly transposed value types.
"""
# pylint: disable=no-member

from .distance_converters import *
from .temperature_converters import *
from .time_converters import *

import numpy as np


def list_to_intervals(numerical_list):
    """
    Converts a list of numerical values to a list of intervals in which the
    values are nonzero.

    For example, given the input array [0, 1, 1, 1, 0, 0, 1, 1], this function
    would return the list [(1, 3), (6, 7)].

    This function is particularly useful when attempting to plot ranges of
    activity, since the plotting function ``axvspan`` requires start and end
    indices instead of an array of true values.

    :param numerical_list:
        a list-like object containing numerical values.
    :type numerical_list:
        list-like

    :returns:
        a list of tuples, in which each tuple contains the start index and
        the end index of a given nonzero interval
    """

    if len(numerical_list) < 1:
        raise RuntimeError("Data selection is empty")

    if not isinstance(numerical_list, np.ndarray):
        # Convert to a numpy array so that we can use the nonzero() function
        numerical_list = np.array(numerical_list)

    starts = [0] if numerical_list[0] else []

    starts.extend(((numerical_list[:-1] == False) &
                    numerical_list[1:]).nonzero()[0] + 1)

    ends = (numerical_list[:-1] &
            (numerical_list[1:] == False)).nonzero()[0].tolist()

    if numerical_list[-1]:
        ends.append(len(numerical_list) - 1)

    return zip(starts, ends)
