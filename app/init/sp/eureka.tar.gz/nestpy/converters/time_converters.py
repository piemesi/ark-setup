"""
Converters for time objects.
"""
# Fix for pylint not recognizing dynamically generated methods.
# pylint: disable=maybe-no-member

from datetime import datetime, time, timedelta
from nestpy.validation.type_validation import assert_is_type
import dateutil.parser
import pytz
import pandas

from .time_constants import (BEGINNING_OF_TIME,
                             MICROSECONDS_PER_SECOND,
                             MILLISECONDS_PER_SECOND,
                             MINUTES_PER_HOUR,
                             NANOSECONDS_PER_SECOND,
                             SECONDS_PER_DAY,
                             SECONDS_PER_HOUR,
                             SECONDS_PER_MINUTE,
                             SECONDS_PER_WEEK,
                             )


def convert_to_utc(timestamp):
    """
    Converts a naive or aware datetime string or object into UTC.
    A timezone aware datetime object in any other timezone will be adjusted to the UTC timezone.
    """

    if isinstance(timestamp, datetime) and timestamp.tzinfo == pytz.utc:
        return timestamp

    utc_date = get_tz_aware_datetime(timestamp)

    if utc_date.tzinfo != pytz.utc:
        return utc_date.astimezone(pytz.utc)

    return utc_date


def datetime_index_to_epoch_time_array(datetime_index):
    """
    Converts a pandas DatetimeIndex to a numpy array with epoch times.

    :param datetime_index:
        Pandas DatetimeIndex
    :type datetime_index:
        pandas.DatetimeIndex

    return:
        Numpy array with corresponding epoch times
    :rtype:
        numpy.ndarray
    """
    return datetime_index.asi8 // NANOSECONDS_PER_SECOND


def timestamp_series_to_epoch_time_array(timestamp_series):
    """
    Converts a pandas Series containing Timestamps to a numpy array with epoch times.

    :param datetime_index:
        Pandas Series containing Timestamps
    :type datetime_index:
        pandas.Series

    return:
        Numpy array with corresponding epoch times
    :rtype:
        numpy.ndarray
    """
    return timestamp_series.apply(lambda x: datetime_to_epoch_time(x)).values


def datetime_to_epoch_time(datetime_to_convert):
    """
    Converts a datetime to epoch time.
    """
    if not datetime_to_convert.tzinfo:
        datetime_to_convert = BEGINNING_OF_TIME.tzinfo.localize(datetime_to_convert)

    # Pandas 0.16 - the Timestamp object is returned for DateTimeIndex which is not the same type as BEGINNING_OF_TIME
    if type(datetime_to_convert) == pandas.tslib.Timestamp:
        datetime_to_convert = datetime_to_convert.to_datetime()

    return (datetime_to_convert - BEGINNING_OF_TIME).total_seconds()


def get_tz_naive_datetime(iterable):
    """
    Removes timezone info from datetime items

    Args:
        iterable: iterable with datetime items

    Returns:
        list with timezone naive datetime items
    """
    return [dt.replace(tzinfo=None) for dt in iterable]


def get_tz_aware_datetime(timestamp, timezone=pytz.utc):
    """
    General utility for turning a timestamp of any valid type into a
    timezone-aware datetime. If the provided timestamp object has no time zone
    information, it will be assumed to be UTC time.

    :param timestamp:
        a timestamp to convert to a timezone-aware datetime.
    :type timestamp:
        str or datetime.datetime

    :return:
        a timezone-aware datetime.
    :rtype:
        datetime.datetime
    """
    assert timezone is not None

    if isinstance(timestamp, datetime):
        pass
    elif isinstance(timestamp, str) or isinstance(timestamp, unicode):
        timestamp = dateutil.parser.parse(timestamp)
    else:
        raise ValueError('timestamp must be instance of datetime or string')

    # Set time zone if not already set.
    if not timestamp.tzinfo:
        timestamp = timezone.localize(timestamp)

    return timestamp


def convert_ordinal_to_datetime(ordinal_time):
    """
    Converts the provided ordinal time to a datetime with 1 millisecond
    resolution.
    """
    day = datetime.fromordinal(int(ordinal_time))
    time_from_midnight = timedelta(milliseconds=int(ordinal_time % 1 * 24 * 60 * 60 * 1000))
    return day + time_from_midnight


def convert_time_units(t, tinput="seconds", toutput="seconds"):
    """
    Converts time from one unit into another.

    :param t:
        a quantity of time
    :type t:
        float

    :param tinput:
        units of t
    :type tset:
        string

    :param toutput:
        units to convert t into
    :type toutput:
        string

    :returns:
        t in toutput units
    :rtype:
        float
    """

    multipliers = {
        "nanoseconds": 1.0 / NANOSECONDS_PER_SECOND,
        "microseconds": 1.0 / MICROSECONDS_PER_SECOND,
        "milliseconds": 1.0 / MILLISECONDS_PER_SECOND,
        "seconds": 1.0,
        "minutes": SECONDS_PER_MINUTE,
        "hours": SECONDS_PER_HOUR,
        "days": SECONDS_PER_DAY,
        "weeks": SECONDS_PER_WEEK
    }

    if tinput not in multipliers:
        raise ValueError("Input unit of '%s' not understood." % tinput)

    if toutput not in multipliers:
        raise ValueError("Output unit of '%s' not understood." % toutput)

    return t * multipliers[tinput] / multipliers[toutput]


def date_ranges(start_date, end_date, increment_size):
    """
    Converts a start and end date into a list of date ranges
    with a fix number of days between start and end.

    :param start_date,end_date:
        a date
    :type start_date,end_date:
        datetime

    :param increment_size:
        number of days between start and end 
    :type increment_size:
        int
       
    >>> start_date=datetime.datetime(2015, 3, 10, 0, 0)
    >>> end_date=datetime.datetime(2015, 3, 20, 0, 0)
    >>> increment_size=5
    >>> date_ranges(start_date, end_date, increment_size)
    [(datetime.datetime(2015, 3, 10, 0, 0), datetime.datetime(2015, 3, 15, 0, 0)), (datetime.datetime(2015, 3, 15, 0, 0), datetime.datetime(2015, 3, 20, 0, 0))]
   
    """
    if increment_size <= 0:
        raise ValueError("Increment size cannot be equal to 0")

    num_increments = (end_date - start_date).days / increment_size + min(
        1,
        (end_date - start_date).days % increment_size
    )
    date_increments = [
        (
            min(start_date + timedelta(days=i * increment_size), end_date),
            min(start_date + timedelta(days=(i + 1) * increment_size), end_date)
        )
        for i in range(num_increments)
    ]
    return date_increments


def to_seconds(hours=0, minutes=0, seconds=0):
    return hours * SECONDS_PER_HOUR + minutes * SECONDS_PER_MINUTE + seconds


def time_to_hour_float(t):
    assert_is_type(t, time)
    return t.hour + t.minute / MINUTES_PER_HOUR + t.second / SECONDS_PER_HOUR


def hour_float_to_time(t):
    return time(
        hour=int(t),
        minute=int((t % 1.) * MINUTES_PER_HOUR),
        second=int((((t % 1.) * MINUTES_PER_HOUR) % 1) * SECONDS_PER_MINUTE),
    )


def utc_datetime_from_timestamp(seconds):
    return pytz.utc.localize(datetime.utcfromtimestamp(seconds))


def unix_time(datetime_):
    delta = datetime_ - BEGINNING_OF_TIME
    return delta.total_seconds()
