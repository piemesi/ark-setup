import avro
import glob
import itertools
import os
import pandas as pd

from avro.datafile import DataFileReader
from avro.io import DatumReader


import logging
logger = logging.getLogger(__name__)


def grouper(n, iterable):
    """
    Facilitates iteration on chunks of size N.

    Shamelessly copied from: http://stackoverflow.com/questions/8991506/iterate-an-iterator-by-chunks-of-n-in-python
    :param n: size of chunks
    :param iterable: an iterable to chunk
    :return: groups of iterables of size chunk
    """
    it = iter(iterable)
    i = 0
    while True:
        logger.debug("Loading Avro chunk: %s", i)
        i += 1
        chunk = tuple(itertools.islice(it, n))
        if not chunk:
            return
        yield chunk


def read_to_data_frame(file_path, readers_schema=None, chunk_size=100000):
    """Creates a DataFrame from Avro records.

    Using an Avro reader's schema with a subset of fields you care about will greatly improve performance.
    :param file_path: path to the Avro file
    :param readers_schema: optional Avro reader's schema
    :param chunk_size: number of rows to load into memory at one time. Used to chunk the data, for improved memory
           performance.
    """
    logger.info("Loading Avro file [%s]", file_path)

    datum_reader = DatumReader(readers_schema=readers_schema)
    reader = DataFileReader(open(file_path, "r"), datum_reader)

    # Chunk rows:
    data_frame = None
    for group in grouper(chunk_size, reader):
        chunk_data_frame = pd.DataFrame([row for row in group])
        data_frame = pd.concat([data_frame, chunk_data_frame])

    return data_frame


class Reader(object):
    """
    Facilitates reading Avro data into a pandas DataFrame.
    """

    def __init__(self, readers_schema_path=None):
        """
        :param readers_schema_path: optional path to a reader's schema. If provides, a schema will be loaded and
            passed to the Avro DataFileReader at read time.
        """

        if readers_schema_path is not None:
            self.readers_schema = avro.schema.parse(open(readers_schema_path).read())
        else:
            self.readers_schema = None

    def read_path(self, path):
        """
        :param path: path to Avro files
        :return: DataFrame of all data from the given Avro files

        """
        avro_file_paths = os.path.join(path, "*.avro")
        files = glob.glob(avro_file_paths)
        return self.read_files(files)

    def read_paths(self, paths):
        """Reads all Avro files from a list of paths into a single DataFrame.
        :param paths: list of paths containing Avro files
        :return: DataFrame of all data from all Avro files in the given paths
        """
        files = []

        for path in paths:
            avro_file_paths = os.path.join(path, "*.avro")
            files += glob.glob(avro_file_paths)

        return self.read_files(files)

    def read_files(self, files):
        """Reads a series of Avro files into a single DataFrame.
        :param files: list of Avro file paths
        :return: DataFrame of all data from the given Avro files

        TODO: Make this load avro files in parallel.
        TODO: Optimize data frame creation and concatenation.
        """
        logger.debug("Reading Avro files %s", files)
        data_frame = None
        for avro_file in files:
            file_data = read_to_data_frame(avro_file, readers_schema=self.readers_schema)
            data_frame = pd.concat([data_frame, file_data], ignore_index=True)

        return data_frame
