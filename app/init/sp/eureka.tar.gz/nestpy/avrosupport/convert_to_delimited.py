import itertools
from avro.datafile import DataFileReader
from avro.io import DatumReader
import pandas as pd


import logging
logger = logging.getLogger(__name__)


def grouper(n, iterable):
    it = iter(iterable)
    while True:
        chunk = tuple(itertools.islice(it, n))
        if not chunk:
            return
        yield chunk


def convert_to_delimited(avro_file_path, destination_file_path, readers_schema=None, chunk_size=100000):
    """Creates a DataFrame from Avro records.

    Using an Avro reader's schema with a subset of fields you care about will greatly improve performance.
    :param avro_file_path: path to the Avro file
    :param readers_schema: optional Avro reader's schema
    """
    logger.debug("Converting Avro file [%s] to delimited file [%s]", avro_file_path, destination_file_path)

    datum_reader = DatumReader(readers_schema=readers_schema)
    reader = DataFileReader(open(avro_file_path, "r"), datum_reader)

    # Chunk rows, load into large data frames, and then append to CSVs
    first_iteration = True
    for group in grouper(chunk_size, reader):
        data_frame = pd.DataFrame([row for row in group])
        if first_iteration:
            data_frame.to_csv(destination_file_path, mode='w', header=True, index=False, sep=chr(9))
            first_iteration = False
        else:
            data_frame.to_csv(destination_file_path, mode='a', header=False, index=False, sep=chr(9))

