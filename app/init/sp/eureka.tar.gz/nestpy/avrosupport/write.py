import avro
from avro.datafile import DataFileWriter
from avro.io import DatumWriter
from pandas.core.common import notnull


class Writer(object):
    """Utility for writing DataFrames into Avro files using a common schema.
    """

    def __init__(self, schema_path):
        self.schema = avro.schema.parse(open(schema_path).read())

    def write(self, data_frame, output_path):
        writer = DataFileWriter(open(output_path, "w"), DatumWriter(), self.schema)

        for record in data_frame.to_dict(outtype='records'):
            minimal_record = {key: value for key, value in record.items() if notnull(value)}
            writer.append(minimal_record)

        writer.close()
