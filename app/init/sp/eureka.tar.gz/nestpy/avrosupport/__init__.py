"""Common data loading and persistence using Apache Avro.

http://avro.apache.org/
"""
# pylint: disable=wildcard-import

from .read import *
from .write import *

