"""
Support for working with curated device event data.
"""

from .load import load
