import os
from ...aws.curated_event_manager import CuratedEventManager
from ... import env
from .. import Reader


def load(event, start_date, end_date, cache_destination=env.cache_destination()):
    """Loads event data from S3 Curated directories.

    Downloads curated Avro event data from S3 into the cache directory, and then parses the data into a single
    DataFrame.

    :param event: name of the event. e.g. EnergySummary
    :param start_date: start date of the window to load
    :param end_date: end date of the window to load
    :return: pandas DataFrame of event data
    """
    curated_cache_destination = os.path.join(cache_destination, "curated")
    if not os.path.exists(curated_cache_destination):
        os.mkdir(curated_cache_destination)

    paths = CuratedEventManager().download_event(event, curated_cache_destination, start_date, end_date)
    reader = Reader()
    event_frame = reader.read_paths(paths)

    return event_frame


