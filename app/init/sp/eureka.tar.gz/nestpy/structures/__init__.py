import functools
import logging

from ..scriptutils import parallelize
from .device_history import DeviceHistory
from .device_history_io import DeviceHistoryIO
from .device_history_base import DeviceHistoryBase
from .device_histories.air_tether import AIRTether
from .device_histories.amber import Amber
from .device_histories.balsam import Balsam
from .device_histories.ble_scanner import BLEScanner
from .device_histories.diamond import Diamond
from .device_histories.flintstone import Flintstone
from .device_histories.hiddenite import Hiddenite
from .device_histories.hobo import Hobo
from .device_histories.lithium import Lithium
from .device_histories.ngs import NGS
from .device_histories.pinna import Pinna
from .device_histories.pinna_tether import PinnaTether
from .device_histories.pinna_proto_tether import PinnaProtoTether
from .device_histories.quartz import Quartz
from .device_histories.tahiti_bridge import TahitiBridge
from .device_histories.topaz import Topaz
from .device_histories.transit import Transit
from .device_histories.weather import Weather
from .device_histories.weather_forecast import WeatherForecast
from .device_histories.wms_scanner import WMSScanner
from .temperature import Temperature
from .structure import Structure


def get_structure(device_type):
    """Returns structure based on device type."""
    for cls in [Diamond, Topaz, Amber]:
        if device_type in cls.DEVICE_TYPES:
            return cls
    raise ValueError("No class supports this device type")


# parallel loading and caching could not be done within the class definitions
#    because of multiprocessing limitations.  Instead, we'll do it
#    here and add the functionality back to the class afterwards

def load_device(kwargs, device_type):
    """Loads a device's history."""
    device_history = None
    try:
        device_history = device_type.load(**kwargs)
    except Exception:
        logging.exception('Error loading device history for class %s. kwargs: [%s]. Returning device_history None.',
                          device_type, kwargs)
    return device_history


def cache_device(kwargs, device_type):
    """Primes the cache for a device's history.

    Used in order to make subsequent loading perform faster.
    """
    success = True
    try:
        device_type.load(**kwargs)
    except Exception:
        logging.exception('Error caching device history for class %s. kwargs: [%s]. Returning device_history None.',
                          device_type, kwargs)
        success = False
    return success

device_types = [Amber, Balsam, Diamond, Hiddenite, Hobo, PinnaTether, PinnaProtoTether,
                Quartz, Temperature, Topaz, Structure, Transit, NGS, Weather, WMSScanner]
for device_type in device_types:
    setattr(device_type,
            'parallel_load',
            functools.partial(parallelize, function_to_run=functools.partial(load_device, device_type=device_type))
    )
    setattr(device_type,
            'parallel_cache',
            functools.partial(parallelize, function_to_run=functools.partial(cache_device, device_type=device_type))
    )
