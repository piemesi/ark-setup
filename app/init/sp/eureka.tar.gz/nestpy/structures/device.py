from ..validation.type_validation import assert_is_type


class Device(object):

    def __init__(self, device_id, structure_id=None):
        self._validate_structure_id(structure_id)
        self._device_id = device_id
        self._structure_id = structure_id

    def __repr__(self):
        return "<{}: device_id={}, structure_id={}>".format(
            self.__class__.__name__,
            self._device_id,
            self._structure_id
        )

    def __hash__(self):
        return hash((str(self.__class__), self._key))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self._key == other._key

    def __ne__(self, other):
        return not self.__eq__(other)

    @property
    def _key(self):
        return self._device_id, self._structure_id

    @staticmethod
    def _validate_structure_id(structure_id):
        if structure_id is not None:
            assert_is_type(structure_id, int)

    def get_device_id(self):
        return self._device_id

    def get_structure_id(self):
        return self._structure_id
