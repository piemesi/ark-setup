import copy
import pandas as pd

from .. import converters
from ..decorators.check_lock import check_lock


def generator_length(generator):
    """
    Returns the number of values in a Python generator in an efficient manner.

    http://stackoverflow.com/questions/393053/length-of-generator-output
    :param generator:
    :return: the number of values
    """
    return sum(1 for _ in generator)


class DeviceHistoryBase(object):
    """
    The base class for Device History.
    This class defines the structure of the object, special methods, and provides functions for working with
    the object.

    Except in rare instances, it should not be inherited directly, rather the DeviceHistory class should be inherited
    from to create individual DeviceHistory objects for each specific device.
    """

    def __init__(self):
        self.serial_number = None
        self.mac_address = None
        self.device_type = None
        self.structure_id = None
        self.tier = None
        self.events = []
        self.earliest_date = None
        self.latest_date = None
        self.native_events = []
        self.nonnative_events = []
        self.metadata = {}
        self._is_locked = False

    @check_lock
    def lock(self):
        self._is_locked = True

    def is_locked(self):
        return self._is_locked

    def __getitem__(self, key):

        if isinstance(key, slice):
            if key.step is not None:
                raise ValueError('DeviceHistory may not be sliced with a step')

            temp = copy.deepcopy(self)
            temp.earliest_date = None
            temp.latest_date = None

            start = key.start
            stop = key.stop
            if start:
                start = converters.get_tz_aware_datetime(start)

            if stop:
                stop = converters.get_tz_aware_datetime(stop)

            for event_type in list(self.events):
                dataframe = temp[event_type]
                if start:
                    dataframe = dataframe[dataframe.index >= start]
                if stop:
                    dataframe = dataframe[dataframe.index < stop]
                temp[event_type] = dataframe

                if len(dataframe) == 0:
                    # No data in this event - do not update the times
                    continue
                earliest_date = dataframe.index.min()
                if not temp.earliest_date or earliest_date < temp.earliest_date:
                    temp.earliest_date = earliest_date

                latest_date = dataframe.index.max()
                if not temp.latest_date or latest_date > temp.latest_date:
                    temp.latest_date = latest_date

            return temp
        else:
            return self.__dict__[key]

    def __getattr__(self, name):
        """
        Intercept calls to unimplemented methods for DeviceHistory objects.
        If the method is a valid function for a Pandas Dataframe, implement it
        on each event in the device history.

        Optional: Pass event_types to limit implementation to selected events
        """
        def method(*args, **kwargs):

            if 'event_types' in kwargs:
                event_types = kwargs['event_types']
                del kwargs['event_types']
            else:
                event_types = self.events

            temp = copy.deepcopy(self)

            for event in list(event_types):
                temp[event] = getattr(temp[event], name)(*args, **kwargs)

            return temp

        # Make sure the attribute is valid on Pandas DataFrames
        # Only implement functions for now, not special methods

        if name in dir(pd.DataFrame()) and not name.startswith('_'):
            return method
        else:
            raise AttributeError

    def __contains__(self, event_type):
        return event_type in self.__dict__ and len(self.__dict__[event_type]) > 0

    @check_lock
    def __setitem__(self, event_type, data):
        self.__dict__[event_type] = data

    @check_lock
    def __delitem__(self, event_type):
        del self.__dict__[event_type]

    def __iter__(self):
        return (x for x in self.events if x in self)

    def __len__(self):
        return generator_length(self.__iter__())

    def __str__(self):
        num_events = len(self.events)
        plurality = '' if num_events is 1 else 's'
        return "%s (%d event type%s from %s to %s)" % (self.unique_device_id,
                                                       num_events,
                                                       plurality,
                                                       self.earliest_date,
                                                       self.latest_date)

    def __repr__(self):
        return "<nestpy.DeviceHistory for %s>" % str(self)

    def __eq__(self, other):
        if self.unique_device_id == other:
            return True
        else:
            return False

    def __ne__(self, other):
        return not self.__eq__(other)

    @check_lock
    def add_event_data(self,
                       event_type,
                       event_data,
                       append=False,
                       sort_by_time=False,
                       native=True):
        """
        Adds the event data to the device history.

        If the event type already exists, the 'append' argument will determine
        whether the existing data will be overwritten or appended to.

        :param event_type:
            the type of event being added (i.e. "BufferedTemperature").
        :type event_type:
            str

        :param event_data:
            the data for the event type.
        :type event_data:
            pandas.DataFrame

        :param append:
            whether to append the new data to existing data instead of
            overwriting it.
        :type append:
            bool

        :param sort_by_time:
            whether to sort the events by time.
        :type sort_by_time:
            boolean

        :param native:
            whether the event was defined natively (i.e. in a header or schema)
            rather than computed or externally defined
        :type native:
            bool
        """

        # If the provided event data is empty, do not attempt to update the
        # device history's date ranges. However, we will still add the data to
        # the history. This allows the user to see that the event was parsed,
        # but contained no data within the specified time range.
        if event_data is not None and len(event_data) > 0 and event_data.empty != True:
            earliest_date = event_data.index.min()
            if not self.earliest_date or earliest_date < self.earliest_date:
                self.earliest_date = earliest_date

            latest_date = event_data.index.max()
            if not self.latest_date or latest_date > self.latest_date:
                self.latest_date = latest_date

        if append and event_type in self.events:
            updated_data = self.__dict__[event_type].append(event_data)
        else:
            updated_data = event_data

        # Save the dataframe as a member variable of this class. This makes
        # lookups less wordy (device.BufferedTemperature instead of
        # device["BufferedTemperature"]) and makes the events appear in auto-
        # completion.
        if sort_by_time:
            self.__dict__[event_type] = updated_data.sort()
        else:
            self.__dict__[event_type] = updated_data

        if event_type not in self.events:
            self.events.append(event_type)
            if native:
                self.native_events.append(event_type)
            else:
                self.nonnative_events.append(event_type)

    @check_lock
    def append(self, another_history, sort_by_time=False):
        """
        Appends the provided history data to this history.

        The appending is in-place, although this function will also return the
        updated Device History.

        :param another_history:
            another history to append.
        :type another_history:
            nestpy.DeviceHistory

        :param sort_by_time:
            whether to sort the events by time.
        :type sort_by_time:
            boolean

        :return:
            nestpy.DeviceHistory
        """

        for event_type in another_history.events:
            self.add_event_data(event_type, another_history[event_type], append=True, sort_by_time=sort_by_time)

        for (metadata_key, metadata_value) in another_history.metadata.items():
            self.add_metadata(metadata_key, metadata_value, append=True)

        return self

    @check_lock
    def delete_event_data(self,
                          event_type):
        """
        Removes the event data from the device history.

        :param event_type:
            the type of event being removed (i.e. "BufferedTemperature").
        :type event_type:
            str
        """

        # TODO: correctly update the earliest_date and latest_date as necessary
        if event_type in self.__dict__:
            del self.__dict__[event_type]

        try:
            self.events.remove(event_type)
        except ValueError:
            pass

        try:
            self.native_events.remove(event_type)
        except ValueError:
            pass

        try:
            self.nonnative_events.remove(event_type)
        except ValueError:
            pass

    @check_lock
    def add_metadata(self,
                     metadata_name,
                     metadata_value,
                     append=False):
        """
        Adds metadata to the device history. Metadata is stored in a dict of key,
        value pairs. Setting metadata for an existing key will overwrite
        the pre-existing key unless the 'append' flag is set to True.

        :param metadata_name:
            the type of metadata being added (i.e. "source_files").
        :type metadata_name:
            str

        :param metadata_value:
            the value to set for this metadata key. Any json serializable type is allowed.

        :param append:
            whether to append metadata for this key rather than overwriting it
        :type append:
            bool
        """

        if metadata_name not in self.metadata or not append:
            self.metadata[metadata_name] = metadata_value
        elif append:
            if type(self.metadata[metadata_name]) not in (list, dict):
                self.metadata[metadata_name] = [self.metadata[metadata_name]]
            if type(metadata_value) not in (list, dict):
                metadata_value = [metadata_value]

            if type(self.metadata[metadata_name]) is list:
                self.metadata[metadata_name] += metadata_value
            elif type(self.metadata[metadata_name]) is dict:
                self.metadata[metadata_name].update(metadata_value)

    @check_lock
    def consolidate_query_metadata(self):
        """
        Take the metadata queries, and combine queries that are overlapping into a single row.
        """
        if 'metadata' in self and 'queries' in self.metadata:
            df = pd.DataFrame.from_dict(self.metadata['queries'])

            # Convert columns to dates from strings:
            # Fix for pandas 0.17 version
            dt_columns =  ['start_date', 'end_date', 'queried_at']
            df[dt_columns] = df[dt_columns].apply(pd.to_datetime)

            new_df = []

            # Groupby and iterate by tier:
            for group, data in df.groupby('tier'):

                data = data.sort(dt_columns)

                current_query = None
                for index, row in data.iterrows():
                    if current_query is None:
                        current_query = row
                    elif (row['start_date'] == current_query['start_date'] and
                            row['end_date'] >= current_query['end_date']):
                        current_query['queried_at'] = row['queried_at']
                    elif (row['start_date'] >= current_query['start_date'] and
                          row['end_date'] >= current_query['end_date'] and
                          row['start_date'] <= current_query['end_date']):
                        current_query['end_date'] = row['end_date']
                        current_query['queried_at'] = min(current_query['queried_at'], row['queried_at'])
                    elif (row['start_date'] >= current_query['start_date'] and
                            row['end_date'] <= current_query['end_date']):
                        pass
                    else:
                        new_df.append(current_query)
                        current_query = row

                new_df.append(current_query)

            def to_iso(x):
                try:
                    return map(lambda y: y.isoformat(), x)
                except:
                    return x

            queries = pd.DataFrame(new_df).apply(to_iso).to_dict(outtype='records')

            self.add_metadata('queries', queries, append=False)

    @check_lock
    def drop_duplicates(self, sort_by_time=False):
        """Drops duplicate rows for each event
        The adjustment is performed in place, the returned DeviceHistory

        :param sort_by_time: whether to sort the events by time.
        :type sort_by_time: boolean

        :returns: the Diamond history, with updated indices
        :rtype: nestpy.Diamond
        """

        for event_type in self.events:
            event_data = self.__dict__[event_type]

            if len(event_data) == 0:
                continue

            event_data['dup_index'] = event_data.index.astype('object')
            event_data = event_data.drop_duplicates()
            del event_data['dup_index']

            self.add_event_data(event_type, event_data, sort_by_time=sort_by_time, append=False)

        return self

    def has_events(self):
        return len(self) > 0

    @staticmethod
    def is_valid(device_id):
        """Checks the device id to determine if it is a valid format.

        An abstract device has no ability to assert the validity of a device id, therefore we always return False.

        Subclasses should implement this according to their device id policies.

        Note: This does not actually check if a device exists with this identifier,
        only that the format of the identifier is valid
        """
        return False

