"""
 Copyright (c) 2013 Nest Labs, Inc.
 All rights reserved.

 This document is the property of Nest. It is considered
 confidential and proprietary information.

 This document may not be reproduced or transmitted in any form,
 in whole or in part, without the express written permission of
 Nest.

 Description:
    Temperature class that handles Celsius, Fahrenheit, and fixed-length
    integer values.

"""

class Temperature(object):
    """
    A generic temperature class that encapsulates multiple temperature units.
    """
    def __init__(self, value=0.0, unit='C'):
        self.unit = unit.lower()
        if self.unit in ('c', 'celsius'):
            self.celsius = value
        elif self.unit in ('f', 'fahrenheit'):
            self.fahrenheit = value
        elif self.unit in ('fixed'):
            self.fixed = value
        else:
            raise ValueError("Unsupported temperature unit ({0})".format(unit))

    @property
    def celsius(self):
        return self._value

    @celsius.setter
    def celsius(self, value):
        self._value = float(value)

    @property
    def fahrenheit(self):
        return self._value * 9 / 5 + 32

    @fahrenheit.setter
    def fahrenheit(self, value):
        self._value = (float(value) - 32) * 5 / 9

    @property
    def fixed(self):
        return long(self._value * 2 ** 16)

    @fixed.setter
    def fixed(self, value):
        self._value = float(value) / 2 ** 16

    def __add__(self, other):
        """ self + other """
        return Temperature(self.fixed + other.fixed, 'fixed')

    def __sub__(self, other):
        """ self - other """
        return Temperature(self.fixed - other.fixed, 'fixed')

    def __eq__(self, other):
        """ self == other """
        return self.fixed == other.fixed

    def __ne__(self, other):
        """ self != other """
        return not self.__eq__(other)

    def __lt__(self, other):
        """ self < other """
        return self.fixed < other.fixed

    def __le__(self, other):
        """ self <= other """
        return self.fixed <= other.fixed

    def __gt__(self, other):
        """ self > other """
        return self.fixed > other.fixed

    def __ge__(self, other):
        """ self >= other """
        return self.fixed >= other.fixed

    def __repr__(self):
        return "<nestpy.Temperature at %s>" % str(self)

    def __str__(self):
        return u'%1.1fC' % self._value
