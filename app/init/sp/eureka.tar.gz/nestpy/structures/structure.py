# pylint: disable=no-member
import logging
from .. import sql
from .device_histories.diamond import Diamond
from .device_histories.topaz import Topaz

from nestpy import env

logger = logging.getLogger(__name__)

DEVICE_CLASSES = {'Diamond': Diamond,
                  'Topaz': Topaz}


class Structure(object):
    """
    A class for holding data from multiple devices in a home.
    """

    def __init__(self, tier='production', structure_id=-1):

        #Properties of Structure
        self.structure_id = structure_id
        self.tier = tier
        self.start_date = None
        self.end_date = None

        self.database ={}
        self.analytics = {}

        # Database connections for retrieving information about devices
        self.database[tier]  = sql.get_db(tier, 'tier')
        self.analytics[tier] = sql.get_db(tier, 'analytics')

        # Containers to store devices
        self.unique_device_ids = []  # Mac Addresses
        self.device_types = DEVICE_CLASSES.keys()

        for dt in self.device_types:
            self[dt] = []

    def __getitem__(self, key):
        if isinstance(key, slice):
            if key.step is not None:
                raise ValueError('Structure may not be sliced with a step')

            raise ValueError('Time slicing not yet implemented for Structure')
        else:
            return self.__dict__[key]

    def __repr__(self):
        output = "<nestpy.Structure with"
        for device_type in self.device_types:
            output += " {} {},".format(len(self[device_type]), device_type)

        output = output[:-1] + ">"
        return output

    def __setitem__(self, device_type, data):
        self.__dict__[device_type] = data

    def __delitem__(self, device_type):
        del self.__dict__[device_type]

    def __iter__(self):
        return iter(self.unique_device_ids)

    def __len__(self):
        return len(self.unique_device_ids)

    @staticmethod
    def is_valid(structure_id):
        """
        Checks to structure id to determine if it is of a valid format
        """
        if (isinstance(structure_id, str) and structure_id.isdigit()) or isinstance(structure_id, int):
            return True
        else:
            return False

    def get_timezone(self):
        """
        Retrieves the timezone of the devices in the structure (currently, only
        Diamonds have a timezone). If more than one timezone is found, a warning
        is printed and the first timezone found is returned. If there is no
        timezone information available, None is returned.
        """
        timezone = None

        for dt in self.device_types:
            for device in self[dt]:
                if hasattr(device, 'get_timezone'):
                    if timezone is None:
                        timezone = device.get_timezone()
                    elif timezone != device.get_timezone():
                        logger.warning('Multiple timezones found!')

        return timezone

    def to_local_time(self, event_types=None):
        """
        This function gets the timezone from all devices that are timezone
        aware (have a get_timezone function).

        The adjustment is performed in place, the returned Structure reflects
        the time zone adjustments.

        If more than one timezone is found, a warning is printed and all
        devices are updated to the first timezone found. If there is no
        timezone information available for the structure, no changes are made.
        """
        timezones = []
        for dt in self.device_types:
            for device in self[dt]:
                if hasattr(device, 'get_timezone'):
                    timezones.append(device.get_timezone())

        if len(timezones) == 0:
            logger.error('No timezone information found for Structure {}'.format(self.structure_id))
        else:
            if len(set(timezones)) > 1:
                logger.warning('Multiple timezones found!')
            self.to_timezone(timezones[0], event_types=event_types)

        return self

    def to_timezone(self, timezone, event_types=None):
        """
        Adjusts all data in this Structure to the specified time zone.

        The adjustment is performed in-place; the returned Structure
        reflects the time zone adjustments.

        :param timezone:
            the time zone to set events to.
        :type timezone:
            pytz.timezone

        :param event_types:
            the event types to convert to local time. If not specified, all
            event types will be converted.
        :type event_types:
            list of str

        :returns:
            the Structure history, adjusted to local time.
        :rtype:
            nestpy.Structure
        """
        for dt in self.device_types:
            for device in self[dt]:
                device.to_timezone(timezone, event_types=event_types)

        return self

    def find_structure_id(self, device_id):

        # Currently there are 5 possible options:
        # Diamond SN: Use database/devices to get the structure ID
        # Topaz SN: Use database/devices to get the stucture ID
        # Diamond Mac: Use analytics/devices to get the serial number
        # Topaz Mac: Use database/devices to get the stucture ID with decimal mac
        # Structure ID: Use passed-in structure ID

        # A table is currently being created in analytics that will greatly simplify this process. Until then,
        # this is a working solution.

        query_key = None
        # If Diamond MAC address, convert to the serial number with the analytics database
        if Diamond.is_mac_address(device_id):

            query = "select serial_number, mac_address from devices where mac_address = '{}'".format(device_id.lower())
            r =  self.analytics['ft']().query(query)
            if len(r) == 0:
                r = self.analytics['production']().query(query)
                if len(r) != 1:
                    raise ValueError('Prod Query {} returned {} results. Expected 1 result'.format(query, len(r)))
            elif len(r) != 1:
                raise ValueError('FT Query {} returned {} results. Expected 1 result'.format(query, len(r)))
            device_id = r.serial_number.values[0]
            query_key = "mac = '{}'".format(device_id.upper())

        # If Diamond Serial Number, we can just query with it.
        elif Diamond.is_serial_number(device_id):
            query_key = "mac = '{}'".format(device_id.upper())

        # If Topaz MAC address, we need it in decimal format
        elif Topaz.is_mac_address(device_id):
            device_id = int(device_id, 16)
            query_key = "weave_device_id = '{}'".format(device_id)

            # If Topaz serial number, we can just query with it
        elif Topaz.is_serial_number(device_id):
            query_key = "mac = '{}'".format(device_id.upper())

        elif Structure.is_valid(device_id):
            self.structure_id = int(device_id)

        else:
            raise ValueError('{} is not a valid ID'.format(device_id))
        
        if query_key is not None:

            # Query for the structure ID
            query = "select mac, weave_device_id, structure_id from devices where " + query_key
            
            r = self.database['ft']().query(query)
            if len(r) == 0:
                r = self.database['production']().query(query)
                if len(r) != 1:
                    raise ValueError('Prod Query {} returned {} results. Expected 1 result.'.format(query, len(r)))
                self.tier = 'production'
            elif len(r) != 1:
                raise ValueError('FT Query {} returned {} results. Expected 1 result'.format(query, len(r)))
            else:
                self.tier = 'ft'
            if 'structure_id' not in r or r.structure_id.values[0] is None:
                raise ValueError('Structure ID not found for device ID: {}'.format(device_id))
            self.structure_id = int(r.structure_id.values[0])

    def find_other_devices(self):
        """
        Search the database for all devices with the structure ID in self.structure_id
        """

        # Search the database for all devices in the structure
        analytics_db = self.analytics[self.tier]()
        query = \
            "select serial_number, mac_address from devices where " \
            "device_type != 'quartz' and structure_id = {}".format(self.structure_id)
        
        query_results = analytics_db.query(query)
        if not query_results.empty:
            devices = query_results.mac_address
            self.unique_device_ids = devices.tolist()
        else:
            self.unique_device_ids = []
            
    def fill_structure(self, cache_destination, event_types=None, overwrite=True):
        """
        Fill the device histories with data from the devices in the structure.
        All devices listed in self.unique_device_ids will be loaded
        """
        devices = {}
        for dt in self.device_types:
            devices[dt] = []

        for device in self.unique_device_ids:
            self.add_device(device, cache_destination, event_types=event_types, overwrite=overwrite)

    @classmethod
    def load(cls, data_source, start_date=None, end_date=None, tier=None, event_types=None, cache_destination=env.cache_destination()):
        """
        Load all devices within a structure

        :param data_source:
            the source to load device data from. Appropriate values
            are:

            - *string* if the data source is a device MAC address, Serial Number, or structure ID.
            - *integer* if the data source is a structure ID
        :type data_source:
            {str, int}

        :param tier:
            the service tier that the device belongs to ("ft", "qa", or
            "production"). Only used if the data source is S3.
        :type tier:
            str

        :param start_date:
            the earliest date to get logs for.
        :type start_date:
            timezone-aware datetime or timezone-naive UTC datetime

        :param end_date:
            the latest date to get logs for.
        :type end_date:
            timezone-aware datetime or timezone-naive UTC datetime

        :param event_types:
            a list of event types to include. If not provided, all event types
            will be loaded.
        :type event_types:
            list of str

        :returns:
            the populated Structure.
        :rtype:
            nestpy.Structure
        """

        if isinstance(data_source, str) or isinstance(data_source, int):
            new_structure = Structure(tier)
            new_structure.find_structure_id(data_source)
        else:
            raise ValueError("Data source '%s' not understood", data_source)

        # Load Data
        new_structure.find_other_devices()

        new_structure.start_date = start_date
        new_structure.end_date = end_date

        new_structure.fill_structure(cache_destination, event_types)

        return new_structure

    def add_device(self, mac_address, destination, event_types=None, overwrite=True):
        logger.debug("Adding device [%s] to structure.", mac_address)

        # Add mac address to device id list:
        if mac_address not in self.unique_device_ids:
            self.unique_device_ids.append(mac_address)

        for dt in self.device_types:
            if DEVICE_CLASSES[dt].is_valid(mac_address):
                if not overwrite:
                    # Check to see if the device has already been loaded
                    for d in self[dt]:
                        if d == mac_address:
                            return
                try:
                    self[dt].append(DEVICE_CLASSES[dt].load(mac_address,
                                                            start_date=self.start_date,
                                                            end_date=self.end_date,
                                                            tier=self.tier,
                                                            event_types=event_types,
                                                            cache_destination=destination))
                except Exception as e:
                    logger.error('Error loading %s: %s' % (str(dt), str(mac_address)))
                    logger.error(str(e))
                    pass
                break
        else:
            raise ValueError("MAC address %s is not understood", mac_address)
