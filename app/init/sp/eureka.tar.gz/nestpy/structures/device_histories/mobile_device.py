from ..device_history import DeviceHistory
from ... import env


class MobileDevice(DeviceHistory):

    DATASET_IDS = {DeviceHistory.FT: 'FT_Raw_Event_Geofence'}
    DEVICE_ID_TYPES = {DeviceHistory.FT: 'mobileDeviceId'}
    PROJECT_IDS = {DeviceHistory.FT: 'nest-algo'}
    QUERY_PROJECT_IDS = {DeviceHistory.FT: 'nest-data'}
    TABLE_INDICES = {DeviceHistory.FT: 'assertionTime'}
    TABLE_PREFIXES = {DeviceHistory.FT: 'GeofenceEvents_'}

    SAMPLE_TIME_FIELDS = {'fenceEvents': ['eventTime']}
    FILTER_STRUCTURE_FIELDS = {'fenceEvents': 'structureId'}

    def __repr__(self):
        return "<nestpy.MobileDevice for %s>" % str(self)

    def filter_structure(self, structure_uuid):
        for event in self.FILTER_STRUCTURE_FIELDS:
            structure_field = self.FILTER_STRUCTURE_FIELDS[event]
            if event in self.events and structure_field in self[event].columns:
                self.add_event_data(event, self[event][self[event][structure_field] == structure_uuid])

    @classmethod
    def load(
            cls,
            device_id,
            start_date=None,
            end_date=None,
            tier=None,
            event_types=None,
            cache_destination=env.cache_destination(),
            **kwargs
    ):
        """
        nestpy.MobileDevice.load wraps nestpy.DeviceHistory.load with:

        :param device_id:
            the mobile device identifier
        :type device_id:
            string

        :param start_date:
            the earliest date to get logs for.
        :type start_date:
            timezone-aware datetime or timezone-naive UTC datetime

        :param end_date:
            the latest date to get logs for.
        :type end_date:
            timezone-aware datetime or timezone-naive UTC datetime

        :param tier:
            the service tier that the device belongs to
        :type tier:
            string

        :param event_types:
            events to be fetched
        :type event_types:
            list

        :param cache_destination:
            the parent folder in which to store raw and parsed data
        :type cache_destination:
            string

        :returns:
            the populated MobileDevice device history.
        :rtype:
            nestpy.MobileDevice
        """
        mobile_device = super(MobileDevice, cls).load(
            device_id=device_id,
            start_date=start_date,
            end_date=end_date,
            tier=tier,
            event_types=event_types,
            download_from=DeviceHistory.GCP,
            sort_by_time=True,
            cache_destination=cache_destination
        )

        mobile_device.index_by_sample_time(
            event_types=event_types,
            sample_time_fields=cls.SAMPLE_TIME_FIELDS,
            sort_by_time=True
        )

        return mobile_device
