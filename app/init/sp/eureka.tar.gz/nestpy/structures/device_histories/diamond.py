import datetime
import json
import logging
import os

import pandas as pd
import pytz

from ...decorators import deprecated
from ..device_history import DeviceHistory
from ... import env
from ...parsing import diamond_events
from ...parsing import diamond_utils
from .weather import Weather
from .weather_forecast import WeatherForecast

logger = logging.getLogger(__name__)


class Diamond(DeviceHistory):
    """
    A DeviceHistory subclass specifically for Diamond.
    """

    with open(os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.realpath(__file__)))), 'parsing', 'diamond_definitions', 'diamond_event_fields.json')) as data_file:
        EVENT_FIELD_DEFINITION = json.load(data_file)

    TIMESTAMP_FIELDS = {event_type: field for timestamp_field in
        [{event_type: [field for field in EVENT_FIELD_DEFINITION[event_type]
        if ("type" in EVENT_FIELD_DEFINITION[event_type][field]) and (EVENT_FIELD_DEFINITION[event_type][field]["type"] == "timestamp")]}
        for event_type in EVENT_FIELD_DEFINITION]
        for event_type, field in timestamp_field.items() if field}
    TEMPERATURE_FIELDS = {event_type: field for timestamp_field in
        [{event_type: [field for field in EVENT_FIELD_DEFINITION[event_type]
        if ("physical_quantity" in EVENT_FIELD_DEFINITION[event_type][field]) and (EVENT_FIELD_DEFINITION[event_type][field]["physical_quantity"] == "temperature")]}
        for event_type in EVENT_FIELD_DEFINITION]
        for event_type, field in timestamp_field.items() if field}
    SAMPLE_TIME_FIELDS = {event_type: field for timestamp_field in
        [{event_type: [field for field in EVENT_FIELD_DEFINITION[event_type]
        if ("sample_time" in EVENT_FIELD_DEFINITION[event_type][field]) and EVENT_FIELD_DEFINITION[event_type][field]["sample_time"]]}
        for event_type in EVENT_FIELD_DEFINITION]
        for event_type, field in timestamp_field.items() if field}

    DEVICE_TYPES = ['diamond', 'j49', 'amber', 'diamond3']
    LOG_TYPE = 'clientevent'
    MAC_LENGTH = 12
    MAC_STARTSWITH = '18b43'
    SERIAL_LENGTH = 16
    SERIAL_STARTSWITH = ['01AA', '02AA', '09AA']

    DATASET_IDS = {DeviceHistory.FT: 'diamond'}
    DEVICE_ID_TYPES = {DeviceHistory.FT: 'mac_address'}
    PROJECT_IDS = {DeviceHistory.FT: 'nest-algo'}
    QUERY_PROJECT_IDS = {DeviceHistory.FT: 'nest-algo'}
    TABLE_INDICES = {DeviceHistory.FT: 'timeindex'}
    TABLE_PREFIXES = {DeviceHistory.FT: 'daily'}

    def __init__(self, device_name=None):
        super(Diamond, self).__init__(device_name)
        self.zip_code = None
        self.weather_from_server = None

    def __repr__(self):
        return "<nestpy.Diamond for %s>" % str(self)

    def has_current_state(self):
        return "CurrentState" in self

    @staticmethod
    def is_mac_address(device_id):
        if isinstance(device_id, str) and device_id.isalnum() and \
           device_id[:5].lower() == Diamond.MAC_STARTSWITH and len(device_id) == Diamond.MAC_LENGTH:
            return True

        return False

    @staticmethod
    def is_serial_number(device_id):
        if isinstance(device_id, str) and device_id.isalnum() and \
           device_id[:4].upper() in Diamond.SERIAL_STARTSWITH and len(device_id) == Diamond.SERIAL_LENGTH:
            return True

        return False

    @staticmethod
    def is_valid(device_id):
        """
        Checks the device id to determine if it is a valid format for a
        Diamond serial number or mac address.
        Note: This does not actually check if a device exists with this identifier,
        only that the format of the identifier is valid
        """
        if Diamond.is_mac_address(device_id) or Diamond.is_serial_number(device_id):
            return True

        return False

    def get_timezone(self):
        """
        Gets the local time zone for this device, based on the CurrentState
        data. Returns the most recent timezone found.

        :returns:
            the timezone of this device.
        :rtype:
            pytz.timezone
        """
        if not self.has_current_state():
            logger.debug('No CurrentState found for device: '+ str(self))
            return None

        timezones = self["CurrentState"].TimeZoneFile
        logger.debug("Timezones loaded: %s " % str(timezones))

        if not len(timezones):
            return None

        timezone_string = timezones[-1]
        timezone_string = timezone_string.replace('\\/', '/')  # Fix for a bug in sapphire with timezone formatting
        timezone = pytz.timezone(timezone_string)

        logger.debug("timezone is %s and localized as %s " % (str(timezone_string), str(timezone)))

        return timezone

    def get_location(self):
        """
        Gets the local time zone name for this device, based on the CurrentState
        data. Returns the most recent timezone found.

        :returns:
            the timezone string
        :rtype:
            string
        """
        if not self.has_current_state():
            return None

        timezones = self["CurrentState"].TimeZoneFile

        if not len(timezones):
            return None

        timezone_string = timezones[-1]
        return timezone_string

    @deprecated("Pass a parameter to `load`, instead.")
    def to_local_time(self, event_types=None):
        """
        Adjusts all data in this Diamond history to the local time of the
        history.

        The adjustment is performed in-place; the returned DeviceHistory
        reflects the time zone adjustments.

        If there is more than one timezone in the history, all data will be
        updated to the local timezone - even if it is actually from a different
        timezone.

        :param event_types:
            the event types to convert to local time. If not specified, all
            event types will be converted.
        :type event_types:
            list of str

        :returns:
            the Diamond history, adjusted to local time.
        :rtype:
            nestpy.Diamond
        """
        timezone = self.get_timezone()
        if timezone is not None:
            self.in_local_time = True
            self.to_timezone(self.get_timezone(), event_types=event_types)
        else:
            self.in_local_time = False
            logger.warn("Cannot determine the Time Zone.")

        return self

    def to_timezone(self, timezone, event_types=None):
        """
        Adjusts all data in this Diamond to the specified time zone.

        The adjustment is performed in-place; the returned Diamond
        reflects the time zone adjustments.

        :param timezone:
            The time zone to set events to.
        :type timezone:
            pytz.timezone

        :param event_types:
            The event types to convert to local time. If not specified, all
            event types will be converted.
        :type event_types:
            list of str

        :returns:
            The Diamond history, adjusted to local time.
        :rtype:
            nestpy.Diamond
        """
        return super(Diamond, self).to_timezone(timezone,
                                                event_types=event_types,
                                                timestamp_fields=Diamond.TIMESTAMP_FIELDS)

    @deprecated("Pass as parameter in 'load' instead.")
    def index_by_sample_time(self, event_types=None, sort_by_time=False):
        """
        Reindex events using a different column as the index instead of the upload time.
        The new index must be a tz aware time object

        The adjustment is performed in-place; the returned Diamond
        reflects the new indices

        :param event_types:
            the event types to convert to local time. If not specified, all
            event types will be converted.
        :type event_types:
            list of str

        :param sort_by_time:
            whether to sort the events by time.
        :type sort_by_time:
            boolean

        :returns:
            the Diamond history, with updated indices
        :rtype:
            nestpy.Diamond
        """
        return super(Diamond, self).index_by_sample_time(event_types=event_types,
                                                         sort_by_time=sort_by_time,
                                                         sample_time_fields=Diamond.SAMPLE_TIME_FIELDS)

    @deprecated("Pass as parameter in 'load' instead.")
    def celsius_to_fahrenheit(self, event_types=None, sort_by_time=False):
        """
        Converts temperature data in this Diamond from
        Celsius to Fahrenheit.

        The adjustment is performed in-place; the returned Diamond
        reflects the temperature conversions.

        :param event_types:
            The event types containing temperature columns to be converted.
        :type event_types:
            list of str

        :param event_field_definition:
            The definitions of the event fields.
        :type event_field_definition:
            dict

        :returns:
            The Diamond, reflecting the temperature conversions.
        :rtype:
            nestpy.Diamond
        """
        return super(Diamond, self).convert_temperature_unit(event_types=event_types,
                                                             temperature_fields=Diamond.TEMPERATURE_FIELDS,
                                                             temperature_unit="F")

    @classmethod
    def load(cls,
             device_id,
             start_date=None,
             end_date=None,
             tier=None,
             event_types=None,
             download_from=DeviceHistory.AWS,
             cache_destination=env.cache_destination(),
             offline=False,
             sort_by_time=False,
             to_local_time=False,
             celsius_to_fahrenheit=False,
             index_by_sample_time=False,
             load_weather_underground=False,
             load_weather_forecast=False):
        """
        nestpy.Diamond.load wraps nestpy.DeviceHistory.load with:
            log_type set to 'clientevent'

        :param device_id:
            the device identifier, typically a macaddress
        :type device_id:
            string

        :param start_date:
            the earliest date to get logs for.
        :type start_date:
            timezone-aware datetime or timezone-naive UTC datetime

        :param end_date:
            the latest date to get logs for.
        :type end_date:
            timezone-aware datetime or timezone-naive UTC datetime

        :param tier:
            the service tier that the device belongs to ("ft", "qa", or
            "production"). Only used if the data source is S3.
        :type tier:
            string

        :param cache_destination:
            the parent folder in which to store raw and parsed data
        :type cache_destination:
            string

        :param offline:
            whether or not to allow downloading
        :type tier:
            boolean

        :param to_local_time:
            whether to convert timestamp fields to local time
        :type to_local_time:
            boolean

        :param celsius_to_fahrenheit:
            whether to convert temperature fields from celsius to fahrenheit
        :type celsius_to_fahrenheit:
            boolean

        :param index_by_sample_time:
            whether to set indices of events to specified sample times
        :type index_by_sample_time:
            boolean

        :returns:
            the populated Diamond device history.
        :rtype:
            nestpy.Diamond
        """
        if to_local_time and (event_types is not None) and ("CurrentState" not in event_types):
            event_types.insert(0, "CurrentState")

        diamond = super(Diamond, cls).load(device_id=device_id,
                                           log_type=Diamond.LOG_TYPE,
                                           start_date=start_date,
                                           end_date=end_date,
                                           tier=tier,
                                           event_types=event_types,
                                           download_from=download_from,
                                           sort_by_time=sort_by_time,
                                           cache_destination=cache_destination,
                                           offline=offline)

        if to_local_time:
            timezone = diamond.get_timezone()
            if timezone is not None:
                super(Diamond, diamond).to_timezone(timezone,
                                                    event_types=event_types,
                                                    timestamp_fields=Diamond.TIMESTAMP_FIELDS)
                diamond.in_local_time = True
            else:
                diamond.in_local_time = False
                logger.warn("Cannot find timezone for device.")

        if celsius_to_fahrenheit:
            super(Diamond, diamond).convert_temperature_unit(event_types=event_types,
                                                             temperature_fields=Diamond.TEMPERATURE_FIELDS,
                                                             temperature_unit="F")
        if index_by_sample_time:
            super(Diamond, diamond).index_by_sample_time(event_types=event_types,
                                                         sample_time_fields=Diamond.SAMPLE_TIME_FIELDS,
                                                         sort_by_time=sort_by_time)
        if load_weather_underground:
            diamond.add_weather_from_server(cache_destination, celsius_to_fahrenheit)

        if load_weather_forecast:
            if end_date.date() < datetime.datetime.today().date():
                logger.warn("Weather forecast data not available")
            else:
                diamond.add_weather_forecast_from_server(to_local_time, celsius_to_fahrenheit)

        # and post-process
        diamond_events.parse_diamond_events(diamond)
        return diamond

    def add_weather_from_server(self, weather_cache_destination=env.cache_destination(), celsius_to_fahrenheit=False):
        """
        Add Weather from server as an object in the Diamond device history.
        """

        # Zip code extraction code. There is an issue in the code base where the zip code is read as an integer from
        # directoried logs.  This code corrects that to make it a string if necessary. Leading zeros are added to
        # zipcodes where the integer conversion drops the leading zero.
        try:
            self.zip_code = self.CurrentState.ZipCode[pd.notnull(self.CurrentState.ZipCode)][0]
        except:
            raise KeyError("Could not extract zip code from Diamond device history CurrentState.")

        wdh = Weather.load(self.zip_code,
                           start_date=self.earliest_date,
                           end_date=self.latest_date,
                           sort_by_time=True,
                           tier='wunderground',
                           event_types=None,
                           cache_destination=weather_cache_destination,
                           offline=False,
                           celsius_to_fahrenheit=celsius_to_fahrenheit)

        # Convert to diamond local time if flag is set
        if self.in_local_time:
            wdh.to_timezone(self.get_timezone())

        # Add the weather events as top level events
        self.add_event_data('WeatherUndergroundDailySummary', wdh.DailyWeatherSummary, native=False)
        self.add_event_data('WeatherUndergroundHourly', wdh.HourlyWeather, native=False)

        return self

    def add_weather_forecast_from_server(self,to_local_time=False, celsius_to_fahrenheit=False):
        """
        Add Weather from server as an object in the Diamond device history.
        """

        try:
            self.zip_code = self.CurrentState.ZipCode[pd.notnull(self.CurrentState.ZipCode)][0]
        except:
            raise KeyError("Could not extract zip code from Diamond device history CurrentState.")
        daily_df, hourly_df = WeatherForecast.get_forecast(self.zip_code,celsius_to_fahrenheit,to_local_time)

        self.add_event_data('WeatherUndergroundDailyForecast', daily_df, native=False)
        self.add_event_data('WeatherUndergroundHourlyForecast', hourly_df, native=False)
        return self

    @classmethod
    def from_raw_event_logs(cls,
                            log_file_list,
                            unique_device_id=None,
                            event_types=None,
                            sort_by_time=False,
                            tier=None):

        if type(log_file_list) != list:
            log_file_list = [log_file_list]

        # for Diamond logs in particular, it is
        # faster to concatenate all before parsing
        destination_filename = os.path.join(os.curdir, "%s_combined.log.gz" % unique_device_id)
        source_file_metadata = {}
        with open(destination_filename, 'w') as outfile:
            for filepath in log_file_list:
                with open(filepath) as infile:
                    outfile.write(infile.read())
                filename = os.path.basename(filepath)
                source_file_metadata[filename] = {}
                source_file_metadata[filename].update({
                    'parsed' : True,
                    'filetime' : str(cls._extract_upload_time_from_filename(filename)),
                    'parsed_at' : str(datetime.datetime.now())
                })
        logger.debug("%d files combined to %s", len(log_file_list), destination_filename)

        dh = cls.from_raw_event_log(destination_filename,
                                    unique_device_id=unique_device_id,
                                    event_types=event_types,
                                    sort_by_time=sort_by_time,
                                    tier=tier)
        os.remove(destination_filename)

        return dh, source_file_metadata

    # general accessor functions that deal with this specific device's log style
    def get_temperature(self):
        temperature = None
        if 'BufferedTemperature' in self and 'temperature' in self.BufferedTemperature:
            temperature = self.BufferedTemperature.temperature
        return temperature

    def get_humidity(self):
        humidity = None
        if 'BufferedTemperature' in self and 'humidity' in self.BufferedTemperature:
            humidity = self.BufferedTemperature.humidity
        return humidity

    def get_occupancy(self):
        occupied = None
        if 'BufferedPassiveInfrared' in self and \
           'threshold' in self.BufferedPassiveInfrared and \
           'max' in self.BufferedPassiveInfrared:
            occupied = self.BufferedPassiveInfrared['max'] > self.BufferedPassiveInfrared.threshold
        return occupied

    def get_schedule_mode(self, time):
        """
        Gets the device's schedule mode for the given time as a string
        :param time: time to get schedule mode for
        :type time: timezone-aware datetime or timezone-naive UTC datetime
        :returns: schedule mode as a string
        :rtype: string
        """

        if not self.has_current_state():
            return None

        appropriate_vals = self.CurrentState.index <= time

        if len(appropriate_vals.nonzero()[0]) > 0:
            schedule_index = self.CurrentState.ScheduleMode[appropriate_vals].iloc[-1]
        else:
            schedule_index = self.CurrentState.ScheduleMode[~appropriate_vals].iloc[0]

        return diamond_utils.nlScheduleMode[int(schedule_index)]

