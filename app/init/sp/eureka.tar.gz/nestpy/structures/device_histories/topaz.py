import datetime

from ... import env
from ... parsing import topaz_events, topaz_tvd, topaz_utils

from ..device_history import DeviceHistory


class Topaz(DeviceHistory):
    """
    A DeviceHistory subclass specifically for Topaz.
    """

    DEVICE_TYPES = ['topaz']
    MAC_LENGTH = 16
    MAC_STARTSWITH = '18b43'
    SERIAL_LENGTH = 16
    SERIAL_STARTSWITH = ['05']
    LOG_TYPE = topaz_tvd.DEFAULT_LOG_TYPE

    DATASET_IDS = {DeviceHistory.FT: 'topaz'}

    def __init__(self, device_name=None):
        super(Topaz, self).__init__(device_name)

    def __repr__(self):
        return "<nestpy.Topaz for %s>" % str(self)

    @staticmethod
    def is_mac_address(device_id):
        if (isinstance(device_id, str) and device_id.isalnum() and
                        device_id[:5].lower() == Topaz.MAC_STARTSWITH and len(device_id) == Topaz.MAC_LENGTH):
            return True

        return False

    @staticmethod
    def is_serial_number(device_id):
        if (isinstance(device_id, str) and device_id.isalnum() and
                        device_id[:2].upper() in Topaz.SERIAL_STARTSWITH and len(device_id) == Topaz.SERIAL_LENGTH):
            return True

        return False

    @staticmethod
    def is_valid(device_id):
        """
        Checks the device id to determine if it is a valid format for a
        Topaz serial number or mac address.
        Note: This does not actually check if a device exists with this identifier,
        only that the format of the identifier is valid
        """
        if Topaz.is_mac_address(device_id) or Topaz.is_serial_number(device_id):
            return True

        return False

    @classmethod
    def load(cls,
             device_id,
             start_date=None,
             end_date=None,
             tier=None,
             event_types=None,
             download_from=DeviceHistory.AWS,
             cache_destination=env.cache_destination(),
             offline=False):
        """
        nestpy.Topaz.load wraps nestpy.DeviceHistory.load for Topaz

        :param device_id:
            device mac address
        :type device_id:
            str

        :param start_date:
            the earliest date to get logs for.
        :type start_date:
            timezone-aware datetime or timezone-naive UTC datetime

        :param end_date:
            the latest date to get logs for.
        :type end_date:
            timezone-aware datetime or timezone-naive UTC datetime

        :param tier:
            the service tier that the device belongs to ("ft", "qa", or
            "production"). Only used if the data source is S3.
        :type tier:
            string

        :param cache_destination:
            the parent folder in which to store raw and parsed data
        :type cache_destination:
            string

        :param offline:
            whether or not to allow downloading
        :type tier:
            boolean

        :returns:
            the populated Device History.
        :rtype:
            nestpy.DeviceHistory
        """
        topaz = super(Topaz, cls).load(device_id=device_id,
                                       log_type=Topaz.LOG_TYPE,
                                       start_date=start_date,
                                       end_date=end_date,
                                       tier=tier,
                                       event_types=event_types,
                                       download_from=download_from,
                                       cache_destination=cache_destination,
                                       offline=offline)

        # and post-process
        topaz_events.parse_topaz_event_fields(topaz)
        return topaz

    @classmethod
    def from_raw_event_logs(cls,
                            log_file_list,
                            unique_device_id=None,
                            event_types=None,
                            sort_by_time=False,
                            tier=None):

        if type(log_file_list) != list:
            log_file_list = [log_file_list]

        (data, source_file_metadata) = topaz_tvd.parse_tvd_files(log_file_list)

        topaz = cls(unique_device_id)

        # store parsed data in the Topaz object
        if data is not None:
            for sensor_type in data:
                dataframe = data[sensor_type]

                if sort_by_time:
                    dataframe = dataframe.sort()

                if "Ultrasonic" in sensor_type:
                    try:
                        # Convert bucketized distances to actual distances
                        dataframe = topaz_utils.resolve_ultrasonic(dataframe)
                    except ValueError:
                        # These logs are not in bucketized format; don't
                        # try to resolve distances using bucketization
                        pass

                topaz.add_event_data(sensor_type, dataframe)

        return (topaz, source_file_metadata)


    @staticmethod
    def _get_files_to_parse_in_directory(directory_name, log_type, start_date, end_date):
        """
        Returns a list logfiles that should be parsed from the specified directory.
        Topaz optimizes to avoid parsing files that are unlikely to contain data
        in the timeframe.

        :param directory_name:
            path to a directory containing logfiles
        :param start_date:
            as an optimization, reject logs uploaded some time before the target start date
        :param end_date:
            as an optimization, reject logs uploaded some time after the target end date

        :rtype:
            dict of Pandas dataframes
        """

        return topaz_tvd.get_files_to_parse_in_tvd_directory(directory_name, start_date, end_date)

    # general accessor functions that deal with this specific device's log style
    def get_temperature(self):
        T = None
        if 'Temperaturebucket' in self and 'Value0' in self.Temperaturebucket:
            T = self.Temperaturebucket.Value0[self.Temperaturebucket.Value0 != 0]
        return T

    def get_humidity(self):
        RH = None
        if 'Humiditybucket' in self and 'Value0' in self.Humiditybucket:
            RH = self.Humiditybucket.Value0[self.Humiditybucket.Value0 != 0]
        return RH

    def get_occupancy(self):
        Occupied = None
        if ('Passiveinfraredbucket' in self and
                        'Value0' in self.Passiveinfraredbucket):
            Occupied = self.Passiveinfraredbucket.Value0 > 100
        return Occupied
