# pylint: disable=no-member

import datetime
from datetime import timedelta
import json
import logging
import numpy as np
import os
import pandas as pd
from pytz import timezone
import urllib
from urllib import urlretrieve, urlopen
from urllib2 import urlopen

from ...fileutils import mkdir_p

from ..device_history import DeviceHistory
from ...converters import c2f

logger = logging.getLogger(__name__)

MAX_EARTH_TEMP = 135.
MIN_EARTH_TEMP = -127.

class WeatherForecast:

    def __repr__(self):
        return "<nestpy.WeatherForecast for %s>" % str(self)

    @classmethod
    def get_forecast(cls,zip_code,celsius_to_fahrenheit=False,to_local_time=False):
        """
        Object that returns two dataframes: 
            one containing 7 days forecast summary
            one containing hourly forecast for 3 days ahead

        :param zip_code:
            the zip code for which you want the weather data
        :type zip_code:
            string

        :param celsius_to_fahrenheit:
            whether to convert temperature fields from celsius to fahrenheit
        :type celsius_to_fahrenheit:
            boolean

        :param to_local_time:
            whether to convert to local time or keep in UTC
        :type:
            bool

        """
        data, tz_string = cls.download_current_forecast_from_wunderground(zip_code)
        daily_df, hourly_df = cls.from_raw_data(data, tz_string,to_local_time)

        # Range filtering to make sure that the temperatures are between the max and min bounds of Earth surface temps.
        def outdoor_temp_filter(temperature):
            if temperature > MIN_EARTH_TEMP and temperature < MAX_EARTH_TEMP:
                return temperature
            else:
                return np.nan
        
        if 'temp_c' in hourly_df.columns:
            filtered_outdoor_temp = hourly_df.temp_c.map(outdoor_temp_filter)

        # Convert to Farenheit if flag is set. Always create a new field in the Hourly Weather called Temperature.
        # This will hold the converted temperature.
        if celsius_to_fahrenheit:
            hourly_df['Temperature'] = c2f(filtered_outdoor_temp)
        else:
            hourly_df['Temperature'] = filtered_outdoor_temp

        return  daily_df,hourly_df

    @classmethod
    def download_current_forecast_from_wunderground(cls, zip_code):
        """
        Download latest forecast data from weather Underground
        :param zip_code:
            the zip code for which you want the weather data
        :type zip_code:
            string
        """

        day_date = datetime.datetime.today().date()
        logger.debug('Downloading Forecast for {} on day {} from Weather Underground API'.format(zip_code, day_date))
        url = "http://www.wunderground.com/auto/nestlabs/geo/current/i?query={}".format(zip_code)
        response = urllib.urlopen(url)
        data = json.loads(response.read())
        tz_string = data[zip_code]['location']['timezone_long']
        return data, tz_string
        
    @classmethod
    def from_raw_data(cls, data, tz_string, to_local_time):
        """
        Creates a two weather dataframes from json data.
        """

        weather_dict = {'WeatherUndergroundDailyWeatherForecast': {}, 'WeatherUndergroundHourlyWeatherForecast': {}}

        # Parse json
        try:
            append_weather_dict = cls.parse_forecast_json(data, tz_string, to_local_time)
        except ValueError as ve:
            print "Could not parse Weather Underground json "  + ve.message

        # Append dictionary
        for event_type in weather_dict:
            weather_dict[event_type].update(append_weather_dict[event_type])

        # Create the data frames for the future device history events. Note that it is tz_aware
        daily_df = pd.DataFrame.from_dict(weather_dict['WeatherUndergroundDailyWeatherForecast'], orient='index')
        daily_df.index.name = 't'
        hourly_df = pd.DataFrame.from_dict(weather_dict['WeatherUndergroundHourlyWeatherForecast'], orient='index')
        hourly_df.index.name = 't'

        return daily_df, hourly_df   

    @classmethod
    def parse_forecast_json(cls,data, tz_string,to_local_time):
        """
        This parses the three days forecast datadata from the Weather Underground JSON and returns a dictionary with two top level
        keys: DailyWeatherForecast and HourlyWeatherForecast.
        """
        wdict = {}
        keys = data.keys()

        # Create hourly weather forecast dictionary indexed by datetime
        hourly_forecast_df = pd.DataFrame(data[keys[0]]['forecast']['hourly'])
        index = pd.DatetimeIndex([datetime.datetime.fromtimestamp(x) for x in hourly_forecast_df['time']])
        hourly_forecast_df = hourly_forecast_df.set_index(index)
        del hourly_forecast_df['date']

        # Create Daily weather forecast dictionary indexed by datetime
        daily_forecast_df = pd.DataFrame(data[keys[0]]['forecast']['daily'])
        index = pd.DatetimeIndex([datetime.datetime.fromtimestamp(x) for x in daily_forecast_df['date']])
        daily_forecast_df = daily_forecast_df.set_index(index)
        del daily_forecast_df['date']

        # Make hourly dataframe time zone aware. Must have infer_dst = True to attempt to infer fall dst-transition
        # times based on order
        time_zone = tz_string if to_local_time else timezone('UTC')
        hourly_forecast_df = hourly_forecast_df.tz_localize(time_zone, infer_dst=True)
        daily_forecast_df = daily_forecast_df.tz_localize(time_zone, infer_dst=True)
        
        wdict['WeatherUndergroundHourlyWeatherForecast'] = hourly_forecast_df.transpose().to_dict()
        wdict['WeatherUndergroundDailyWeatherForecast'] = daily_forecast_df.transpose().to_dict()
        return wdict