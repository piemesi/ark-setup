import datetime
import logging
from ... import env
from ..device_history import DeviceHistory
from ..device_history_io import DeviceHistoryIO
from ...gcp.data_downloader import DataDownloader

logger = logging.getLogger(__name__)


class Quartz(DeviceHistory):

    DATASET_IDS = {DeviceHistory.FT: 'quartz'}
    DEVICE_ID_TYPES = {DeviceHistoryIO.FT: 'uuid'}
    PROJECT_IDS = {DeviceHistory.FT: 'nest-algo'}
    QUERY_PROJECT_IDS = {DeviceHistory.FT: 'nest-algo'}
    TABLE_INDICES = {DeviceHistory.FT: 'timeindex'}
    TABLE_PREFIXES = {DeviceHistoryIO.FT: 'cuepoint'}

    UPLOAD_PULL_BUFFER_BEFORE = datetime.timedelta(hours=1)
    UPLOAD_PULL_BUFFER_AFTER = datetime.timedelta(hours=1)

    CUEPOINTS = 'Cuepoints'
    _HAS_PERSON = 'has_person'
    _HAS_PERSON_HIGH_CONFIDENCE = 'has_person_high_confidence'
    _HAS_PERSON_TALKING = 'has_person_talking'
    _HAS_PERSON_TALKING_HIGH_CONFIDENCE = 'has_person_talking_high_confidence'
    _EVENT_TYPES = [
        _HAS_PERSON,
        _HAS_PERSON_HIGH_CONFIDENCE,
        _HAS_PERSON_TALKING,
        _HAS_PERSON_TALKING_HIGH_CONFIDENCE
    ]

    def __init__(self, device_name=None):
        super(Quartz, self).__init__(device_name)

    def __repr__(self):
        return "<nestpy.Quartz for %s>" % str(self)

    @classmethod
    def load(
            cls,
            device_id,
            start_date=None,
            end_date=None,
            tier=None,
            event_types=_EVENT_TYPES
    ):
        """
        nestpy.Quartz.load wraps nestpy.DeviceHistory.load with:

        :param device_id:
            the quartz device identifier, typically referred to as uuid
        :type device_id:
            string

        :param start_date:
            the earliest date to get logs for.
        :type start_date:
            timezone-aware datetime or timezone-naive UTC datetime

        :param end_date:
            the latest date to get logs for.
        :type end_date:
            timezone-aware datetime or timezone-naive UTC datetime

        :param tier:
            the service tier that the device belongs to
        :type tier:
            string

        :param event_types:
            the cuepoint event types that should be loaded.
        :type event_types:
            array of string

        :returns:
            the populated Quartz device history.
        :rtype:
            nestpy.Quartz
        """

        try:
            dh = super(Quartz, cls).load(
                device_id=device_id,
                start_date=start_date,
                end_date=end_date,
                tier=tier,
                event_types=[DataDownloader.FLAT],
                download_from=DeviceHistory.GCP,
                cache_destination=env.cache_destination(),
                sort_by_time=True,
            )

            if DataDownloader.FLAT in dh.events:
                cuepoints = dh[DataDownloader.FLAT]
                for column in cuepoints.columns:
                    if column not in event_types:
                        del cuepoints[column]

                cuepoints = cuepoints[(cuepoints.T != 0).any()]  #Drop rows with all zeros.
                dh.add_event_data(cls.CUEPOINTS, cuepoints)
                dh.delete_event_data(DataDownloader.FLAT)

        except Exception as e:
            logger.error(e)
            dh = cls(device_id)
            dh.events = []

        return dh
