from ..device_history import DeviceHistory
from ...hiddenite.hiddenite_ble_scanner_api_client import HiddeniteBLEScannerAPIClient
from ...validation.datetime_validation import assert_valid_start_and_end_dates

import itertools
import logging
import pandas as pd

logger = logging.getLogger(__name__)


class BLEScanner(DeviceHistory):

    """
    A BLEScanner is a device which periodically scans for known BLE devices, such as user's mobile phones.
    """

    BLE_SCANS = 'BLEScans'
    BLE_PRESENCE = 'BLEPresence'

    def __init__(self, hiddenite_structure_id, start_date, end_date):
        super(BLEScanner, self).__init__()

        self.hiddenite_structure_id = hiddenite_structure_id
        self.unique_device_id = hiddenite_structure_id + '_ble_scanner'
        self.start_date = start_date
        self.end_date = end_date

        assert_valid_start_and_end_dates(self.start_date, self.end_date)

    @classmethod
    def load(cls, hiddenite_structure_id, start_date, end_date):
        ble_scanner = cls(hiddenite_structure_id, start_date, end_date)
        ble_scan_results = HiddeniteBLEScannerAPIClient.get_ble_scan_results(structureID=hiddenite_structure_id,
                                                                             start_date=start_date,
                                                                             end_date=end_date)

        ble_scanner.add_event_data(cls.BLE_SCANS, ble_scan_results)
        ble_presence = ble_scanner.transform_scan_results_to_presence()
        ble_scanner.add_event_data(cls.BLE_PRESENCE, ble_presence, native=False)
        return ble_scanner

    @staticmethod
    def _unique_mobile_device(mobile_device):
        return sorted(list(set(itertools.chain(*mobile_device))))

    def unique_mobile_device(self):
        return self._unique_mobile_device(self.BLEScans.foundUserIDs)

    def transform_scan_results_to_presence(self):
        mobile_device_present = pd.DataFrame(index=self.BLEScans.index)
        if len(self.BLEScans) != 0:
            for user in self.unique_mobile_device():
                mobile_device_present[user] = self.BLEScans.foundUserIDs.apply(
                    lambda mobile_device_found: user in mobile_device_found
                )
        return mobile_device_present

    @classmethod
    def load_structure_ble_scanner(cls, hiddenite_structure_id, start_date, end_date):
        logger.info("Loading ble data event histories for structure %s", hiddenite_structure_id)

        ble_scanners = []

        if HiddeniteBLEScannerAPIClient.has_ble_scanner(hiddenite_structure_id):
            ble_scanner = cls.load(hiddenite_structure_id, start_date, end_date)

            if len(ble_scanner) == 0:
                logger.warning("Device {} that has no BLE data from {} to {}".format(hiddenite_structure_id,
                                                                                     start_date,
                                                                                     end_date))
            else:
                ble_scanners.append(ble_scanner)

        return ble_scanners

    def get_mobile_device_ids(self):
        return getattr(self, self.BLE_PRESENCE).columns.tolist()
