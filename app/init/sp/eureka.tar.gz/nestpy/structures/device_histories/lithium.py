# pylint: disable=no-member

import datetime
from multiprocessing import current_process, cpu_count

import pandas

from ... import env
from ...parsing import lithium_events
from ..device_history import DeviceHistory

class Lithium(DeviceHistory):
    """
    A DeviceHistory subclass specifically for Lithium
    """
    LOG_TYPE = 'lithiumlog'
    UPLOAD_PULL_BUFFER_BEFORE = datetime.timedelta(hours=1)
    UPLOAD_PULL_BUFFER_AFTER = datetime.timedelta(hours=1)

    def __init__(self, device_name=None):
        super(Lithium, self).__init__(device_name)

    def __repr__(self):
        return '<nestpy.Lithium for %s>' % str(self)

    @classmethod
    def load(cls,
             device_id,
             start_date=None,
             end_date=None,
             tier=None,
             event_types=None,
             cache_destination=env.cache_destination(),
             offline=False):
        """
        nestpy.Lithium.load wraps nestpy.DeviceHistory.load with:
            log_type set to 'lithiumlog'

        :param device_id:
            device mac address

        :type data_source:
            str

        :param start_date:
            the earliest date to get logs for.
        :type start_date:
            timezone-aware datetime or timezone-naive UTC datetime

        :param end_date:
            the latest date to get logs for.
        :type end_date:
            timezone-aware datetime or timezone-naive UTC datetime

        :param tier:
            the service tier that the device belongs to ("ft", "qa", or
            "production"). Only used if the data source is S3.
        :type tier:
            string

        :param cache_destination:
            the parent folder in which to store raw and parsed data
        :type cache_destination:
            string

        :param offline:
            whether or not to allow downloading
        :type tier:
            boolean

        :returns:
            the populated Device History.
        :rtype:
            nestpy.DeviceHistory
        """
        dh = super(Lithium, cls).load(device_id=device_id.lower(),  # balsams always use lower case hex strings
                                      log_type=Lithium.LOG_TYPE,
                                      start_date=start_date,
                                      end_date=end_date,
                                      tier='production',  # all balsam logs go to production
                                      event_types=event_types,
                                      cache_destination=cache_destination,
                                      offline=offline)

        return dh

    @classmethod
    def from_raw_event_logs(cls,
                            log_file_list,
                            unique_device_id=None,
                            event_types=None,
                            sort_by_time=False,
                            tier=None):

        if type(log_file_list) != list:
            log_file_list = [log_file_list]

        if current_process().daemon:
            # If already running in parallel, don't try to parallelize again.
            threads = 1
        else:
            # Set threads to number of logical cores available for maximum efficiency with parsing.
            threads = cpu_count()

        (data, source_file_metadata) = lithium_events.parse_lithium_files(log_file_list, threads=threads)

        event_desc = 'current'
        dataframe = data[event_desc]
        lithium = cls(unique_device_id)
        lithium.add_event_data(event_desc, dataframe)

        return lithium, source_file_metadata

    def movingaverage(self, values, alpha=0.001):
        emwa = []
        one_minus_alpha = 1 - alpha
        emwa.append(values[0])
        for i in xrange(1, len(values)):
            emwa.append(values[i] * alpha + emwa[i-1] * one_minus_alpha)
        return emwa

    def _post_load_step(self):
        emwa = self.movingaverage([x[0] for x in self.current.get_values()])
        df = pandas.DataFrame({'emwa':emwa}, index=self.current.index)
        df.set_index(self.current.index)
        self.add_event_data('emwa', df, native=False)
