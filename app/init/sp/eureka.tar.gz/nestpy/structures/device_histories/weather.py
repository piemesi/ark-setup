# pylint: disable=no-member

import datetime
from datetime import timedelta
import json
import logging
import numpy as np
import os
import pandas as pd
from pytz import timezone
from urllib import urlretrieve
from urllib2 import urlopen

from ...fileutils import mkdir_p

from ..device_history import DeviceHistory
from ...converters import c2f

logger = logging.getLogger(__name__)

MAX_EARTH_TEMP = 135.
MIN_EARTH_TEMP = -127.


class Weather(DeviceHistory):
    """
    A DeviceHistory for Weather Underground data.
    """
    LOG_TYPE = 'wunderground'

    def __init__(self, device_name=None):
        super(Weather, self).__init__(device_name)

    def __repr__(self):
        return "<nestpy.Weather for %s>" % str(self)

    def get_timezone(self):
        """
        Gets the local time zone for this device, based on the DailyWeatherSummary
        data. Returns the most recent timezone found.

        :returns:
            the timezone of this device.
        :rtype:
            pytz.timezone
        """
        if "DailyWeatherSummary" not in self.events:
            raise RuntimeError("Time zone data not available in this device history.")

        dh_timezones = self["DailyWeatherSummary"].timezone_long

        if not len(dh_timezones):
            raise RuntimeError("No time zones were found.")

        timezone_string = dh_timezones[-1]
        dh_timezone = timezone(timezone_string)

        return dh_timezone

    @classmethod
    def load(cls,
             zip_code,
             start_date=None,
             end_date=None,
             sort_by_time=False,
             tier=None,
             event_types=None,
             cache_destination=os.getcwd(),
             offline=False,
             to_local_time=False,
             celsius_to_fahrenheit=False):
        """
        nestpy.WeatherUnderground.load wraps nestpy.DeviceHistory.load

        :param zip_code:
            the zip code for which you want the weather data
        :type zip_code:
            string

        :param start_date:
            the earliest date to get logs for.
        :type start_date:
            timezone-aware datetime or timezone-naive UTC datetime

        :param end_date:
            the latest date to get logs for.
        :type end_date:
            timezone-aware datetime or timezone-naive UTC datetime

        :param tier:
            Not used for Weather. But here because it's in the parent func prototype.
        :type tier:
            string

        :param cache_destination:
            the parent folder in which to store raw and parsed data
        :type cache_destination:
            string

        :param offline:
            whether or not to allow downloading
        :type offline:
            boolean

        :param celsius_to_fahrenheit:
            whether to convert temperature fields from celsius to fahrenheit
        :type celsius_to_fahrenheit:
            boolean

        :returns:
            the populated Weather Underground device history.
        :rtype:
            nestpy.WeatherUnderground
        """
        weather_dh = super(Weather, cls).load(device_id=zip_code,
                                              log_type=Weather.LOG_TYPE,
                                              start_date=start_date,
                                              end_date=end_date,
                                              tier="wunderground",
                                              event_types=event_types,
                                              sort_by_time=sort_by_time,
                                              cache_destination=cache_destination,
                                              download_from=DeviceHistory.AWS,
                                              offline=offline)

        # If this flag is true, convert to local time, otherwise convert to UTC.  The conversion to UTC must be explicit
        # because when reading from raw logs the DataFrames are stored in local time.
        time_zone = weather_dh.get_timezone() if to_local_time else timezone('UTC')
        weather_dh.to_timezone(time_zone)

        # Range filtering to make sure that the temperatures are between the max and min bounds of Earth surface temps.
        def outdoor_temp_filter(temperature):
            if temperature > MIN_EARTH_TEMP and temperature < MAX_EARTH_TEMP:
                return temperature
            else:
                return np.nan

        if 'temp_c' in weather_dh.HourlyWeather:
            filtered_outdoor_temp = weather_dh.HourlyWeather.temp_c.map(outdoor_temp_filter)

            # Convert to Farenheit if flag is set. Always create a new field in the Hourly Weather called Temperature.
            # This will hold the converted temperature.
            if celsius_to_fahrenheit:
                weather_dh.HourlyWeather['Temperature'] = c2f(filtered_outdoor_temp)
            else:
                weather_dh.HourlyWeather['Temperature'] = filtered_outdoor_temp

        return weather_dh

    @staticmethod
    def download_single_day_from_wunderground(zip_code, day_date, destination):
        """
        Download a single day of data from Weather Underground and write to file in destination folder.
        :param zip_code:
            the zip code for which you want the weather data
        :type zip_code:
            string

        :param day_date:
            the date to download Weather Underground logs for.
        :type day_date:
            local datetime (can be timezone-aware or timezone-naive)
        """
        logger.debug('Downloading {} on day {} from Weather Underground API'.format(zip_code, day_date))
        url = "http://www.wunderground.com/auto/nestlabs/history/zipcode/{}/{}/{}/{}/DailyHistory.html".format(
            zip_code,
            day_date.year,
            day_date.month,
            day_date.day)
        urlretrieve(url, os.path.join(destination, zip_code,
                                      "wunderground_{}_{}_{}_{}.log".format(zip_code, day_date.year, day_date.month,
                                                                            day_date.day)))
        return True

    @classmethod
    def download_to_local(cls,
                          device_id,
                          tier,
                          log_type,
                          start_date,
                          end_date,
                          destination):
        """
        Downloads data from WeatherUnderground for a single zip-code.
        TODO: Speed up using multiprocessing.

        :param device_id:
            the zip code for which you want the weather data
        :type device_id:
            string

        :param tier:
            not used
        :type tier:
            string

        :param start_date:
            the earliest date to get logs for.
        :type start_date:
            timezone-aware datetime or timezone-naive UTC datetime

        :param end_date:
            the latest date to get logs for.
        :type end_date:
            timezone-aware datetime or timezone-naive UTC datetime

        :param destination:
            the parent folder in which to store raw and parsed data
        :type destination:
            string
        """
        logger.info('Downloading {} from Weather Underground API from {} to {}'.format(device_id,
                                                                                       start_date.date(),
                                                                                       end_date.date()))
        mkdir_p(os.path.join(destination, device_id))
        for single_date in Weather.daterange_end_inclusive(start_date, end_date):
            cls.download_single_day_from_wunderground(device_id, single_date, destination)


    @staticmethod
    def daterange_end_inclusive(start_date, end_date):
        """
        Helper function to create a range of datetimes between start and end dates.

        This is a subtle piece of code. We find the number of days between start_date and end_date and always round up.
        So if we're at 2.8 days, we round up to 3 days.  Then we add another day because this function is meant to
        include the last day.
        """
        numdays = int(np.ceil((end_date - start_date).total_seconds() / (3600 * 24.)) + 1)

        for n in range(numdays):
            yield start_date + timedelta(n)

    @classmethod
    def from_raw_event_logs(cls,
                            log_file_list,
                            unique_device_id=None,
                            event_types=None,
                            sort_by_time=False,
                            tier=None):
        """
        Creates a Weather device history object from a list of raw Weather Underground log files.
        """
        if type(log_file_list) != list:
            log_file_list = [log_file_list]

        weather_dict = {'DailyWeatherSummary': {}, 'HourlyWeather': {}}
        source_file_metadata = {}
        for filepath in log_file_list:
            append_weather_dict = cls.load_single_day_from_file(filepath)

            if append_weather_dict is None:
                continue

            filename = os.path.basename(filepath)
            source_file_metadata[filename] = {}
            source_file_metadata[filename].update({
                'parsed': True,
                'filetime': str(cls._extract_upload_time_from_filename(filename)),
                'parsed_at': str(datetime.datetime.now())
            })

            # Append to old dictionary
            for event_type in weather_dict:
                weather_dict[event_type].update(append_weather_dict[event_type])

        # Create the data frames for the DeviceHistory events. Note that it is in local time zone.
        daily_df = pd.DataFrame.from_dict(weather_dict['DailyWeatherSummary'], orient='index')
        daily_df.index.name = 't'
        hourly_df = pd.DataFrame.from_dict(weather_dict['HourlyWeather'], orient='index')
        hourly_df.index.name = 't'

        # add events to device history
        dh = cls()
        dh.add_event_data('DailyWeatherSummary', daily_df)
        dh.add_event_data('HourlyWeather', hourly_df)
        return dh, source_file_metadata

    @staticmethod
    def _extract_upload_time_from_filename(filename):
        """
        Extract the upload time from Weather Underground filename, for example:
            wunderground_<zip>_2014_2_4.log

        :param filename:
        Name of the Weather Underground filename
        """
        try:
            filename_ = os.path.split(filename)[-1]
            filename_ = filename_.split('.')[0]
            tokenized = filename_.split('_')
            datetime_ = datetime.datetime(int(tokenized[2]), int(tokenized[3]), int(tokenized[4]))
            datetime_ = '{:%Y-%m-%d}'.format(datetime_)
        except ValueError:
            logger.error('Could not extract upload time from filename: %s', filename)
            datetime_ = None
        return datetime_

    @staticmethod
    def load_single_day_from_file(filepath):
        """
        This parses a single days data from the Weather Underground JSON and returns a dictionary with two top level
        keys: DailyWeatherSummary and HourlyWeather. There is special handling of the timezone because Weather
        Underground does not use standard Olsen Codes for the timezone. For simplicity, we have converted the timestamps
        into UTC time using the GMT offset specified by Weather Underground.
        """
        wdict = {}

        with open(filepath, 'rb') as f:
            json_content = f.read()
            try:
                data = json.loads(json_content)
            except ValueError:
                logger.error("Invalid JSON from Weather Underground API: %s", json_content)
                return None

        keys = data.keys()
        zip_code = data[keys[0]]['location']['zip']

        # This code gets the timezone for this zip code.
        # Check if the timezone file exists, otherwise go and get it from the WeatherUnderground API
        destination_dir = os.path.dirname(filepath)
        timezone_file = os.path.join(destination_dir, "timezone.log")
        if os.path.isfile(timezone_file):
            with open(timezone_file, 'rb') as f:
                tz_data = json.load(f)
        else:
            url = "http://www.wunderground.com/auto/nestlabs/geo/current/i?query={}".format(zip_code)
            urlretrieve(url, os.path.join(destination_dir, "timezone.log"))
            tz_data = json.load(urlopen(url))

        tz_string = tz_data[zip_code]['location']['timezone_long']

        # Create daily summary dictionary indexed by date
        daily_dict = data[keys[0]]['querydate']

        # Make current date time zone aware
        current_date = datetime.datetime.strptime(daily_dict['date'], '%Y%m%d')
        local_time_zone = timezone(tz_string)
        current_date = local_time_zone.localize(current_date)

        del daily_dict['date']
        daily_dict.update(data[keys[0]]['location'])
        daily_dict['timezone_long'] = tz_string
        wdict['DailyWeatherSummary'] = {current_date: daily_dict}

        # Create hourly weather dictionary indexed by datetime
        hourly_df = pd.DataFrame(data[keys[0]]['hourly'])
        hourly_df['date_dt'] = [datetime.datetime.strptime(x, '%Y%m%d%H%M') for x in hourly_df['date']]
        hourly_df = hourly_df.set_index('date_dt')
        del hourly_df['date']

        # Make hourly dataframe time zone aware. Must have infer_dst = True to attempt to infer fall dst-transition
        # times based on order
        hourly_df = hourly_df.tz_localize(tz_string, infer_dst=True)

        wdict['HourlyWeather'] = hourly_df.transpose().to_dict()

        return wdict