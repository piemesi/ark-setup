# pylint: disable=no-member
import datetime
import logging
from multiprocessing import current_process, cpu_count
import os

import pandas
import numpy

from ... import converters
from ..device_history import DeviceHistory
from ...decorators import deprecated
from ...parsing import tvdreader
from ...parsing import topaz_tvd
from ...parsing import balsam_events

logger = logging.getLogger(__name__)


class Balsam(DeviceHistory):
    """
    A DeviceHistory base class for all the devices attached to Balsams. Currently includes PinnaTether, PinnaProtoTether,
    and AIRTether.
    """

    LOG_TYPE = 'balsamlog'
    UPLOAD_PULL_BUFFER_BEFORE = datetime.timedelta(hours=1)
    UPLOAD_PULL_BUFFER_AFTER = datetime.timedelta(hours=1)

    DATASET_IDS = {DeviceHistory.FT: 'balsam'}

    def __init__(self, device_name=None):
        super(Balsam, self).__init__(device_name)

    def __repr__(self):
        return "<nestpy.Balsam for %s>" % str(self)

    @classmethod
    def from_raw_event_logs(cls,
                            log_file_list,
                            unique_device_id=None,
                            event_types=None,
                            sort_by_time=False,
                            tier=None,
                            include_raw_tvd_values=False,
                            default_synchronization=tvdreader.TVDReader.Synchronization.Unknown):

        if type(log_file_list) != list:
            log_file_list = [log_file_list]

        if current_process().daemon:
            # If already running in parallel, don't try to parallelize again.
            threads = 1
        else:
            # Set threads to number of logical cores available for maximum efficiency with parsing.
            threads = cpu_count()

        (data, source_file_metadata) = topaz_tvd.parse_tvd_files(log_file_list, threads=threads,
                                                                 include_raw_values=include_raw_tvd_values,
                                                                 default_synchronization=default_synchronization)

        balsam = cls(unique_device_id)

        if data is not None:
            for sensor_type in data:
                dataframe = data[sensor_type]

                # override the timestamp behavior borrowed from topaz_tvd
                # index by service-synchronized time stamp but keep rtc_time as a separate column for logic that
                # requires monotonicity
                dataframe['service_time'] = dataframe.index

                if sort_by_time:
                    dataframe = dataframe.sort()

                balsam.add_event_data(sensor_type, dataframe)

        return balsam, source_file_metadata


    @staticmethod
    def _get_files_to_parse_in_directory(directory_name, log_type, start_date, end_date):
        """
        Returns a list logfiles that should be parsed from the specified directory

        :param directory_name:
            path to a directory containing logfiles
        :param start_date:
            as an optimization, reject logs uploaded some time before the target start date
        :param end_date:
            as an optimization, reject logs uploaded some time after the target end date

        :rtype:
            list of filepaths to parse
        """
        if start_date:
            start_date = converters.get_tz_aware_datetime(start_date)

        if end_date:
            end_date = converters.get_tz_aware_datetime(end_date)

        filenames = sorted(os.listdir(directory_name))
        files = [os.path.join(directory_name, filepath) for filepath in filenames if filepath.find(log_type) != -1]

        if len(files) > 0:
            # Balsam is not summarizing data so contents of the file can be determined by the timestamp and other uploaded file timestamps
            # select the smallest number of files to speed up loading
            file_info = pandas.DataFrame.from_dict([{'filename':filename, 'filetime':DeviceHistory._extract_upload_time_from_filename(filename)} for filename in files])
            file_info.sort(['filetime'], inplace=True)
            file_info['to_parse'] = (file_info.filetime > start_date) & (file_info.filetime < end_date)
            file_info.to_parse[(1*(file_info.filetime > end_date)).diff() == 1] = True
            return file_info.filename[file_info.to_parse].tolist()
        else:
            return []

    @deprecated(message="This function is deprecated and not used anywhere in the balsam parsing.")
    def _reindex_event_by_rtc_time(self, event_name):
        """
        Reindexes each event by RTC time. Note that this is done independently for each event. This function assumes
        that the event is non-zero length.
        :param event_name: name of event to reindex
        :return: DataFrame representing the reindexed event
        """
        # Find all the places where the RTC time resets by looking where diff is negative
        rtc_time = self[event_name].rtc_time
        rtc_delta = rtc_time.diff()
        rtc_resets = rtc_delta[rtc_delta < 0]
        slices = rtc_resets.index.tolist()

        # Append beginning time as the beginning of first slice and last time as the end of last slice
        slices.append(self[event_name].index[-1])
        slices.insert(0, self[event_name].index[0])

        # Compute all the offsets -- use numpy arrays as common format to to calculation.
        service_times_at_reset = numpy.array([converters.datetime_to_epoch_time(x) for x in slices[0:-1]])

        # Find the row indices in the original rtc_time array where the resets happen. We need to get
        # row indices because the index may not be unique in the entire rtc_time array.
        rtc_delta_reindexed = rtc_delta.reset_index()
        rtc_row_indices_for_slices = rtc_delta_reindexed[rtc_delta_reindexed.rtc_time < 0].index
        rtc_row_indices_for_slices = rtc_row_indices_for_slices.insert(0, 0) #only need to insert at beginning becuase don't need offset of last sample
        rtc_times_at_reset = rtc_time.iloc[rtc_row_indices_for_slices].values

        # Compute the offsets
        offsets = service_times_at_reset - rtc_times_at_reset

        # Pack all the slice information and relevant offset into single DataFrame
        slice_df = pandas.DataFrame({'start_segment': slices[0:-1], 'end_segment': slices[1:], 'offset': offsets})
        assert((slice_df.offset > 0).all(axis=0)) #Check that all the offsets are > 0

        # Iterate through all the pieces and reindex them by RTC time
        event_pieces = []
        for index, row in slice_df.iterrows():
            dt = self[event_name].ix[row['start_segment']:row['end_segment']].rtc_time + row['offset']
            fixed_rtc_timestamps = pandas.to_datetime(dt.values, unit='s', utc=True)
            event_pieces.append(self[event_name].ix[row['start_segment']:row['end_segment']].set_index(fixed_rtc_timestamps).sort())

        # Stitch all the pieces together into a single DataFrame and return
        reindexed_event = pandas.concat(event_pieces).sort()

        return reindexed_event

    def _remove_nonsensical_times(self, event_df):
        filtered_event_df = event_df[(event_df.index > '01-01-2010') & (event_df.index < datetime.datetime.now() +
                                                                        datetime.timedelta(days=10))]
        return filtered_event_df

    def _post_load_step(self):
        """
        Subroutine that runs right after loading the data from the cache.
        :return:
        """
        event_names = list(self.events) #Create a copy of the list because we're replacing elements in loop below.
        for event_name in event_names:
            if len(self[event_name]):
                # For each event remove the non-sensical times.
                filtered_event = self._remove_nonsensical_times(self[event_name])
                self[event_name] = filtered_event

        #TODO: self.earliest_date and self.latest_date are slightly incorrect now because of the reindexing with rtc

        # post-process
        balsam_events.parse_balsam_events(self)

        # add DataUpload as a synthetic event
        if 'metadata' in self and 'source_files' in self.metadata:
            df = pandas.DataFrame.from_dict(self.metadata['source_files'], orient='index')
            df.index = pandas.to_datetime(df.filetime)
            if type(df.index) == pandas.DatetimeIndex:
                df = df.tz_localize('UTC')
                if self.earliest_date is not None and self.latest_date is not None:
                    df = df[(df.index >= self.earliest_date) & (df.index < self.latest_date)]
                self.add_event_data('DataUpload', df, append=False, sort_by_time=True, native=False)
