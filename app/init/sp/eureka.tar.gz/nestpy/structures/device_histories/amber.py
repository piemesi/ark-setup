# pylint: disable=no-member
import datetime
import logging
from multiprocessing import current_process, cpu_count
import os

import pandas
import numpy

from ... import converters
from ..device_history import DeviceHistory
from ... import env
from ...parsing import tvdreader
from ...parsing import topaz_tvd
from ... parsing import amber_events, amber_utils

logger = logging.getLogger(__name__)


class Amber(DeviceHistory):
    """
    A DeviceHistory base class for POR Amberlogging
    """

    LOG_TYPE = 'heatlinkevent'
    UPLOAD_PULL_BUFFER_BEFORE = datetime.timedelta(hours=1)
    UPLOAD_PULL_BUFFER_AFTER = datetime.timedelta(hours=1)

    def __init__(self, device_name=None):
        super(Amber, self).__init__(device_name)

    def __repr__(self):
        return "<nestpy.Amber for %s>" % str(self)

    @classmethod
    def load(cls,
             device_id,
             start_date=None,
             end_date=None,
             tier=None,
             event_types=None,
             cache_destination=env.cache_destination(),
             offline=False,
             drop_service_time=True):
        """
        nestpy.Amber.load wraps nestpy.DeviceHistory.load with:
            log_type set to 'heatlinkevent'

        :param device_id:
            device mac address

        :type data_source:
            str

        :param start_date:
            the earliest date to get logs for.
        :type start_date:
            timezone-aware datetime or timezone-naive UTC datetime

        :param end_date:
            the latest date to get logs for.
        :type end_date:
            timezone-aware datetime or timezone-naive UTC datetime

        :param tier:
            the service tier that the device belongs to ("ft", "qa", or
            "production"). 
        :type tier:
            string

        :param cache_destination:
            the parent folder in which to store raw and parsed data
        :type cache_destination:
            string

        :param offline:
            whether or not to allow downloading
        :type tier:
            boolean

        :returns:
            the populated Device History.
        :rtype:
            nestpy.DeviceHistory
        """
        dh = super(Amber, cls).load(device_id=device_id.lower(),
                                    log_type=Amber.LOG_TYPE,
                                    start_date=start_date,
                                    end_date=end_date,
                                    tier=tier,
                                    event_types=event_types,
                                    cache_destination=cache_destination,
                                    offline=offline)
        amber_events.parse_amber_event_fields(dh)
        return dh

    @classmethod
    def from_raw_event_logs(cls,
                            log_file_list,
                            unique_device_id=None,
                            event_types=None,
                            sort_by_time=False,
                            tier=None,
                            include_raw_tvd_values=False,
                            default_synchronization=tvdreader.TVDReader.Synchronization.Synchronized):

        if type(log_file_list) != list:
            log_file_list = [log_file_list]

        if current_process().daemon:
            # If already running in parallel, don't try to parallelize again.
            threads = 1
        else:
            # Set threads to number of logical cores available for maximum efficiency with parsing.
            threads = cpu_count()

        (data, source_file_metadata) = topaz_tvd.parse_tvd_files(log_file_list, threads=threads)

        amber = cls(unique_device_id)

        if data is not None:
            for sensor_type in data:
                dataframe = data[sensor_type]

                if sort_by_time:
                    dataframe = dataframe.sort()

                amber.add_event_data(sensor_type, dataframe)

        return (amber, source_file_metadata)

    @classmethod
    def load_file(cls,
                  log_file):
        amber, source_file_metadata = cls.from_raw_event_logs(log_file)
        amber_events.parse_amber_event_fields(amber)
        return amber

    @staticmethod
    def _get_files_to_parse_in_directory(directory_name, log_type, start_date, end_date):
        """
        Returns a list logfiles that should be parsed from the specified directory

        :param directory_name:
            path to a directory containing logfiles
        :param start_date:
            as an optimization, reject logs uploaded some time before the target start date
        :param end_date:
            as an optimization, reject logs uploaded some time after the target end date

        :rtype:
            list of filepaths to parse
        """
        if start_date:
            start_date = converters.get_tz_aware_datetime(start_date)

        if end_date:
            end_date = converters.get_tz_aware_datetime(end_date)

        filenames = sorted(os.listdir(directory_name))
        files = [os.path.join(directory_name, filepath) for filepath in filenames if filepath.find(log_type) != -1]

        if len(files) > 0:
            file_info = pandas.DataFrame.from_dict([{'filename': filename,
                                                     'filetime': DeviceHistory.
                                                   _extract_upload_time_from_filename(filename)} for filename in files])
            file_info.sort(['filetime'], inplace=True)
            file_info['to_parse'] = (file_info.filetime > start_date) & (file_info.filetime < end_date)
            file_info.to_parse[(1*(file_info.filetime > end_date)).diff() == 1] = True
            return file_info.filename[file_info.to_parse].tolist()
        else:
            return []

    @staticmethod
    def _remove_nonsensical_times(event_df):
        filtered_event_df = event_df[(event_df.index > '01-01-2010') & (event_df.index < datetime.datetime.now() +
                                                                        datetime.timedelta(days=10))]
        return filtered_event_df

