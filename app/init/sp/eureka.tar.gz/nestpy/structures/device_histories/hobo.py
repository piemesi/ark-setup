# -*- coding: utf-8 -*-
"""
Hobo class that can load data into a dataframe and perform common manipulations.
"""
# pylint: disable=maybe-no-member

import datetime
import gzip
import os
import pandas as pd

from ... import converters


def basename(filepath):
    return os.path.splitext(os.path.basename(os.path.abspath(filepath)))[0]


class Hobo(pd.DataFrame):
    """
    A class to manage Hobo data.
    """

    COLUMN_NAME_TRANSLATION = dict({
        'Date Time, GMT+00:00': 't',
        'Temp, °C': 'Temperature',
        'RH, %': 'RelativeHumidity',
        'Light': 'Light',
        'Occupancy':'Occupancy'})

    def __init__(self, unique_device_id = "Unknown"):
        super(Hobo, self).__init__()
        self.unique_device_id = str(unique_device_id)

    def __str__(self):
        return "%s\nunique_device_id: %s" % (super(Hobo, self).__str__(), self.unique_device_id)

    def __repr__(self):
        return str(self)

    def to_directoried_event_file(self,
                                  filename=None,
                                  compressed=False):
        """
        Writes the Hobo data to a file in the directoried log format.

        :param filename:
            the destination of the directoried event file
        :type filename:
            str

        :param compressed: whether to write the event logs in GZIP-compressed
          format.
        """
        if not filename:
            filename = os.path.join(os.curdir, self.unique_device_id)

        # Convert the index timestamps to epoch times
        self.index = [converters.datetime_to_epoch_time(timestamp) for timestamp in self.index]

        # Preprocess each column
        header = []
        for index, column_name in enumerate(self.columns):
            data_type = str(self.dtypes[index])

            # Determine column type
            if "int" in data_type:
                header.append("%s:integer" % column_name)
            elif "float" in data_type:
                header.append("%s:decimal" % column_name)
            elif "bool" in data_type:
                header.append("%s:boolean" % column_name)
            elif "object" in data_type and \
                isinstance(self[column_name][0], datetime):
                header.append("%s:timestamp" % column_name)
                self[column_name] = self[column_name].apply(converters.datetime_to_epoch_time)
            else:
                header.append("%s:string" % column_name)

        if compressed:
            event_file_handle = gzip.open("%s.gz" % filename, 'wb')
        else:
            event_file_handle = open(filename, 'wb')

        self.to_csv(event_file_handle,
                    header=header,
                    index_label="t:timestamp",
                    sep = "\t",
                    na_rep = "NaN")
        event_file_handle.close()

    @classmethod
    def load_supported_data_from_csv(cls,
                                     hobo_csv_filename,
                                     unique_device_id=None):
        """
        Creates a new Hobo object using the data from the Hobo csv.

        :param hobo_csv_filename:
            the path to the CSV.
        :type hobo_csv_filename:
            str

        :param unique_device_id:
            a name for the Hobo object
        :type unique_device_id:
            str

        :returns:
            the populated Hobo object
        :rtype:
            nestpy.Hobo
        """
        if not unique_device_id:
            unique_device_id = basename(hobo_csv_filename)

        hobo = cls(unique_device_id)

        # Hobo CSVs have text in the first line and the second line is the header
        dataframe = pd.read_csv(hobo_csv_filename, header=1)

        # rename supported columns and remove unsupported ones
        dataframe.rename(columns=Hobo.COLUMN_NAME_TRANSLATION, inplace=True)
        dataframe = dataframe.filter(items=Hobo.COLUMN_NAME_TRANSLATION.values())

        # parse the time string into timezone aware datetimes (note the column name above requires GMT)
        dataframe.t = [converters.get_tz_aware_datetime(datetime.datetime.strptime(i, "%m/%d/%Y %I:%M:%S %p")) for i in dataframe.t]

        # make the time column the index
        dataframe = dataframe.set_index('t')

        hobo._data = dataframe._data
        return hobo
