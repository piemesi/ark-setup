from pandas import DataFrame

from ...env import cache_destination
from ...fileutils import basename
from ...parsing import transit_binary
from ...structures import DeviceHistory

class Transit(DeviceHistory):
    """
    A DeviceHistory subclass specifically for the Transit GPS logger.
    """

    LOCALIZE_TIME_COLUMNS = []
    LOG_TYPE = 'transitlog'

    def __init__(self, device_name = None):
        super(Transit, self).__init__(device_name)

    def __repr__(self):
        return "<nestpy.Transit for %s>" % str(self)

    @classmethod
    def load(cls,
             device_id,
             start_date=None,
             end_date=None,
             tier=None,
             event_types=None,
             cache_destination=cache_destination(),
             offline=False):
        """
        nestpy.Transit.load wraps nestpy.DeviceHistory.load

        :param device_id:
            device UUID
        :type device_id:
            str

        :param start_date:
            the earliest date to get logs for.
        :type start_date:
            timezone-aware datetime or timezone-naive UTC datetime

        :param end_date:
            the latest date to get logs for.
        :type end_date:
            timezone-aware datetime or timezone-naive UTC datetime

        :param tier:
            the service tier that the device belongs to ("ft", "qa", or
            "production"). Only used if the data source is S3.
        :type tier:
            string

        :param cache_destination:
            the parent folder in which to store raw and parsed data
        :type cache_destination:
            string

        :param offline:
            whether or not to allow downloading
        :type tier:
            boolean

        :returns:
            the populated Device History.
        :rtype:
            nestpy.DeviceHistory
        """

        return super(Transit, cls).load(device_id.upper(), # force capitalized
                                        log_type=Transit.LOG_TYPE,
                                        start_date=start_date,
                                        end_date=end_date,
                                        tier='production', # all qstarz logs go to production
                                        event_types=event_types,
                                        cache_destination=cache_destination,
                                        offline=offline)

    @classmethod
    def from_raw_event_log(cls,
                           log_file,
                           unique_device_id=None,
                           event_types=None,
                           sort_by_time=True,
                           tier=None):
        """
        Creates a new Device History object using raw data in the
        provided file.

        :param log_file:
            the log file containing raw event logs.
        :type log_file:
            str

        :param unique_device_id:
            a unique device identifier, typically the device's MAC address or
            serial number. If not provided, the ID will be based on the
            provided folder name.
        :type unique_device_id:
            str

        :param event_types:
            a list of event types to include. If not provided, all event types
            will be loaded.
        :type event_types:
            list of str

        :param sort_by_time:
            whether to sort the events by time.
        :type sort_by_time:
            boolean

        :returns:
            the populated Device History.
        :rtype:
            nestpy.DeviceHistory
        """

        # Populate the device history object
        if not unique_device_id:
            unique_device_id = basename(log_file)
            unique_device_id = unique_device_id.replace('_', '-').split('-')[1]

        device_history = cls(unique_device_id)

        event_data = transit_binary.parse_file(log_file)

        for event_type in event_data:
            current_event_data = event_data[event_type]
            dataframe = DataFrame.from_records(current_event_data, index=['time'])
            device_history.add_event_data(event_type, dataframe, sort_by_time=sort_by_time)

        device_history.events.sort()
        return device_history
