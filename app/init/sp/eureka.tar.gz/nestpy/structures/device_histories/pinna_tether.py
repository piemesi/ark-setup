# pylint: disable=no-member
import logging

import numpy
import pandas
from pandas.stats.moments import rolling_mean

from .balsam import Balsam
from ... import env

logger = logging.getLogger(__name__)


class PinnaTether(Balsam):
    """
    A DeviceHistory subclass specifically for Balsam.
    """

    def __init__(self, device_name=None):
        super(PinnaTether, self).__init__(device_name)

    def __repr__(self):
        return "<nestpy.PinnaTether for %s>" % str(self)

    @classmethod
    def load(cls,
             device_id,
             start_date=None,
             end_date=None,
             tier=None,
             event_types=None,
             cache_destination=env.cache_destination(),
             offline=False,
             downsampling_enabled=True,
             drop_service_time=True):
        """
        nestpy.PinnaTether.load wraps nestpy.DeviceHistory.load with:
            log_type set to 'balsamlog'

        :param device_id:
            device mac address

        :type data_source:
            str

        :param start_date:
            the earliest date to get logs for.
        :type start_date:
            timezone-aware datetime or timezone-naive UTC datetime

        :param end_date:
            the latest date to get logs for.
        :type end_date:
            timezone-aware datetime or timezone-naive UTC datetime

        :param tier:
            the service tier that the device belongs to ("ft", "qa", or
            "production"). Only used if the data source is S3.
        :type tier:
            string

        :param cache_destination:
            the parent folder in which to store raw and parsed data
        :type cache_destination:
            string

        :param offline:
            whether or not to allow downloading
        :type tier:
            boolean

        :returns:
            the populated Device History.
        :rtype:
            nestpy.DeviceHistory
        """
        dh = super(PinnaTether, cls).load(device_id=device_id.lower(),  # balsams always use lower case hex strings
                                       log_type=PinnaTether.LOG_TYPE,
                                       start_date=start_date,
                                       end_date=end_date,
                                       tier='production',  # all balsam logs go to production
                                       event_types=event_types,
                                       cache_destination=cache_destination,
                                       offline=offline,
                                       downsampling_enabled=downsampling_enabled)

        if drop_service_time:
            # Remove service_time column - we want it parsed and remembered for future, but it breaks things
            for event in dh:
                if 'service_time' in dh[event].columns:
                    dh[event].drop('service_time', inplace=True, axis=1)

        return dh

    def _post_parse_step(self):
        if self.downsampling_enabled:
            # pylint: disable=access-member-before-definition

            # separate out dummy accelerometer values
            if 'ThreeAxisAccelerometer' in self:
                acc = self.ThreeAxisAccelerometer.copy()
                acc['invalid'] = (acc.Value0 > 32.0) | \
                                 (acc.Value1 > 32.0) | \
                                 (acc.Value2 > 32.0)
                if acc.invalid.any():
                    self.add_event_data('AccelerometerFailure', acc[acc.invalid], append=True, sort_by_time=True, native=False)
                    self.ThreeAxisAccelerometer = self.ThreeAxisAccelerometer[~acc.invalid]
                    logger.info('%d accel readings converted to failures' % (len(self.AccelerometerFailure)))

            # downsample accelerometer
            if 'ThreeAxisAccelerometer' in self:
                acc = self.ThreeAxisAccelerometer.copy()
                before = len(acc)
                acc['Motion'] = \
                    ((acc.Value0 - rolling_mean(acc.Value0,1024)).abs() > 0.05) | \
                    ((acc.Value1 - rolling_mean(acc.Value1,1024)).abs() > 0.05) | \
                    ((acc.Value2 - rolling_mean(acc.Value2,1024)).abs() > 0.05)
                acc['TimeOfLastMotion'] = acc.index
                acc.TimeOfLastMotion[acc.Motion == False] = numpy.nan
                acc.TimeOfLastMotion.fillna(method='ffill', inplace=True)
                acc['TimeSinceMotion'] = (acc.index.values - acc.TimeOfLastMotion).fillna(numpy.timedelta64(100,'s'))
                self.ThreeAxisAccelerometer = self.ThreeAxisAccelerometer[acc.TimeSinceMotion < numpy.timedelta64(10,'s')]
                logger.info('Reduced accel from %d to %d rows using dynamic sampling' % (before, len(self.ThreeAxisAccelerometer)))

            if 'ThreeAxisCompass' in self:
                before = len(self.ThreeAxisCompass)
                self.ThreeAxisCompass = \
                    self.ThreeAxisCompass[(self.ThreeAxisCompass.Value0.diff().fillna(1).abs() > 0.00002) |
                                          (self.ThreeAxisCompass.Value1.diff().abs() > 0.00002) |
                                          (self.ThreeAxisCompass.Value2.diff().abs() > 0.00002)]
                logger.info('Reduced compass from %d to %d rows using 0.00002 delta cutoff' % (before, len(self.ThreeAxisCompass)))

            if 'Passiveinfrared' in self:
                before = len(self.Passiveinfrared)
                self.Passiveinfrared['Value0'] = self.Passiveinfrared['Value0'].abs()
                self.Passiveinfrared = self.Passiveinfrared.resample('5Min', how={'Value0':numpy.max,
                                                                                  'service_time': 'first'})
                logger.info('Reduced PIR from %d to %d rows using 5 min sampling' % (before, len(self.Passiveinfrared)))

            if 'BME280Pressure' in self:
                before = len(self.BME280Pressure)
                self.BME280Pressure = self.BME280Pressure['Value0'] = self.BME280Pressure['Value0'].abs()
                self.BME280Pressure = self.BME280Pressure.resample('5Min', how={'Value0':numpy.max,
                                                                                'service_time': 'first'})
                logger.info('Reduced barometer from %d to %d rows using 5 min sampling' % (before, len(self.BME280Pressure)))

            # pylint: enable=access-member-before-definition

    def _post_load_step(self):

        super(PinnaTether, self)._post_load_step()

        # merge TMR interrupt and periodic samples
        if 'TMRSwitch' in self or 'PeriodicTMRSwitch' in self:
            TMRStreams = [self[stream] for stream in ['TMRSwitch','PeriodicTMRSwitch'] if stream in self]
            TMRSwitch = pandas.concat(TMRStreams).sort_index()
            self.delete_event_data('TMRSwitch')
            self.delete_event_data('PeriodicTMRSwitch')
            self.add_event_data('TMRSwitch', TMRSwitch, append=False, sort_by_time=True, native=True)

        if 'Passiveinfrared' in self:
            pir = self['Passiveinfrared'].Value0
            # Note that the pir Series must be cast to a DataFrame before calling the add_event_data.
            self.add_event_data('pir', pandas.DataFrame(pir), append=True, sort_by_time=True, native=False)

    # general accessor functions that deal with this specific device's log style
    def get_temperature(self):
        return self.SHTC1Temperature.Value0

    def get_humidity(self):
        return self.SHTC1Humidity.Value0
