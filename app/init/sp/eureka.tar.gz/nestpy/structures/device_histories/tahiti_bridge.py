# pylint: disable=maybe-no-member

from ..device_history import DeviceHistory
from ... import env

import datetime
import json
import gzip
import logging
import os
import pandas
import pytz
import re

logger = logging.getLogger(__name__)

class TahitiBridge(DeviceHistory):
    """
    A DeviceHistory subclass specifically for TahitiBridge.
    """

    DEVICE_TYPES = ["hiddenite"]
    LOG_TYPE = 'tahitift'

    def __init__(self, device_name=None):
        super(TahitiBridge, self).__init__(device_name)

    def __repr__(self):
        return "<nestpy.TahitiBridge for %s>" % str(self)

    @classmethod
    def load(cls,
             device_id,
             start_date=None,
             end_date=None,
             tier=None,
             event_types=None,
             cache_destination=env.cache_destination(),
             offline=False):
        """
        nestpy.TahitiBridge.load wraps nestpy.DeviceHistory.load

        :param device_id:
            device UUID
        :type device_id:
            str

        :param start_date:
            the earliest date to get logs for.
        :type start_date:
            timezone-aware datetime or timezone-naive UTC datetime

        :param end_date:
            the latest date to get logs for.
        :type end_date:
            timezone-aware datetime or timezone-naive UTC datetime

        :param tier:
            the service tier that the device belongs to ("ft", "qa", or
            "production"). Only used if the data source is S3.
        :type tier:
            string

        :param cache_destination:
            the parent folder in which to store raw and parsed data
        :type cache_destination:
            string

        :param offline:
            whether or not to allow downloading
        :type tier:
            boolean

        :returns:
            the populated Device History.
        :rtype:
            nestpy.DeviceHistory
        """
        return super(TahitiBridge, cls).load(device_id,
                                             log_type=TahitiBridge.LOG_TYPE,
                                             start_date=start_date,
                                             end_date=end_date,
                                             tier='production',  # all TahitiBridge logs go to production
                                             event_types=event_types,
                                             cache_destination=cache_destination,
                                             offline=offline)

    @classmethod
    def from_raw_event_logs(cls,
                            log_file_list,
                            unique_device_id=None,
                            event_types=None,
                            sort_by_time=False,
                            tier=None):

        if type(log_file_list) != list:
            log_file_list = [log_file_list]

        # parse data from the logfiles into a dataframe
        timestamps = []
        records = []
        source_file_metadata = {}
        for log_file in log_file_list:
            if log_file.endswith("gz"):
                file_reader = gzip.open(log_file, 'r')
            else:
                file_reader = open(log_file, 'r')
            filename = os.path.basename(log_file)
            source_file_metadata[filename] = {}
            source_file_metadata[filename].update({
                'parsed' : True,
                'filetime' : str(cls._extract_upload_time_from_filename(filename)),
                'parsed_at' : str(datetime.datetime.now())
            })

            for line in file_reader:
                try:
                    [ymd, hms, loglevel, jsonData] = re.findall(r'(?:[^\s "]|"(?:\\.|[^"])*")+', line)
                    time = datetime.datetime.strptime(ymd+'T'+hms, "%Y-%m-%dT%H:%M:%S,%f").replace(tzinfo=pytz.utc)
                    data = json.loads(jsonData)
                    timestamps.append(time)
                    records.append(data)
                except Exception:
                    logging.warn('Skipping broken line: %s' % line)
        df = pandas.DataFrame(records, index=timestamps)

        dh = cls(unique_device_id)
        dh.add_event_data('TahitiState', df, sort_by_time=sort_by_time)

        return dh, source_file_metadata

    def _post_load_step(self):
        """
        Subroutine that runs right after loading the data from the cache.
        :return:
        """

        # add DataUpload as a synthetic event
        if 'metadata' in self and 'source_files' in self.metadata:
            df = pandas.DataFrame.from_dict(self.metadata['source_files'], orient='index')
            df.index = pandas.to_datetime(df.filetime)
            if type(df.index) == pandas.DatetimeIndex:
                df = df.tz_localize('UTC')
                if self.earliest_date is not None and self.latest_date is not None:
                    df = df[(df.index >= self.earliest_date) & (df.index < self.latest_date)]
                self.add_event_data('DataUpload', df, append=False, sort_by_time=True, native=False)

