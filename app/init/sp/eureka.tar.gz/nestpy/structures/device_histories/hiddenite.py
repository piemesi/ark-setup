# pylint: disable=maybe-no-member

from ..device_history import DeviceHistory
from ... import env
from ...hiddenite.hiddenite_api_client import HiddeniteAPIClient
from ...aws.hiddenite_data_coverage import HiddeniteDataCoverage

import datetime
import logging
import numpy

logger = logging.getLogger(__name__)

class Hiddenite(DeviceHistory):
    """
    A DeviceHistory subclass specifically for Hiddenite.
    """

    DEVICE_TYPES = ["hiddenite"]
    LOCALIZE_TIME_COLUMNS = ["bucketTime", "FetchedAt"]
    LOG_TYPE = 'hiddenitelog'

    DATASET_IDS = {DeviceHistory.FT: 'hiddenite'}
    TABLE_PREFIXES = {DeviceHistory.FT: 'applogs'}

    def __init__(self, device_name=None):
        super(Hiddenite, self).__init__(device_name)

    def __repr__(self):
        return "<nestpy.Hiddenite for %s>" % str(self)

    @classmethod
    def load(cls,
             device_id,
             start_date=None,
             end_date=None,
             tier=None,
             event_types=None,
             download_from=DeviceHistory.GCP,
             cache_destination=env.cache_destination(),
             offline=False):
        """
        nestpy.Hiddenite.load wraps nestpy.DeviceHistory.load

        :param device_id:
            device UUID
        :type device_id:
            str

        :param start_date:
            the earliest date to get logs for.
        :type start_date:
            timezone-aware datetime or timezone-naive UTC datetime

        :param end_date:
            the latest date to get logs for.
        :type end_date:
            timezone-aware datetime or timezone-naive UTC datetime

        :param tier:
            the service tier that the device belongs to ("ft", "qa", or
            "production"). Only used if the data source is S3.
        :type tier:
            string

        :param cache_destination:
            the parent folder in which to store raw and parsed data
        :type cache_destination:
            string

        :param offline:
            whether or not to allow downloading
        :type tier:
            boolean

        :returns:
            the populated Device History.
        :rtype:
            nestpy.DeviceHistory
        """
        return super(Hiddenite, cls).load(device_id.upper(),
                                          log_type=Hiddenite.LOG_TYPE,
                                          start_date=start_date,
                                          end_date=end_date,
                                          tier='production',  # all hiddenite logs go to production
                                          event_types=event_types,
                                          download_from=download_from,
                                          cache_destination=cache_destination,
                                          offline=offline)

    def _post_load_step(self):
        if 'GeofenceAccuracy' in self:
            GEOFENCE_EVENT_SEPARATION_WINDOW = numpy.timedelta64(datetime.timedelta(seconds=30))
            self.GeofenceAccuracy['t'] = self.GeofenceAccuracy.index
            self.GeofenceAccuracy['dt'] = self.GeofenceAccuracy.t.diff()
            self.GeofenceAccuracy['newEvent'] = False
            self.GeofenceAccuracy.newEvent[self.GeofenceAccuracy.dt > GEOFENCE_EVENT_SEPARATION_WINDOW] = True
            self.GeofenceAccuracy.newEvent[self.GeofenceAccuracy.entering.diff().fillna(True)] = True
            self.GeofenceAccuracy.newEvent[self.GeofenceAccuracy.delay > 0.5] = False
            GeofenceRealtimeEvent = self.GeofenceAccuracy[self.GeofenceAccuracy.newEvent]
            self.add_event_data('GeofenceRealtimeEvent', GeofenceRealtimeEvent, append=False, sort_by_time=True, native=False)

    @classmethod
    def load_structure_hiddenites(cls, hiddenite_structure_id, start, end, event_types=None):
        logger.info("Loading Hiddenite event histories for structure %s", hiddenite_structure_id)

        device_mappings = HiddeniteAPIClient.get_mobile_structure_pairing()
        hiddenite_devices = device_mappings[device_mappings.structure == hiddenite_structure_id]

        hiddenites = []
        for i, device_id in hiddenite_devices.device_id.iteritems():
            hiddenite = cls.load(device_id,
                                 start_date=start,
                                 end_date=end,
                                 event_types=event_types)
            if len(hiddenite) == 0:
                logger.warning("Device {} that has no Hiddenite data from {} to {}".format(device_id, start, end))
            else:
                hiddenites.append(hiddenite)

        return hiddenites

    @staticmethod
    def device_mappings_and_coverage():
        coverage = HiddeniteDataCoverage().data_coverage()
        device_mappings = HiddeniteAPIClient.get_mobile_structure_pairing()
        date_coverage = coverage.groupby("device_id")["date"].aggregate(["min", "max"])
        date_coverage.start_date = date_coverage["min"]
        date_coverage.end_date = date_coverage["max"]
        result = date_coverage.reset_index().merge(device_mappings)

        logger.debug("Hiddenite device mappings and coverage: %s", result)
        return result

    @staticmethod
    def is_valid(device_id):
        """Checks the device id to determine if it is a valid format.

        Hiddenite device ids do not follow any convention, but they also have no ability to assert valid ids. Therefore,
        we always return false.

        Note: This does not actually check if a device exists with this identifier,
        only that the format of the identifier is valid
        """
        logger.debug("Hiddenite has no concept of valid device ids. Considering device id to be invalid: %s", device_id)
        return False
