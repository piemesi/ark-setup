# pylint: disable=no-member

import pandas

from ... import converters
from ... import env
from ...parsing import balsam_events
from .balsam import Balsam
from ...parsing import tvdreader

class AIRTether(Balsam):
    """
    A DeviceHistory subclass specifically for AIRTether, tethered to Balsam.
    """

    def __init__(self, device_name=None):
        super(AIRTether, self).__init__(device_name)

    def __repr__(self):
        return "<nestpy.AIRTether for %s>" % str(self)

    @classmethod
    def load(cls,
             device_id,
             start_date=None,
             end_date=None,
             tier=None,
             event_types=None,
             cache_destination=env.cache_destination(),
             offline=False,
             downsampling_enabled=True,
             drop_service_time=True,
             default_synchronization=tvdreader.TVDReader.Synchronization.Synchronized):
        """
        nestpy.AIRTether.load wraps nestpy.DeviceHistory.load with:
            log_type set to 'balsamlog'

        :param device_id:
            device mac address

        :type data_source:
            str

        :param start_date:
            the earliest date to get logs for.
        :type start_date:
            timezone-aware datetime or timezone-naive UTC datetime

        :param end_date:
            the latest date to get logs for.
        :type end_date:
            timezone-aware datetime or timezone-naive UTC datetime

        :param tier:
            the service tier that the device belongs to ("ft", "qa", or
            "production"). Only used if the data source is S3.
        :type tier:
            string

        :param cache_destination:
            the parent folder in which to store raw and parsed data
        :type cache_destination:
            string

        :param offline:
            whether or not to allow downloading
        :type tier:
            boolean

        :returns:
            the populated Device History.
        :rtype:
            nestpy.DeviceHistory
        """
        dh = super(AIRTether, cls).load(device_id=device_id.lower(),  # balsams always use lower case hex strings
                                       log_type=AIRTether.LOG_TYPE,
                                       start_date=start_date,
                                       end_date=end_date,
                                       tier='production',  # all balsam tether logs go to production
                                       event_types=event_types,
                                       cache_destination=cache_destination,
                                       offline=offline,
                                       downsampling_enabled=downsampling_enabled,
                                       default_synchronization=default_synchronization)

        if drop_service_time:
            # Remove service_time column - we want it parsed and remembered for future, but it breaks things
            for event in dh:
                if 'service_time' in dh[event].columns:
                    dh[event].drop('service_time', inplace=True, axis=1)

        return dh

    def _post_parse_step(self):
        if self.downsampling_enabled:
            # pylint: disable=access-member-before-definition
            pass
            # pylint: enable=access-member-before-definition

