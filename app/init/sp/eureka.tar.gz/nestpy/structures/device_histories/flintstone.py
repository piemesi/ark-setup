# pylint: disable=no-member

from ... import env
from .balsam import Balsam

class Flintstone(Balsam):
    """
    A DeviceHistory subclass specifically for Flintstone. Note that this inherits
    from Balsam though it is not a Balsam-tethered device.
    """
    LOG_TYPES = ['clientsensordata', 'clientsensordata-flintstone']
    MAC_SUFFIXES = ['-FLINTSTONE', '']

    DATASET_IDS = {Balsam.FT: 'flintstone'}

    def __init__(self, device_name=None):
        super(Flintstone, self).__init__(device_name)

    def __repr__(self):
        return "<nestpy.Flintstone for %s>" % str(self)

    @classmethod
    def load(cls,
             device_id,
             start_date=None,
             end_date=None,
             tier=None,
             event_types=None,
             download_from=Balsam.GCP,
             cache_destination=env.cache_destination(),
             offline=False,
             downsampling_enabled=True,
             drop_service_time=True,
             include_raw_tvd_values=False,
             sort_by_time=True,
             log_type='clientevent'):
        """
        nestpy.Flintstone.load wraps nestpy.DeviceHistory.load

        :param device_id:
            device mac address

        :type data_source:
            str

        :param start_date:
            the earliest date to get logs for.
        :type start_date:
            timezone-aware datetime or timezone-naive UTC datetime

        :param end_date:
            the latest date to get logs for.
        :type end_date:
            timezone-aware datetime or timezone-naive UTC datetime

        :param tier:
            the service tier that the device belongs to ("ft", "qa", or
            "production"). Only used if the data source is S3.
        :type tier:
            string

        :param cache_destination:
            the parent folder in which to store raw and parsed data
        :type cache_destination:
            string

        :param offline:
            whether or not to allow downloading
        :type tier:
            boolean

        :returns:
            the populated Device History.
        :rtype:
            nestpy.DeviceHistory
        """
        dh = super(Flintstone, cls).load(
            device_id=device_id.lower(),
            log_type=log_type,
            start_date=start_date,
            end_date=end_date,
            tier=tier,
            event_types=event_types,
            download_from=download_from,
            cache_destination=cache_destination,
            offline=offline,
            downsampling_enabled=downsampling_enabled,
            include_raw_tvd_values=include_raw_tvd_values,
            sort_by_time=sort_by_time
        )


        if drop_service_time:
            # Remove service_time column - we want it parsed and remembered for future, but it breaks things
            for event in dh:
                if 'service_time' in dh[event].columns:
                    dh[event].drop('service_time', inplace=True, axis=1)

        return dh
