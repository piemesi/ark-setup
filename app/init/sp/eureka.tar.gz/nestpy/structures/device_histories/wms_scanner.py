# pylint: disable=maybe-no-member

from ..device_history import DeviceHistory
from ... import env

import datetime
import logging
import numpy

logger = logging.getLogger(__name__)


class WMSScanner(DeviceHistory):
    """
    A DeviceHistory subclass specifically for WMS Scanner.
    """

    DEVICE_TYPES = ["wmsscanner"]
    LOCALIZE_TIME_COLUMNS = ["bucketTime", "FetchedAt"]
    LOG_TYPE = 'wmsscannerlog'

    def __init__(self, device_name=None):
        super(WMSScanner, self).__init__(device_name)

    def __repr__(self):
        return "<nestpy.WMSScanner for %s>" % str(self)

    @classmethod
    def load(cls,
             device_id,
             start_date=None,
             end_date=None,
             tier=None,
             event_types=None,
             cache_destination=env.cache_destination(),
             offline=False):
        """
        nestpy.WMSScanner.load wraps nestpy.DeviceHistory.load

        :param device_id:
            device UUID
        :type device_id:
            str

        :param start_date:
            the earliest date to get logs for.
        :type start_date:
            timezone-aware datetime or timezone-naive UTC datetime

        :param end_date:
            the latest date to get logs for.
        :type end_date:
            timezone-aware datetime or timezone-naive UTC datetime

        :param tier:
            the service tier that the device belongs to ("ft", "qa", or
            "production"). Only used if the data source is S3.
        :type tier:
            string

        :param cache_destination:
            the parent folder in which to store raw and parsed data
        :type cache_destination:
            string

        :param offline:
            whether or not to allow downloading
        :type tier:
            boolean

        :returns:
            the populated Device History.
        :rtype:
            nestpy.DeviceHistory
        """
        return super(WMSScanner, cls).load(device_id.upper(),
                                          log_type=WMSScanner.LOG_TYPE,
                                          start_date=start_date,
                                          end_date=end_date,
                                          tier='production',  # all WMSScanner logs go to production
                                          event_types=event_types,
                                          cache_destination=cache_destination,
                                          offline=offline)
