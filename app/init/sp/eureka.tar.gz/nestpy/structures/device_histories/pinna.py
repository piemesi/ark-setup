# pylint: disable=no-member
import datetime
import logging
from multiprocessing import current_process, cpu_count
import os

import pandas
import numpy

from ... import converters
from ..device_history import DeviceHistory
from ... import env
from ...parsing import tvdreader
from ...parsing import topaz_tvd
from ...parsing import balsam_events

logger = logging.getLogger(__name__)


class Pinna(DeviceHistory):
    """
    A DeviceHistory base class for POR Pinna logging
    """

    LOG_TYPE = 'clientsensordata-pinna'
    UPLOAD_PULL_BUFFER_BEFORE = datetime.timedelta(hours=1)
    UPLOAD_PULL_BUFFER_AFTER = datetime.timedelta(hours=1)

    DATASET_IDS = {DeviceHistory.FT: 'pinna'}

    def __init__(self, device_name=None):
        super(Pinna, self).__init__(device_name)

    def __repr__(self):
        return "<nestpy.Pinna for %s>" % str(self)

    @classmethod
    def load(cls,
             device_id,
             start_date=None,
             end_date=None,
             tier=None,
             event_types=None,
             download_from=DeviceHistory.GCP,
             cache_destination=env.cache_destination(),
             offline=False,
             downsampling_enabled=True,
             drop_service_time=True,
             sort_by_time=True,):
        """
        nestpy.PinnaTether.load wraps nestpy.DeviceHistory.load with:
            log_type set to 'balsamlog'

        :param device_id:
            device mac address

        :type data_source:
            str

        :param start_date:
            the earliest date to get logs for.
        :type start_date:
            timezone-aware datetime or timezone-naive UTC datetime

        :param end_date:
            the latest date to get logs for.
        :type end_date:
            timezone-aware datetime or timezone-naive UTC datetime

        :param tier:
            the service tier that the device belongs to ("ft", "qa", or
            "production"). Only used if the data source is S3.
        :type tier:
            string

        :param cache_destination:
            the parent folder in which to store raw and parsed data
        :type cache_destination:
            string

        :param offline:
            whether or not to allow downloading
        :type tier:
            boolean

        :returns:
            the populated Device History.
        :rtype:
            nestpy.DeviceHistory
        """
        dh = super(Pinna, cls).load(device_id=device_id.lower(),  # balsams always use lower case hex strings
                                    log_type=Pinna.LOG_TYPE,
                                    start_date=start_date,
                                    end_date=end_date,
                                    tier=tier,
                                    event_types=event_types,
                                    download_from=download_from,
                                    cache_destination=cache_destination,
                                    offline=offline,
                                    downsampling_enabled=downsampling_enabled,
                                    sort_by_time=sort_by_time)

        return dh

    @classmethod
    def from_raw_event_logs(cls,
                            log_file_list,
                            unique_device_id=None,
                            event_types=None,
                            sort_by_time=False,
                            tier=None,
                            include_raw_tvd_values=False,
                            default_synchronization=tvdreader.TVDReader.Synchronization.Unknown):

        if type(log_file_list) != list:
            log_file_list = [log_file_list]

        if current_process().daemon:
            # If already running in parallel, don't try to parallelize again.
            threads = 1
        else:
            # Set threads to number of logical cores available for maximum efficiency with parsing.
            threads = cpu_count()

        (data, source_file_metadata) = topaz_tvd.parse_tvd_files(log_file_list, threads=threads,
                                                                 include_raw_values=include_raw_tvd_values,
                                                                 default_synchronization=default_synchronization)

        pinna = cls(unique_device_id)

        if data is not None:
            for sensor_type in data:
                dataframe = data[sensor_type]

                # override the timestamp behavior borrowed from topaz_tvd
                # index by service-synchronized time stamp but keep rtc_time as a separate column for logic that
                # requires monotonicity
                dataframe['service_time'] = dataframe.index

                if sort_by_time:
                    dataframe = dataframe.sort()

                pinna.add_event_data(sensor_type, dataframe)

        return pinna, source_file_metadata

    @staticmethod
    def _get_files_to_parse_in_directory(directory_name, log_type, start_date, end_date):
        """
        Returns a list logfiles that should be parsed from the specified directory

        :param directory_name:
            path to a directory containing logfiles
        :param start_date:
            as an optimization, reject logs uploaded some time before the target start date
        :param end_date:
            as an optimization, reject logs uploaded some time after the target end date

        :rtype:
            list of filepaths to parse
        """
        if start_date:
            start_date = converters.get_tz_aware_datetime(start_date)

        if end_date:
            end_date = converters.get_tz_aware_datetime(end_date)

        filenames = sorted(os.listdir(directory_name))
        files = [os.path.join(directory_name, filepath) for filepath in filenames if filepath.find(log_type) != -1]

        if len(files) > 0:
            file_info = pandas.DataFrame.from_dict([{'filename': filename,
                                                     'filetime': DeviceHistory.
                                                   _extract_upload_time_from_filename(filename)} for filename in files])
            file_info.sort(['filetime'], inplace=True)
            file_info['to_parse'] = (file_info.filetime > start_date) & (file_info.filetime < end_date)
            file_info.to_parse[(1*(file_info.filetime > end_date)).diff() == 1] = True
            return file_info.filename[file_info.to_parse].tolist()
        else:
            return []

    @staticmethod
    def _remove_nonsensical_times(event_df):
        filtered_event_df = event_df[(event_df.index > '01-01-2010') & (event_df.index < datetime.datetime.now() +
                                                                        datetime.timedelta(days=10))]
        return filtered_event_df

    def _post_load_step(self):
        """
        Subroutine that runs right after loading the data from the cache.
        :return:
        """
        event_names = list(self.events) #Create a copy of the list because we're replacing elements in loop below.
        for event_name in event_names:
            if len(self[event_name]):
                # For each event remove the non-sensical times.
                filtered_event = self._remove_nonsensical_times(self[event_name])
                self[event_name] = filtered_event

        #TODO: self.earliest_date and self.latest_date are slightly incorrect now because of the reindexing with rtc

        # post-process
        # TODO: Replace the balsam event parser with a better version based on the TVD metadata.
        balsam_events.parse_balsam_events(self)

        # add DataUpload as a synthetic event
        if 'metadata' in self and 'source_files' in self.metadata:
            df = pandas.DataFrame.from_dict(self.metadata['source_files'], orient='index')
            df.index = pandas.to_datetime(df.filetime)
            if type(df.index) == pandas.DatetimeIndex:
                df = df.tz_localize('UTC')
                if self.earliest_date is not None and self.latest_date is not None:
                    df = df[(df.index >= self.earliest_date) & (df.index < self.latest_date)]
                self.add_event_data('DataUpload', df, append=False, sort_by_time=True, native=False)
