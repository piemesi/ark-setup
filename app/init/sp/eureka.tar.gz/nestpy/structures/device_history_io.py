import datetime
import gzip
import json
import logging
import os
import pytz
import shutil
import string
import subprocess
import tarfile

import pandas as pd
import numpy as np

from .. import aws
from .. import converters
from .device_history_base import DeviceHistoryBase
from .. import env
from ..fileutils import basename
from .. import gcp
from ..parsing import eventlog

logger = logging.getLogger(__name__)


METADATA_FILENAME = 'metadata.json'
HDF5_PREFIX = 'hdf5_'

MEGABYTES=2**20

class DeviceHistoryIO(DeviceHistoryBase):
    """
    This class provides the methods for reading and writing the DeviceHistoryBase objects to a file.

    Except in rare instances, it should not be inherited directly, rather the DeviceHistory class should be inherited
    from to create individual DeviceHistory objects for each specific device.
    """
    UPLOAD_PULL_BUFFER_BEFORE = datetime.timedelta(hours=28)
    UPLOAD_PULL_BUFFER_AFTER = datetime.timedelta(hours=28)

    # NOTE: this pattern should not be followed for production, which should instead use key-based storage
    FT, PROD, QA = 'ft', 'production', 'qa'
    TIERS = [FT, PROD, QA]

    DATASET_IDS = {}
    DEVICE_ID_TYPES = {FT: 'mac_address'}
    PROJECT_IDS = {FT: 'nest-algo'}
    QUERY_PROJECT_IDS = {FT: 'nest-algo'}
    TABLE_INDICES = {FT: 'timeindex'}
    TABLE_PREFIXES = {FT: 'daily'}

    AWS = 'AWS'
    GCP = 'GCP'
    SOURCES = [AWS, GCP]

    def __init__(self, unique_device_id="Unknown"):

        super(DeviceHistoryIO, self).__init__()
        self.unique_device_id = str(unique_device_id)

    @classmethod
    def load(cls, *args, **kwargs):
        download_from = kwargs.pop('download_from', cls.AWS)

        if env.hdf5_enabled():
            return cls._load_hdf5(*args, download_from=download_from, **kwargs)
        else:
            return cls._load_directoried(*args, **kwargs)

    # Device History API
    @classmethod
    def _load_directoried(cls,
                          device_id,
                          log_type=None,
                          start_date=None,
                          end_date=None,
                          sort_by_time=False,
                          tier=None,
                          event_types=None,
                          cache_destination=env.cache_destination(),
                          offline=False,
                          downsampling_enabled=False,
                          **kwargs):
        """
        Loads a Device History quickly by automatically downloading, parsing,
        and loading the appropriate data into memory.

        :param device_id: the device identifier, typically a macaddress
        :type device_id: string

        :param log_type: the log type as it appears in the raw uploaded file (clientevent, hiddenitelog).
        :type log_type: string

        :param start_date: the earliest date to get logs for.
        :type start_date: timezone-aware datetime or timezone-naive UTC datetime

        :param end_date: the latest date to get logs for.
        :type end_date: timezone-aware datetime or timezone-naive UTC datetime

        :param tier: the service tier that the device belongs to ("ft", "qa", or "production")
        :type tier: string

        :param cache_destination: the parent folder in which to store raw and parsed data
        :type cache_destination: string

        :param offline: whether or not to allow downloading
        :type tier: boolean

        :returns: the populated Device History.
        :rtype: nestpy.DeviceHistory
        """

        # sanitize inputs
        if start_date is not None:
            start_date = converters.get_tz_aware_datetime(start_date)
        if end_date is not None:
            end_date = converters.get_tz_aware_datetime(end_date)

        # create the Device History object
        dh = cls(device_id)
        dh.downsampling_enabled = downsampling_enabled

        device_cache_destination = os.path.join(cache_destination, device_id)

        # we will write new directoried logs unless only source was existing directoried logs
        write_new_directoried_logs = False

        # populate the Device History from specified source
        # cheapest resource is directoried logs. Load first to see if others are necessary
        if dh._query_requires_load(data_source=device_cache_destination,
                                   tier=tier,
                                   start_date=start_date,
                                   end_date=end_date):
            if os.path.isdir(device_cache_destination):
                logger.debug('Loading <%s> from directoried logs', device_id)
                new_dh = cls.from_directoried_event_logs(directory=device_cache_destination,
                                                         event_types=event_types,
                                                         sort_by_time=sort_by_time)
                dh.append(new_dh)

        # download from S3 if necessary and allowed
        if dh._query_requires_download(tier=tier, start_date=start_date, end_date=end_date):
            if offline:
                logger.info('Would download from S3 for <%s> but forced to offline', device_id)
            else:
                retval = cls.download_to_local(device_id=device_id,
                                               tier=tier,
                                               log_type=log_type,
                                               start_date=start_date,
                                               end_date=end_date,
                                               destination=cache_destination)

                # append query to metadata
                if retval != "Error":

                    query = {'tier': tier,
                             'start_date': str(start_date),
                             'end_date': str(end_date),
                             'queried_at': str(datetime.datetime.now())}
                    dh.add_metadata('queries', [query], append=True)

                    # make sure new directoried logs get cached
                    write_new_directoried_logs = True

                    # perform any post download steps
                    dh._post_download_step()

        # parse new files if necessary
        new_files_to_parse = dh._get_new_files_to_parse(log_directory=device_cache_destination,
                                                        log_type=log_type,
                                                        tier=tier,
                                                        start_date=start_date,
                                                        end_date=end_date)

        if new_files_to_parse is not None and len(new_files_to_parse) > 0:
            logger.debug('Parsing %d files for device %s' % (len(new_files_to_parse), device_id))

            # note: to avoid possibly reparsing files in the future, we will
            # - parse all event types
            # - load all available times in the specified files
            # - after parsing and storing to directoried logs, we then discard these extra data
            (new_dh, source_file_metadata) = cls.from_raw_event_logs(new_files_to_parse,
                                                                     unique_device_id=device_id,
                                                                     tier=tier,
                                                                     sort_by_time=sort_by_time,
                                                                     **kwargs)

            # Since there are new files from raw event logs, we need to load all of the events
            # from directoried logs so they can be properly cached.
            if event_types is not None:
                unloaded_events = [event for event in new_dh.events if event not in event_types]
                unloaded_dh = cls.from_directoried_event_logs(directory=device_cache_destination,
                                                              event_types=unloaded_events,
                                                              sort_by_time=sort_by_time,
                                                              **kwargs)
                dh.append(unloaded_dh, sort_by_time=True)
            dh.append(new_dh, sort_by_time=True)
            dh.add_metadata('source_files', source_file_metadata, append=True)

            # make sure new directoried logs get cached
            write_new_directoried_logs = True

            # perform any post parsing steps
            dh._post_parse_step()

        # Save to directoried logs in this directory so we won't have to
        # re-parse files if the data is re-loaded
        if write_new_directoried_logs:
            dh.to_directoried_event_logs(os.path.abspath(os.path.join(device_cache_destination, "../")))

        # perform any custom post load steps
        dh._post_load_step()

        # now that we have saved everything, filter.
        # done after writing to directoried logs to cache as much as possible
        # 1. limit to the requested time limits
        if tier != 'w_forecast':
            dh = dh[start_date:end_date]

        # 2. limit to the requested event types
        if event_types is not None and len(event_types) > 0:
            found_events = []
            found_native_events = []
            found_nonnative_events = []
            for event_type in dh.events:
                if event_type not in event_types:
                    del dh[event_type]
                else:
                    found_events.append(event_type)
                    if event_type in dh.native_events:
                        found_native_events.append(event_type)
                    if event_type in dh.nonnative_events:
                        found_nonnative_events.append(event_type)
            dh.events = found_events
            dh.native_events = found_native_events
            dh.nonnative_events = found_nonnative_events

        return dh

    @classmethod
    def from_directoried_event_logs(cls, directory,
                                    unique_device_id=None,
                                    event_types=None,
                                    start_date=None,
                                    end_date=None,
                                    sort_by_time=False,
                                    log_type=None,
                                    load_metadata=True,
                                    tier=None,
                                    **kwargs):
        """
        Creates a new Device History object using the event logs in the provided
        directory.

        :param directory: the directory containing parsed event logs.
        :type directory: str

        :param unique_device_id: a unique device identifier, typically the device's MAC address or serial number. If not
            provided, the ID will be based on the provided folder name.
        :type unique_device_id: str

        :param event_types: a list of event types to include. If not provided, all event types will be loaded.
        :type event_types: list of str

        :param start_date: the earliest date to get logs for.
        :type start_date: timezone-aware datetime or timezone-naive UTC datetime

        :param end_date: the latest date to get logs for.
        :type end_date: timezone-aware datetime or timezone-naive UTC datetime

        :param sort_by_time: whether to sort the events by time.
        :type sort_by_time: boolean

        :param load_metadata: whether to load in metadata if it exists
        :type load_metadata: boolean

        :returns: the populated device history.
        :rtype: nestpy.DeviceHistory
        """

        if not unique_device_id:
            unique_device_id = basename(directory)

        if start_date:
            start_date = converters.get_tz_aware_datetime(start_date)

        if end_date:
            end_date = converters.get_tz_aware_datetime(end_date)

        device = cls(unique_device_id)
        for file_name in os.listdir(directory):

            full_file = os.path.join(directory, file_name)
            if not os.path.isfile(full_file):
                continue

            if METADATA_FILENAME == file_name:
                if load_metadata:
                    device.load_metadata(directory, hdf5=False)
                continue

            if (file_name.startswith(".") or
               ".log" in file_name or
               "Icon" in file_name or
               '.h5' in file_name or
               '.json' in file_name):
                # Ignore files that start with a dot, raw logs, h5 logs, .json files (except metadata) or other trash
                continue

            if event_types and basename(file_name) not in event_types:
                continue

            device._load_event_log(full_file,
                                   start_date=start_date,
                                   end_date=end_date,
                                   sort_by_time=sort_by_time)

        return device

    def to_directoried_event_logs(self, directory=None,
                                  event_types=None,
                                  compressed=False,
                                  write_metadata=True):
        """
        Creates directoried event logs based on the data stored in this device
        history.

        :param directory:
          The directory to place the directoried event logs. The directory will
          be created if it doesn't already exist.

          If not provided, the current directory will be used.
        :param event_types: a list of event types to write out. If not provided,
          all event types will be written to directoried logs.
        :param compressed: whether to write the event logs in GZIP-compressed
          format.
        :param write_metadata: whether to include metadata in the directoried log
        """

        if not directory:
            directory = os.getcwd()
        save_directory = os.path.join(directory, self.unique_device_id)

        if not os.path.isdir(save_directory):
            os.makedirs(save_directory)

        if not event_types:
            event_types = self.native_events

        for event in event_types:
            event_file = os.path.join(save_directory, event)
            if event not in self.events:
                continue

            event_data = self.__dict__[event].copy()

            # Convert the index timestamps to epoch times
            event_data.index = [converters.datetime_to_epoch_time(timestamp) for timestamp in event_data.index]

            # Preprocess each column
            header = ["t:timestamp"]
            for index, column_name in enumerate(event_data.columns):
                data_type = str(event_data.dtypes[index])

                # Determine column type
                if "int" in data_type:
                    header.append("%s:integer" % column_name)
                elif "float" in data_type:
                    header.append("%s:decimal" % column_name)
                elif "bool" in data_type:
                    header.append("%s:boolean" % column_name)
                elif "object" in data_type and \
                        len(event_data[column_name]) > 0 and \
                        isinstance(event_data[column_name].iloc[0], datetime.datetime):
                    header.append("%s:timestamp" % column_name)
                    non_nan_indexes = event_data[column_name].dropna().index
                    event_data.loc[non_nan_indexes,
                                   column_name] = event_data.loc[non_nan_indexes,
                                                                 column_name].apply(converters.datetime_to_epoch_time)

                else:
                    header.append("%s:string" % column_name)

            if compressed:
                event_file_handle = gzip.open("%s.gz" % event_file, 'wb')
            else:
                event_file_handle = open(event_file, 'wb')

            event_data.reset_index().to_csv(event_file_handle, header=header, index=False, float_format='%r', sep="\t", na_rep="NaN")
            event_file_handle.close()

        if write_metadata:
            self.write_metadata(save_directory)

    @classmethod
    def _load_hdf5(cls,
                   device_id,
                   log_type=None,
                   start_date=None,
                   end_date=None,
                   sort_by_time=False,
                   tier=None,
                   event_types=None,
                   cache_destination=env.cache_destination(),
                   offline=False,
                   downsampling_enabled=False,
                   download_from=GCP,
                   **kwargs):
        """
        Implementation of the load() function using hdf5 as the log store instead of directoried logs. This may
        eventually replace the current load() but is provided separately for the current time.
        """

        logger.debug('Loading device %s using HDF5', device_id)

        # sanitize inputs
        if start_date is not None:
            start_date = converters.get_tz_aware_datetime(start_date)
        if end_date is not None:
            end_date = converters.get_tz_aware_datetime(end_date)
        if not hasattr(event_types, '__iter__'):
            event_types = [event_types]

        device = cls(device_id)
        device.downsampling_enabled = downsampling_enabled
        device.cache_destination = os.path.join(cache_destination, device_id)
        write_new_logs = False

        # The first thing that we do is look for metadata and load it.
        device.load_metadata(device.cache_destination, hdf5=True)

        # Based on the metadata, we determine if we need to download logs.
        if device._query_requires_download(tier=tier, start_date=start_date, end_date=end_date):
            if offline:
                logger.debug('Would download for <%s> but forced to offline', device_id)
            else:
                logger.debug('Downloading files for %s from %s', device_id, download_from)

                if download_from.upper() == cls.AWS:
                    new_dh = cls._get_device_history_from_aws(device,
                                                              log_type=log_type,
                                                              start_date=start_date,
                                                              end_date=end_date,
                                                              sort_by_time=sort_by_time,
                                                              tier=tier,
                                                              cache_destination=cache_destination)
                elif download_from.upper() == cls.GCP:
                    new_dh = cls._get_device_history_from_gcp(device,
                                                              start_date=start_date,
                                                              end_date=end_date,
                                                              event_types=event_types,
                                                              sort_by_time=sort_by_time,
                                                              tier=tier)
                else:
                    raise ValueError('expected `download_from` to be in {}'.format(cls.SOURCES))

                if new_dh:
                    device.append(new_dh)
                    device._post_parse_step()

                    # append query to metadata
                    query = {'tier': tier,
                             'start_date': str(start_date),
                             'end_date': str(end_date),
                             'queried_at': str(datetime.datetime.now())}
                    device.add_metadata('queries', [query], append=True)
                    device.consolidate_query_metadata()

                    # The newly downloaded and parsed logs are now added to the HDF5 Store.
                    logger.debug('Writing new data to HDF5 store')
                    device.to_hdf5_event_logs(directory=cache_destination)

        # Now, load the desired date range into the HDF5 Store into memory.
        # This is very fast, so we won't worry about joining data we already have in memory, we'll just
        # drop the loaded data and get everything fresh from HDF5.
        device = cls.from_hdf5_event_logs(directory=device.cache_destination,
                                          unique_device_id=device_id,
                                          event_types=event_types,
                                          start_date=start_date,
                                          end_date=end_date,
                                          sort_by_time=sort_by_time,
                                          load_metadata=True)

        # perform any custom post load steps
        device._post_load_step()

        return device

    @classmethod
    def _get_device_history_from_aws(cls,
                                     device,
                                     log_type=None,
                                     start_date=None,
                                     end_date=None,
                                     sort_by_time=False,
                                     tier=None,
                                     cache_destination=env.cache_destination()):

        device_id = device.unique_device_id
        new_dh = None
        retval = cls.download_to_local(device_id=device_id,
                                       tier=tier,
                                       log_type=log_type,
                                       start_date=start_date,
                                       end_date=end_date,
                                       destination=cache_destination)

        if retval != "Error":
            # perform any post download steps
            device._post_download_step()

        new_files_to_parse = device._get_new_files_to_parse(log_directory=device.cache_destination,
                                                            log_type=log_type,
                                                            tier=tier,
                                                            start_date=start_date,
                                                            end_date=end_date)

        if new_files_to_parse is not None and len(new_files_to_parse) > 0:
            logger.debug('Parsing %d files for device %s', len(new_files_to_parse), device_id)

            # note: to avoid possibly reparsing files in the future, we will
            # - parse all event types
            # - load all available times in the specified files
            # - after parsing and storing to hdf5 logs, we then discard these extra data
            new_dh, source_file_metadata = cls.from_raw_event_logs(new_files_to_parse,
                                                                   unique_device_id=device_id,
                                                                   tier=tier,
                                                                   sort_by_time=sort_by_time)

            device.add_metadata('source_files', source_file_metadata, append=True)

        return new_dh

    @staticmethod
    def _get_tier_parameter(tier, mapping):
        assert tier in DeviceHistoryIO.TIERS
        tier = tier.lower()

        if tier in mapping:
            return mapping[tier]
        else:
            raise NotImplementedError

    @classmethod
    def get_dataset_id(cls, tier=None):
        return cls._get_tier_parameter(tier, cls.DATASET_IDS)

    @classmethod
    def get_device_id_type(cls, tier=None):
        return cls._get_tier_parameter(tier, cls.DEVICE_ID_TYPES)

    @classmethod
    def get_project_id(cls, tier=None):
        return cls._get_tier_parameter(tier, cls.PROJECT_IDS)

    @classmethod
    def get_query_project_id(cls, tier=None):
        return cls._get_tier_parameter(tier, cls.QUERY_PROJECT_IDS)

    @classmethod
    def get_table_index(cls, tier=None):
        return cls._get_tier_parameter(tier, cls.TABLE_INDICES)

    @classmethod
    def get_table_prefix(cls, tier=None):
        return cls._get_tier_parameter(tier, cls.TABLE_PREFIXES)

    @classmethod
    def _get_device_history_from_gcp(cls,
                                     device,
                                     start_date=None,
                                     end_date=None,
                                     event_types=None,
                                     sort_by_time=False,
                                     tier=None):
        if not event_types:
            raise ValueError('you probably don\'t need all the event types...')

        device_id = device.unique_device_id

        downloader = gcp.DataDownloader(start_date=start_date,
                                        end_date=end_date,
                                        bq_project_id=cls.get_project_id(tier=tier),
                                        device_id_type=cls.get_device_id_type(tier=tier))

        data_dict = downloader.events_to_dataframes(event_types=event_types,
                                                    device_id=device_id,
                                                    project_id=cls.get_query_project_id(tier=tier),
                                                    dataset_id=cls.get_dataset_id(tier=tier),
                                                    table_prefix=cls.get_table_prefix(tier=tier),
                                                    index=cls.get_table_index(tier=tier),
                                                    threads=10)

        return cls.from_event_data_dict(data_dict, device_id, sort_by_time=sort_by_time)

    def to_hdf5_event_logs(self,
                           directory=None,
                           event_types=None,
                           compressed=True,
                           write_metadata=True):
        """
        Creates an HDF5 store for event logs that is much faster than using the traditional
        CSV store.

        File compression is enabled by default, however any uncompressed files will remain uncompressed.
        To compress a file after the fact, you can call the following at the command line:
        ptrepack --chunkshape=auto --propindexes --complevel=9 --complib=blosc in.h5 out.h5
        """
        if directory is None:
            directory = os.getcwd()
        save_directory = os.path.join(directory, self.unique_device_id)

        if not os.path.isdir(save_directory):
            os.makedirs(save_directory)

        save_file = os.path.join(save_directory, self.unique_device_id+'.h5')

        # Set format type to table, which is appendable and queryable.
        pd.set_option('io.hdf.default_format', 'table')

        try:
            if compressed:
                store = pd.HDFStore(save_file, complevel=9, complib='blosc')
            else:
                store = pd.HDFStore(save_file)
        except:
            logger.error("Unable to open %s as an HDFStore", save_file)
            raise

        # Only save native events. Consider saving non-native events in the future to increase speed at the expense
        # of memory. Could be an option.
        if not event_types:
            event_types = self.native_events

        # This is the only place that data is writen to the HDF5 log store.
        def append_data(event, event_data, data_columns=None):
            try:
                store.append(event, event_data, data_columns=data_columns)
            except ValueError:
                # This is probably because a new column was added to the dataframe or a long string was
                # added. To handle this, the store can be read into memory, joined with the new data, and
                # re-writen now with the new columns.
                old_data = store[event]
                if old_data is not None:
                    data = old_data.append(event_data)
                    store.put(event, data, data_columns=data_columns)
                else:
                    # Something else has gone wrong, re-raise error
                    raise

        for event in event_types:
            if event not in self.events:
                continue

            # This is also inefficient, and probably not needed.
            event_data = self.__dict__[event].copy()

            for column in event_data:
                # Before writing to the HDF store, we need to convert all datetime.datetime columns to the pandas
                # Timestamp type. This combines the benefits of numpy's datetime64 (fast, low memory) with
                # datetime.datetime (timezone-awareness)
                if len(event_data) and type(event_data[column].values[0]) == datetime.datetime:
                    event_data[column] = event_data[column].apply(lambda x: pd.Timestamp(x))
                # Unicode columns are not allowed to be stored in h5 logs, and need to be converted to strings.
                if len(event_data) and isinstance(event_data[column].values[0], unicode):
                    event_data[column] = event_data[column].astype(str)

            try:
                append_data(event, event_data)
            except TypeError, e:
                # There are 2 reasons that this error is commonly seen, so we will attempt to handle both. These are
                # rare, so it is inefficient to handle it up front, instead we wait for the error and deal with it
                # properly at that point.
                # First, we see if a column has mixed datatypes, which aren't allowed. Pandas provides a function
                # for coercing datatypes such as ints with N/A objects to a better representation (floats in this case)
                # This is a bit of a magic bullet that isn't well documented, so we only try it as a last resort after
                # getting an exception.
                event_data = event_data.convert_objects(convert_dates=False, convert_numeric=True)

                # Second, we check for multiple objects of different types (pandas issue #8284). To work around, the
                # non string columns are added as data_columns. This is less efficient, but keeps the types correct.
                object_types = set()
                data_columns = []
                for column, dtype in event_data.dtypes.iteritems():
                    if dtype == 'object':
                        object_type = pd.lib.infer_dtype(event_data[column])

                        # PyTables cannot handle long values in a mixed data type column, as a result of which
                        # these values need to be filtered out. long values are generally unsigned 32/64 bit integers
                        # that are not supported by PyTables for now.

                        if object_type == 'integer':
                            logger.warn("The column %s in event %s may have long values that will be filtered out..." % (str(column), str(event)))
                            criterion_fn = event_data[column].map(lambda x: not isinstance(x, long))
                            event_data = event_data[criterion_fn]
                            event_data[column] = event_data[column].astype(float)
                        elif object_type == 'string':
                            logger.warn("The column %s in event %s will be converted to String has a mixed data type" % (str(column), str(event)))
                            event_data[column] = event_data[column].astype(str)
                        elif object_type == 'datetime':
                            logger.warn("The column %s in event %s contains timestamps and NaNs and will be converted to float" % (str(column), str(event)))
                            event_data[column] = event_data[column].map(lambda x: pd.Timestamp(x).value if not pd.isnull(x) else np.nan)

                        object_types.add(object_type)
                        if object_type != 'string':
                            data_columns.append(column)

                if len(object_types) <= 1:
                    data_columns = None

                append_data(event, event_data, data_columns=data_columns)

        store.close()
        # Determine if the HDF5 store is significantly larger than the last time it was sized. If so, run the
        # re-compression tool to re-optimize the blocking.

        def run_ptrepack():
            logger.debug('HDF5 filesize has increased significantly. Reoptimizing with ptrepack.')

            method = ("ptrepack --chunkshape=auto --propindexes "
                      "--complevel=9 --complib=blosc {0} {0}_COMPRESSED".format(save_file))

            subprocess.call(method, shell=True, close_fds=True)

            os.rename(save_file+'_COMPRESSED', save_file)

            hdf5_size = os.path.getsize(save_file)
            self.add_metadata('hdf5_size', hdf5_size)

        hdf5_size = os.path.getsize(save_file)
        if 'hdf5_size' in self.metadata:
            previous_size = self.metadata['hdf5_size']
            if ((previous_size < 100*MEGABYTES and hdf5_size > 100*MEGABYTES) or
                (hdf5_size - previous_size > 250*MEGABYTES)):
                run_ptrepack()
                new_hdf5_size = os.path.getsize(save_file)
                logger.debug('HDF5 log file has been repacked from {} bytes to {} bytes'.format(hdf5_size,
                                                                                                new_hdf5_size))
        else:
            self.add_metadata('hdf5_size', hdf5_size)

        if write_metadata:
            self.write_metadata(save_directory, hdf5=True)

    def load_metadata(self, directory=None, hdf5=False):
        """
        When using the HDF5 log files, the metadata is handled separately.
        """

        if hdf5:
            hdf5_prefix = HDF5_PREFIX
        else:
            hdf5_prefix = ''

        if directory is None:
            directory = os.getcwd()
        metadata_filename = os.path.join(directory, hdf5_prefix + METADATA_FILENAME)
        if os.path.isfile(metadata_filename):
            with open(metadata_filename) as metadata_file:
                self.metadata = json.load(metadata_file)
        else:
            # Can't find uncompressed file, look for compressed file
            # Metadata will always be stored uncompressed now, but legacy compressed files exist.
            # We will look for them and read them, re-writing them as compressed files.
            metadata_filename = metadata_filename + '.gz'
            if os.path.isfile(metadata_filename):
                with gzip.open(metadata_filename, 'r') as metadata_file:
                    self.metadata = json.load(metadata_file)
                self.write_metadata(directory, hdf5)
                os.remove(metadata_filename)
            else:
                self.metadata = {}

    def write_metadata(self, directory=None, hdf5=False):
        """
        Write the metadata to a file in the specified directory.
        """
        if hdf5:
            hdf5_prefix = HDF5_PREFIX
        else:
            hdf5_prefix = ''

        metadata_file = os.path.join(directory, hdf5_prefix + METADATA_FILENAME)

        with open(metadata_file, 'wb') as file_handle:
            json.dump(self.metadata, file_handle)

    @classmethod
    def from_hdf5_event_logs(cls,
                             directory,
                             unique_device_id=None,
                             event_types=None,
                             start_date=None,
                             end_date=None,
                             sort_by_time=False,
                             load_metadata=True):
        """
        Loads an HDF5 store for event logs that is much faster than using the traditional
        CSV store.
        """

        # Currently, this function loads the requested data into memory using the standard DH structure. In future
        # versions, this loading should be performed lazily. Device History will keep track of a range of dates that
        # were requested. When a specific event is loaded, the data will actually be loaded from the store, otherwise,
        # it will never be loaded. This will provide a significant speed up since few events are actually used.

        if unique_device_id is None:
            unique_device_id = basename(directory)

        device = cls(unique_device_id)

        # Look for h5 file:
        if not os.path.isfile(os.path.join(directory, unique_device_id+'.h5')):
            return device

        store = pd.HDFStore(os.path.join(directory, unique_device_id+'.h5'))

        if event_types is None or not len(event_types):
            event_types = store.keys()
        if type(event_types) != list:
            event_types = [event_types]

        where = ''
        if start_date is not None:
            where += 'index >= start_date'
        if end_date is not None:
            if where != '':
                where += ' & '
            where += 'index < end_date'
        if where == '':
            where = None

        for event in event_types:
            if event in store:
                try:
                    df = store.select(event, where=where)
                except IndexError:
                    # An exception is raised if there is no data within the time range
                    df = pd.DataFrame()
                if df is not None:
                    device.add_event_data(event.strip('/'), df, sort_by_time=sort_by_time)

        store.close()

        if load_metadata:
            device.load_metadata(directory, hdf5=True)

        return device

    @staticmethod
    def convert_directoried_to_hdf5(directory,
                                    unique_device_id=None,
                                    event_types=None,
                                    start_date=None,
                                    end_date=None,
                                    sort_by_time=False,
                                    load_metadata=True,
                                    compressed=True):

        device = DeviceHistoryIO.from_directoried_event_logs(directory,
                                                             unique_device_id=unique_device_id,
                                                             event_types=event_types,
                                                             start_date=start_date,
                                                             end_date=end_date,
                                                             sort_by_time=sort_by_time,
                                                             load_metadata=load_metadata)

        device.to_hdf5_event_logs(directory=directory,
                                  event_types=event_types,
                                  compressed=compressed,
                                  write_metadata=True)

    @classmethod
    def download_to_local(cls, device_id, tier, log_type, start_date, end_date, destination):
        """
        This is the generic S3 downloading code that will work for Diamond and Topaz.  It is overloaded by children that
        do not download from S3, e.g. Weather.

        :param device_id: the device id for which you want the S3 logs for
        :type device_id: string

        :param tier: not used
        :type tier: string

        :param start_date: the earliest date to get logs for.
        :type start_date: timezone-aware datetime or timezone-naive UTC datetime

        :param end_date: the latest date to get logs for.
        :type end_date: timezone-aware datetime or timezone-naive UTC datetime

        :param destination: the parent folder in which to store raw and parsed data
        :type destination: string
        """
        downloader = aws.DataDownloader(tier=tier,
                                        log_type=log_type,
                                        start_date=start_date - cls.UPLOAD_PULL_BUFFER_BEFORE,
                                        end_date=end_date + cls.UPLOAD_PULL_BUFFER_AFTER)
        retval = downloader.single_device_download(mac_address=device_id, destination=destination)
        return retval

    @classmethod
    def from_raw_event_logs(cls,
                            log_file_list,
                            unique_device_id=None,
                            event_types=None,
                            sort_by_time=False,
                            tier=None):
        # KP Note: This function should be generic to all subclasses, and should handle correctly storing the metadata,
        # and passing the list of log files to the subclass specific parser.

        if type(log_file_list) != list:
            log_file_list = [log_file_list]

        dh = cls(unique_device_id)
        source_file_metadata = {}
        for filepath in log_file_list:
            filename = os.path.basename(filepath)
            source_file_metadata[filename] = {}
            new_dh = cls.from_raw_event_log(filepath,
                                            event_types=event_types,
                                            sort_by_time=sort_by_time,
                                            tier=tier)
            dh.append(new_dh, sort_by_time=sort_by_time)
            source_file_metadata[filename].update({
                'parsed': True,
                'filetime': str(cls._extract_upload_time_from_filename(filename)),
                'parsed_at': str(datetime.datetime.now())
            })
        return (dh, source_file_metadata)

    @classmethod
    def from_raw_event_log(cls,
                           log_file,
                           unique_device_id=None,
                           event_types=None,
                           sort_by_time=True,
                           tier=None):
        """
        Creates a new Device History object using raw event logs in the
        provided event logfile.

        :param log_file: the log file containing raw event logs.
        :type log_file: str

        :param unique_device_id: a unique device identifier, typically the device's MAC address or serial number. If not
            provided, the ID will be based on the provided folder name.
        :type unique_device_id: str

        :param event_types: a list of event types to include. If not provided, all event types will be loaded.
        :type event_types: list of str

        :param sort_by_time: whether to sort the events by time.
        :type sort_by_time: boolean

        :returns: the populated Device History.
        :rtype: nestpy.DeviceHistory
        """
        # KP Note: This function should be unimplemented here, with each subclass responsible for defining how it's logs
        # are parsed. It should also return a dict, instead of a full dh. The dicts should be combined before creating
        # the device history object, for improved efficiency.

        # Populate the device history object
        if not unique_device_id:
            unique_device_id = basename(log_file)
            unique_device_id = unique_device_id.split('.')[0]

        dh = cls(unique_device_id)
        event_data = eventlog.parse_raw_event_log(log_file,
                                                  event_types=event_types)

        for event_type in event_data:
            current_event_data = event_data[event_type]
            times = current_event_data["times"]
            values = current_event_data["values"]

            if len(times) > 0:
                dataframe = pd.DataFrame(values, index=times)

                dh.add_event_data(event_type, dataframe, sort_by_time=sort_by_time)

        dh.events.sort()
        return dh

    @classmethod
    def from_event_data_dict(cls, data_dict, unique_device_id, event_types=None, sort_by_time=True):
        dh = cls(unique_device_id)

        if event_types:
            data_dict = dict(filter(lambda x: x[0] in event_types, data_dict.iteritems()))

        for event_type, dataframe in data_dict.iteritems():
            # probably want to return something even if dataframes are empty
            dh.add_event_data(event_type, dataframe, sort_by_time=sort_by_time)

        dh.events.sort()
        return dh

    def package_directoried_logs(self,
                                 directory=None,
                                 destination=None,
                                 remove_source=True):
        """
        Packages directoried log into a .tar.gz file for portability.
        """

        if not directory:
            directory = os.path.join(os.getcwd(), self.unique_device_id)

        if not destination:
            destination = os.path.join(os.getcwd(), "%s.tar.gz" % (self.unique_device_id))

        tar = tarfile.open(destination, "w:gz")
        for filename in sorted(os.listdir(directory)):
            if 'source_files' in self.metadata and filename in self.metadata['source_files']:
                continue
            if filename.find(self.LOG_TYPE) != -1:
                continue
            tar.add(os.path.join(directory, filename), arcname=filename)
        tar.close()
        logger.info('Packaged to %s' % destination)

        if remove_source:
            shutil.rmtree(directory)
            logger.info('Removed source directory [%s]' % directory)

        return destination

    # Internal methods:
    def _query_requires_load(self, data_source, tier, start_date, end_date):
        return True

    def _query_requires_download(self, tier, start_date, end_date):
        """
        Answers the question: do I need to fetch more data from S3 to meet the request?

        :param tier: tier to which the device is paired
        :param start_date: earliest data the requester wants returned
        :param end_date: latest data the requested wants returned
        :rtype: boolean
        """
        download_required = True
        # if query is malformed, do not attempt download
        # this allows loading whatever is available by other means
        if tier is None or start_date is None or end_date is None:
            download_required = False
        elif 'queries' in self.metadata:
            # check if any of the existing queries cover the desired range
            for query in self.metadata['queries']:
                # always re-query unless all of the following are true:
                # - the existing query was for the same tier
                # - the existing query was before the likely upload buffer end
                # - the existing start_date <= start date
                # - the existing end_date >= end_date
                if ((query['tier'] == tier or query['tier'] == 'all') and
                   converters.get_tz_aware_datetime(query['queried_at']) > end_date + self.UPLOAD_PULL_BUFFER_AFTER and
                   converters.get_tz_aware_datetime(query['start_date']) <= start_date and
                   converters.get_tz_aware_datetime(query['end_date']) >= end_date):
                    download_required = False
                    break
        return download_required

    def _get_new_files_to_parse(self, log_directory, log_type, tier, start_date, end_date):
        """
        Answers the question: given the data I want, what I have downloaded,
        and the files I have already parsed, what new files do I need to parse?

        :param log_directory: directory where parse-able log files have been placed
        :param tier: tier to which the device is paired
        :param start_date: earliest data the requester wants returned
        :param end_date: latest data the requested wants returned
        :rtype: list of filepaths
        """
        new_files_to_parse = []
        # if query is malformed, do not attempt parse
        # this allows loading whatever is available by other means (directoried logs)
        if tier is None or start_date is None or end_date is None:
            pass
        else:
            files_to_parse = self._get_files_to_parse_in_directory(log_directory, log_type, start_date, end_date)
            if 'source_files' in self.metadata:
                meta_source_filenames = [os.path.basename(filepath) for filepath in
                                         self.metadata['source_files'].keys()]
                new_files_to_parse = [filepath for filepath in files_to_parse if
                                      os.path.basename(filepath) not in meta_source_filenames]
            else:
                new_files_to_parse = files_to_parse
        return new_files_to_parse

    @staticmethod
    def _get_files_to_parse_in_directory(directory_name, log_type, start_date, end_date):
        """
        Returns a list logfiles that should be parsed from the specified directory

        :param directory_name: path to a directory containing logfiles
        :param start_date: as an optimization, reject logs uploaded some time before the target start date
        :param end_date: as an optimization, reject logs uploaded some time after the target end date
        :rtype: list of filepaths to parse
        """
        if start_date:
            start_date = converters.get_tz_aware_datetime(start_date)

        if end_date:
            end_date = converters.get_tz_aware_datetime(end_date)

        filenames = sorted(os.listdir(directory_name))
        files = [os.path.join(directory_name, filepath) for filepath in filenames]
        files_to_parse = []
        for filename in files:
            if filename.find(log_type) == -1:  # skip files like .DS_Store, or possibly directoried logs
                continue
            # possible optimization: do not parse raw logs that are unlikely to
            # contain data in the requested time range.  This policy was used for
            # Topaz but is currently disabled for general Device Histories.
            # #filetime = extract_upload_time_from_filename(filename)
            ##if  start_date is not None and filetime < start_date - UPLOAD_PULL_BUFFER or \
            ##    end_date is not None and filetime > end_date + UPLOAD_PULL_BUFFER:
            ##    continue
            files_to_parse.append(filename)

        return files_to_parse

    @staticmethod
    def _extract_upload_time_from_filename(filename):
        """
        Extract the upload time from the S3 filename, for example:
            topazevent_18b43000001e84ee-2013-07-17T04-53-14.149Z-v1-id32e689.log

        :param filename: Name of the Topaz logfile S3
        """
        try:
            f = os.path.split(filename)[1]
            d = datetime.datetime.strptime(string.join(f.rsplit('-', 7)[1:6], '-'), "%Y-%m-%dT%H-%M-%S.%fZ").replace(
                tzinfo=pytz.utc)
        except ValueError:
            logger.warn('Could not extract upload time from filename: %s', filename)
            d = None
        return d

    def _post_download_step(self):
        pass

    def _post_parse_step(self):
        pass

    def _post_load_step(self):
        pass

    # This should go elsewhere or be combined with other functions.
    def _load_event_log(self, filename,
                       event_name=None,
                       start_date=None,
                       end_date=None,
                       sort_by_time=True,
                       append=False):
        """
        Loads the specified event log into the device history.

        :param filename:
            the name of the parsed event file to load.
        :type filename:
            str

        :param event_name:
            the name of the event. If not specified, the base filename will be
            used as the event name.
        :type event_name:
            str

        :param start_date:
            the earliest date/time to include. If not specified, all data up
            to end_date will be included.
        :type start_date:
            datetime.datetime

        :param end_date:
            the latest date to include. If not specified, all data past
            start_date will be included.
        :type end_date:
            datetime.datetime

        :param sort_by_time:
            whether to sort the events by time.
        :type sort_by_time:
            bool

        :param append:
            whether to append new event data to existing data instead of
            overwriting it.
        :type append:
            bool
        """

        if not event_name:
            event_name = basename(filename)

        # Ignore the EMRParsingErrors log file.
        if "EMRParsingErrors" in event_name:
            return

        dataframe = eventlog.parse_directoried_event_log(filename,
                                                         start_date=start_date,
                                                         end_date=end_date,
                                                         sort_by_time=sort_by_time)

        self.add_event_data(event_name, dataframe)
