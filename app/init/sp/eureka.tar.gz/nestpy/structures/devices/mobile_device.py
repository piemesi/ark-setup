from ..device import Device


class MobileDevice(Device):
    pass
