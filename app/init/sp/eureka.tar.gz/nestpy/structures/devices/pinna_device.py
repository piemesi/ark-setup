from ..device import Device


class PinnaDevice(Device):
    pass
