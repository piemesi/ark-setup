from ..device import Device


class TopazDevice(Device):

    def __init__(self, mac_address, structure_id=None):
        super(TopazDevice, self).__init__(device_id=mac_address, structure_id=structure_id)
