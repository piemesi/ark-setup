from ..device import Device


class QuartzDevice(Device):
    pass
