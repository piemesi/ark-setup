from ..device import Device


class FlintstoneDevice(Device):
    pass
