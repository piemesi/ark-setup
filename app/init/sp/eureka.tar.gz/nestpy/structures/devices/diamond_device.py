from ..device import Device


class DiamondDevice(Device):

    def __init__(self, mac_address, structure_id=None):
        super(DiamondDevice, self).__init__(device_id=mac_address, structure_id=structure_id)
