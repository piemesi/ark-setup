import datetime
import logging
import numpy as np
import pandas as pd

from .. import converters
from .device_history_io import DeviceHistoryIO

logger = logging.getLogger(__name__)


class DeviceHistory(DeviceHistoryIO):
    """
    A generic class that encapsulates device history data. Each product type
    should subclass this object.
    """

    def __init__(self, unique_device_id="Unknown", temperature_unit="C"):

        super(DeviceHistory, self).__init__(unique_device_id)

        self.temperature_unit = temperature_unit
        self.downsampling_enabled = False
        self.in_local_time = None

    def compute_durations(self, event_types=None, name_of_new_column='duration', allow_overwrite=False):
        """Adds a duration column to each event's dataframe.

        The duration is computed as the time until next change:
            dt = [diff(t); NaN]

        :param event_types: the event types for which to compute durations. If not specified, all event types will be
            computed.
        :type event_types: list of str

        :param name_of_new_column: name of the column in which to place the computed duration
        :type name_of_new_column: str

        :param allow_overwrite: if False, throw an error if 'duration' column already exists (the default). Otherwise,
            silently overwrite any existing values.
        :type allow_overwrite: bool

        :returns: the device history, with added columns.
        :rtype: nestpy.DeviceHistory
        """

        if not event_types:
            event_types = list(self.events)
        for event_type in event_types:
            event_data = self.__dict__[event_type]

            if len(event_data) == 0:
                # No data in this event - do not add the empty column.
                continue
            if not allow_overwrite and name_of_new_column in event_data:
                raise ValueError("not allowed to overwrite existing column '%s' in '%s'" %
                                 (name_of_new_column, event_type))
            event_data['t'] = event_data.index
            event_data[name_of_new_column] = (event_data['t'].shift(-1) - event_data['t'])
            # note: it appears that these operations on event_data act on 'self' already
            # so no need to commit new event_data to 'self'?
        return self

    # general accessor functions that deal with this specific device's log style
    def get_temperature(self):
        return None

    def get_humidity(self):
        return None

    def get_occupancy(self):
        return None

    def to_timezone(self, timezone, event_types=None, timestamp_fields=None):
        """
        Adjusts all data in this device history to the specified time zone.

        The adjustment is performed in-place; the returned DeviceHistory
        reflects the time zone adjustments.

        :param timezone: The time zone to set events to.
        :type timezone: pytz.timezone
        :param event_types: The event types to convert to local time. If not specified, all event types will be
            converted.
        :type event_types: list of str
        :param timestamp_fields: The timestamp fields with corresponding event types.
        :type timestamp_fields: dict
        :returns: The device history, adjusted to local time.
        :rtype: nestpy.DeviceHistory
        """
        def timestamp_as_timezone(_timestamp, _timezone):
            try:
                _timestamp = _timestamp.astimezone(_timezone)
            except AttributeError:
                pass
            return _timestamp

        if not event_types:
            event_types = list(self.events)

        # Reset time range
        self.earliest_date = None
        self.latest_date = None

        for event_type in event_types:
            if event_type in self:
                event_data = self.__dict__[event_type]
                if len(event_data) == 0:
                    continue
                updated_event_data = event_data.tz_convert(str(timezone))
                if timestamp_fields is not None and event_type in timestamp_fields:
                    for field in timestamp_fields[event_type]:
                        if field in updated_event_data.columns:
                            timestamps = updated_event_data[field].values
                            updated_event_data[field] = [
                                timestamp_as_timezone(timestamp, timezone)
                                if timestamp is not np.nan else timestamp
                                for timestamp in timestamps
                            ]
                self.add_event_data(event_type, updated_event_data)

        return self

    def convert_temperature_unit(self, event_types=None, temperature_fields=None, temperature_unit="C"):
        """
        Converts temperature data in this device history to a specified
        temperature unit.

        The adjustment is performed in-place; the returned DeviceHistory
        reflects the temperature conversions.

        :param event_types: The event types containing temperature columns to be converted.
        :type event_types: list of str
        :param temperature_fields: The temperature fields with corresponding event types.
        :type temperature_fields: dict
        :param temperature_unit: Temperature unit to convert temperatures to.
        :type temperature_unit: {"C","F"}
        :returns: The device history, reflecting the temperature conversions.
        :rtype: nestpy.DeviceHistory
        """

        if self.temperature_unit == temperature_unit:
            logger.info("Temperatures are already in '%s'" % self.temperature_unit)
        else:

            if temperature_unit == "C":
                converter = converters.f2c
            elif temperature_unit == "F":
                converter = converters.c2f
            else:
                raise ValueError("'%s' is not a valid temperature unit" % temperature_unit)

            if not event_types:
                event_types = list(self.events)

            for event_type in temperature_fields.keys():
                if event_type in event_types and event_type in self.__dict__:
                    event_data = self.__dict__[event_type]
                    if len(event_data) == 0:
                        continue
                    for field in temperature_fields[event_type]:
                        if field in event_data.columns:
                            event_data[field] = event_data[field].apply(converter)

                    self.add_event_data(event_type, event_data)

            self.temperature_unit = temperature_unit

        return self

    def index_by_sample_time(self, event_types=None, sort_by_time=False, sample_time_fields=None):
        """
        Reindex events using a different column as the index instead of the upload time.
        The new index must be a tz aware time object

        The adjustment is performed in-place; the returned DeviceHistory
        reflects the new indices

        :param event_types: The event types to be reindexed if sample time available. If not specified, all event types
            will be converted.
        :type event_types: list of str
        :param sample_time_fields: The sample time fields with corresponding event types.
        :type sample_time_fields: dict
        :param sort_by_time: Whether to sort the events by time.
        :type sort_by_time: boolean

        :returns: the DeviceHistory, with updated indices
        :rtype: nestpy.DeviceHistory
        """

        if not event_types:
            event_types = list(self.events)

        for event_type in sample_time_fields.keys():
            if event_type in event_types and event_type in self:
                event_data = self.__dict__[event_type]
                if len(event_data) == 0:
                    continue
                for field in sample_time_fields[event_type]:
                    if field in event_data.columns:
                        tz = event_data.index.tz
                        index = pd.DatetimeIndex(event_data[field].values, tz=tz)
                        event_data = event_data.set_index(index)

                self.add_event_data(event_type, event_data, sort_by_time=sort_by_time)

        return self

    def get_build_from_metadata(self, start_date, end_date=None):
        """
        Query the metadata to find the build for a given date. If only a start date is provided,
        the query will return a single value of the most likely build date for that value based on log upload times.
        If a start and end date are provided, it will return a list of all builds present during that period.
        """
        if 'metadata' in self and 'source_files' in self.metadata:
            df = pd.DataFrame.from_dict(self.metadata['source_files'], orient='index')
            df.index = pd.to_datetime(df.filetime)
            df = df.tz_localize('UTC').sort()

            before_start = df[:start_date]
            after_start = df[start_date:]

            if len(before_start) > 0:
                start_build = before_start.description.values[-1]
            elif len(after_start) > 0:
                start_build = after_start.description.values[0]
            else:
                return None

            if end_date is not None:
                builds = list(after_start[:end_date].description.unique())
                if start_build not in builds:
                    builds.append(start_build)
                builds.sort()
                return builds

            else:
                return start_build

        else:
            return None
