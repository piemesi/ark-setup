from .device_group import DeviceGroup
from ..sql import lookup_devices


class DeviceGroupLookup(DeviceGroup):
    """
    Manages and looks up meta data for multiple cross-platform devices.

    Can be called with a list of arbitrary devices, containing either mac addresses or serial numbers. The backend
    then does a database lookup to find the corresponding device meta data and stores this in an internal and
    immutable data frame.

    >>> import nestpy

    Example:

    >>> dg = nestpy.DeviceGroupLookup(['01AA02AB25120346','18b4302a28da','05CA02AC52130BH6'])

    >>> dg
    <nestpy.DeviceGroupLookup with 3 devices (1 diamond, 1 topaz, 1 j49)>

    >>> dg.devices
          serial_number       mac_address device_type structure_id        tier
    0  01AA02AB25120346      18b430047f40     diamond       364332  production
    1  02AA01AC511302CM      18b4302a28da         j49       252309  production
    2  05CA02AC52130BH6  18b43000002366e5       topaz       863986  production

    >>> dg['18b430047f40']
    serial_number    01AA02AB25120346
    mac_address          18b430047f40
    device_type               diamond
    structure_id               364332
    tier                   production
    Name: 0, dtype: object
    """

    def __init__(self, devices):

        super(DeviceGroupLookup, self).__init__(lookup_devices(devices))

    def __repr__(self):

        if not self.devices.empty:
            device_type_counts = self.devices.device_type.value_counts()
            device_type_counts_str = ", ".join(["{} {}".format(device_type_counts[device_type], device_type)
                                                for device_type in device_type_counts.index.values])
            output = "<nestpy.DeviceGroupLookup with {} devices ({})>".format(len(self.devices), device_type_counts_str)
        else:
            output = "<nestpy.DeviceGroupLookup>"

        return output