import pandas as pd


class DeviceGroup(object):
    """
    Manages meta data for multiple cross-platform devices.

    Can be called with a list of mac addresses or a pandas data frame, containing a column named 'mac_address'.
    This metadata is then stored in an internal and immutable data frame.

    >>> import nestpy

    Example:

    >>> dg = nestpy.DeviceGroup(['18b430047f40', '18b4302a28da', '18b43000002366e5'])

    >>> dg
    <nestpy.DeviceGroup with 3 devices>

    >>> dg.devices
            mac_address
    0      18b430047f40
    1      18b4302a28da
    2  18b43000002366e5

    >>> dg['18b430047f40']
    mac_address    18b430047f40
    Name: 0, dtype: object
    """

    MAC_ADDRESS = 'mac_address'

    def __init__(self,
                 devices):

        self.devices = None
        self._add_devices(devices)

    def __repr__(self):

        if not self.devices.empty:
            output = "<nestpy.DeviceGroup with {} devices>".format(len(self.devices))
        else:
            output = "<nestpy.DeviceGroup>"

        return output

    def __getitem__(self, key):
        return self._get_device(key)

    def __setitem__(self, key, value):
        raise NotImplementedError("DeviceGroups are immutable")

    def __delitem__(self, key):
        raise NotImplementedError("DeviceGroups are immutable")

    def __iter__(self):
        return iter(self.devices.iterrows())

    def __len__(self):
        return len(self.devices)

    def _get_device(self, key):

        if isinstance(key, int):
            return self.devices.loc[key]
        elif isinstance(key, str):
            if key in self.devices.mac_address.values:
                return self.devices[self.devices.mac_address == key].iloc[0]

        raise ValueError("Invalid key '{}' provided. Try specifying an index or mac address".format(key))

    def _add_devices(self, devices):

        if self.devices is not None:
            raise NotImplementedError("DeviceGroup is immutable and already contains {} devices"
                                      .format(len(self.devices)))

        if isinstance(devices, pd.DataFrame):
            if self.MAC_ADDRESS not in devices.columns:
                raise ValueError("Specified devices data frame is missing a '{}' column".format(self.MAC_ADDRESS))
            self.devices = devices
        else:
            self.devices = pd.DataFrame(devices, columns=[self.MAC_ADDRESS])
