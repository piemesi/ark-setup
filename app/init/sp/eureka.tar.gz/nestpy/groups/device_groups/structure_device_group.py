from nestpy import DeviceGroup
import pandas
from pandas.util.testing import assert_frame_equal


class StructureDeviceGroup(DeviceGroup):
    """A DeviceGroup which supports loading and using device data for a single Structure

    Supports Nest structures on multiple tiers, Hiddenite structures, and any other future device types.

    Note that the implementation of assumes that all data for an individual structure can fit in
    memory. It is intended for use in building multi-sensor models for use in applications such as GOOSE.
    """
    TZINFO_COLUMN = "tzinfo"

    def __eq__(self, other):
        return (isinstance(other, self.__class__)
                and self._devices_equal(other))

    def _devices_equal(self, other):
        try:
            assert_frame_equal(self.devices, other.devices)
            return True
        except (AssertionError, ValueError, TypeError):
            return False

    def get_timezone(self):
        return self._single_value_or_none(self.TZINFO_COLUMN)

    def subset_view(self, unique_device_identifiers):
        """
        Creates a new StructureDeviceGroup based on a subset of devices.

        :param unique_device_identifiers: a list of unique_device_identifiers to include in the subset view
        :return: a new StructureDeviceGroup, which has a DataFrame view including only the subset of devices requested
        """
        device_subset = self.devices[self.devices.unique_device_id.isin(unique_device_identifiers)]
        new_subset_device_group = StructureDeviceGroup(device_subset)
        return new_subset_device_group

    def filter_by_class_name(self, device_class_name):
        return self.devices[self.devices.device_class_name == device_class_name]

    def write(self, path):
        """Serialize the StructureDeviceGroup to the given path"""
        self.devices.to_pickle(path)

    @classmethod
    def read(cls, path):
        """Deserialize the StructureDeviceGroup from the given path"""
        devices = pandas.read_pickle(path)
        structure_device_group = cls(devices)
        return structure_device_group

    def _single_value_or_none(self, column):
        if not self.devices.empty:
            unique_values = self.devices[column].unique()
            if len(unique_values) != 1:
                raise ValueError("Found more than one unique value for column %s" % column)

            return unique_values[0]
        return None

    def get_earliest_date(self):
        earliest_date = self.devices.apply(lambda device: device.device_history.earliest_date, axis=1).min()
        return earliest_date

    def get_latest_date(self):
        latest_date = self.devices.apply(lambda device: device.device_history.latest_date, axis=1).max()
        return latest_date

