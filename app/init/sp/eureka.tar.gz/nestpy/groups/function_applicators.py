import functools

from ..scriptutils import parallelize
from ..structures import get_structure

REQUIRED_METADATA = ['mac_address', 'device_type', 'tier']


def parallel_function_applicator(iterable, function, threads=10):
    """
    Parallel apply function to an iterable object

    :param iterable:
        Iterable to apply the function to
    :type iterable:
        iterable

    :param function:
        Function to be applied to the iterable
    :type function:
        function

    :param threads:
        Number of parallel threads
    :type threads:
        int

    :return:
        List containing tuples with the arguments and the results
    :rtype:
        list
    """
    return parallelize(list(iterable),
                       threads,
                       function)


def serial_function_applicator(iterable, function):
    """
    Serial apply function to an iterable object

    :param iterable:
        Iterable to apply the function to
    :type iterable:
        iterable

    :param function:
        Function to be applied to the iterable
    :type function:
        function

    :return:
        List containing tuples with the arguments and the results
    :rtype:
        list
    """
    results = []
    for arg in iterable:
        result = function(arg)
        results.append((arg, result))
    return results


def _device_function_applicator(arg, function):
    return function(arg[1])


def _device_group_function_applicator(dg, function, function_applicator):
    return function_applicator(dg, functools.partial(_device_function_applicator, function=function))


def serial_device_group_function_applicator(dg, function):
    """
    Serial apply a function to the metadata of the devices in a device group

    :param dg:
        Device group
    :type iterable:
        nestpy.DeviceGroup

    :param function:
        Function to be applied to the devices' metadata
    :type function:
        function

    :return:
        List containing tuples with the arguments and the results
    :rtype:
        list
    """
    return _device_group_function_applicator(dg, function, serial_function_applicator)


def parallel_device_group_function_applicator(dg, function, threads=10):
    """
    Parallel apply a function to the metadata of the devices in a device group

    :param dg:
        Device group
    :type iterable:
        nestpy.DeviceGroup

    :param function:
        Function to be applied to the devices' metadata
    :type function:
        function

    :param threads:
        Number of parallel threads
    :type threads:
        int

    :return:
        List containing tuples with the arguments and the results
    :rtype:
        list
    """
    function_applicator = functools.partial(parallel_function_applicator, threads=threads)
    return _device_group_function_applicator(dg, function, function_applicator)


def device_history_loader(device, **kwargs):
    """
    Load a device history for based on device metadata

    :param device:
        Device metadata
    :type device:
        pandas.Series

    :return:
        Device history
    :rtype:
        nestpy.DeviceHistory
    """
    for metadata in REQUIRED_METADATA:
        if metadata not in device.index:
            raise ValueError("Device metadata is missing a required '{}' field".format(metadata))
    structure = get_structure(device.device_type)
    return structure.load(device.mac_address, tier=device.tier, **kwargs)