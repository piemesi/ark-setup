from pandas import DataFrame

from ..structures.device_histories.hiddenite import Hiddenite
from .device_groups.structure_device_group import StructureDeviceGroup

import logging
logger = logging.getLogger(__name__)


class StructureDeviceGroupBuilder(object):
    """Provides different builders to create a StructureDeviceGroup."""

    @classmethod
    def from_device_list(cls, device_list, characteristics=None):
        """Builds a DeviceGroup from an existing Structure object.

        :param device_list: a list of `DeviceHistory` objects
        :param characteristics: characteristics to be appended to all device records
        :return: a StructureDeviceGroup instance.
        """
        if characteristics is None:
            characteristics = {}
        elif type(characteristics) != dict:
            raise ValueError("Characteristics must be a dictionary.")

        devices = cls._build_devices_frame(device_list)
        return cls._build_from_devices_and_characteristics(devices, characteristics)

    @classmethod
    def from_structure(cls, structure):
        """Builds a DeviceGroup from an existing Structure object.

        :param structure: a `nestpy.structures.structure.Structure` instance.
        :return: a StructureDeviceGroup instance.
        """
        device_list = structure.Diamond + structure.Topaz
        return cls.from_device_list(device_list, {"tzinfo": structure.get_timezone()})

    @classmethod
    def from_structure_and_hiddenite_structure_device_list(cls,
                                                           tzinfo,
                                                           hiddenite_structure_id,
                                                           device_list):
        """Builds a DeviceGroup from a list of Diamond, Topaz, and Hiddenite devices. Params tzinfo and
        hiddenite_structure_id are metadata for the DeviceGroup.

        :param tzinfo: timezone of the structure.
        :param hiddenite_structure_id: a hiddenite structure id, used to load Hiddenite data from logs.
        :param device_list: a list of Diamond, Topaz, and Hiddenite devices.
        :return: a StructureDeviceGroup instance.
        """
        characteristics = {"tzinfo": tzinfo, "hiddenite_structure_id": hiddenite_structure_id}
        return cls.from_device_list(device_list, characteristics)

    @classmethod
    def _build_from_devices_and_characteristics(cls, devices, characteristics):
        for key, value in characteristics.iteritems():
            devices[key] = value
        structure_device_group = StructureDeviceGroup(devices)
        return structure_device_group

    @staticmethod
    def _build_devices_frame(device_list):

        devices_dict = []

        for device in device_list:

            devices_dict.append(
                {
                    "unique_device_id": device.unique_device_id,
                    "mac_address": device.mac_address,
                    "serial_number": device.serial_number,
                    "device_type": device.device_type,
                    "device_class": type(device),
                    "device_class_name": type(device).__name__,
                    "structure_id": device.structure_id,
                    "tier": device.tier,
                    "device_history": device
                })

        devices = DataFrame(devices_dict)
        return devices
