"""
A JSON wrapper for a single device's information.
"""

import json

class Device(object):
    """
    Encapsulates a device configuration, as received from CZ.

    Based on keys in ``nlczbucket.h``.
    """

    _SERIAL_NUMBER          = "serial_number"
    _MAC_ADDRESS            = "mac_address"
    _AWAY_TEMP_LOW_ENABLED  = "away_temperature_low_enabled"
    _AWAY_TEMP_LOW          = "away_temperature_low"
    _AWAY_TEMP_HIGH_ENABLED = "away_temperature_high_enabled"
    _AWAY_TEMP_HIGH         = "away_temperature_high"
    _HVAC_PINS              = "hvac_pins"
    _POSTAL_CODE            = "postal_code"

    def __init__(self, config):
        """
        Initializes a new device with the specified configuration.
        """

        if isinstance(config, dict):
            self._config = config
        else:
            self._config = json.loads(config)

    def get_serial_number(self):
        if self._SERIAL_NUMBER not in self._config:
            return None

        return str(self._config[self._SERIAL_NUMBER])

    def get_mac_address(self):
        if self._MAC_ADDRESS not in self._config:
            return None

        return str(self._config[self._MAC_ADDRESS])

    def is_heating_away_enabled(self):
        if self._AWAY_TEMP_LOW_ENABLED not in self._config:
            return None

        return bool(self._config[self._AWAY_TEMP_LOW_ENABLED])

    def get_heating_away_temp(self):

        if not self.is_heating_away_enabled():
            return "Off"

        if self._AWAY_TEMP_LOW not in self._config:
            return None

        return self._config[self._AWAY_TEMP_LOW]

    def is_cooling_away_enabled(self):
        if self._AWAY_TEMP_HIGH_ENABLED not in self._config:
            return None

        return bool(self._config[self._AWAY_TEMP_HIGH_ENABLED])

    def get_cooling_away_temp(self):

        if not self.is_cooling_away_enabled():
            return "Off"

        if self._AWAY_TEMP_HIGH not in self._config:
            return None

        return self._config[self._AWAY_TEMP_HIGH]

    def get_hvac_pins(self):
        """
        :rtype: list of detected HVAC pins=
        """

        if self._HVAC_PINS not in self._config:
            return None

        return self._config[self._HVAC_PINS].split(',')

    def has_y1_or_y2_wires(self):
        pins = self.get_hvac_pins()

        if not pins:
            return None

        return 'Y1' in pins or 'Y2' in pins

    def has_ob_wire(self):
        pins = self.get_hvac_pins()

        if not pins:
            return None

        return 'OB' in pins

    def is_away_enabled(self):
        return self.is_heating_away_enabled() and self.is_cooling_away_enabled()

    def get_postal_code(self):

        if self._POSTAL_CODE not in self._config:
            return None

        return str(self._config[self._POSTAL_CODE])
