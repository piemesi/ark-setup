
import logging
logger = logging.getLogger(__name__)


def log_parameters(func):
    """
    Decorator for logging function parameters.
    """
    def inner(*args, **kwargs):
        name = func.__name__
        logger.debug("Function %s parameters: %s", name, args)
        logger.debug("Function %s keyword parameters: %s", name, kwargs)
        return func(*args, **kwargs)
    return inner
