def check_lock(function):
    def wrapper(self, *args, **kwargs):
        assert not self.is_locked(), "Illegal operation. This object is immutable."
        function(self, *args, **kwargs)
    return wrapper
