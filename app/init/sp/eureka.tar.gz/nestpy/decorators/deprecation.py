import warnings

class deprecated(object):
    """
    A decorator for marking a function as deprecated.
    """

    def __init__(self, message=""):
        """Initializes a deprecation decorator.
        :param message: The message to be displayed in the log.
        """
        self.message = message

    def __call__(self, f):
        """
        If there are decorator arguments, __call__() is only called
        once, as part of the decoration process! You can only give
        it a single argument, which is the function object.

        """

        def wrapped_f(*args, **kwargs):
            message = "Call to deprecated nestpy function {}. Details: {}".format(f.__name__, self.message)
            warnings.warn(message, DeprecationWarning)
            return f(*args, **kwargs)

        return wrapped_f

