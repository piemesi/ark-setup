import logging
import os
import pickle
from datetime import datetime
from functools import wraps

from .. import env

logger = logging.getLogger(__name__)


class cache_with_name(object):

    def __init__(self, cache_namespace):
        self.namespace = cache_namespace

    def __call__(self, f):

        def wrapped_f(*args, **kwargs):
            path = os.path.join(env.cache_destination(), "%s_%s" % (f.__name__, self.namespace))

            if os.path.exists(path):
                logger.debug("Loading results from cache: %s", path)
                return pickle.load(open(path, 'r'))

            value = f(*args, **kwargs)
            with open(path, 'wb') as pickle_file:
                logger.debug("Writing results to cache: %s", path)
                pickle.dump(value, pickle_file)

            return value

        return wrapped_f


class day_cache(cache_with_name):

    def __init__(self):
        super(day_cache, self).__init__(datetime.today().strftime("%Y-%m-%d"))


def _ensure_path(*dirs, **kwargs):
    path = ''
    for dir in dirs:
        path = os.path.join(path, dir)
        if not os.path.exists(path):
            os.makedirs(path)
    return os.path.join(path, kwargs.pop('file_name', ''))


def custom_key_cache(key='', redo=False):
    key_ = key
    def _cache(func):
        @wraps(func)
        def wrapped(*args, **kwargs):
            key = str(kwargs.pop('cache_key', '') or str(hash((func.func_name, args))))
            path = _ensure_path(
                env.cache_destination(),
                key_ or func.func_name,
                kwargs.pop('cache_directory', ''),
                file_name=key
            )
            if not redo and os.path.exists(path):
                logger.debug("Loading results from cache: %s", path)
                return pickle.load(open(path, "rb"))
            else:
                logger.debug("Writing results to cache: %s", path)
                result = func(*args, **kwargs)
                pickle.dump(result, open(path, 'w+'))
                return result
        return wrapped
    return _cache


