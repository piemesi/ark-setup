import os


def requires_s3(method):

    def f(*args, **kw):
        if not os.path.exists(os.path.expanduser("~/.s3cfg")) and not os.path.exists(os.path.expanduser("~/.aws/credentials")):
            raise Exception("Cannot download data without an S3 configuration.")

        return method(*args, **kw)

    return f
