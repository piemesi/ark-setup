"""Logging utilities for `nestpy`.

`nestpy` currently supports two log approaches:

1. Standard logging, using module-level loggers and standard Python log configuration support. In this case,
log handlers must be managed by applications, with a common `nestpy` function for initializing loggers
using a configuration file.

Additionally, standard `nestpy` loggers have a `trace` log level.

Example usage of standard `nestpy` logging:
>>> logger = logging.getLogger(__name__)
>>> configure()  # Handy configuration loading for legacy applications.
>>> logger.info("Normal info level logging.")
>>> logger.trace("Custom trace log.")

2. Legacy singleton logger, which used a shared Eureka logger. For this logger, log handler configuration will
continue to be set up by default. However, it will be deprecated and removed at a future date.

Example usage of the legacy singleton logger:
>>> from nestpy.logger import get_logger
>>> logger = get_logger()
>>> logger.info("Log things using the singleton")

Eureka log configuration.

For Python logging configuration specs, see:
https://docs.python.org/2/library/logging.config.html#logging-config-fileformat
"""
import json
from logging import config
import logging
import multiprocessing

from .decorators import deprecated
from .fileutils import resource_path

LOG_DICT_CONFIG_FILE = resource_path("logging_config.json")

# Set up a "trace" logging function, below DEBUG, which is at level 10.
# See https://docs.python.org/2/library/logging.html#logging-levels
TRACE_LOG_LEVEL_NUM = 5
logging.addLevelName(TRACE_LOG_LEVEL_NUM, "TRACE")


class NestLogger(logging.Logger):
    """Nest logger, which supports trace level logging."""

    def trace(self, message, *args, **kws):
        """Trace level logging for `nestpy`.

        Additionally, standard `nestpy` loggers have a `trace` log level. For example:

        >>> logger = logging.getLogger(__name__)
        >>> logger.trace("This is a trace log.")
        """
        # Yes, logger takes its '*args' as 'args'.
        if self.isEnabledFor(TRACE_LOG_LEVEL_NUM):
            self._log(TRACE_LOG_LEVEL_NUM, message, args, **kws)

logging.setLoggerClass(NestLogger)


def configure(config_dict={}, config_json_file=LOG_DICT_CONFIG_FILE):
    """Configure loggers for individual modules.

    For ease of use and to facilitate a faster migration, `nestpy` includes a default configuration file. Note that
    applications will sometimes want to override the default log configuration. In these cases, a custom log
    configuration file may be used OR manual overrides may be set using the logging library.

    For example:
    >>> from nestpy import logger
    >>> logger.configure()

    For Python logging configuration specs, see:
    https://docs.python.org/2/library/logging.config.html#logging-config-fileformat

    For a comprehensive example configuration example (though not in dictionary form), see:
    http://www.red-dove.com/python_logging.html

    :param config_dict: Dictionary of log configuration.
    :param config_json_file: Python log configuration file.
    """
    config.dictConfig(json.load(open(config_json_file)))

    config_dict["incremental"] = True
    config_dict["version"] = 1
    config.dictConfig(config_dict)
