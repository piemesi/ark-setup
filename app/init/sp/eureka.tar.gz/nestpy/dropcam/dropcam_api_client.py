import json
import logging
import os
import sys
import traceback

import getpass
import requests
from requests.auth import HTTPBasicAuth
from requests.utils import dict_from_cookiejar

logger = logging.getLogger(__name__)

class DropCamAPIClient(object):
    # Store json dict caches in home dir
    COOKIE_CACHE = os.getenv("HOME") + '/.dropcam_cookie_cache'

    API_SERVER_BASE = "https://www.dropcam.com"
    HTTP_PASSWORD = "piggy1"
    CLIPS_SERVER_BASE = "https://clips.dropcam.com/s3"
    HTTP_BASICAUTH_USER = 'dropcam'
    HTTP_BASICAUTH_PASSWORD = 'fr@nkyth'

    _training_data = None

    @classmethod
    def get_training_data(cls):
        if getattr(cls, '_training_data', None) is None:
            training_data = cls.load_training_data()
            cls._training_data = training_data
        return cls._training_data

    @classmethod
    def load_training_data(cls, base_url=API_SERVER_BASE, http_password=HTTP_PASSWORD):
        logging.info('Loading all clip requests from DropCam service into memory.')
        cookies = cls.get_admin_cookiejar(base_url, http_password)
        headers = {'Referer': base_url}
        auth = HTTPBasicAuth('dropcam', http_password) if http_password else None
        try:
            url = '{0}/api/videos.get_training_data'.format(base_url)
            response = requests.get(url, cookies=cookies, headers=headers, auth=auth)
            response.raise_for_status()
            json_data = response.json()
            assert json_data['status'] != 403
            assert 'items' in json_data
        except AssertionError:
            cls.bad_auth()
            sys.stderr.write('Authentication expired. Re-run to refresh authentication')
        return json_data['items']

    @classmethod
    def get_training_data_with_matching_notes(cls, notes={}):
        all_items = cls.get_training_data()
        matching_items = []
        for item in all_items:
            try:
                item_notes = json.loads(item['notes'])
                # check all requested notes are contained in the item's notes
                if not [k for (k, v) in notes.items() if item_notes.get(k) != v]:
                    matching_items.append(item)
            except ValueError:
                # not all notes are valid json.
                continue
        return matching_items

    @classmethod
    def get_approved_clip_url(cls, requestID):
        clipUrl = None
        items = cls.get_training_data_with_matching_notes(notes={'requestID':requestID})
        if len(items) == 1 and 'filename' in items[0]:
            clipUrl = '{0}/{1}'.format(cls.CLIPS_SERVER_BASE, items[0]['filename'])
        return clipUrl

    @classmethod
    def save_to_file(cls, stuff_to_save, fname):
        with open(fname, 'w') as outfile:
            outfile.write(json.dumps(stuff_to_save))
        logger.info("NOTICE: Your dropcam session token has been saved in {0}\n".format(cls.COOKIE_CACHE))

    @staticmethod
    def load_from_file(fname):
        try:
            with open(fname) as infile:
                return json.loads(infile.read())
        except Exception:
            pass
        return None

    @classmethod
    def get_admin_cookiejar(cls, base_url, http_password=None):
        """ Use a cached cookiejar if available, else prompt the user to log in """
        cookiejar = cls.load_from_file(cls.COOKIE_CACHE)
        if not cookiejar:
            cookiejar = cls.admin_login(base_url, http_password)
            cls.save_to_file(cookiejar, cls.COOKIE_CACHE)
        return cookiejar

    @classmethod
    def admin_login(cls, base_url, http_password):
        auth = HTTPBasicAuth('dropcam', http_password) if http_password else None
        with requests.session() as c:
            login_data = cls.login_prompt()

            c.post('{0}/api/login.login'.format(base_url), data=login_data, auth=auth)
            c.post('{0}/api/login.mfa'.format(base_url), data=login_data, auth=auth)
            to_cache = dict_from_cookiejar(c.cookies)

            cookie_name = 'website_staging_2' if 'staging' in base_url else 'website_2'
            assert cookie_name in to_cache
            return to_cache

    @staticmethod
    def login_prompt():
        # TODO: use Eureka's credential manager than leverages keyring
        sys.stderr.write("Enter your Dropcam username: ")
        uname = raw_input('')
        sys.stderr.write("Password: ")
        passwd = getpass.getpass('')
        sys.stderr.write("MFA Token: ")
        code = raw_input('')
        return {'username': uname, 'password': passwd, 'code': code}

    @classmethod
    def bad_auth(cls):
        sys.stderr.write(traceback.format_exc())
        sys.stderr.write("Error querying admin API; Deleting {0}\n".format(cls.COOKIE_CACHE))
        os.remove(cls.COOKIE_CACHE)
        exit(1)

    @classmethod
    def request_clip(cls, cameraUUID, requestID, start, duration, clipType):
        cookies = cls.get_admin_cookiejar(cls.API_SERVER_BASE)

        clip = {
            'uuid': cameraUUID,
            'start_date': start,
            'duration': duration,
            'notes': json.dumps({'clipType': clipType, 'requestID': requestID})
        }

        try:
            head = {'Referer': cls.API_SERVER_BASE}
            json_response = requests.post('{0}/admin2/create_donor_clip/{1}'.format(cls.API_SERVER_BASE, cameraUUID),
                                          cookies=cookies,
                                          headers=head,
                                          data=clip,
                                          auth=HTTPBasicAuth(cls.HTTP_BASICAUTH_USER, cls.HTTP_BASICAUTH_PASSWORD))
            if json_response.status_code != 200:
                logger.warn(json_response.text)
                logger.warn('Could not submit request, error code %s' % json_response.status_code)
                if 'Unauthorized' in json_response.text:
                    raise Exception('Possible authentication failure')
                else:
                    return False
            else:
                return True
        except Exception:
            cls.bad_auth()
