"""General utilities for scripts."""
# pylint: disable=no-member,unexpected-keyword-arg
import argparse
from argparse import ArgumentParser as ArgumentParserBaseClass
from copy import deepcopy
import logging
from multiprocessing import Pool
import os
import sys
import random

from dateutil import parser
import numpy as np
import pandas as pd


logger = logging.getLogger(__name__)


if "DISABLE_MATPLOTLIB" not in os.environ:
    import matplotlib.pyplot as plt


def create_hexadecimal_str():
    """
    Creates a hexadecimal string of 30 characters.

    :return:
        Hexadecimal string
    :rtype:
        str
    """
    return '%030x' % random.randrange(16**30)


def yn_choice(message, default='y'):
    """
    Asks for a yes or no response to a message from the user
    through terminal input.

    :param message:
        the question to ask the user

    :param default:
        assumed response if user does not specify

    :rtype: boolean.
    """
    choices = 'Y/n' if default.lower() in ('y', 'yes') else 'y/N'
    choice = raw_input("%s (%s) " % (message, choices))
    values = ('y', 'yes', '') if default == 'y' else ('y', 'yes')
    return choice.strip().lower() in values


def flatten_list(nested_list):
    """Flatten an arbitrarily nested list, without recursion (to avoid
    stack overflows). Returns a new list, the original list is unchanged.

    :param nested_list:
        Nested list
    :type nested_list:
        list

    :returns:
        Flattened list
    :rtype:
        list
    """
    nested_list = deepcopy(nested_list)

    flattened_list = []

    while nested_list:
        sublist = nested_list.pop(0)

        if isinstance(sublist, list):
            nested_list = sublist + nested_list
        else:
            flattened_list += [sublist]

    return flattened_list


def expand_kwargs(**kwargs):
    """
    Expand argument lists.

    :param kwargs:
        Named arguments to expand (need to all have the same length or length 1)
    :type kwargs:
        kwargs

    :returns:
        List of dicts
    :rtype:
        list
    """
    return pd.DataFrame.from_dict(kwargs).to_dict('records')


def expand_device_arguments(values, key='device_id', **kwargs):
    """
    Expand an argument list based to match the length of the primary dimension.
    :param key: name for the primary key
    :param values: list of values for the primary dimension
    :param kwargs: named arguments to expand to the primary dimension
    :rtype: list of dicts
    """
    return [dict({key: value}.items() + kwargs.items()) for value in values]


def parallelize(parameter_list, threads, function_to_run):
    """
    Runs a function in parallel.

    :param parameter_list: list of arguments
    :param threads: number of concurrent threads
    :param function_to_run: pointer to the function to parallelize
    :rtype: list of tuples, (args, result)
    """

    def parallel(function):
        def wrapper(_):
            def apply_parallel(values):

                pool = Pool(threads)
                result = pool.map(function, values)
                pool.close()
                pool.join()
                return zip(values, result)

            return apply_parallel

        return wrapper

    # pylint: disable=unused-argument
    @parallel(function_to_run)
    def parallel_function(kwargs):
        pass
    # pylint: enable=unused-argument

    return parallel_function(parameter_list)


def weighted_average(series, interpolation_method="zero", start_time=None, end_time=None):
    """Compute the weighted average for a pandas Series object.

    :param series:
        Series (with numeric values)
    :type series:
        pandas.core.series.Series

    :param interpolation_method:
        Interpolation method
    :type interpolation_method:
        {'zero','time'}

    :param start_time:
        Start time for weighted average
    :type start_time:
        datetime.datetime or pandas.tslib.Timestamp

    :param end_time:
        End time for weighted average
    :type end_time:
        datetime.datetime or pandas.tslib.Timestamp

    :returns:
        Weighted average
    :rtype:
        float
    """
    if not isinstance(series, pd.Series):
        raise TypeError("Function only accepts pandas.core.series.Series format")
    if series.index.dtype.kind != "M":
        raise TypeError("'%s' is not a datetime format" % series.index.dtype.name)
    if series.dtype.kind not in ["b", "i", "u", "f", "c"]:
        raise TypeError("'%s' is not a numeric format" % series.dtype.name)
    if series.dtype.kind != "f":
        series = series.astype(float)
    series = set_timeframe(series,
                           interpolation_method=interpolation_method,
                           start_time=start_time,
                           end_time=end_time)
    if interpolation_method == "zero":
        values = series.values[:-1]
    elif interpolation_method == "time":
        values = (series.values[1:] + series.values[:-1]) / 2
    else:
        raise ValueError("'%s' is not a supported interpolation order" % interpolation_method)
    return np.average(values, weights=np.diff(series.index.asi8))


def set_timeframe(data, interpolation_method="zero", start_time=None, end_time=None, populate_boundary=True):
    """Set timeframe of a pandas Series or DataFrame object.

    :param data: 
        DataFrame or TimeSeries to set timeframe for.
    :type data:
        pandas.core.frame.DataFrame or pandas.core.series.Series

    :param interpolation_method:
        Interpolation method
    :type interpolation_method:
        pandas.core.series.Series.interpolate methods

    :param start_time:
        Start time for timeframe
    :type start_time:
        datetime.datetime or pandas.tslib.Timestamp

    :param end_time:
        End time for timeframe
    :type end_time:
        datetime.datetime or pandas.tslib.Timestamp

    :param populate_boundary:
        Whether or not to populate the boundaries
    :type populate_boundary:
        boolean

    :returns:
        DataFrame or TimeSeries with specified start time or end time
    :rtype:
        pandas.core.frame.DataFrame or pandas.core.series.Series
    """
    if not isinstance(data, pd.Series) and not isinstance(data, pd.DataFrame):
        raise TypeError("Function only accepts pandas.core.frame.DataFrame or pandas.core.series.Series format")
    if data.index.dtype.kind != "M":
        raise TypeError("'%s' is not a datetime format" % data.index.dtype.name)
    if start_time:
        if start_time in data.index or not populate_boundary:
            data = data[data.index >= start_time]
        else:
            boundary_value = create_boundary_value(data,
                                                   boundary_time=start_time,
                                                   interpolation_method=interpolation_method)
            data = pd.concat([boundary_value, data[data.index > start_time]])
    if end_time:
        if end_time in data.index or not populate_boundary:
            data = data[data.index <= end_time]
        else:
            boundary_value = create_boundary_value(data,
                                                   boundary_time=end_time,
                                                   interpolation_method=interpolation_method)
            data = pd.concat([data[data.index < end_time], boundary_value])
    return data


def create_boundary_value(data, boundary_time, interpolation_method="zero"):
    """Set timeframe of a pandas Series or DataFrame object.

    :param data: 
        DataFrame or TimeSeries.
    :type data:
        pandas.core.frame.DataFrame or pandas.core.series.Series

    :param boundary_time:
        Time for boundary value
    :type boundary_time:
        datetime.datetime or pandas.tslib.Timestamp

    :param interpolation_method:
        Interpolation method
    :type interpolation_method:
        pandas.core.series.Series.interpolate methods

    :returns:
        DataFrame or TimeSeries containing only boundary values
    :rtype:
        pandas.core.frame.DataFrame or pandas.core.series.Series
    """
    if not isinstance(data, pd.Series) and not isinstance(data, pd.DataFrame):
        raise TypeError("Function only accepts pandas.core.frame.DataFrame or pandas.core.series.Series format")
    if boundary_time in data.index:
        raise ValueError("Boundary time already exists in index")
    if data[data.index < boundary_time].empty:
        logger.warn("No data available prior to boundary time, setting it to NaN")
    if data.index.dtype.kind != "M":
        raise TypeError("'%s' is not a datetime format" % data.index.dtype.name)
    if (data.index == boundary_time).sum() == 0:
        if isinstance(data, pd.Series):
            dtype = data.dtype
            if dtype == np.dtype('bool'):
                dtype = np.dtype('object')
            boundary_data = pd.Series(index=[boundary_time], name=data.name, dtype=dtype)
            data = pd.concat([boundary_data, data]).sort_index()
            if not data[data.index < boundary_time].empty and not np.isnan(data[data.index < boundary_time][-1]):
                data = pd.Series.interpolate(data, method=interpolation_method)
                if interpolation_method == "zero":
                    data = data.fillna(method="pad")
        elif isinstance(data, pd.DataFrame):
            boundary_data = pd.DataFrame(index=[boundary_time], columns=data.columns, dtype=np.dtype('object'))
            data = pd.concat([boundary_data, data]).sort_index()

            if interpolation_method == "zero":
                data = data.fillna(method="pad")
    return data[data.index == boundary_time]


def series_to_dataframe_histogram(series, columns=None):
    """Create pandas DataFrame which columns are the unique values of the
    pandas Series object. The values in each line are either '0' or '1',
    depending on which column contains the value for that index.

    :param series:
        Series
    :type series:
        pandas.core.series.Series

    :param columns:
        List of columns
    :type columns:
        list

    :returns:
        DateFrame which columns are the unique values of the Series
    :rtype:
        pandas.core.frame.DataFrame
    """
    if not isinstance(series, pd.Series):
        raise ValueError("Function only accepts pandas.core.series.Series format")
    if not columns:
        columns = series.dropna().unique()
    dataframe = pd.DataFrame(columns=columns, index=series.index)
    for column in dataframe:
        dataframe[column] = (series == column)
    return dataframe.fillna(value=0)


def set_unique_index(data, take_last=True):
    """Set unique index for given pandas DataFrame or Series by
       removing duplicates, keeping the last value.

    :param data:
        DataFrame or TimeSeries to set unique index for.
    :type data:
        pandas.core.frame.DataFrame or pandas.core.series.Series

    :param take_last:
        Take the last observed row in a row.
    :type take_last:
        boolean

    :returns:
        Data with unique index.
    :rtype:
        pandas.core.frame.DataFrame or pandas.core.series.Series
    """
    if not isinstance(data, pd.Series) and not isinstance(data, pd.DataFrame):
        raise TypeError("Function only accepts pandas.core.frame.DataFrame or pandas.core.series.Series format")
    if not data.index.is_unique:

        def do_drop_duplicates(data_frame):
            data_frame["index"] = data_frame.index
            data_frame.drop_duplicates(subset='index', take_last=take_last, inplace=True)
            del data_frame["index"]

        if isinstance(data, pd.DataFrame):
            do_drop_duplicates(data)
        elif isinstance(data, pd.Series):
            data = pd.DataFrame(data)
            do_drop_duplicates(data)
            data = pd.Series(data.iloc[:, 0], name=data.columns[0])

    return data


def concat_fill_nan(data, axis=1, interpolation_methods=None, start_time=None, end_time=None):
    """Concatenate Pandas DataFrame or TimeSeries, specifying
    desired methods to fill NaN holes.

    :param data:
        List containing Series to be concatenated
    :type data:
        list containing pandas.core.series.Series

    :param axis:
        Axis to concatenate along
    :type axis:
        int

    :param interpolation_methods:
        List of interpolation methods
    :type interpolation_method:
        list of pandas.core.series.Series.interpolate methods

    :param start_time:
        Start time
    :type start_time:
        datetime.datetime or pandas.tslib.Timestamp

    :param end_time:
        End time
    :type end_time:
        datetime.datetime or pandas.tslib.Timestamp

    :returns:
        Concatenated input data
    :rtype:
        pandas.core.frame.DataFrame or pandas.core.series.Series
    """
    if interpolation_methods:
        items = 0
        for item in data:
            if isinstance(item, pd.DataFrame):
                items += len(item.columns)
            elif isinstance(item, pd.Series):
                items += 1
        if len(interpolation_methods) != items:
            raise ValueError("Lists with input data and interpolation orders need to have the same size")
    if start_time or end_time:
        for index in range(0, len(data)):
            if interpolation_methods:
                interpolation_method = interpolation_methods[index]
            else:
                interpolation_method = "zero"
            data[index] = set_timeframe(data[index], interpolation_method=interpolation_method, start_time=start_time,
                                        end_time=end_time)
    if len(data) > 0:
        data = pd.concat(data, axis=axis)
        for index in range(0, len(data.columns)):
            if interpolation_methods:
                interpolation_method = interpolation_methods[index]
            else:
                interpolation_method = "zero"
            data.iloc[:, index] = pd.Series(pd.Series.interpolate(data.iloc[:, index], method=interpolation_method),
                                            dtype=data.iloc[:, index].dtype)
    return set_unique_index(data).sort_index()


def series_diff(series, interpolation_methods=None, start_time=None, end_time=None, name=None):
    """Compute the difference between two pandas Series

    :param series:
        List containing two Series
    :type series:
        list containing pandas.core.series.Series

    :param interpolation_methods:
        List of interpolation methods
    :type interpolation_methods:
        list of pandas.core.series.Series.interpolate methods

    :param start_time:
        Start time
    :type start_time:
        datetime.datetime or pandas.tslib.Timestamp

    :param end_time:
        End time
    :type end_time:
        datetime.datetime or pandas.tslib.Timestamp

    :param name:
        Name for resulting Series
    :type name:
        str

    :returns:
        Series containing the difference between input Series
    :rtype:
        pandas.core.series.Series
    """
    dataframe = concat_fill_nan(series, interpolation_methods=interpolation_methods, start_time=start_time,
                                end_time=end_time)
    return pd.Series(dataframe.iloc[:, 1] - dataframe.iloc[:, 0], name=name)


def drop_consecutive_duplicates(data):
    """Drop consecutive duplicates in pandas DataFrame or Series

    :param data:
        Input data
    :type data:
        pandas.core.frame.DataFrame or pandas.core.series.Series

    :returns:
        Data without consecutive duplicates
    :rtype:
        pandas.core.frame.DataFrame or pandas.core.series.Series
    """
    data_no_nan = data.fillna('NaN')
    if isinstance(data, pd.DataFrame):
        data = data.loc[(data_no_nan.shift(1) != data_no_nan).any(1)]
    elif isinstance(data, pd.Series):
        data = data.loc[(data_no_nan.shift(1) != data_no_nan)]
    return data


class ArgumentParser(ArgumentParserBaseClass):
    def __init__(self, *args, **kwargs):
        super(ArgumentParser, self).__init__(*args, **kwargs)

    def quick_load(self):
        """
        This function automatically adds all of the command line arguments used by the device history load.
        Currently added flags are: -i, -s, -e, and -t.
        """
        self.quick_add('-i', '-s', '-e', '-t')

    def quick_add(self, *flags):
        """Provide an easy way to add common command line flags to a script.

        :param *flags:
            Currently supported flags are:
            -i, --input_file
            -l, --log_type
            -s, --start_date
            -e, --end_date
            -t, --tier
            -f, --folder
            -o, --output_format (for images)
            -p, --processes
        :type data:
            flags of the form: -i, --input_file
        """

        for flag in flags:

            if flag in ['-i', '--input_file']:
                super(ArgumentParser, self).add_argument('-i', '--input_file',
                                                         help='file with newline-separated device MAC addresses (stdin works as well)',
                                                         type=argparse.FileType('r'),
                                                         default=sys.stdin)

            elif flag in ['-l', '--log_type']:
                super(ArgumentParser, self).add_argument('-l', '--log_type',
                                                         help='type of logs requested',
                                                         type=str,
                                                         choices=['clientevent',
                                                                  'clientdebug',
                                                                  'topazevent',
                                                                  'balsamlog',
                                                                  'hiddenitelog'],
                                                         default=None)

            elif flag in ['-s', '--start_date']:
                super(ArgumentParser, self).add_argument('-s', '--start_date',
                                                         type=parser.parse,
                                                         help='start date and time, format: YYYY-MM-DDTHH:MM:SS or YYYY-MM-DD',
                                                         default=None)

            elif flag in ['-e', '--end_date']:
                super(ArgumentParser, self).add_argument('-e', '--end_date',
                                                         type=parser.parse,
                                                         help='end date and time, format: YYYY-MM-DDTHH:MM:SS or YYYY-MM-DD',
                                                         default=None)

            elif flag in ['-t', '--tier']:
                super(ArgumentParser, self).add_argument('-t', '--tier',
                                                         help='tier from which to pull data',
                                                         default=None,
                                                         type=str,
                                                         choices=['production', 'ft', 'qa', 'all'])

            elif flag in ['-f', '--folder']:
                super(ArgumentParser, self).add_argument('-f', '--folder',
                                                         dest='save_folder',
                                                         help='folder for storing any information saved by the script ',
                                                         default=os.getcwd(),
                                                         type=str)

            elif flag in ['-o', '--output_format']:
                fig = plt.figure()
                super(ArgumentParser, self).add_argument('-o', '--output_format',
                                                         help='if images output, the format can be specified.',
                                                         default='png',
                                                         choices=fig.canvas.get_supported_filetypes().keys(),
                                                         type=str)
                plt.close()

            elif flag in ['-p', '--processes']:
                super(ArgumentParser, self).add_argument('-p', '--processes',
                                                         help='Number of processes to use if script is parallelized',
                                                         default=1,
                                                         type=int)

            else:
                raise ValueError('{} option not understood'.format(flag))
