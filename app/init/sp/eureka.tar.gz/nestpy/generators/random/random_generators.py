import datetime
import numpy as np

from ...validation.datetime_validation import assert_valid_start_and_end_dates


def random_datetime_generator(n_datetimes, start_datetime, end_datetime):
    """Generates random datetime objects, uniquely sampled from a specified sampling time frame

    :param n_datetimes:
        Number of datetime objects to be generated
    :type n_datetimes:
        int

    :param start_datetime:
        Start of sampling time frame
    :type start_datetime:
        datetime.datetime

    :param end_datetime:
        End of sampling time frame
    :type end_datetime:
        datetime.datetime

    :returns:
        Random datetime generator
    :rtype:
        generator
    """
    assert_valid_start_and_end_dates(start_datetime, end_datetime)
    total_seconds = int((end_datetime - start_datetime).total_seconds())
    random_seconds_array = np.sort(np.random.choice(total_seconds, n_datetimes, replace=False))
    for random_seconds in random_seconds_array:
        yield start_datetime + datetime.timedelta(seconds=random_seconds)


def random_sample_generator(n_samples, samples_choices):
    """Generates random samples, sampled from a specified list of sample choices

    :param n_samples:
        Number of samples to be generated
    :type n_samples:
        int

    :param samples_choices:
        List of sample choices
    :type samples_choices:
        list

    :returns:
        Random sample generator
    :rtype:
        generator
    """
    for _ in range(n_samples):
        yield np.random.choice(samples_choices)


def random_integer_generator(n_integers, lower_bound, upper_bound):
    """Generates random integers, sampled from a lower and upper bounded interval

    :param n_integers:
        Number of integers to be generated
    :type n_integers:
        int

    :param lower_bound:
        Lower bound of sample interval
    :type lower_bound:
        int

    :param upper_bound:
        Upper bound of sample interval
    :type upper_bound:
        int

    :returns:
        Random integer generator
    :rtype:
        generator
    """
    for _ in range(n_integers):
        yield np.random.randint(lower_bound, upper_bound)


def random_boolean_generator(n_booleans):
    """Generates random booleans

    :param n_booleans:
        Number of booleans to be generated
    :type n_booleans:
        int

    :returns:
        Random booleans generator
    :rtype:
        generator
    """
    for _ in range(n_booleans):
        yield np.random.choice([True, False])
