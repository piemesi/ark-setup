# pylint: disable=no-member
import numpy
import pytz

from pandas import DataFrame, date_range
from pandas.tslib import Timestamp

from .random_generators import random_datetime_generator


class RandomEventGenerator(object):

    @classmethod
    def random_timestamps(cls, start_date, end_date, number_of_timestamps):
        """
        :param start_date: the earliest datetime
        :param end_date: the latest datetime
        :param number_of_timestamps:  the number of timestamps to generate
        :return: list of pandas Timestamps corresponding to random times between start_date and end_date
        """
        datetimes = random_datetime_generator(number_of_timestamps, start_date, end_date)
        return [Timestamp(datetime) for datetime in datetimes]

    @classmethod
    def random_events(cls,
                      start_date,
                      end_date,
                      number_of_records,
                      timestamp_column_name="timestamp",
                      tzinfo=pytz.utc):

        timestamps = cls.random_timestamps(start_date, end_date, number_of_records)
        records = [
            {
                timestamp_column_name: timestamp
            }
            for timestamp in timestamps
        ]

        return DataFrame(records).set_index(timestamp_column_name, drop=False).tz_convert(tzinfo)

    @classmethod
    def random_buffered_pir(cls, start_date, end_date, freq, low=0, high=1000):
        index = date_range(start=start_date, end=end_date, freq=freq)
        max_pir = numpy.random.random_integers(low=low, high=high, size=len(index))
        return DataFrame(index=index, data=dict(max=max_pir, bucketTime=index.to_pydatetime()))

    @classmethod
    def random_buffered_als(cls, start_date, end_date, freq, low=0, high=1000):
        index = date_range(start=start_date, end=end_date, freq=freq)
        min_als = numpy.random.random_integers(low=low, high=high, size=len(index))
        max_als = min_als + 1
        return DataFrame(index=index, data=dict(min=min_als, max=max_als, bucketTime=index.to_pydatetime()))

    @staticmethod
    def _topaz_random_event(start_date, end_date, freq, low, high):
        index = date_range(start=start_date, end=end_date, freq=freq)
        series = numpy.random.random_integers(low=low, high=high, size=len(index))
        return DataFrame(index=index, data=dict(Value0=series))

    @classmethod
    def random_topaz_pir(cls, start_date, end_date, freq, low=-30, high=30):
        return cls._topaz_random_event(start_date, end_date, freq, low, high)

    @classmethod
    def random_topaz_als(cls, start_date, end_date, freq, low=0, high=1000):
        return cls._topaz_random_event(start_date, end_date, freq, low, high)

    @staticmethod
    def create_mobile_device_key(mobile_device_index):
        return 'mobile_device_{}'.format(mobile_device_index)

    @staticmethod
    def random_enter_exit_events(random_events, column):
        random_events[column] = True
        random_events.loc[::2, column] = False
        return random_events

    @classmethod
    def random_enter_exit_ble_events(cls,
                                     start_date,
                                     end_date,
                                     number_of_events,
                                     number_of_mobile_devices):
        random_enter_exit_events_ble = cls.random_events(start_date, end_date, number_of_events)
        mobile_device_keys = [cls.create_mobile_device_key(i) for i in range(number_of_mobile_devices)]
        for column in mobile_device_keys:
            random_enter_exit_events_ble = cls.random_enter_exit_events(random_enter_exit_events_ble, column)
        return random_enter_exit_events_ble
