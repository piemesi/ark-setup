import datetime
import math
import pandas as pd

from ..manipulators.datetime_manipulators import ceil_datetime
from ..validation.type_validation import assert_is_type
from ..validation.datetime_validation import assert_valid_start_and_end_dates


def datetime_range_generator(start_datetime, end_datetime, interval, closed_left=True, closed_right=False):
    """Generates a range of datetime objects

    :param start_datetime:
        Start date of time frame
    :type start_datetime:
        datetime.datetime

    :param end_datetime:
        End date of time frame
    :type end_datetime:
        datetime.datetime

    :param interval:
        Interval to be used
    :type interval:
        datetime.timedelta

    :param closed_left:
        Whether or not to close the time frame on the left side
    :type closed_left:
        bool

    :param closed_right:
        Whether or not to close the time frame on the right side
    :type closed_right:
        bool

    :returns:
        Datetime range generator
    :rtype:
        generator
    """
    assert_valid_start_and_end_dates(start_datetime, end_datetime)
    assert_is_type(interval, datetime.timedelta)
    time_frame = end_datetime - start_datetime
    time_frame_seconds = int(time_frame.total_seconds())
    interval_seconds = int(interval.total_seconds())
    number_of_intervals = time_frame_seconds / interval_seconds
    start_timestamp = pd.Timestamp(start_datetime)
    if closed_left:
        start_interval_index = 0
    else:
        start_interval_index = 1
    if not closed_right and time_frame_seconds % interval_seconds == 0:
        end_interval_index = number_of_intervals
    else:
        end_interval_index = number_of_intervals + 1
    for interval_index in range(start_interval_index, end_interval_index):
        timedelta = datetime.timedelta(seconds=interval_index * interval_seconds)
        timestamp = start_timestamp + timedelta
        yield timestamp.to_datetime()


def rounded_datetime_range_generator(start_datetime, end_datetime, interval, closed_left=True, closed_right=False):
    """Generates a range of datetime objects, rounded to the specified interval

    :param start_datetime:
        Start date of time frame
    :type start_datetime:
        datetime.datetime

    :param end_datetime:
        End date of time frame
    :type end_datetime:
        datetime.datetime

    :param interval:
        Interval to be used
    :type interval:
        datetime.timedelta

    :param closed_left:
        Whether or not to close the time frame on the left side
    :type closed_left:
        bool

    :param closed_right:
        Whether or not to close the time frame on the right side
    :type closed_right:
        bool

    :returns:
        Rounded datetime range generator
    :rtype:
        generator
    """
    assert_valid_start_and_end_dates(start_datetime, end_datetime)
    assert_is_type(interval, datetime.timedelta)
    rounded_start_datetime = ceil_datetime(start_datetime, interval)
    if rounded_start_datetime > start_datetime:
        closed_left = True
    if rounded_start_datetime <= end_datetime:
        generator = datetime_range_generator(
            start_datetime=rounded_start_datetime,
            end_datetime=end_datetime,
            interval=interval,
            closed_left=closed_left,
            closed_right=closed_right
        )
    else:
        generator = (_ for _ in ())
    return generator
