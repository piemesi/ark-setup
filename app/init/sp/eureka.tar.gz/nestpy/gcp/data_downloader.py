import logging
import os
import pandas as pd
import re
import subprocess
import time

from datetime import timedelta
from functools import partial
from google.cloud import bigquery
from multiprocessing import Pool
from multiprocessing.pool import ThreadPool
from nestpy.converters import get_tz_aware_datetime

logger = logging.getLogger(__name__)


def call_instance_method(obj, method_name, *args, **kwargs):
    """
    Top-level wrapper function making it possible to pickle instance methods passed to multiprocessing methods.

    :param obj: object containing method to be called
    :param method_name: name of object's method to be called
    :param args: arguments passed to object's method
    :param kwargs: keyword arguments passed to object's method
    :return: return type of object's method
    """
    return getattr(obj, method_name)(*args, **kwargs)


class DataDownloader(object):
    """
    Fetches device data from BigQuery; mirrors role of nestpy.aws.data_downloader.

    Using this module requires users to have installed the gcloud command-line tool.
    """
    FLAT = 'FLAT'
    INDEX = 'timeindex'
    TEMP = 'Temp'

    def __init__(self,
                 start_date=None,
                 end_date=None,
                 bq_project_id='nest-algo',
                 device_id_type='mac_address'):
        """
        :param start_date: start date acceptable to BigQuery's TIMESTAMP function, such as 'YYYY-MM-DD'
        :param end_date: end date acceptable to BigQuery's TIMESTAMP function, such as 'YYYY-MM-DD'
        :param bq_project_id: BigQuery project from which to get device data
        :param device_id_type: BigQuery column name of unique device identifier, such as 'mac-address'
        """
        self.start_date = get_tz_aware_datetime(start_date)
        self.end_date = get_tz_aware_datetime(end_date)
        self.bq_project_id = bq_project_id
        self.device_id_type = device_id_type

        self._check_gcloud_installation()
        self._check_gcloud_credentials()

        self._bq_client = bigquery.Client(project=bq_project_id)
        self.refresh()

    @staticmethod
    def _check_gcloud_installation():
        """
        Check that the gcloud command-line tool is installed.
        """
        if subprocess.call(['type', 'gcloud']) != 0:
            raise ValueError('No gcloud installation found. Install gcloud: https://cloud.google.com/sdk/downloads')

    @staticmethod
    def _check_gcloud_credentials():
        """
        Check that the user has a gcloud credentials file.
        """
        if not os.path.isfile(os.path.expanduser('~/.config/gcloud/application_default_credentials.json')):
            raise ValueError('No gcloud credentials found. Run `gcloud auth login`')

    def refresh(self):
        """
        Reset prefix used to name jobs and temporary tables.
        """
        self.prefix = self._get_prefix()

    @staticmethod
    def _get_prefix():
        """
        Create a prefix used to name jobs and temporary tables.

        :return: new prefix used to name tables and jobs
        """
        return str(int(time.time()))

    def _get_bq_client(self, project_id=None, parallel=False, client=None):
        """
        Get a client object that can be used to interact with BigQuery.

        :param parallel: whether a client is being sought for a parallel operation
        :param client: an existing client object
        :return: a gcloud.bigquery.Client object
        """
        if client:
            pass
        elif project_id:
            client = bigquery.Client(project=project_id)
        elif parallel:
            client = bigquery.Client(project=self.bq_project_id)
        else:
            client = self._bq_client

        return client

    def get_job_id(self, other_id=None, job_id=None):
        """
        Get an identifier for a BigQuery query job.

        :param other_id: a relevant identifier, such as a table_id
        :param job_id: an existing job_id
        :return: a unique query job identifier
        """
        if job_id:
            return job_id

        job_id = self.prefix

        if other_id:
            job_id += '_{}'.format(other_id)

        return re.sub(r'\W+', '', job_id)

    def get_table_id(self, device_id=None, event_type=None, table_id=None):
        """
        Get an identifier for a table used to store the results of a BigQuery query.

        :param device_id: a relevant device identifier
        :param event_type: the type of event data the table will contain
        :param table_id: an existing table_id
        :return: a unique table identifier
        """
        if table_id:
            return table_id

        table_id = self.prefix

        if device_id:
            table_id += '_{}'.format(device_id)

        if event_type:
            table_id += '_{}'.format(event_type)

        return re.sub(r'\W+', '', table_id)

    def get_last_table(self, project_id, dataset_id, table_prefix):
        """
        Get the last table in a given dataset with a given prefix.

        :param project_id: identifier of the project from which to get data
        :param dataset_id: identifier of the dataset from which to get data
        :param table_prefix: identifier of table(s) from which to get event data, stripped of date suffixes
        :return: a gcloud.bigquery.table.Table object if one is found
        """
        dataset = self._get_bq_client(project_id).dataset(dataset_id)

        for i in range((self.end_date - self.start_date).days + 1)[::-1]:
            date = self.start_date + timedelta(days=i)
            table_name = table_prefix + date.strftime('%Y%m%d')
            table = dataset.table(table_name)
            table.reload()

            if table.exists():
                return table

        return None

    @staticmethod
    def get_all_not_event_types(schema):
        """
        Get all elements of the schema that contain don't fields.

        :param schema: a mapping from event name to gcloud.bigquery.table.SchemaField objects
        :return: a mapping from event name to gcloud.bigquery.table.SchemaField objects
        """
        return filter(lambda x: not x.fields, schema)

    @staticmethod
    def get_not_event_types(schema):
        """
        Get elements of the schema with names in event_types that don't contain fields.

        :param schema: a mapping from event name to gcloud.bigquery.table.SchemaField objects
        :return: a subset of the schema
        """
        all_not_event_types = DataDownloader.get_all_not_event_types(schema)
        return map(lambda x: x.name, all_not_event_types)

    @staticmethod
    def get_all_event_types(schema):
        """
        Get all elements of the schema that contain fields, i.e., those that are events, such as 'CurrentState'.

        :param schema: a mapping from event name to gcloud.bigquery.table.SchemaField objects
        :return: a mapping from event name to gcloud.bigquery.table.SchemaField objects
        """
        return filter(lambda x: x.fields, schema)

    @staticmethod
    def get_event_types(schema, *event_types):
        """
        Get elements of the schema with names in event_types that contain fields.

        :param schema: a mapping from event name to gcloud.bigquery.table.SchemaField objects
        :param event_types: event names not to discard from schema
        :return: a subset of the schema
        """
        all_event_types = DataDownloader.get_all_event_types(schema)

        out = map(lambda x: x.name, filter(lambda x: x.name in event_types, all_event_types))

        if DataDownloader.FLAT in event_types:
            out.append(DataDownloader.FLAT)

        return out

    @staticmethod
    def _get_index(index, schema):
        """
        Get the name of an index contained in the schema to return with device event data.

        :param index: the name of the index to use, defaults to 'timeindex'
        :param schema the relevant schema
        :return: the name of the index if it's contained in the schema
        """
        if not index:
            index = DataDownloader.INDEX

        if index not in map(lambda x: x.name, schema):
            index = None

        return index

    def get_event_query(self, event_type, device_id, project_id, dataset_id, table_prefix, schema, index=None):
        """
        Get a query string appropriate to a given event_type.

        :param event_type: name of the relevant event
        :param device_id: identifier of the relevant device
        :param project_id: identifier of the project from which to get data
        :param dataset_id: identifier of the dataset from which to get data
        :param table_prefix: identifier of table(s) from which to get event data, stripped of date suffixes
        :param schema: a relevant schema
        :param index: a relevant index

        :return: a string representing a BigQuery standard SQL query
        """
        if event_type == self.FLAT:
            return self._get_flat_event_query(device_id, project_id, dataset_id, table_prefix, schema, index=index)

        else:
            return self._get_record_event_query(
                event_type,
                device_id,
                project_id,
                dataset_id,
                table_prefix,
                schema,
                index=index
            )

    def _get_flat_event_query(self, device_id, project_id, dataset_id, table_prefix, schema, index=None):
        not_event_types = self.get_not_event_types(schema)

        if index:
            assert index in not_event_types

        select_not_event_types = ','.join(not_event_types)
        where_not_event_types = '\n      OR '.join(map(lambda x: '{} IS NOT NULL'.format(x), not_event_types))

        SELECT = 'SELECT {not_event_types}'.format(
            not_event_types=select_not_event_types)

        FROM = 'FROM `{project}.{dataset}.{table_prefix}*`'.format(
            project=project_id,
            dataset=dataset_id,
            table_prefix=table_prefix)

        WHERE = '''\
WHERE _TABLE_SUFFIX BETWEEN "{start_date}" AND "{end_date}"
  AND {device_id_type} = "{device_id}"
  AND ({not_event_types})'''.format(
            start_date=self.start_date.strftime('%Y%m%d'),
            end_date=self.end_date.strftime('%Y%m%d'),
            device_id_type=self.device_id_type,
            device_id=device_id,
            not_event_types=where_not_event_types)

        query = '\n'.join((SELECT, FROM, WHERE))

        logger.debug('{event_type} query: \n{query}'.format(event_type=self.FLAT, query=query))

        return query

    def _get_record_event_query(self, event_type, device_id, project_id, dataset_id, table_prefix, schema, index=None):
        index = self._get_index(index, schema)

        if event_type not in map(lambda x: x.name, schema):
            raise ValueError('Event type {} not found in schema.'.format(event_type))

        if index:
            SELECT = 'SELECT {index}, {event_type}'.format(
                index=index,
                event_type=event_type)
        else:
            SELECT = 'SELECT {event_type}'.format(
                event_type=event_type)

        FROM = 'FROM `{project}.{dataset}.{table_prefix}*`'.format(
            project=project_id,
            dataset=dataset_id,
            table_prefix=table_prefix)

        WHERE = '''\
WHERE _TABLE_SUFFIX BETWEEN "{start_date}" AND "{end_date}"
  AND {device_id_type} = "{device_id}"
  AND {event_type} IS NOT NULL'''.format(
            start_date=self.start_date.strftime('%Y%m%d'),
            end_date=self.end_date.strftime('%Y%m%d'),
            device_id_type=self.device_id_type,
            device_id=device_id,
            event_type=event_type)

        query = '\n'.join((SELECT, FROM, WHERE))

        logger.debug('{event_type} query: \n{query}'.format(event_type=event_type, query=query))

        return query

    @staticmethod
    def _get_event_columns(schema):
        if schema:
            columns = [field.name for field in schema]
        else:
            columns = None

        return columns

    @staticmethod
    def _unpack_data(data, index=None):
        events = []
        for row in data:
            if index:
                index_value, event = row
                if isinstance(event, dict):
                    event.update({index: index_value})
                    events.append(event)
                elif isinstance(event, list):
                    for sub_event in event:
                        sub_event.update({index: index_value})
                        events.append(sub_event)
            else:
                event, = row
                if isinstance(event, dict):
                    events.append(event)
                elif isinstance(event, list):
                    events += event
        return events

    @classmethod
    def _row_data_to_dataframe(cls, fetch_data_func, index=None, columns=None):
        """
        Convert row data downloaded from BigQuery into a pandas.DataFrame.

        :param fetch_data_func: a function that can be used to get row data
        :param index: the name of a column to use as a dataframe index
        :param columns: the names of columns in the resultant dataframe
        :return: a pandas.DataFrame
        """
        df = pd.DataFrame()
        first = True
        page_token = None
        while page_token or first:
            if first:
                first = False

            row_data = cls._unpack_data(data=fetch_data_func(page_token=page_token), index=index)

            if row_data:
                new_df = pd.DataFrame(row_data)
                if df.empty:
                    df = new_df
                else:
                    df = df.append(new_df)

        if index and index in df:
            df = df.set_index(index)
        elif index:
            logger.warning('Index {} not found in dataframe.'.format(index))

        return df

    def _event_to_table(self, event_type, device_id, project_id, dataset_id, table_prefix, parallel=False,
                        client=None, schema=None, index=None, table_id=None, job_id=None,
                        use_query_cache=True, wait=False):
        """
        Create a BigQuery table of relevant event data.

        :param event_type: name of the relevant event
        :param device_id: identifier of the relevant device
        :param project_id: identifier of the project from which to get data
        :param dataset_id: identifier of the dataset from which to get data
        :param table_prefix: identifier of table(s) from which to get event data, stripped of date suffixes
        :param parallel: whether the function is being called as part of a parallel operation
        :param client: a gcloud.bigquery.Client to use
        :param schema: a relevant schema
        :param index: a relevant index
        :param table_id: identifier of the resultant table
        :param job_id: identifier of the resultant query job
        :param use_query_cache: whether to create the table using cached query results when available
        :param wait: whether to wait for the query job to complete before returning
        :return: the name of the relevant event
        """
        table_id = self.get_table_id(event_type=event_type, device_id=device_id, table_id=table_id)
        job_id = self.get_job_id(table_id, job_id=job_id)
        client = self._get_bq_client(parallel=parallel, client=client)

        logger.info('Starting query job for device {}\'s {}.'.format(device_id, event_type))

        query = self.get_event_query(
            event_type,
            device_id,
            project_id,
            dataset_id,
            table_prefix,
            schema=schema,
            index=index
        )

        query_job = client.run_async_query(job_id, query)
        query_job.allow_large_results = True
        query_job.create_disposition = 'CREATE_IF_NEEDED'
        query_job.destination = client.dataset(self.TEMP).table(table_id)
        query_job.flatten_results = True
        query_job.use_legacy_sql = False
        query_job.use_query_cache = use_query_cache

        query_job.begin()

        if wait:
            logger.info('Waiting for {} query.'.format(event_type))
            self.wait_for_query_jobs([query_job])

        return event_type

    def _table_to_dataframe(self, event_type, device_id, parallel=True, client=None,
                            index=None, table_id=None):
        """
        Download data from a BigQuery table to a local pandas.DataFrame.

        :param event_type: name of the relevant event
        :param device_id: identifier of the relevant device
        :param parallel: whether the function is being called as part of a parallel operation
        :param client: a gcloud.bigquery.Client to use
        :param index: a relevant index
        :param table_id: identifier of a table from which to get data
        :return: a tuple of (the name of the relevant event type, a pandas.DataFrame of event data)
        """
        try:
            table_id = self.get_table_id(device_id=device_id, event_type=event_type, table_id=table_id)
            client = self._get_bq_client(parallel=parallel, client=client)
            table = client.dataset(self.TEMP).table(table_id)
            table.reload()

            schema = table.schema
            index = self._get_index(index=index, schema=schema)
            columns = self._get_event_columns(schema)
            df = self._row_data_to_dataframe(table.fetch_data, index=index, columns=columns)
        except Exception as e:
            logger.error(e)

        return event_type, df

    # could move some parameters to the constructor
    def events_to_dataframes(self, event_types, device_id, project_id, dataset_id, table_prefix,
                             index=None, threads=None, use_query_cache=True):
        """
        Download data from event(s) to local pandas.DataFrame(s).

        :param event_types: name(s) of relevant event(s)
        :param device_id: identifier of the relevant device
        :param project_id: identifer of the project from which to get data
        :param dataset_id: identifer of the dataset from which to get data
        :param table_prefix: identifier of table(s) from which to get event data, stripped of date suffixes
        :param index: a relevant index
        :param threads: the number of thread to use while fetching data
        :param use_query_cache: whether to used cached query results when available
        :return: a mapping from event name to pandas.DataFrame of data
        """
        # don't default to getting all event types
        if not hasattr(event_types, '__iter__'):
            event_types = [event_types]

        schema = self.get_last_table(project_id, dataset_id, table_prefix=table_prefix).schema
        event_types = self.get_event_types(schema, *event_types)
        index = self._get_index(index, schema=schema)

        a_args = tuple(event_type for event_type in event_types)
        a_func = partial(call_instance_method, self, '_event_to_table', device_id=device_id, project_id=project_id,
                         dataset_id=dataset_id, table_prefix=table_prefix, parallel=True,
                         schema=schema, index=index, use_query_cache=use_query_cache, wait=True)
        b_func = partial(call_instance_method, self, '_table_to_dataframe', device_id=device_id,
                         parallel=True, client=None, index=index)
        pool_a = ThreadPool(processes=threads)
        pool_b = Pool(processes=None)

        dfs = {}
        i = 1
        for event_type, df in pool_b.imap_unordered(b_func, pool_a.imap_unordered(a_func, a_args)):
            dfs[event_type] = df
            i += 1

        pool_a.close()
        pool_b.close()
        pool_a.join()
        pool_b.join()

        return dfs

    @staticmethod
    def wait_for_query_jobs(query_jobs, max_polls=240, poll_every=0.5):
        """
        :param query_jobs: query jobs to wait for
        :param max_polls: maximum number of times to poll each query job for its status
        :param poll_every: time in seconds to wait between polls
        """
        polls_left = max_polls

        while query_jobs and polls_left > 0:
            query_jobs = filter(lambda x: x.reload() or x.state.upper() != 'DONE', query_jobs)

            polls_left -= 1
            time.sleep(poll_every)

        if query_jobs:
            raise ValueError('Jobs {} timed out after {} * {} seconds.'
                             .format([job.name for job in query_jobs], max_polls, poll_every))
