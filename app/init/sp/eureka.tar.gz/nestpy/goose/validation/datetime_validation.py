def assert_valid_test_days(test_days, start_date, end_date):

    if test_days <= 0:
        raise ValueError("Test days must be greater than zero.")

    num_days = (end_date - start_date).days

    if test_days > num_days:
        raise ValueError("Insufficient data for training and testing. Requested %s testing days, but found "
                         "%s days of data." % (test_days, num_days))

