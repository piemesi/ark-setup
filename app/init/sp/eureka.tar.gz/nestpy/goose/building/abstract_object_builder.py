from abc import ABCMeta, abstractmethod
from copy import deepcopy

from ...validation.type_validation import assert_is_type, assert_list_of_type, assert_is_subclass


def extend_builder_config(builder_config, **builder_config_extension):
    extended_builder_config = dict(**builder_config)
    extended_builder_config.update(**builder_config_extension)
    return extended_builder_config


class AbstractObjectBuilder(object):
    """The object builder is an abstract base class for builders throughout the GOOSE prototype."""
    __metaclass__ = ABCMeta

    def __init__(self, object_cls, **builder_config):
        """The object builder is instantiated with the class of the object to be built and the builder configuration."""
        assert_is_subclass(object_cls, self._get_object_base_cls())
        self._validate_kwarg_types(builder_config, self._get_builder_config_types())
        self._object_cls = object_cls
        self._builder_config = builder_config

    def _key(self):
        return tuple([self._object_cls] + self._builder_config.values())

    def __hash__(self):
        return hash(self._key())

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self._key() == other._key()

    def __ne__(self, other):
        return not self.__eq__(other)

    def __repr__(self):
        return "<{}>".format(self.__class__.__name__)

    @staticmethod
    def _validate_kwarg_types(kwargs, kwarg_types):
        for object_key, expected_type in kwarg_types.items():
            if kwargs[object_key] is not None:
                if isinstance(kwargs[object_key], list):
                    if expected_type is not list:
                        assert_list_of_type(kwargs[object_key], expected_type)
                else:
                    assert_is_type(kwargs[object_key], expected_type)

    @abstractmethod
    def _get_object_base_cls(self):
        """This method should return the base class of the objects that will be built."""
        raise NotImplementedError

    def _get_builder_config_types(self):
        """This method should return a dictionary with the expected configuration parameters and types."""
        return dict()

    def _get_build_kwargs_types(self):
        """This method should return a dictionary with the expected build parameters and types."""
        return dict()

    def build(self, *args, **kwargs):
        """Builds the object by combining the passed arguments with the configuration parameters."""
        self._validate_kwarg_types(kwargs, self._get_build_kwargs_types())
        kwargs.update(self._builder_config)
        try:
            obj = self._object_cls(*args, **kwargs)
        except Exception as e:
            raise type(e)("{} for '{}'".format(e.args[0], self._object_cls))
        return obj

    def modify_parameter(self, path, value):
        if hasattr(path, '__iter__') and len(path) == 1:
            self._builder_config[path[0]] = value
        elif not hasattr(path, '__iter__'):
            self._builder_config[path] = value
        else:
            self._builder_config[path[0]].modify_parameter(path[1:], value)

    def new_builder_with_parameter(self, path, value):
        new_builder = deepcopy(self)
        new_builder.modify_parameter(path, value)
        return new_builder

    def get_object_cls(self):
        return self._object_cls
