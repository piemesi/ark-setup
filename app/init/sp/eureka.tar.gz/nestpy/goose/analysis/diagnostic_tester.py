import datetime
import numpy as np
import pandas as pd

from .diagnostic_test_results import DiagnosticTestResults
from ..states import State, StateSeries
from ...manipulators.series_manipulators import compute_timedelta_series, set_unique_index
from ...manipulators.frame_manipulators import drop_consecutive_duplicates
from ...validation.type_validation import assert_is_type


class DiagnosticTester(object):

    _TARGET_SERIES = "target_series"
    _TEST_SERIES = "test_series"
    _TIMEDELTA_SERIES = "timedelta_series"

    _TRANSITION_OFFSETS_PATTERNS = [
        pd.DataFrame(
            columns=[_TARGET_SERIES, _TEST_SERIES],
            data=[[False, False], [True, True]]
        ),
        pd.DataFrame(
            columns=[_TARGET_SERIES, _TEST_SERIES],
            data=[[False, np.nan], [True, False], [True, True]]
        )
    ]
    _OFFSET_INTERVALS_PATTERNS = [
        pd.DataFrame(
            columns=[_TARGET_SERIES, _TEST_SERIES],
            data=[[False, np.nan], [True, False], [False, np.nan]]
        )
    ]

    def __init__(self, target_state_series, target_state):
        self._validate_state_series(target_state_series, target_state)
        self._target_state_series = target_state_series
        self._target_state = target_state

    @staticmethod
    def _validate_state_series(state_series, state):
        assert_is_type(state_series, StateSeries)
        assert_is_type(state, State)
        if not state_series.get_state_space().has_state(state):
            raise ValueError("State space of state series does not contain state '{}'.".format(state))

    def _compute_classification_frame(self, test_state_series, test_state):
        self._validate_state_series(test_state_series, test_state)
        target_series = self._target_state_series.get_series().astype(str)
        test_series = test_state_series.get_series().astype(str)
        classification_frame = drop_consecutive_duplicates(
            pd.DataFrame(
                {
                    self._TARGET_SERIES: set_unique_index(target_series) == self._target_state.get_state_label(),
                    self._TEST_SERIES: set_unique_index(test_series) == test_state.get_state_label()
                }
            ).fillna(method='pad').dropna().astype(bool)
        )
        classification_frame[self._TIMEDELTA_SERIES] = compute_timedelta_series(classification_frame.index)
        return classification_frame

    @classmethod
    def _compute_statistic(cls, classification_frame, condition):
        if not classification_frame.empty:
            timedelta_series = classification_frame[cls._TIMEDELTA_SERIES].loc[condition]
            statistic = timedelta_series.sum().to_pytimedelta()
        else:
            statistic = datetime.timedelta(0)
        return statistic

    @classmethod
    def _compute_true_positive(cls, classification_frame):
        true_positive = cls._compute_statistic(
            classification_frame,
            classification_frame[cls._TARGET_SERIES].values & classification_frame[cls._TEST_SERIES].values
        )
        return true_positive

    @classmethod
    def _compute_true_negative(cls, classification_frame):
        true_negative = cls._compute_statistic(
            classification_frame,
            ~classification_frame[cls._TARGET_SERIES].values & ~classification_frame[cls._TEST_SERIES].values
        )
        return true_negative

    @classmethod
    def _compute_false_positive(cls, classification_frame):
        false_positive = cls._compute_statistic(
            classification_frame,
            ~classification_frame[cls._TARGET_SERIES].values & classification_frame[cls._TEST_SERIES].values
        )
        return false_positive

    @classmethod
    def _compute_false_negative(cls, classification_frame):
        false_negative = cls._compute_statistic(
            classification_frame,
            classification_frame[cls._TARGET_SERIES].values & ~classification_frame[cls._TEST_SERIES].values
        )
        return false_negative

    @classmethod
    def _compute_pattern_intervals(cls, classification_frame, patterns):
        pattern_intervals = []
        if not classification_frame.empty:
            for index in range(len(classification_frame)):
                for pattern in patterns:
                    if index >= len(pattern) - 1:
                        sample_frame = classification_frame[pattern.columns].iloc[index - len(pattern) + 1:index + 1]
                        if ((sample_frame.values == pattern.values) | pattern.isnull()).all().all():
                            # Difference between last and (length of pattern - 2) before last timestamp
                            pattern_interval = sample_frame.index[-1] - sample_frame.index[1 - len(pattern)]
                            pattern_intervals.append(pattern_interval.to_pytimedelta())
                            break
        return pattern_intervals

    @staticmethod
    def _flip_patterns(patterns, flip_boolean, flip_label):
        flipped_patterns = [pattern.copy() for pattern in patterns]
        for index, pattern in enumerate(flipped_patterns):
            if flip_boolean:
                pattern = pattern.applymap(lambda x: np.nan if np.isnan(x) else not x)
            if flip_label:
                pattern.columns = reversed(pattern.columns)
            flipped_patterns[index] = pattern
        return flipped_patterns

    @classmethod
    def _compute_transition_offsets(cls, classification_frame, flip_boolean, flip_label):
        patterns = cls._flip_patterns(cls._TRANSITION_OFFSETS_PATTERNS, flip_boolean, flip_label)
        transition_offsets = cls._compute_pattern_intervals(classification_frame, patterns)
        return transition_offsets

    @classmethod
    def _compute_positive_transition_delays(cls, classification_frame):
        positive_transition_delays = cls._compute_transition_offsets(
            classification_frame=classification_frame,
            flip_boolean=False,
            flip_label=False
        )
        return positive_transition_delays

    @classmethod
    def _compute_negative_transition_delays(cls, classification_frame):
        negative_transition_delays = cls._compute_transition_offsets(
            classification_frame=classification_frame,
            flip_boolean=True,
            flip_label=False
        )
        return negative_transition_delays

    @classmethod
    def _compute_positive_transition_advances(cls, classification_frame):
        positive_transition_advances = cls._compute_transition_offsets(
            classification_frame=classification_frame,
            flip_boolean=False,
            flip_label=True
        )
        return positive_transition_advances

    @classmethod
    def _compute_negative_transition_advances(cls, classification_frame):
        negative_transition_advances = cls._compute_transition_offsets(
            classification_frame=classification_frame,
            flip_boolean=True,
            flip_label=True
        )
        return negative_transition_advances

    @classmethod
    def _compute_offset_intervals(cls, classification_frame, flip_boolean, flip_label):
        patterns = cls._flip_patterns(cls._OFFSET_INTERVALS_PATTERNS, flip_boolean, flip_label)
        offset_intervals = cls._compute_pattern_intervals(classification_frame, patterns)
        return offset_intervals

    @classmethod
    def _compute_missed_positive_intervals(cls, classification_frame):
        missed_positive_intervals = cls._compute_offset_intervals(
            classification_frame=classification_frame,
            flip_boolean=False,
            flip_label=False
        )
        return missed_positive_intervals

    @classmethod
    def _compute_missed_negative_intervals(cls, classification_frame):
        missed_negative_intervals = cls._compute_offset_intervals(
            classification_frame=classification_frame,
            flip_boolean=True,
            flip_label=False
        )
        return missed_negative_intervals

    @classmethod
    def _compute_false_positive_intervals(cls, classification_frame):
        false_positive_intervals = cls._compute_offset_intervals(
            classification_frame=classification_frame,
            flip_boolean=False,
            flip_label=True
        )
        return false_positive_intervals

    @classmethod
    def _compute_false_negative_intervals(cls, classification_frame):
        false_negative_intervals = cls._compute_offset_intervals(
            classification_frame=classification_frame,
            flip_boolean=True,
            flip_label=True
        )
        return false_negative_intervals

    def compute_diagnostic_test_results(self, test_state_series, test_state):
        classification_frame = self._compute_classification_frame(test_state_series, test_state)
        diagnostic_test_results = DiagnosticTestResults(
            target_state_series=self._target_state_series,
            test_state_series=test_state_series,
            target_state=self._target_state,
            true_positive=self._compute_true_positive(classification_frame),
            true_negative=self._compute_true_negative(classification_frame),
            false_positive=self._compute_false_positive(classification_frame),
            false_negative=self._compute_false_negative(classification_frame),
            positive_transition_delays=self._compute_positive_transition_delays(classification_frame),
            negative_transition_delays=self._compute_negative_transition_delays(classification_frame),
            positive_transition_advances=self._compute_positive_transition_advances(classification_frame),
            negative_transition_advances=self._compute_negative_transition_advances(classification_frame),
            missed_positive_intervals=self._compute_missed_positive_intervals(classification_frame),
            missed_negative_intervals=self._compute_missed_negative_intervals(classification_frame),
            false_positive_intervals=self._compute_false_positive_intervals(classification_frame),
            false_negative_intervals=self._compute_false_negative_intervals(classification_frame)
        )
        return diagnostic_test_results

    def get_target_state_series(self):
        return self._target_state_series

    def get_target_state(self):
        return self._target_state
