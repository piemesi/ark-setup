from abc import ABCMeta

from .diagnostic_test_results import DiagnosticTestResults
from ...validation.type_validation import assert_is_type


class AbstractResultsAnalysis(object):
    __metaclass__ = ABCMeta

    def __init__(self, experiment_id, device_diagnostic_test_results=None):
        if device_diagnostic_test_results is not None:
            assert_is_type(device_diagnostic_test_results, DiagnosticTestResults)
        assert_is_type(experiment_id, (int, basestring))
        self._experiment_id = experiment_id
        self._device_diagnostic_test_results = device_diagnostic_test_results

    def __repr__(self):
        return "<{} experiment_id={}>".format(self.__class__.__name__, self._experiment_id)

    def get_device_diagnostic_test_results(self):
        return self._device_diagnostic_test_results
