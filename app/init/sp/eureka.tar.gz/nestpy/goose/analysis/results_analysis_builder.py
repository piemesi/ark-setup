from . import DiagnosticTester, DiagnosticTestResultsCollection
from .abstract_results_analysis import AbstractResultsAnalysis
from .results_analyses import ValidationResultsAnalysis
from ..building.abstract_object_builder import AbstractObjectBuilder
from ..results.results.validation_results import ValidationResults
from ..states import State, StateSpace, StateSeries
from ..states.state_series_.auto_away_state_series_ import DeviceAutoAwayStateSeries
from ..states.state_spaces import AUTO_AWAY_STATE_SPACE, OCCUPANCY_STATE_SPACE
from ...validation.type_validation import assert_is_type


OCCUPANCY_VALIDATION_RESULTS_ANALYSIS_BUILDER_CONFIG = dict(
    object_cls=ValidationResultsAnalysis,
    target_state_space=OCCUPANCY_STATE_SPACE,
    target_state=OCCUPANCY_STATE_SPACE.get_vacant_state(),
)


class ResultsAnalysisBuilder(AbstractObjectBuilder):

    def _get_object_base_cls(self):
        return AbstractResultsAnalysis

    def _get_builder_config_types(self):
        return dict(
            target_state_space=StateSpace,
            target_state=State,
        )

    def _validate_target_state_series(self, target_state_series):
        assert_is_type(target_state_series, StateSeries)
        if target_state_series.get_state_space() != self._builder_config['target_state_space']:
            raise ValueError("State space of state series needs to be equal to '{}'.".format(
                self._builder_config['target_state_space']))

    def build(self, results, experiment_id):
        assert_is_type(results, ValidationResults)
        if results.get_ground_truth_state_series():
            target_state_series = results.get_ground_truth_state_series()
        else:
            target_state_series = results.get_estimated_truth_state_series()
        self._validate_target_state_series(target_state_series)
        application_processor_results = results.get_application_processor_results()
        application_processor_results_collection = results.get_application_processor_results_collection()
        device_auto_away_state_series = results.get_device_auto_away_state_series()
        diagnostic_tester = DiagnosticTester(
            target_state_series,
            self._builder_config['target_state']
        )
        auto_away_state = AUTO_AWAY_STATE_SPACE.get_auto_away_state()
        goose_diagnostic_test_results = diagnostic_tester.compute_diagnostic_test_results(
            application_processor_results.get_state_series(),
            auto_away_state)
        goose_diagnostic_test_results_list = []
        for application_processor_results in (
                application_processor_results_collection.get_application_processor_results_list()
        ):
            goose_diagnostic_test_results_list.append(
                diagnostic_tester.compute_diagnostic_test_results(
                    application_processor_results.get_state_series(),
                    auto_away_state
                )
            )
        goose_diagnostic_test_results_collection = DiagnosticTestResultsCollection(goose_diagnostic_test_results_list)
        if device_auto_away_state_series is not None:
            assert_is_type(device_auto_away_state_series, DeviceAutoAwayStateSeries)
            device_diagnostic_test_results = diagnostic_tester.compute_diagnostic_test_results(
                device_auto_away_state_series,
                auto_away_state
            )
        else:
            device_diagnostic_test_results = None
        results_analysis = self._object_cls(
            device_diagnostic_test_results=device_diagnostic_test_results,
            goose_diagnostic_test_results=goose_diagnostic_test_results,
            goose_diagnostic_test_results_collection=goose_diagnostic_test_results_collection,
            experiment_id=experiment_id,
        )
        return results_analysis
