import datetime
import math
import pandas as pd
import numpy as np

from ..states import State, StateSeries
from ...validation.type_validation import assert_is_type, assert_list_of_type


class DiagnosticTestResults(object):

    def __init__(
            self,
            target_state_series,
            test_state_series,
            target_state,
            true_positive,
            true_negative,
            false_positive,
            false_negative,
            positive_transition_delays,
            negative_transition_delays,
            positive_transition_advances,
            negative_transition_advances,
            missed_positive_intervals,
            missed_negative_intervals,
            false_positive_intervals,
            false_negative_intervals
    ):
        assert_list_of_type([target_state_series, test_state_series], StateSeries)
        assert_is_type(target_state, State)
        assert_list_of_type(
            [
                true_positive,
                true_negative,
                false_positive,
                false_negative
            ],
            (datetime.timedelta, float)
        )
        for transition_delays in [
            positive_transition_delays,
            negative_transition_delays,
            positive_transition_advances,
            negative_transition_advances,
            missed_positive_intervals,
            missed_negative_intervals,
            false_positive_intervals,
            false_negative_intervals
        ]:
            assert_list_of_type(transition_delays, datetime.timedelta)
        self._target_state_series = target_state_series
        self._test_state_series = test_state_series
        self._target_state = target_state
        self._true_positive = true_positive
        self._true_negative = true_negative
        self._false_positive = false_positive
        self._false_negative = false_negative
        self._positive_transition_delays = positive_transition_delays
        self._negative_transition_delays = negative_transition_delays
        self._positive_transition_advances = positive_transition_advances
        self._negative_transition_advances = negative_transition_advances
        self._missed_positive_intervals = missed_positive_intervals
        self._missed_negative_intervals = missed_negative_intervals
        self._false_positive_intervals = false_positive_intervals
        self._false_negative_intervals = false_negative_intervals

    @staticmethod
    def _divide(numerator, denominator):
        try:
            return float(numerator) / float(denominator)
        except ZeroDivisionError:
            return np.nan

    def get_target_state_series(self):
        return self._target_state_series

    def get_test_state_series(self):
        return self._test_state_series

    def get_target_state(self):
        return self._target_state

    def get_target_base_rate(self):
        return self._divide(
            (self._true_positive + self._false_negative).total_seconds(),
            (self._true_positive + self._true_negative + self._false_positive + self._false_negative).total_seconds()
        )

    def get_test_base_rate(self):
        return self._divide(
            (self._true_positive + self._false_positive).total_seconds(),
            (self._true_positive + self._true_negative + self._false_positive + self._false_negative).total_seconds()
        )

    def get_true_positive_rate(self):
        return self._divide(
            self._true_positive.total_seconds(),
            (self._true_positive + self._false_negative).total_seconds()
        )

    def get_true_negative_rate(self):
        return self._divide(
            self._true_negative.total_seconds(),
            (self._true_negative + self._false_positive).total_seconds()
        )

    def get_false_positive_rate(self):
        return self._divide(
            self._false_positive.total_seconds(),
            (self._false_positive + self._true_negative).total_seconds()
        )

    def get_false_negative_rate(self):
        return self._divide(
            self._false_negative.total_seconds(),
            (self._false_negative + self._true_positive).total_seconds()
        )

    def get_positive_predicted_value(self):
        return self._divide(
            self._true_positive.total_seconds(),
            (self._true_positive + self._false_positive).total_seconds()
        )

    def get_accuracy(self):
        return self._divide(
            (self._true_positive + self._true_negative).total_seconds(),
            (self._true_positive + self._true_negative + self._false_negative + self._false_positive).total_seconds()
        )

    def get_f1_score(self):
        return self._divide(
            (self._true_positive + self._true_positive).total_seconds(),
            (self._true_positive + self._true_positive + self._false_positive + self._false_negative).total_seconds()
        )

    def get_matthews_correlation_coefficient(self):
        return self._divide(
            self._true_positive.total_seconds() * self._true_negative.total_seconds() -
            self._false_positive.total_seconds() * self._false_negative.total_seconds(),
            math.sqrt(
                (self._true_positive + self._false_positive).total_seconds() *
                (self._true_positive + self._false_negative).total_seconds() *
                (self._true_negative + self._false_positive).total_seconds() *
                (self._true_negative + self._false_negative).total_seconds()
            )
        )

    def get_positive_transition_delays(self):
        return self._positive_transition_delays

    def get_negative_transition_delays(self):
        return self._negative_transition_delays

    def get_positive_transition_advances(self):
        return self._positive_transition_advances

    def get_negative_transition_advances(self):
        return self._negative_transition_advances

    def get_missed_positive_intervals(self):
        return self._missed_positive_intervals

    def get_missed_negative_intervals(self):
        return self._missed_negative_intervals

    def get_false_positive_intervals(self):
        return self._false_positive_intervals

    def get_false_negative_intervals(self):
        return self._false_negative_intervals

    def get_confusion_matrix(self):
        labels = [label.format(self._target_state.get_state_label()) for label in "{}", "Not {}"]
        return pd.DataFrame(
            index=labels,
            columns=labels,
            data=[
                [self._true_positive.total_seconds(), self._false_negative.total_seconds()],
                [self._false_positive.total_seconds(), self._true_negative.total_seconds()],
            ]
        )
