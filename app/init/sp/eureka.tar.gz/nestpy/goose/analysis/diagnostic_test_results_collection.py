from abc import ABCMeta

from .diagnostic_test_results import DiagnosticTestResults
from ...validation.type_validation import assert_list_of_type


class DiagnosticTestResultsCollection(object):
    __metaclass__ = ABCMeta

    def __init__(self, diagnostic_test_results_list):
        assert_list_of_type(diagnostic_test_results_list, DiagnosticTestResults)
        self._diagnostic_test_results_list = diagnostic_test_results_list

    def __repr__(self):
        return "<{}>".format(self.__class__.__name__)

    def get_diagnostic_test_results_list(self):
        return self._diagnostic_test_results_list
