from abc import ABCMeta

from ..diagnostic_test_results import DiagnosticTestResults
from ..diagnostic_test_results_collection import DiagnosticTestResultsCollection
from ..abstract_results_analysis import AbstractResultsAnalysis
from ....validation.type_validation import assert_is_type


class ValidationResultsAnalysis(AbstractResultsAnalysis):
    __metaclass__ = ABCMeta

    def __init__(self, goose_diagnostic_test_results, goose_diagnostic_test_results_collection, *args, **kwargs):
        super(ValidationResultsAnalysis, self).__init__(*args, **kwargs)
        assert_is_type(goose_diagnostic_test_results, DiagnosticTestResults)
        assert_is_type(goose_diagnostic_test_results_collection, DiagnosticTestResultsCollection)
        self._goose_diagnostic_test_results = goose_diagnostic_test_results
        self._goose_diagnostic_test_results_collection = goose_diagnostic_test_results_collection

    def get_goose_diagnostic_test_results(self):
        return self._goose_diagnostic_test_results

    def get_goose_diagnostic_test_results_collection(self):
        return self._goose_diagnostic_test_results_collection
