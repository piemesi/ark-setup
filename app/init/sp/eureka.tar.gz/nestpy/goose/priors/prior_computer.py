import logging
import pandas as pd

from .prior_cache import PriorCache
from ..data_collection.data_collection_builders.structure_data_collection_builder import StructureDataCollectionBuilder
from ..environment.workspace_builder import WorkspaceBuilder
from ..models.sensor_model_collection_builder import SensorModelCollectionBuilder
from ..models.sensor_model_prior_collection_builder import SensorModelPriorCollectionBuilder
from ..models.model_builders.transition_model_builder import TransitionModelBuilder
from ..models.model_builders.transition_model_prior_builder import TransitionModelPriorBuilder
from ..sensors.sensor_events_collection_builder import SensorEventsCollectionBuilder
from ..states.state_series_builders import EstimatedTruthStateSeriesBuilder
from ...scriptutils import parallelize
from ...validation.type_validation import assert_is_type, assert_type_in
from ...validation.datetime_validation import assert_valid_start_and_end_dates

logger = logging.getLogger(__name__)


class PriorComputer(object):

    def __init__(
            self,
            prior_id,
            start_date,
            end_date,
            structures,
            workspace_builder,
            data_collection_builder,
            sensor_events_collection_builder,
            state_series_builder,
            transition_model_builder,
            transition_model_prior_builder,
            sensor_model_collection_builder,
            sensor_model_prior_collection_builder
    ):
        assert_type_in(prior_id, [basestring, int])
        assert_valid_start_and_end_dates(start_date, end_date)
        assert_is_type(workspace_builder, WorkspaceBuilder)
        assert_is_type(data_collection_builder, StructureDataCollectionBuilder)
        assert_is_type(sensor_events_collection_builder, SensorEventsCollectionBuilder)
        assert_is_type(state_series_builder, EstimatedTruthStateSeriesBuilder)
        assert_is_type(transition_model_builder, TransitionModelBuilder)
        assert_is_type(transition_model_prior_builder, TransitionModelPriorBuilder)
        assert_is_type(sensor_model_collection_builder, SensorModelCollectionBuilder)
        assert_is_type(sensor_model_prior_collection_builder, SensorModelPriorCollectionBuilder)
        self._validate_structures(structures)
        self._prior_id = prior_id
        self._start_date = start_date
        self._end_date = end_date
        self._structures = structures
        self._workspace_builder = workspace_builder
        self._data_collection_builder = data_collection_builder
        self._sensor_events_collection_builder = sensor_events_collection_builder
        self._state_series_builder = state_series_builder
        self._transition_model_builder = transition_model_builder
        self._transition_model_prior_builder = transition_model_prior_builder
        self._sensor_model_collection_builder = sensor_model_collection_builder
        self._sensor_model_prior_collection_builder = sensor_model_prior_collection_builder
        self._workspace = self._build_workspace()
        self._prior_cache = self._build_prior_cache()

    def __repr__(self):
        return "<{}>".format(self.__class__.__name__)

    def __hash__(self):
        return hash(self._key())

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self._key() == other._key()

    def __ne__(self, other):
        return not self.__eq__(other)

    def _key(self):
        return (
            self._sensor_events_collection_builder,
            self._state_series_builder,
            self._transition_model_builder,
            self._transition_model_prior_builder,
            self._sensor_model_collection_builder,
            self._sensor_model_prior_collection_builder
        )

    @staticmethod
    def _validate_structures(structures):
        assert_is_type(structures, pd.DataFrame)
        for column_name in ['structure_id', 'tier']:
            if column_name not in structures.columns:
                raise ValueError("Structures must contain a column named: '{}'".format(column_name))

    def serial_compute_and_store_priors(self):
        for kwargs in self._structures.to_dict(orient='records'):
            self._build_and_train_and_store_models(kwargs)
        self._incorporate_models_and_store_priors()

    def parallel_compute_and_store_priors(self, threads=10):
        parallelize(self._structures.to_dict(orient='records'), threads, self._build_and_train_and_store_models)
        self._incorporate_models_and_store_priors()

    def _build_workspace(self):
        workspace = self._workspace_builder.build(workspace_id=self._prior_id)
        return workspace

    def _build_data_collection(self, structure_id, tier):
        data_collection = self._data_collection_builder.build(
            start_date=self._start_date,
            end_date=self._end_date,
            structure_id=structure_id,
            tier=tier
        )
        return data_collection

    def _build_sensor_events_collection(self, data_collection):
        sensor_events_collection = self._sensor_events_collection_builder.build(
            diamond_devices=data_collection.get_diamond_devices(),
            diamond_device_histories=data_collection.get_diamond_device_histories(),
            flintstone_devices=data_collection.get_flintstone_devices(),
            flintstone_device_histories=data_collection.get_flintstone_device_histories(),
            mobile_devices=data_collection.get_mobile_devices(),
            mobile_device_histories=data_collection.get_mobile_device_histories(),
            pinna_devices=data_collection.get_pinna_devices(),
            pinna_device_histories=data_collection.get_pinna_device_histories(),
            quartz_devices=data_collection.get_quartz_devices(),
            quartz_device_histories=data_collection.get_quartz_device_histories(),
            topaz_devices=data_collection.get_topaz_devices(),
            topaz_device_histories=data_collection.get_topaz_device_histories(),
        )
        return sensor_events_collection

    def _build_state_series(self, sensor_events_collection):
        state_series = self._state_series_builder.build(sensor_events_collection)
        return state_series

    def _build_and_train_transition_model(self, state_series):
        transition_model = self._transition_model_builder.build()
        transition_model.train(state_series)
        return transition_model

    def _build_and_train_sensor_model_collection(self, state_series, sensor_events_collection):
        sensors = sensor_events_collection.get_sensors()
        sensor_model_collection = self._sensor_model_collection_builder.build(sensors)
        sensor_model_collection.train(state_series, sensor_events_collection)
        return sensor_model_collection

    def _build_and_train_and_store_models(self, kwargs):
        try:
            data_collection = self._build_data_collection(**kwargs)
            sensor_events_collection = self._build_sensor_events_collection(data_collection)
            estimated_truth_state_series = self._build_state_series(sensor_events_collection)
            transition_model = self._build_and_train_transition_model(estimated_truth_state_series)
            sensor_model_collection = self._build_and_train_sensor_model_collection(
                state_series=estimated_truth_state_series,
                sensor_events_collection=sensor_events_collection
            )
            self._prior_cache.cache_transition_model(kwargs['structure_id'], transition_model)
            self._prior_cache.cache_sensor_model_collection(kwargs['structure_id'], sensor_model_collection)
        except Exception, e:
            logger.exception(e)

    def _build_prior_cache(self):
        return PriorCache(self._workspace)

    def _build_transition_model_prior(self):
        transition_model_prior = self._transition_model_prior_builder.build()
        return transition_model_prior

    def _build_sensor_model_prior_collection(self):
        sensor_model_prior_collection = self._sensor_model_prior_collection_builder.build()
        return sensor_model_prior_collection

    def _incorporate_models_and_store_priors(self):
        transition_model_prior = self._build_transition_model_prior()
        sensor_model_prior_collection = self._build_sensor_model_prior_collection()
        for structure_id in self._structures.structure_id.tolist():
            transition_model = self._prior_cache.load_transition_model(structure_id)
            if transition_model is not None:
                transition_model_prior.incorporate_transition_models([transition_model])
            sensor_model_collection = self._prior_cache.load_sensor_model_collection(structure_id)
            if sensor_model_collection is not None:
                sensor_model_prior_collection.incorporate_sensor_model_collection(sensor_model_collection)
        self._prior_cache.cache_transition_model_prior(transition_model_prior)
        for sensor_model_prior in sensor_model_prior_collection.get_sensor_model_priors():
            self._prior_cache.cache_sensor_model_prior(sensor_model_prior)

    def get_workspace(self):
        return self._workspace

    def get_start_date(self):
        return self._start_date

    def get_end_date(self):
        return self._end_date

    def get_structures(self):
        return self._structures
