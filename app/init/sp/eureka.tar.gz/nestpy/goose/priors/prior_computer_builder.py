from .prior_computer import PriorComputer
from ..building import AbstractObjectBuilder
from ..data_collection.data_collection_builders.structure_data_collection_builder import (
    OCCUPANCY_STRUCTURE_DATA_COLLECTION_BUILDER_CONFIG,
    StructureDataCollectionBuilder
)
from ..models.sensor_model_collection_builder import (
    SensorModelCollectionBuilder,
    OCCUPANCY_ALL_SENSOR_MODEL_COLLECTION_BUILDER_CONFIG
)
from ..models.sensor_model_prior_collection_builder import (
    SensorModelPriorCollectionBuilder,
    OCCUPANCY_ALL_SENSOR_MODEL_PRIOR_COLLECTION_BUILDER_CONFIG
)
from ..models.model_builders.transition_model_builder import (
    TransitionModelBuilder,
    OCCUPANCY_MARKOV_TRANSITION_MODEL_BUILDER_CONFIG
)
from ..models.model_builders.transition_model_prior_builder import (
    TransitionModelPriorBuilder,
    OCCUPANCY_MARKOV_TRANSITION_MODEL_PRIOR_BUILDER_CONFIG
)
from ..sensors.sensor_events_collection_builder import (
    SensorEventsCollectionBuilder,
    OCCUPANCY_SENSOR_EVENTS_COLLECTION_BUILDER_CONFIG
)
from ..states.state_series_builders.estimated_truth_state_series_builder import (
    EstimatedTruthStateSeriesBuilder,
    OCCUPANCY_ESTIMATED_TRUTH_STATE_SERIES_BUILDER_CONFIG
)


OCCUPANCY_PRIOR_COMPUTER_BUILDER_CONFIG = dict(
    object_cls=PriorComputer,
    data_collection_builder=StructureDataCollectionBuilder(
        **OCCUPANCY_STRUCTURE_DATA_COLLECTION_BUILDER_CONFIG
    ),
    sensor_events_collection_builder=SensorEventsCollectionBuilder(
        **OCCUPANCY_SENSOR_EVENTS_COLLECTION_BUILDER_CONFIG
    ),
    state_series_builder=EstimatedTruthStateSeriesBuilder(
        **OCCUPANCY_ESTIMATED_TRUTH_STATE_SERIES_BUILDER_CONFIG
    ),
    transition_model_builder=TransitionModelBuilder(
        **OCCUPANCY_MARKOV_TRANSITION_MODEL_BUILDER_CONFIG
    ),
    transition_model_prior_builder=TransitionModelPriorBuilder(
        **OCCUPANCY_MARKOV_TRANSITION_MODEL_PRIOR_BUILDER_CONFIG
    ),
    sensor_model_collection_builder=SensorModelCollectionBuilder(
        **OCCUPANCY_ALL_SENSOR_MODEL_COLLECTION_BUILDER_CONFIG
    ),
    sensor_model_prior_collection_builder=SensorModelPriorCollectionBuilder(
        **OCCUPANCY_ALL_SENSOR_MODEL_PRIOR_COLLECTION_BUILDER_CONFIG
    ),
)


class PriorComputerBuilder(AbstractObjectBuilder):

    def _get_object_base_cls(self):
        return PriorComputer

    def _get_builder_config_types(self):
        return dict(
            data_collection_builder=StructureDataCollectionBuilder,
            sensor_events_collection_builder=SensorEventsCollectionBuilder,
            state_series_builder=EstimatedTruthStateSeriesBuilder,
            transition_model_builder=TransitionModelBuilder,
            transition_model_prior_builder=TransitionModelPriorBuilder,
            sensor_model_collection_builder=SensorModelCollectionBuilder,
            sensor_model_prior_collection_builder=SensorModelPriorCollectionBuilder,
        )
