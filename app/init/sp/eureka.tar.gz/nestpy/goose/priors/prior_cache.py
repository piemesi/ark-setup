import dill
import os
import pandas as pd

from ..environment.workspace import Workspace
from ..models.models.abstract_transition_model import AbstractTransitionModel
from ..models.models.abstract_transition_model_prior import AbstractTransitionModelPrior
from ..models.models.abstract_sensor_model_prior import AbstractSensorModelPrior
from ..models.sensor_model_collection import SensorModelCollection
from ...validation.type_validation import assert_is_type, assert_is_subclass
from ...fileutils import resource_path


class PriorCache(object):

    _PRIORS = "priors"
    _TRANSITION_MODEL = "transition_model"
    _TRANSITION_MODEL_PRIORS = "transition_model_priors"
    _SENSOR_MODEL_COLLECTION = "sensor_model_collection"
    _SENSOR_MODEL_PRIORS = "sensor_model_priors"

    def __init__(self, workspace):
        assert_is_type(workspace, Workspace)
        self._workspace = workspace

    @staticmethod
    def _initialize_path(path):
        if not os.path.exists(path):
            os.makedirs(path)

    @staticmethod
    def _cache_object(path, obj):
        dill.dump(obj, open(path, "wb"))

    @staticmethod
    def _load_object(path):
        if os.path.exists(path):
            obj = pd.read_pickle(path)
        else:
            obj = None
        return obj

    @classmethod
    def _get_prior_cache_path(cls, file_name, *path_args):
        prior_cache_path = os.path.join(resource_path("goose", "priors"), *path_args)
        cls._initialize_path(prior_cache_path)
        return os.path.join(prior_cache_path, "{}.pickle".format(file_name))

    @classmethod
    def cache_transition_model_prior(cls, transition_model_prior):
        assert_is_type(transition_model_prior, AbstractTransitionModelPrior)
        cls._cache_object(
            path=cls._get_prior_cache_path(transition_model_prior.__class__.__name__, cls._TRANSITION_MODEL_PRIORS),
            obj=transition_model_prior
        )

    @classmethod
    def load_transition_model_prior(cls, transition_model_prior_cls):
        assert_is_subclass(transition_model_prior_cls, AbstractTransitionModelPrior)
        return cls._load_object(
            path=cls._get_prior_cache_path(transition_model_prior_cls.__name__, cls._TRANSITION_MODEL_PRIORS)
        )

    @classmethod
    def cache_sensor_model_prior(cls, sensor_model_prior):
        assert_is_type(sensor_model_prior, AbstractSensorModelPrior)
        cls._cache_object(
            path=cls._get_prior_cache_path(
                "{}-{}".format(
                    sensor_model_prior.__class__.__name__,
                    sensor_model_prior.get_featurizer().__class__.__name__
                ),
                cls._SENSOR_MODEL_PRIORS
            ),
            obj=sensor_model_prior
        )

    @classmethod
    def load_sensor_model_prior(cls, sensor_model_prior_cls, featurizer_cls):
        assert_is_subclass(sensor_model_prior_cls, AbstractSensorModelPrior)
        return cls._load_object(
            path=cls._get_prior_cache_path(
                "{}-{}".format(sensor_model_prior_cls.__name__, featurizer_cls.__name__),
                cls._SENSOR_MODEL_PRIORS
            )
        )

    def _get_model_cache_path(self, file_name, *path_args):
        return os.path.join(self._workspace.get_path(self._PRIORS, *path_args), "{}.pickle".format(file_name))

    def cache_transition_model(self, identifier, transition_model):
        assert_is_type(transition_model, AbstractTransitionModel)
        self._cache_object(self._get_model_cache_path(self._TRANSITION_MODEL, str(identifier)), transition_model)

    def load_transition_model(self, identifier):
        return self._load_object(self._get_model_cache_path(self._TRANSITION_MODEL, str(identifier)))

    def cache_sensor_model_collection(self, identifier, sensor_model_collection):
        assert_is_type(sensor_model_collection, SensorModelCollection)
        self._cache_object(
            path=self._get_model_cache_path(self._SENSOR_MODEL_COLLECTION, str(identifier)),
            obj=sensor_model_collection
        )

    def load_sensor_model_collection(self, identifier):
        return self._load_object(self._get_model_cache_path(self._SENSOR_MODEL_COLLECTION, str(identifier)))

    def get_workspace(self):
        return self._workspace
