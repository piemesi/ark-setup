import datetime
import math
import pandas as pd

from ..abstract_featurizer import AbstractFeaturizer
from ...sensors.sensor_types.boolean_sensor_types import ActivitySensorType
from ....generators.datetime_generators import datetime_range_generator
from ....manipulators.series_manipulators import compute_timedelta_series
from ....validation.type_validation import assert_list_of_type


class GapFeaturizer(AbstractFeaturizer):

    _SENSOR_TYPE_CLS = ActivitySensorType

    def __init__(self, gap_time, gap_time_limit):
        assert_list_of_type([gap_time, gap_time_limit], datetime.timedelta)
        self._gap_time = gap_time
        self._gap_time_limit = gap_time_limit

    @property
    def _keys(self):
        return self._gap_time, self._gap_time_limit

    def _featurize_sensor_events(self, sensor_events):
        series = sensor_events.get_series()
        if not series.empty:
            true_series = series[series]
            if not series[-1]:
                timedelta_series = compute_timedelta_series(true_series.append(series[-1:]).index)[:-1]
            else:
                timedelta_series = compute_timedelta_series(true_series.index)
            gap_dict = {}
            for index, timedelta in timedelta_series.iteritems():
                index_range = list(
                    datetime_range_generator(
                        start_datetime=index,
                        end_datetime=index + timedelta,
                        interval=self._gap_time,
                        closed_left=True,
                        closed_right=(timedelta.total_seconds() == 0)
                    )
                )
                gap_dict.update({index: gap for index, gap in zip(index_range, range(len(index_range)))})
            gap_series = pd.Series(gap_dict, dtype="int").sort_index()
        else:
            gap_series = series.astype(int)
        feature_series = gap_series[gap_series <= self.get_max_allowed_gap()]
        return feature_series

    def _featurize_sensor_states(self, sensor_states, previous_update_timestamp, current_update_timestamp):
        online_sensor_states = filter(
            lambda sensor_state: all(
                [
                    sensor_state.is_online(previous_update_timestamp),
                    not sensor_state.get_transition_enabled_timestamp() is None
                ]
            ),
            sensor_states
        )
        gap_dict = {}
        if online_sensor_states:
            transition_enabled_timestamp = max(
                map(
                    lambda sensor_state: sensor_state.get_transition_enabled_timestamp(),
                    online_sensor_states
                )
            )
            if transition_enabled_timestamp >= previous_update_timestamp:
                number_of_start_gaps = 0
                gap_start_datetime = transition_enabled_timestamp
            else:
                timedelta = previous_update_timestamp - transition_enabled_timestamp
                number_of_start_gaps = int(math.ceil(timedelta.total_seconds() / self._gap_time.total_seconds()))
                gap_start_datetime = transition_enabled_timestamp + number_of_start_gaps * self._gap_time
            if gap_start_datetime > current_update_timestamp:
                index_range = []
            else:
                index_range = list(
                    datetime_range_generator(
                        start_datetime=gap_start_datetime,
                        end_datetime=current_update_timestamp,
                        interval=self._gap_time,
                        closed_left=(gap_start_datetime != previous_update_timestamp),
                        closed_right=True
                    )
                )
            if all(map(lambda sensor_state: sensor_state.is_disabled(), online_sensor_states)):
                transition_disabled_timestamp = max(
                    map(
                        lambda sensor_state: sensor_state.get_transition_disabled_timestamp(),
                        online_sensor_states
                    )
                )
                timedelta = transition_disabled_timestamp - transition_enabled_timestamp
                number_of_diff_gaps = int(math.floor(timedelta.total_seconds() / self._gap_time.total_seconds()))
                gap_difference = number_of_start_gaps - number_of_diff_gaps + int(gap_start_datetime == previous_update_timestamp)
                if gap_difference >= 0:
                    gaps = range(gap_difference, len(index_range) + gap_difference)
                else:
                    gaps = abs(gap_difference) * [0] + range(len(index_range) - gap_difference)
                gap_dict.update({index: gap for index, gap in zip(index_range, gaps)})
            else:
                gap_dict.update({index: 0 for index in index_range})
        gap_dict = {
            index: gap
            for index, gap in gap_dict.items()
            if any([sensor_state.is_online(index) for sensor_state in sensor_states])
        }
        gap_series = pd.Series(gap_dict).sort_index()
        feature_series = gap_series.clip_upper(self.get_max_allowed_gap())
        time_zone = pd.Timestamp(previous_update_timestamp).tz
        if feature_series.empty or feature_series.index.tz is None:
            feature_series = feature_series.tz_localize(time_zone)
        else:
            feature_series = feature_series.tz_convert(time_zone)
        return feature_series.astype("int")

    def get_max_allowed_gap(self):
        return int(self._gap_time_limit.total_seconds() / self._gap_time.total_seconds())

    def get_gap_time(self):
        return self._gap_time
