from ..gap_featurizer import GapFeaturizer


class BooleanGapFeaturizer(GapFeaturizer):

    def _featurize_sensor_events(self, sensor_events):
        feature_series = super(BooleanGapFeaturizer, self)._featurize_sensor_events(sensor_events=sensor_events)
        return feature_series == 0

    def _featurize_sensor_states(self, sensor_states, previous_update_timestamp, current_update_timestamp):
        feature_series = super(BooleanGapFeaturizer, self)._featurize_sensor_states(
            sensor_states=sensor_states,
            previous_update_timestamp=previous_update_timestamp,
            current_update_timestamp=current_update_timestamp
        )
        return feature_series == 0
