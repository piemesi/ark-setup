import datetime
import pandas as pd

from ..abstract_featurizer import AbstractFeaturizer
from ...sensors.sensor_types.boolean_sensor_types import ActivitySensorType, PresenceSensorType
from ....generators.datetime_generators import rounded_datetime_range_generator
from ....manipulators.datetime_manipulators import ceil_datetime
from ....manipulators.series_manipulators import any_hold_resample, zero_order_hold_resample
from ....validation.type_validation import assert_is_type


class SampledBooleanFeaturizer(AbstractFeaturizer):

    _SENSOR_TYPE_CLS = (ActivitySensorType, PresenceSensorType)

    def __init__(self, sample_time):
        assert_is_type(sample_time, datetime.timedelta)
        self._sample_time = sample_time

    @property
    def _keys(self):
        return self._sample_time

    def _featurize_sensor_events(self, sensor_events):
        series = sensor_events.get_series()
        sensor_type = sensor_events.get_sensor().get_sensor_type()
        if isinstance(sensor_type, ActivitySensorType):
            feature_series = any_hold_resample(series, self._sample_time)
        elif isinstance(sensor_type, PresenceSensorType):
            feature_series = zero_order_hold_resample(series, self._sample_time)
        else:
            raise ValueError("Sensors of type '{}' are currently not supported.".format(sensor_type))
        return feature_series

    @staticmethod
    def _filter_online(sensor_states, timestamp):
        return filter(lambda sensor_state: sensor_state.is_online(timestamp), sensor_states)

    @staticmethod
    def _any_online(sensor_states, timestamp):
        return any(map(lambda sensor_state: sensor_state.is_online(timestamp), sensor_states))

    @staticmethod
    def _any_enabled(sensor_states):
        return any(map(lambda sensor_state: sensor_state.is_enabled(), sensor_states))

    @staticmethod
    def _all_disabled(sensor_states):
        return all(map(lambda sensor_state: sensor_state.is_disabled(), sensor_states))

    @staticmethod
    def _get_latest_transition_disabled_timestamp(sensor_states):
        return max(
            map(
                lambda sensor_state: sensor_state.get_transition_disabled_timestamp(),
                sensor_states
            )
        )

    @classmethod
    def _transition_enabled(cls, sensor_states, timestamp):
        return (
            cls._any_enabled(sensor_states) and
            all(
                map(
                    lambda sensor_state: sensor_state.get_transition_enabled_timestamp() == timestamp,
                    filter(lambda sensor_state: sensor_state.is_enabled(), sensor_states)
                )
            )
        )

    @classmethod
    def _transition_disabled(cls, sensor_states, timestamp):
        return (
            cls._all_disabled(sensor_states) and
            cls._get_latest_transition_disabled_timestamp(sensor_states) == timestamp
        )

    def _featurize_sensor_states(self, sensor_states, previous_update_timestamp, current_update_timestamp):
        online_sensor_states = self._filter_online(sensor_states, previous_update_timestamp)
        gap_dict = {}
        if online_sensor_states:
            ceil_previous_update_timestamp = ceil_datetime(previous_update_timestamp, self._sample_time)
            ceil_current_update_timestamp = ceil_datetime(current_update_timestamp, self._sample_time)
            timestamp_range = list(
                rounded_datetime_range_generator(
                    start_datetime=ceil_previous_update_timestamp,
                    end_datetime=ceil_current_update_timestamp,
                    interval=self._sample_time,
                    closed_left=(
                        ceil_previous_update_timestamp == ceil_current_update_timestamp and
                        (
                            self._transition_enabled(online_sensor_states, current_update_timestamp) or
                            self._transition_disabled(online_sensor_states, current_update_timestamp)
                        )
                    ),
                    closed_right=True
                )
            )
            if self._all_disabled(online_sensor_states):
                transition_disabled_timestamp = self._get_latest_transition_disabled_timestamp(online_sensor_states)
                gap_dict.update(
                    map(lambda timestamp: (timestamp, timestamp < transition_disabled_timestamp), timestamp_range)
                )
            else:
                gap_dict.update(
                    map(lambda timestamp: (timestamp, True), timestamp_range)
                )
        gap_dict = dict(
            filter(
                lambda (timestamp, value): self._any_online(online_sensor_states, timestamp),
                gap_dict.items()
            )
        )
        feature_series = pd.Series(gap_dict).sort_index()
        time_zone = pd.Timestamp(previous_update_timestamp).tz
        if feature_series.empty or feature_series.index.tz is None:
            feature_series = feature_series.tz_localize(time_zone)
        else:
            feature_series = feature_series.tz_convert(time_zone)
        return feature_series.astype("bool")

    def get_sample_time(self):
        return self._sample_time
