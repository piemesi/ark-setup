from abc import ABCMeta, abstractmethod, abstractproperty

from ...validation.type_validation import assert_is_type, assert_list_of_type


class AbstractFeaturizer(object):
    """Core abstraction of the featurizer classes.

    Featurizers are responsible for generating feature series, both in the batch and real time scenarios.
    Implementation classes should implement methods for both of these use cases.
    """
    __metaclass__ = ABCMeta

    _SENSOR_TYPE_CLS = abstractproperty()

    def __repr__(self):
        return "<{}>".format(self.__class__.__name__)

    def __hash__(self):
        return hash((self.__class__, self._keys))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self._keys == other._keys

    def __ne__(self, other):
        return not self.__eq__(other)

    @abstractproperty
    def _keys(self):
        raise NotImplementedError

    @abstractmethod
    def _featurize_sensor_events(self, sensor_events):
        raise NotImplementedError

    def featurize_sensor_events(self, sensor_events):
        """Featurizes sensor events by mapping these events to a feature series.

        Args:
            sensor_events (SensorEvents): sensor events

        Returns:
            pandas.Series: feature series
        """
        assert_is_type(sensor_events.get_sensor().get_sensor_type(), self._SENSOR_TYPE_CLS)
        return self._featurize_sensor_events(sensor_events)

    @abstractmethod
    def _featurize_sensor_states(self, sensor_states, previous_update_timestamp, current_update_timestamp):
        raise NotImplementedError

    def featurize_sensor_states(self, sensor_states, previous_update_timestamp, current_update_timestamp):
        """Featurizes sensor states by mapping these states to a feature series.

        Note that the index of the resulting feature series may or may not be within the range of the provided
        previous and current update timestamps. This behavior needs to be defined in the implementation classes.

        Args:
            sensor_states (list of AbstractSensorState): sensor states
            previous_update_timestamp (datetime.datetime): previous update timestamp
            current_update_timestamp (datetime.datetime): current update timestamp

        Returns:
            pandas.Series: feature series
        """
        sensor_types = map(lambda sensor_state: sensor_state.get_sensor().get_sensor_type(), sensor_states)
        assert_list_of_type(sensor_types, self._SENSOR_TYPE_CLS)
        return self._featurize_sensor_states(sensor_states, previous_update_timestamp, current_update_timestamp)
