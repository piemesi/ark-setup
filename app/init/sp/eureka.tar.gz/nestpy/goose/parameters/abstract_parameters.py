from abc import ABCMeta


class AbstractParameters(object):

    __metaclass__ = ABCMeta

    def __repr__(self):
        return "<{}>".format(self.__class__.__name__)

    def _key(self):
        raise NotImplementedError

    def __hash__(self):
        return hash(self._key())

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self._key() == other._key()

    def __ne__(self, other):
        return not self.__eq__(other)
