import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from abc import ABCMeta
from datetime import time
from scipy.stats import gamma

from ....converters.time_constants import HOURS_PER_DAY, MINUTES_PER_DAY, MINUTES_PER_HOUR
from ....validation.type_validation import assert_is_type


class InactivityTransitionDistribution(object):
    """
    The InactivityTransitionDistribution object describes a transition process from activity to inactivity or vice versa
    with a probabilistic model. It requires as inputs the discrete PDF to which the continuous distribution is fitted,
    the bin_size of the data and the period of the activity distribution.
    """
    __metaclass__ = ABCMeta

    _MINIMUM_VARIANCE = 10. ** 2

    def __init__(self, pdf_data, bin_size, period):
        self._from_inactivity_activity = pdf_data.index[0] > pdf_data.index[-1]
        self._edge = pdf_data.index[0]
        if self.is_transition_from_activity_to_inactivity():
            self._type = "start"
        else:
            self._type = "end"
            self._edge += bin_size
        self._series = pdf_data
        self._bin_size = bin_size
        self._period = period
        self._zero_based_mean, self._zero_based_var = self._mean_var_from_pdf(pdf_data)

    def __repr__(self):
        return "<{} ({})>".format(self.__class__.__name__, self._type)

    def _key(self):
        return (
            self._edge,
            self._period,
            self._bin_size,
            frozenset(self._series.iteritems()),
        )

    def __hash__(self):
        return hash(self._key())

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self._key() == other._key()

    def __ne__(self, other):
        return not self.__eq__(other)

    def is_transition_from_inactivity_to_activity(self):
        return self._from_inactivity_activity

    def is_transition_from_activity_to_inactivity(self):
        return not self._from_inactivity_activity

    def get_bin_size(self):
        return self._bin_size

    def get_edge(self):
        return self._edge

    def get_period(self):
        return self._period

    def get_mean(self):
        """
        Compute the mean of the InacitivtyDistribution

        Returns:
            float representing the mean of the distribution

        """
        if self._zero_based_mean == 0 and self._zero_based_var == self._MINIMUM_VARIANCE:
            return 0.
        elif not self._from_inactivity_activity:
            mean = self._edge + self._get_gamma(
                self._zero_based_mean,
                self._zero_based_var
            ).mean()
        else:
            mean = self._edge - self._get_gamma(
                self._zero_based_mean,
                self._zero_based_var
            ).mean()
        return mean % self._period

    def get_edge_based_series(self):
        """
        Returns:
            a pandas Series where the first index is the edge of the InactivityTransitionDistribution
        """
        return self._series

    def get_zero_based_series(self):
        """
        Returns:
            a pandas Series where the first index is 0
        """
        return self._zero_base_series(self._series)

    def _mean_var_from_pdf(self, discrete_pdf):
        zero_based_discrete_pdf = self._zero_base_series(discrete_pdf)
        centered_discrete_pdf = self._center_index(zero_based_discrete_pdf, self._bin_size)
        mean = (centered_discrete_pdf.index.values * centered_discrete_pdf.values).sum()
        var = max(
            self._MINIMUM_VARIANCE,
            (centered_discrete_pdf.index.values ** 2 * centered_discrete_pdf.values).sum() - mean ** 2
        )
        return mean, var

    @staticmethod
    def _zero_base_series(series):
        return pd.Series(
            data=series.values,
            index=np.abs(series.index[0] - series.index.values)
        )

    @staticmethod
    def _edge_base_series(series, edge, is_transition_from_inactivity_to_activityd):
        if not is_transition_from_inactivity_to_activityd:
            edge_based_index = edge + series.index.values
        else:
            edge_based_index = edge - series.index.values
        return pd.Series(
            data=series.values,
            index=edge_based_index
        )

    @staticmethod
    def _center_index(series, bin_size):
        return pd.Series(
            data=series.values,
            index=series.index.values + bin_size / 2.
        )

    @staticmethod
    def _uncenter_index(centered_series, bin_size):
        return pd.Series(
            data=centered_series.values,
            index=centered_series.index.values - bin_size / 2.
        )

    @staticmethod
    def _get_gamma(mean, var):
        mean = float(mean)
        var = float(var)
        return gamma(
            mean ** 2 / var,
            scale=var / mean
        )

    def pdf(self, x):
        """
        Samples the continuous PDF

        Args:
            x: value (time) at which the PDF is evaluated

        Returns:
            the probability of a transition occuring
        """
        if self._zero_based_mean == 0 and self._zero_based_var == self._MINIMUM_VARIANCE:
            return 0.
        elif not self._from_inactivity_activity:
            zero_based_x = (x - self._edge) % self._period
        else:
            zero_based_x = (self._edge - x) % self._period
        return self._get_gamma(self._zero_based_mean, self._zero_based_var).pdf(zero_based_x) * MINUTES_PER_HOUR

    def ppf(self, p):
        """
        Compute the value x (time) at which the  distribution has its pth percentile

        Args:
            p: percentile of distribution (inverse of cumulative distribution function)

        Returns:
            the pth percentile of the start distribution
        """
        if self._zero_based_mean == 0 and self._zero_based_var == self._MINIMUM_VARIANCE:
            zero_based_x = 0.
        else:
            zero_based_x = self._get_gamma(self._zero_based_mean, self._zero_based_var).ppf(p)
        if not self._from_inactivity_activity:
            edge_based_x = self._edge + zero_based_x
        else:
            edge_based_x = self._edge - zero_based_x
        return edge_based_x % self._period

    def plot_pdf(self, axis=None, step_minutes=1, color="dodgerblue", *args, **kwargs):
        """
        Plots the continuous Probability Density Function.

        Args:
            axis: matplotlib.Axes object to plot on
            step_minutes: step size of data points
            color: color of line
            *args: additional args to be passed to plot method
            **kwargs: additional kwargs to be passed to plot method

        Returns:
            matplotlib.Axes object where the data has been plotted on
        """
        axis = self._assert_axis(axis)
        x = np.arange(0, HOURS_PER_DAY * MINUTES_PER_HOUR, step_minutes)
        axis.plot(
            x,
            np.clip(self.pdf(x), 0., 10.),
            label="{} distribution".format(self._type),
            color=color,
            *args,
            **kwargs
        )
        self._set_24h_xticks(axis)
        axis.set_ylim(0, 1)
        return axis

    def plot_fit_data(self, axis=None, *args, **kwargs):
        """
        Plots the discrete probabilities to which the PDF is fitted.

        Args:
            axis: matplotlib.Axes object to plot on
            *args: additional args to be passed to plot method
            **kwargs: additional kwargs to be passed to plot method

        Returns:
            matplotlib.Axes object where the data has been plotted on
        """
        axis = self._assert_axis(axis)
        axis.bar(
            (self._series.index.values % self._period),
            self._series.values / self._bin_size,
            width=self._bin_size,
            align="edge",
            label="{} pdf fit data".format(self._type),
            *args,
            **kwargs
        )
        self._set_24h_xticks(axis)
        return axis

    @staticmethod
    def _assert_axis(axis):
        """
        Asserts an axis is created if None is passed.

        Args:
            axis: matplotlib.Axes class or None

        Returns:
            matplotlib.Axes object
        """
        if axis is None:
            _, axis = plt.subplots()
        assert_is_type(axis, plt.Axes)
        return axis

    @staticmethod
    def _set_24h_xticks(axis, start=0, end=MINUTES_PER_DAY, granularity_minutes=30):
        """
        Sets the ticks and labels of the x-axis to granularity_minutes intervals.

        Args:
            axis: matplotlib.Axes object to plot on
            start: start of plot (defaults to 0)
            end: end of plot (defaults to 24*60 minutes)
            granularity_minutes: interval at which ticks and labels are placed (defaults to 30 minutes)

        Returns:
            matplotlib.Axes object
        """
        labels = [time(
            hour=int(m // MINUTES_PER_HOUR),
            minute=int(m % MINUTES_PER_HOUR),
        ).strftime("%H:%M") for m in np.arange(start, end, granularity_minutes, dtype=np.int)]
        axis.set_xticks(
            np.arange(start, end + granularity_minutes, granularity_minutes)
        )
        axis.set_xticklabels(labels + [labels[0]], rotation=90)
        axis.set_xlim(start, end)
        return axis
