import matplotlib.pyplot as plt
import pandas as pd

from datetime import time

from .inactivity_transition_distribution import InactivityTransitionDistribution
from ..abstract_parameters import AbstractParameters
from ....converters.time_constants import MINUTES_PER_HOUR
from ....converters.time_converters import hour_float_to_time, time_to_hour_float
from ....validation.type_validation import assert_is_type


class InactivityParameters(AbstractParameters):
    """
    Set of parameters that describes a period of inactivity.

    Args:
        start_transition_distribution: InactivityDistribution object describing the transition from activity to
                                        inactivity

        end_transition_distribution: InactivityDistribution object describing the transition from inactivity to
                                        activity
        score: score corresponding to the quality of the underlying InactivityWindow
    """

    def __init__(self, start_transition_distribution, end_transition_distribution, score=1.):
        super(InactivityParameters, self).__init__()
        self._validate_inactivity_parameters(
            start_transition_distribution,
            end_transition_distribution,
        )
        self._start_transition_distribution = start_transition_distribution
        self._end_transition_distribution = end_transition_distribution
        self._score = score
        self._period = self._start_transition_distribution.get_period()
        self._bin_size = self._start_transition_distribution.get_bin_size()

    def _key(self):
        return (
            self._start_transition_distribution,
            self._end_transition_distribution,
            self._period,
            self._bin_size,
            self._score
        )

    @staticmethod
    def _validate_inactivity_parameters(start_transition_distribution, end_transition_distribution):
        """
        Validate start and end distributions. Checks whether the period and the bin_size match.

        Args:
            start_transition_distribution: InactivityTransitionDistribution object
            end_transition_distribution: InactivityTransitionDistribution object
        """
        assert_is_type(start_transition_distribution, InactivityTransitionDistribution)
        assert_is_type(end_transition_distribution, InactivityTransitionDistribution)
        assert start_transition_distribution.get_period() == end_transition_distribution.get_period(), (
            "Unequal period"
        )
        assert start_transition_distribution.get_bin_size() == end_transition_distribution.get_bin_size(), (
            "Unequal bin size"
        )
        return

    def get_start_transition_distribution(self):
        return self._start_transition_distribution

    def get_end_transition_distribution(self):
        return self._end_transition_distribution

    def get_period(self):
        return self._period

    def get_bin_size(self):
        return self._bin_size

    def get_score(self):
        return self._score

    def in_window(self, t):
        """
        Checks whether time t is in the inactivity window

        Args:
            t: datetime.time representing the hour in 24h notation (e.g. 16 for 4pm)

        Returns:
            boolean
        """
        assert_is_type(t, time)
        t_minutes = int(time_to_hour_float(t) * MINUTES_PER_HOUR)
        start = self._start_transition_distribution.get_edge()
        end = self._end_transition_distribution.get_edge()
        assert end > start
        while t_minutes < start:
            t_minutes += self._period
        return start < t_minutes < end

    def start_ppf(self, p):
        """
        Compute the value x (time) at which the start distribution has its pth percentile

        Args:
            p: percentile of distribution (inverse of cumulative distribution function)

        Returns:
            the pth percentile of the start distribution
        """
        return self._start_transition_distribution.ppf(p)

    def end_ppf(self, p):
        """
        Compute the value x (time) at which the end distribution has its pth percentile

        Args:
            p: percentile of distribution (inverse of cumulative distribution function)

        Returns:
            the pth percentile of the end distribution
        """
        return self._end_transition_distribution.ppf(p)

    def start_pdf(self, x):
        """
        Samples the PDF of the start distribution (activity -> inactivity)

        Args:
            x: value (time) at which the PDF is evaluated

        Returns:
            the probability of a transition occuring
        """
        return self._start_transition_distribution.pdf(x)

    def end_pdf(self, x):
        """
        Samples the PDF of the end distribution (inactivity -> activity)

        Args:
            x: value (time) at which the PDF is evaluated

        Returns:
            the probability of a transition occuring
        """
        return self._end_transition_distribution.pdf(x)

    def get_early_start_time(self, p=0.05):

        return self.start_ppf(p)

    def get_regular_start_time(self):
        return self._start_transition_distribution.get_mean()

    def get_late_start_time(self, p=0.95):
        return self.start_ppf(p)

    def get_early_end_time(self, p=0.95):
        return self.end_ppf(p)

    def get_regular_end_time(self):
        return self._end_transition_distribution.get_mean()

    def get_late_end_time(self, p=0.05):
        return self.end_ppf(p)

    def to_dataframe(self, to_time=True):
        """
        Exports the early/regular/late start/end parameters of an inactivity period as a pandas DataFrame

        Args:
            to_time: Flag to convert content in DataFrame to datetime.time objects (True by default)

        Returns:
            pandas DataFrame
        """
        if to_time:
            mask = lambda x: hour_float_to_time(x / MINUTES_PER_HOUR)
        else:
            mask = lambda x: x

        return pd.DataFrame(
            data=[[
                mask(self.get_early_start_time()),
                mask(self.get_regular_start_time()),
                mask(self.get_late_start_time()),
                mask(self.get_early_end_time()),
                mask(self.get_regular_end_time()),
                mask(self.get_late_end_time()),
            ]],
            columns=pd.MultiIndex.from_product(
                [
                    ["inactivity start", "inactivity end"],
                    ["early", "regular", "late"],
                ]
            )
        )

    @staticmethod
    def _assert_axis(axis):
        """
        Asserts an axis is created if None is passed.

        Args:
            axis: matplotlib.Axes class or None

        Returns:
            matplotlib.Axes object
        """
        if axis is None:
            axis = plt.subplots()[1]
        assert_is_type(axis, plt.Axes)
        return axis

    def plot(self, axis=None):
        axis = self._assert_axis(axis)
        self.plot_fit_data(axis=axis, alpha=0.2)
        self.plot_pdf(axis=axis, color="green")
        self.plot_parameters(axis=axis, linestyles='solid', colors=["orange", "red", "orange"])
        return axis

    def plot_pdf(self, axis=None, step_minutes=1, color="dodgerblue", *args, **kwargs):
        """
        Plots the continuous Probability Density Functions corresponding to the start and end transition distributions.

        Args:
            axis: matplotlib.Axes object to plot on
            step_minutes: step size of data points
            color: color of line
            *args: additional args to be passed to plot method
            **kwargs: additional kwargs to be passed to plot method

        Returns:
            matplotlib.Axes object where the data has been plotted on
        """
        axis = self._assert_axis(axis)
        self._start_transition_distribution.plot_pdf(
            axis=axis,
            step_minutes=step_minutes,
            linewidth=2,
            color=color,
            *args,
            **kwargs
        )
        self._end_transition_distribution.plot_pdf(
            axis=axis,
            step_minutes=step_minutes,
            linewidth=2,
            color=color,
            *args,
            **kwargs
        )
        return axis

    def plot_fit_data(self, axis=None, *args, **kwargs):
        """
        Plots the discrete probabilities to which the PDFs are fitted.

        Args:
            axis: matplotlib.Axes object to plot on
            *args: additional args to be passed to plot method
            **kwargs: additional kwargs to be passed to plot method

        Returns:
            matplotlib.Axes object where the data has been plotted on
        """
        axis = self._assert_axis(axis)
        self._start_transition_distribution.plot_fit_data(
            axis=axis,
            *args,
            **kwargs
        )
        self._end_transition_distribution.plot_fit_data(
            axis=axis,
            *args,
            **kwargs
        )
        return axis

    def plot_parameters(self, axis=None, colors=("coral", "orangered", "coral"), *args, **kwargs):
        """
        Plots the early/regular/late start and end times as vertical lines.

        Args:
            axis: matplotlib.Axes object to plot on
            colors: set of colors for the vlines
            *args: additional args to be passed to vlines method
            **kwargs: additional kwargs to be passed to vlines method

        Returns:
            matplotlib.Axes object where the data has been plotted on
        """
        axis = self._assert_axis(axis)
        ylim = axis.get_ylim()
        axis.vlines(
            [
                self.get_early_start_time(),
                self.get_regular_start_time(),
                self.get_late_start_time(),
                self.get_early_end_time(),
                self.get_regular_end_time(),
                self.get_late_end_time(),
            ],
            ylim[0],
            ylim[1],
            linewidth=2,
            colors=colors,
            *args,
            **kwargs
        )
        return axis

    def plot_parameter_markers(self, axis=None, marker="x", *args, **kwargs):
        """
        Plots the early/regular/late start and end times as vertical lines.

        Args:
            axis: matplotlib.Axes object to plot on
            marker: plot marker
            *args: additional args to be passed to vlines method
            **kwargs: additional kwargs to be passed to vlines method

        Returns:
            matplotlib.Axes object where the data has been plotted on
        """
        axis = self._assert_axis(axis)
        axis.scatter(
            [
                self.get_early_start_time(),
                self.get_regular_start_time(),
                self.get_late_start_time(),
                self.get_early_end_time(),
                self.get_regular_end_time(),
                self.get_late_end_time(),
            ],
            [0] * 6,
            marker=marker,
            *args,
            **kwargs
        )
        return axis
