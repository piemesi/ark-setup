import pandas as pd

from ..abstract_parameters_collection import AbstractParametersCollection
from ..inactivity_parameters import InactivityParameters


class InactivityParametersCollection(AbstractParametersCollection):
    """
    This class is a wrapper around a list containing several instances of the InactivityParameters class. To be
    instantiated with a list of InactivityParameters.
    """

    @classmethod
    def _get_parameters_cls(cls):
        return InactivityParameters

    def to_dataframe(self):
        """
        Exports the early/regular/late start/end parameters for all InactivityParameters objects as a pandas DataFrame

        Returns:
            pandas DataFrame
        """
        if self._parameters_list:
            inactivity_parameters_data_frame = pd.concat(
                [inactivity_parameters.to_dataframe() for inactivity_parameters in self._parameters_list]
            )
        else:
            inactivity_parameters_data_frame = pd.DataFrame()
        return inactivity_parameters_data_frame.reset_index(drop=True)
