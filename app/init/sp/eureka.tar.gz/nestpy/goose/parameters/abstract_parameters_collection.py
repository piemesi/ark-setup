from abc import ABCMeta

from .abstract_parameters import AbstractParameters
from ...validation.type_validation import assert_is_type


class AbstractParametersCollection(object):

    __metaclass__ = ABCMeta

    def __init__(self, parameters_list):
        self._validate_parameters_list(parameters_list)
        self._parameters_list = parameters_list

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__hash__() == other.__hash__()

    def __ne__(self, other):
        return not self.__eq__(other)

    def __hash__(self):
        return hash(frozenset(self._parameters_list))

    def __repr__(self):
        return "<{}>".format(self.__class__.__name__)

    def __getitem__(self, item):
        return self._parameters_list.__getitem__(item)

    def __len__(self):
        return len(self._parameters_list)

    @classmethod
    def _get_parameters_cls(cls):
        return AbstractParameters

    def get_parameters_list(self):
        return self._parameters_list

    @classmethod
    def _validate_parameters_list(cls, parameters_list):
        assert_is_type(parameters_list, list)
        for parameters in parameters_list:
            assert_is_type(parameters, cls._get_parameters_cls())
        return
