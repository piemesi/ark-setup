import datetime

from .events.event_emitters import Person
from .events.event_emitters.abstract_device import AbstractDevice
from .events.event_emitters.schedules import WorkSchedule
from .events.event_emitters.sensors import GeofenceSensor
from .events.event_emitters.sensors.pir_sensors import PoissonPIRSensor
from .events.event_emitters.devices import Diamond, MobileDevice
from .environment.datetime_environments import MOOSEEnvironment
from .simulation import Simulation
from ..building import AbstractObjectBuilder
from ..states.state_spaces import GOOSEStateSpace
from ..states.state_spaces import OCCUPANCY_STATE_SPACE
from ...validation.type_validation import assert_is_type


SINGLE_WORKING_PERSON_SIMULATION_BUILDER_CONFIG = dict(
    object_cls=Simulation,
    state_space=OCCUPANCY_STATE_SPACE,
    persons=[
        Person(
            identifier='john',
            schedule=WorkSchedule(
                wake_up_time=datetime.time(hour=7),
                work_start_time=datetime.time(hour=9),
                work_end_time=datetime.time(hour=18),
                bed_time=datetime.time(hour=23)
            )
        )
    ],
    devices=[
        MobileDevice(
            identifier='mobile_device',
            person_id='john',
            geofence_sensor=GeofenceSensor()
        ),
        Diamond(
            identifier='diamond',
            pir_sensor=PoissonPIRSensor(
                threshold=100,
                sample_time=datetime.timedelta(minutes=5),
                mean_interarrival_time=datetime.timedelta(minutes=15)
            )
        )
    ]
)


class SimulationBuilder(AbstractObjectBuilder):

    def _get_object_base_cls(self):
        return Simulation

    def _get_builder_config_types(self):
        return dict(
            state_space=GOOSEStateSpace,
            persons=Person,
            devices=AbstractDevice
        )

    def build(self, start_datetime, end_datetime):
        assert_is_type(start_datetime, datetime.datetime)
        assert_is_type(end_datetime, datetime.datetime)
        env = MOOSEEnvironment(
            start_datetime=start_datetime,
            end_datetime=end_datetime,
            state_space=self._builder_config.get('state_space')
        )
        simulation = self._object_cls(
            env=env,
            persons=self._builder_config.get('persons'),
            devices=self._builder_config.get('devices')
        )
        return simulation
