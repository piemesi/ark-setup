import datetime
import numpy as np

from ..abstract_schedule import AbstractSchedule


class AbstractProbabilisticSchedule(AbstractSchedule):
    """Core abstraction of the probabilistic schedule classes."""

    _MINIMUM_BUFFER_TIMEDELTA = datetime.timedelta(minutes=5)

    @classmethod
    def _generate_gaussian_random_timedelta(cls, mean_timedelta, std_timedelta):
        random_timedelta = datetime.timedelta(
            seconds=np.random.normal(
                loc=mean_timedelta.total_seconds(),
                scale=std_timedelta.total_seconds()
            )
        )
        return random_timedelta

    @classmethod
    def _gaussian_random_timedelta_generator(cls, gaussian_params):
        for index, (mean_timedelta, std_timedelta) in enumerate(gaussian_params):
            previous_mean_timedelta, _ = gaussian_params[(index - 1) % len(gaussian_params)]
            next_mean_timedelta, _ = gaussian_params[(index + 1) % len(gaussian_params)]
            if index == 0:
                previous_mean_timedelta -= cls._DAY_TIMEDELTA
            if index == len(gaussian_params) - 1:
                next_mean_timedelta += cls._DAY_TIMEDELTA
            random_timedelta = min(
                max(
                    (mean_timedelta + previous_mean_timedelta) / 2 + cls._MINIMUM_BUFFER_TIMEDELTA,
                    cls._generate_gaussian_random_timedelta(mean_timedelta, std_timedelta)
                ),
                (next_mean_timedelta + mean_timedelta) / 2 - cls._MINIMUM_BUFFER_TIMEDELTA
            )
            yield random_timedelta
