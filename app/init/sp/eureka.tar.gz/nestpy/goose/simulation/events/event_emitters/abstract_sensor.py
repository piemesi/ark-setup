from abc import ABCMeta, abstractmethod

from ..abstract_event_emitter import AbstractEventEmitter, emission_process


class AbstractSensor(AbstractEventEmitter):
    """Core abstraction of the sensor classes.

    Sensors emit events based on the events of the persons in the person observer.
    """
    __metaclass__ = ABCMeta

    @abstractmethod
    def _sensor_process(self, env, *args, **kwargs):
        """The sensor emission process that needs to be defined by implementation classes."""
        raise NotImplementedError

    @emission_process
    def sensor_process(self, env, *args, **kwargs):
        """The sensor emission process, which calls the implemented sensor process."""
        return self._sensor_process(env, *args, **kwargs)
