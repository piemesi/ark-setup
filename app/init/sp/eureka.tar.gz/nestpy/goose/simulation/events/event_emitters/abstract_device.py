from abc import ABCMeta, abstractproperty

from .abstract_sensor import AbstractSensor
from ..abstract_event_emitter import AbstractEventEmitter, emission_process
from ...pipes import ManyToOnePipe, OneToOnePipe


class AbstractDevice(AbstractEventEmitter):
    """Core abstraction of the device classes.

    Devices are initiated with an identifier and inherited parameters. Devices emit events based on the events its
    sensors are emitting. Implementation classes are responsible for registering the sensors to the many-to-one pipe.
    """
    __metaclass__ = ABCMeta

    def __init__(self, identifier, sensors):
        """Initializes a Device object with an identifier and a list of sensors.

        Args:
            identifier (basestring/int): an identifier for the device
            sensors (list of AbstractSensor): a list of sensors
        """
        super(AbstractDevice, self).__init__(identifier=identifier)
        self._sensors = sensors

    @staticmethod
    def _create_logging_pipe_for_sensors(env, logging_schemas):
        """Creates a logging pipe for a list of sensors."""
        logging_pipe = ManyToOnePipe(env)
        for logging_schema in logging_schemas:
            def mapping_func(output, _logging_schema=logging_schema):
                _datetime, sensor_event = output
                return _datetime, {_logging_schema['event_name']: _logging_schema['logging_func'](sensor_event)}
            mapping_pipe = OneToOnePipe(
                env=env,
                input_pipe=env.event_manager.get_output_pipe(logging_schema['sensor'].sensor_process),
                mapping_func=mapping_func
            )
            logging_pipe.register(mapping_pipe)
        return logging_pipe

    @abstractproperty
    def _logging_schemas(self):
        """The logging schemas that need to be defined by implementation classes."""
        raise NotImplementedError

    @emission_process
    def logging_process(self, env):
        """Emits the logs from the individual sensors."""
        logging_pipe = self._create_logging_pipe_for_sensors(env, self._logging_schemas)
        while True:
            _datetime, event = yield logging_pipe.get()
            env.event_manager.emit_event(self.logging_process, event)

    @property
    def _sensor_register_kwargs(self):
        """Returns the keyword arguments that are passed when registering the sensors."""
        return dict()

    def register(self, env, *args, **kwargs):
        """Registers the device with the specified environment."""
        for sensor in self._sensors:
            sensor.register(env, **self._sensor_register_kwargs)
        super(AbstractDevice, self).register(env, *args, **kwargs)
        env.devices.register(self._identifier, self)
