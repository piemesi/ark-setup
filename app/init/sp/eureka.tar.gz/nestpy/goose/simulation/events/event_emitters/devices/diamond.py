from ..abstract_device import AbstractDevice
from ..sensors.abstract_pir_sensor import AbstractPIRSensor
from ......validation.type_validation import assert_is_type


def _pir_logging_func(sensor_event):
    return dict(max=sensor_event.get(AbstractPIRSensor.VALUE), threshold=100)


class Diamond(AbstractDevice):
    """Diamond device.

    Diamond devices are instantiated with an identifier and a PIR sensor. Furthermore, for each of its sensors, a
    logging schema is defined that maps the sensor events to logging events.
    """

    def __init__(self, identifier, pir_sensor):
        """Initializes a Diamond object with an identifier and a PIR sensor.

        Args:
            identifier (basestring/int): an identifier for the Diamond
            pir_sensor (AbstractPIRSensor): a PIR sensor
        """
        super(Diamond, self).__init__(identifier=identifier, sensors=[pir_sensor])
        assert_is_type(pir_sensor, AbstractPIRSensor)
        self._pir_sensor = pir_sensor

    @property
    def _logging_schemas(self):
        return [
            dict(
                sensor=self._pir_sensor,
                event_name='BufferedPassiveInfrared',
                logging_func=_pir_logging_func
            )
        ]
