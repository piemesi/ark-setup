import inspect

from ..environment import DatetimeEnvironment

from ..pipes import OneToManyPipe, ManyToManyPipe
from ....validation.type_validation import assert_is_type


class EventManager(object):
    """An EventManager is the core event emission manager for a set of event emitters.

    An event manager is initiated with an environment and has an internal container for one-to-many pipes. Individual
    emission processes can register to the event manager, which creates a one-to-many pipe for them. Consumer can then
    access any combination of events of the registered emission processes.
    """

    def __init__(self, env):
        """Initializes an EventManager object with containers for one-to-many and many-to-many pipes.

        Args:
            env (DatetimeEnvironment): a simulation environment
        """
        assert_is_type(env, DatetimeEnvironment)
        self._env = env
        self._one_to_many_pipes = {}
        self._many_to_many_pipes = {}

    @staticmethod
    def _validate_process(event_emitter, process):
        assert isinstance(event_emitter, process.im_class)

    @staticmethod
    def _get_emission_process_key(bound_emission_process):
        assert inspect.ismethod(bound_emission_process) and bound_emission_process.im_self is not None
        return bound_emission_process.im_self, bound_emission_process.im_func.func_name

    def register(self, bound_emission_process):
        """Registers an emission process."""
        emission_process_key = self._get_emission_process_key(bound_emission_process)
        if emission_process_key in self._one_to_many_pipes:
            raise ValueError("Event emitter '{}' with '{}' already registered.".format(*emission_process_key))
        self._one_to_many_pipes[emission_process_key] = OneToManyPipe(self._env)

    def emit_event(self, bound_emission_process, event):
        """Emits an event to all output pipes for the specified emission process."""
        emission_process_key = self._get_emission_process_key(bound_emission_process)
        event = self._one_to_many_pipes[emission_process_key].put((self._env.get_current_datetime(), event))
        return self._env.all_of([event])

    def get_output_pipe(self, bound_emission_process):
        """Returns an output pipe for a single emission process"""
        emission_process_key = self._get_emission_process_key(bound_emission_process)
        return self._one_to_many_pipes[emission_process_key].get_output_pipe()

    def get_combined_output_pipe(self, bound_emission_processes):
        """Returns an output pipe for a subset of emission processes."""
        emission_processes_keys = [self._get_emission_process_key(bound_emission_process)
                                   for bound_emission_process in bound_emission_processes]
        subset_key = frozenset(emission_processes_keys)
        if subset_key not in self._many_to_many_pipes.keys():
            self._many_to_many_pipes[subset_key] = ManyToManyPipe.from_pipes(
                env=self._env,
                input_pipes=[
                    self._one_to_many_pipes[emission_process_key].get_output_pipe()
                    for emission_process_key in emission_processes_keys
                ]
            )
        return self._many_to_many_pipes[subset_key].get_output_pipe()
