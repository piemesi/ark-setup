import datetime
import numpy as np

from ..abstract_pir_sensor import AbstractPIRSensor
from .......validation.type_validation import assert_is_type


class PoissonPIRSensor(AbstractPIRSensor):
    """Poisson PIR sensor that generates PIR readings using a Poisson random variable."""

    def __init__(self, mean_interarrival_time, *args, **kwargs):
        """Initializes a PoissonPIRSensor object with a mean interarrival time.

        Args:
            mean_interarrival_time (datetime.timedelta): the mean interarrival time
            *args: side arguments
            **kwargs: keyword side arguments
        """
        super(PoissonPIRSensor, self).__init__(*args, **kwargs)
        assert_is_type(mean_interarrival_time, datetime.timedelta)
        self._mean_interarrival_time = mean_interarrival_time

    def _generate_activity(self):
        """Generates activity using a Poisson random variable."""
        poisson_rate = self._sample_time.total_seconds() / self._mean_interarrival_time.total_seconds()
        activity = np.random.poisson(poisson_rate) > 0
        return activity

    def _generate_pir_reading(self, env, person_states):
        """Generates a PIR reading based on the person states and a Poisson random variable."""
        if env.get_state_space().get_active_state().get_state_label() in person_states:
            activity = self._generate_activity()
            if activity:
                reading = self._generate_high_pir_reading()
            else:
                reading = self._generate_low_pir_reading()
        else:
            reading = self._generate_low_pir_reading()
        return reading
