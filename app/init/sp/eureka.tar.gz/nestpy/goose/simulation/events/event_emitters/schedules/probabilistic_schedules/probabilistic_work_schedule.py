import datetime

from ..abstract_probabilistic_schedule import AbstractProbabilisticSchedule
from .......validation.type_validation import assert_list_of_type


class ProbabilisticWorkSchedule(AbstractProbabilisticSchedule):
    """The probabilistic schedule of a person who works on weekdays, and wakes up and goes to bed at set times."""

    def __init__(
            self,
            mean_wake_up_time,
            std_wake_up_time,
            mean_work_start_time,
            std_work_start_time,
            mean_work_end_time,
            std_work_end_time,
            mean_bed_time,
            std_bed_time,
            *args,
            **kwargs
    ):
        """Initializes the object with a mean and standard deviation for the wake up, work start, work end and bed time.

        Args:
            mean_wake_up_time (datetime.time): mean wake up time
            std_wake_up_time (datetime.timedelta): standard deviation for the wake up time
            mean_work_start_time (datetime.time): mean work start time
            std_work_start_time (datetime.timedelta): standard deviation for the work start time
            mean_work_end_time (datetime.time): mean work end time
            std_work_end_time (datetime.timedelta): standard deviation for the work end time
            mean_bed_time (datetime.time): mean bed time
            std_bed_time (datetime.timedelta): standard deviation for the bed time
            *args: side arguments
            **kwargs: keyword side arguments
        """
        super(ProbabilisticWorkSchedule, self).__init__(*args, **kwargs)
        self._validate_ordered_times([mean_wake_up_time, mean_work_start_time, mean_work_end_time, mean_bed_time])
        assert_list_of_type(
            [
                std_wake_up_time,
                std_work_start_time,
                std_work_end_time,
                std_bed_time
            ],
            datetime.timedelta
        )
        self._mean_wake_up_time = mean_wake_up_time
        self._std_wake_up_time = std_wake_up_time
        self._mean_work_start_time = mean_work_start_time
        self._std_work_start_time = std_work_start_time
        self._mean_work_end_time = mean_work_end_time
        self._std_work_end_time = std_work_end_time
        self._mean_bed_time = mean_bed_time
        self._std_bed_time = std_bed_time

    def _get_schedule(self, env, weekday):
        schedule = zip(
            self._gaussian_random_timedelta_generator(
                zip(
                    self._ordered_timedelta_generator(
                        [
                            self._mean_wake_up_time,
                            self._mean_bed_time
                        ]
                    ),
                    [
                        self._std_wake_up_time,
                        self._std_bed_time
                    ]
                )
            ),
            [
                env.get_state_space().get_active_state().get_state_label(),
                env.get_state_space().get_sleep_state().get_state_label()
            ]
        )
        if weekday in range(5):
            schedule = zip(
                self._gaussian_random_timedelta_generator(
                    zip(
                        self._ordered_timedelta_generator(
                            [
                                self._mean_wake_up_time,
                                self._mean_work_start_time,
                                self._mean_work_end_time,
                                self._mean_bed_time
                            ]
                        ),
                        [
                            self._std_wake_up_time,
                            self._std_work_start_time,
                            self._std_work_end_time,
                            self._std_bed_time
                        ]
                    )
                ),
                [
                    env.get_state_space().get_active_state().get_state_label(),
                    env.get_state_space().get_vacant_state().get_state_label(),
                    env.get_state_space().get_active_state().get_state_label(),
                    env.get_state_space().get_sleep_state().get_state_label()
                ]
            )
        return schedule
