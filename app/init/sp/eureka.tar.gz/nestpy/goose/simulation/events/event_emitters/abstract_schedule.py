import datetime
import operator

from abc import ABCMeta, abstractmethod

from ..abstract_event_emitter import AbstractEventEmitter, emission_process
from .....manipulators.datetime_manipulators import floor_datetime
from .....validation.type_validation import assert_list_of_type


class AbstractSchedule(AbstractEventEmitter):
    """Core abstraction of the schedule classes.

    Schedules add an emission process to their environment which calls a daily emission process that uses a schedule
    that is defined by the implementation classes.
    """
    __metaclass__ = ABCMeta

    _DAY_TIMEDELTA = datetime.timedelta(days=1)

    @staticmethod
    def _validate_ordered_times(ordered_times):
        assert_list_of_type(ordered_times, datetime.time)
        offset = False
        for index in range(len(ordered_times)):
            if index > 0 and not ordered_times[index] > ordered_times[index - 1]:
                if offset:
                    raise ValueError("Invalid sequences of times '{}'.".format(ordered_times))
                offset = True

    @staticmethod
    def _time_to_timedelta(time):
        timedelta = datetime.timedelta(
            hours=time.hour,
            minutes=time.minute,
            seconds=time.second,
            microseconds=time.microsecond
        )
        return timedelta

    @staticmethod
    def _timedelta_to_time(timedelta):
        time = (datetime.datetime.min + timedelta).time()
        return time

    @classmethod
    def _ordered_timedelta_generator(cls, ordered_times):
        offset_timedelta = datetime.timedelta()
        for index in range(len(ordered_times)):
            timedelta = cls._time_to_timedelta(ordered_times[index])
            if index > 0 and not ordered_times[index] > ordered_times[index - 1]:
                offset_timedelta = cls._DAY_TIMEDELTA
            yield timedelta + offset_timedelta

    @abstractmethod
    def _get_schedule(self, env, weekday):
        """The schedule to be implemented by implementation classes."""
        raise NotImplementedError

    def _daily_schedule_process(self, env, start_datetime):
        """The daily emission process that uses the defined schedule."""
        floored_start_datetime = floor_datetime(start_datetime, self._DAY_TIMEDELTA)
        schedule = sorted(self._get_schedule(env, start_datetime.weekday()), key=operator.itemgetter(0))
        for timedelta, state_label in schedule:
            _datetime = floored_start_datetime + timedelta
            if _datetime >= start_datetime:
                yield env.timeout_until_datetime(_datetime)
                yield env.event_manager.emit_event(self.schedule_process, state_label)

    @emission_process
    def schedule_process(self, env):
        """The emission process that calls the daily emission process."""
        start_datetime = env.get_start_datetime()
        while True:
            for item in self._daily_schedule_process(env, start_datetime):
                yield item
            start_datetime = floor_datetime(start_datetime, self._DAY_TIMEDELTA) + self._DAY_TIMEDELTA
