import datetime

from ..abstract_schedule import AbstractSchedule
from ......validation.type_validation import assert_list_of_type


class WorkSchedule(AbstractSchedule):
    """The schedule of a person who works on weekdays, and wakes up and goes to bed at set times."""

    def __init__(self, wake_up_time, work_start_time, work_end_time, bed_time, *args, **kwargs):
        """Initializes a WorkSchedule object with a wake up, work start, work end and bed time.

        Args:
            wake_up_time (datetime.time): wake up time
            work_start_time (datetime.time): start time of work
            work_end_time (datetime.time): end time of work
            bed_time (datetime.time): bed time
            *args: side arguments
            **kwargs: keyword side arguments
        """
        super(WorkSchedule, self).__init__(*args, **kwargs)
        self._validate_ordered_times([wake_up_time, work_start_time, work_end_time, bed_time])
        self._wake_up_time = wake_up_time
        self._work_start_time = work_start_time
        self._work_end_time = work_end_time
        self._bed_time = bed_time

    def _get_schedule(self, env, weekday):
        schedule = zip(
            self._ordered_timedelta_generator(
                [
                    self._wake_up_time,
                    self._bed_time
                ]
            ),
            [
                env.get_state_space().get_active_state().get_state_label(),
                env.get_state_space().get_sleep_state().get_state_label()
            ]
        )
        if weekday in range(5):
            schedule = zip(
                self._ordered_timedelta_generator(
                    [
                        self._wake_up_time,
                        self._work_start_time,
                        self._work_end_time,
                        self._bed_time
                    ]
                ),
                [
                    env.get_state_space().get_active_state().get_state_label(),
                    env.get_state_space().get_vacant_state().get_state_label(),
                    env.get_state_space().get_active_state().get_state_label(),
                    env.get_state_space().get_sleep_state().get_state_label()
                ]
            )
        return schedule
