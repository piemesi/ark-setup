import datetime
import random

from abc import ABCMeta, abstractmethod

from ..abstract_sensor import AbstractSensor
from ......manipulators.datetime_manipulators import ceil_datetime
from ......validation.type_validation import assert_is_type, assert_type_in


class AbstractPIRSensor(AbstractSensor):
    """Core abstraction of the PIR sensor classes.

    PIR sensors are initiated with a threshold, sample time and inherited parameters. It emits PIR readings using
    to the specified sample time and threshold, and according to logic that is implemented by implementation classes.
    """
    __metaclass__ = ABCMeta

    VALUE = 'value'

    def __init__(self, threshold, sample_time, *args, **kwargs):
        """Initializes a PIRSensor object with a threshold and sample time.

        Args:
            threshold (int/float): activity threshold for PIR readings
            sample_time: sample time of PIR readings
            *args: side arguments
            **kwargs: keyword side arguments
        """
        super(AbstractPIRSensor, self).__init__(*args, **kwargs)
        assert_type_in(threshold, [int, float])
        assert_is_type(sample_time, datetime.timedelta)
        self._threshold = threshold
        self._sample_time = sample_time

    def _generate_low_pir_reading(self):
        """Generates a low PIR reading, based on the specified threshold."""
        return (0.5 + random.uniform(-0.25, 0.25)) * self._threshold

    def _generate_high_pir_reading(self):
        """Generates a high PIR reading, based on the specified threshold."""
        return (5 + random.uniform(-1, 1)) * self._threshold

    @abstractmethod
    def _generate_pir_reading(self, env, person_states):
        """The PIR generation logic that needs to be implemented by implementation classes."""
        raise NotImplementedError

    def _sensor_process(self, env, *args, **kwargs):
        persons = env.persons.get_all()
        persons_pipe = env.event_manager.get_combined_output_pipe([person.person_process for person in persons])
        persons_state = dict()
        while True:
            _datetime, person_event = yield persons_pipe.get()
            persons_state.update(person_event)
            ceiled_datetime = ceil_datetime(env.get_current_datetime(), self._sample_time)
            if ceiled_datetime > env.get_current_datetime():
                yield env.timeout_until_datetime(ceiled_datetime)
            while not persons_pipe.items:
                reading = self._generate_pir_reading(env, persons_state.values())
                yield env.event_manager.emit_event(self.sensor_process, {self.VALUE: reading})
                yield env.timeout_timedelta(self._sample_time)
