from ..abstract_sensor import AbstractSensor


class GeofenceSensor(AbstractSensor):
    """Geofence sensor that listens to the schedule state of a single person."""

    EVENT = 'event'
    ENTER_EVENT = 'enter'
    EXIT_EVENT = 'exit'

    def _sensor_process(self, env, *args, **kwargs):
        person = env.persons.get(kwargs.get('person_id'))
        person_pipe = env.event_manager.get_output_pipe(person.person_process)
        old_event = None
        while True:
            _datetime, person_event = yield person_pipe.get()
            (person_id, state_label), = person_event.items()
            if state_label == env.get_state_space().get_vacant_state().get_state_label():
                new_event = self.EXIT_EVENT
            else:
                new_event = self.ENTER_EVENT
            if new_event != old_event:
                yield env.event_manager.emit_event(self.sensor_process, {self.EVENT: new_event})
            old_event = new_event
