from .abstract_schedule import AbstractSchedule
from ..abstract_event_emitter import AbstractEventEmitter, emission_process
from .....validation.type_validation import assert_is_type


class Person(AbstractEventEmitter):
    """A Person is one of the core agents, which interacts with devices.

    Persons are initiated with an identifier, a schedule and inherited parameters. Their emission process consists
    of labeling their schedule states with their own identifier.
    """

    def __init__(self, identifier, schedule):
        """Initializes a Person object with an identifier and schedule.

        Args:
            identifier (basestring/int): an identifier for the person
            schedule (AbstractSchedule): a schedule to be used by the person
        """
        super(Person, self).__init__(identifier=identifier)
        assert_is_type(schedule, AbstractSchedule)
        self._schedule = schedule

    @emission_process
    def person_process(self, env):
        """Emits the schedule state labeled with its own identifier."""
        schedule_pipe = env.event_manager.get_output_pipe(self._schedule.schedule_process)
        while True:
            _datetime, state_label = yield schedule_pipe.get()
            yield env.event_manager.emit_event(self.person_process, {self._identifier: state_label})

    def register(self, env, *args, **kwargs):
        """Registers the person with the specified environment."""
        self._schedule.register(env)
        super(Person, self).register(env, *args, **kwargs)
        env.persons.register(self._identifier, self)

    def get_schedule(self):
        return self._schedule
