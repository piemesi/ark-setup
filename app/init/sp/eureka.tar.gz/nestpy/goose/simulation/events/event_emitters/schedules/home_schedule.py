import datetime

from ..abstract_schedule import AbstractSchedule
from ......validation.type_validation import assert_list_of_type


class HomeSchedule(AbstractSchedule):
    """The schedule of a person who is home all the time, and wakes up and goes to bed at set times."""

    def __init__(self, wake_up_time, bed_time, *args, **kwargs):
        """Initializes a HomeSchedule object with a wake up and bed time.

        Args:
            wake_up_time (datetime.time): wake up time
            bed_time (datetime.time): bed time
            *args: side arguments
            **kwargs: keyword side arguments
        """
        super(HomeSchedule, self).__init__(*args, **kwargs)
        self._validate_ordered_times([wake_up_time, bed_time])
        self._wake_up_time = wake_up_time
        self._bed_time = bed_time

    def _get_schedule(self, env, weekday):
        return zip(
            self._ordered_timedelta_generator(
                [
                    self._wake_up_time,
                    self._bed_time
                ]
            ),
            [
                env.get_state_space().get_active_state().get_state_label(),
                env.get_state_space().get_sleep_state().get_state_label()
            ]
        )
