import binascii
import inspect
import operator
import os

from abc import ABCMeta

from ..environment.datetime_environments import MOOSEEnvironment
from ....validation.type_validation import assert_is_type, assert_type_in

_IS_EMISSION_PROCESS = "_is_emission_process"


def emission_process(func):
    """Decorator for the emission process methods."""
    for expected_arg in ["self", "env"]:
        if expected_arg not in func.func_code.co_varnames:
            raise KeyError("Expected argument '{}' not found in '{}'".format(expected_arg, func))
    setattr(func, _IS_EMISSION_PROCESS, True)
    return func


class AbstractEventEmitterMeta(ABCMeta):
    """Event emitter metaclass, which makes sure the mission processes are stored."""

    EMISSION_PROCESSES = "_EMISSION_PROCESSES"

    def __new__(mcs, name, bases, namespace):
        cls = super(AbstractEventEmitterMeta, mcs).__new__(mcs, name, bases, namespace)
        emission_processes = map(
            operator.itemgetter(1),
            filter(
                lambda (_, func): getattr(func, _IS_EMISSION_PROCESS, False),
                inspect.getmembers(cls, predicate=inspect.ismethod)
            )
        )
        setattr(cls, mcs.EMISSION_PROCESSES, emission_processes)
        return cls


class AbstractEventEmitter(object):
    """Core abstraction of the event emitting classes.

    An EventEmitter is initiated with an optional identifier. Its register method adds itself to an environment
    by registering its emission processes with the event manager and by adding its emission process to the environment.
    The emission processes should be defined by the implementation classes using the 'emission_process' decorator.
    """
    __metaclass__ = AbstractEventEmitterMeta

    def __init__(self, identifier=None):
        """Initializes an EventEmitter object with an optional identifier.

        Args:
            identifier (basestring/int): an optional identifier for the event emitter
        """
        if identifier is not None:
            assert_type_in(identifier, [basestring, int])
        else:
            identifier = binascii.b2a_hex(os.urandom(15))
        self._identifier = identifier

    def __repr__(self):
        return "<{}: {}>".format(self.__class__.__name__, self._key())

    def __hash__(self):
        return hash(self._key())

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self._key() == other._key()

    def __ne__(self, other):
        return not self.__eq__(other)

    def _key(self):
        return self._identifier

    def register(self, env, *args, **kwargs):
        """Registers the event emission processes with the specified environment."""
        assert_is_type(env, MOOSEEnvironment)
        for unbound_emission_process in getattr(self, AbstractEventEmitterMeta.EMISSION_PROCESSES):
            env.event_manager.register(unbound_emission_process.__get__(self, self.__class__))
            env.process(unbound_emission_process(self, env, *args, **kwargs))

    def get_identifier(self):
        return self._identifier
