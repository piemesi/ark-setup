from ..abstract_device import AbstractDevice
from ..sensors import GeofenceSensor
from ......validation.type_validation import assert_is_type, assert_type_in


def _geofence_logging_func(sensor_event):
    sensor_event_map = {GeofenceSensor.ENTER_EVENT: "INSIDE", GeofenceSensor.EXIT_EVENT: "OUTSIDE"}
    return dict(direction=sensor_event_map.get(sensor_event.get(GeofenceSensor.EVENT)))


class MobileDevice(AbstractDevice):
    """Mobile device.

    Mobile devices are instantiated with an identifier, a person identifier and a geofence sensor. Furthermore, for
    each of its sensors, a logging schema is defined that maps the sensor events to logging events.
    """

    def __init__(self, identifier, person_id, geofence_sensor):
        """Initializes a MobileDevice object with an identifier, person identifier and a geofence sensor.

        Args:
            identifier (basestring/int): an identifier for the mobile device
            person_id (basestring/int): identifier of the person the mobile device belongs to
            geofence_sensor (GeofenceSensor): a geofence sensor
        """
        super(MobileDevice, self).__init__(identifier=identifier, sensors=[geofence_sensor])
        assert_type_in(person_id, [basestring, int])
        assert_is_type(geofence_sensor, GeofenceSensor)
        self._person_id = person_id
        self._geofence_sensor = geofence_sensor

    @property
    def _logging_schemas(self):
        return [
            dict(
                sensor=self._geofence_sensor,
                event_name='fenceEvents',
                logging_func=_geofence_logging_func
            )
        ]

    @property
    def _sensor_register_kwargs(self):
        return dict(person_id=self._person_id)
