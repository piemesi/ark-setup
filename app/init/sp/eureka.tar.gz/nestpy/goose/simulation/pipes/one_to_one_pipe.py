from simpy import Environment, Store
from types import FunctionType

from ....validation.type_validation import assert_is_type


class OneToOnePipe(object):
    """A one-to-one pipe that allows one to map the output of an input pipe using a mapping function."""

    def __init__(self, env, input_pipe, mapping_func=None):
        """Initializes a OneToOnePipe object and creates an internal pipe for the mapped events.

        Args:
            env (Environment): a Simpy environment
            input_pipe (Store): a Simpy store
            mapping_func (function): a mapping function to be applied to the output of the input pipe
        """
        assert_is_type(env, Environment)
        assert_is_type(input_pipe, Store)
        if mapping_func is not None:
            assert_is_type(mapping_func, FunctionType)
        self._env = env
        self._store = Store(self._env)
        self._env.process(self._mapping_process(input_pipe, mapping_func))

    def _mapping_process(self, input_pipe, mapping_func):
        """The process that maps the input pipe to the internal store."""
        while True:
            output = yield input_pipe.get()
            if mapping_func is not None:
                output = mapping_func(output)
            self._store.put(output)

    @property
    def items(self):
        return self._store.items

    def get(self):
        return self._store.get()
