from simpy import Environment

from .many_to_one_pipe import ManyToOnePipe
from .one_to_many_pipe import OneToManyPipe
from ....validation.type_validation import assert_is_type


class ManyToManyPipe(object):
    """A many-to-many pipe that allows one to combine the outputs of multiple pipes and broadcast them to many."""

    def __init__(self, env):
        """Initializes a ManyToManyPipe object and launches the linking process.

        Args:
            env (Environment): a Simpy environment
        """
        assert_is_type(env, Environment)
        self._env = env
        self._many_to_one_pipe = ManyToOnePipe(self._env)
        self._one_to_many_pipe = OneToManyPipe(self._env)
        self._process = env.process(self._link_process())

    @classmethod
    def from_pipes(cls, env, input_pipes):
        """Creates a many-to-many pipe and registers the input pipes to it."""
        many_to_many_pipe = cls(env)
        for pipe in input_pipes:
            many_to_many_pipe.register(pipe)
        return many_to_many_pipe

    def _link_process(self):
        """The process that links the many-to-one pipe to the one-to-many pipe."""
        while True:
            output = yield self._many_to_one_pipe.get()
            self._one_to_many_pipe.put(output)

    def register(self, pipe):
        """Registers the passed pipe to the many-to-many pipe."""
        self._many_to_one_pipe.register(pipe)

    def get_output_pipe(self):
        """Returns an output pipe for the many-to-many pipe."""
        return self._one_to_many_pipe.get_output_pipe()
