from simpy import Environment, Store

from ....validation.type_validation import assert_is_type


class OneToManyPipe(object):
    """A one-to-many pipe that allows one process to send messages to many."""

    def __init__(self, env):
        """Initializes a OneToManyPipe object with an internal container for broadcasting pipes.

        Args:
            env (Environment): a Simpy environment
        """
        assert_is_type(env, Environment)
        self._env = env
        self._pipes = []

    def put(self, value):
        """Broadcasts a value to all output pipes."""
        events = [store.put(value) for store in self._pipes]
        return self._env.all_of(events)

    def get_output_pipe(self):
        """Returns an output pipe for the one-to-many pipe."""
        pipe = Store(self._env)
        self._pipes.append(pipe)
        return pipe
