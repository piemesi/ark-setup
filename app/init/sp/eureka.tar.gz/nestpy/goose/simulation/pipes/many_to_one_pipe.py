from simpy import Environment, Store

from ....validation.type_validation import assert_is_type


class ManyToOnePipe(object):
    """A many-to-one pipe that allows one to combine the outputs of multiple pipes."""

    def __init__(self, env):
        """Initializes a ManyToOnePipe object and creates an internal pipe for the combined events.

        Args:
            env (Environment): a Simpy environment
        """
        assert_is_type(env, Environment)
        self._env = env
        self._combined_pipe = Store(self._env)

    def _combine_process(self, pipe):
        """The process that adds the individual pipes to the combined pipe."""
        while True:
            output = yield pipe.get()
            self._combined_pipe.put(output)

    def register(self, pipe):
        """Registers the passed pipe to the combined pipe."""
        self._env.process(self._combine_process(pipe))

    @property
    def items(self):
        return self._combined_pipe.items

    def get(self):
        return self._combined_pipe.get()
