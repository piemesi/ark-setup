from ..datetime_environment import DatetimeEnvironment
from ...events.event_manager import EventManager
from ....states.state_spaces import GOOSEStateSpace
from .....validation.type_validation import assert_is_type


class _EventEmitterContainer(object):
    """Container for storing and retrieving event emitters."""

    def __init__(self):
        self._event_emitters = {}

    def register(self, identifier, event_emitter):
        if identifier in self._event_emitters:
            raise ValueError("Event emitter with identifier '{}' has already been registered".format(identifier))
        self._event_emitters[identifier] = event_emitter

    def get(self, identifier):
        return self._event_emitters.get(identifier)

    def get_all(self):
        return self._event_emitters.values()


class _PersonContainer(_EventEmitterContainer):
    pass


class _DeviceContainer(_EventEmitterContainer):
    pass


class MOOSEEnvironment(DatetimeEnvironment):
    """The MOOSE environment is the core environment used for MOOSE simulations."""

    def __init__(self, state_space, *args, **kwargs):
        """Initializes a MOOSEEnvironment object with a state space and inherited parameters.

        Args:
            state_space (GOOSEStateSpace): the state space of the environment
        """
        super(MOOSEEnvironment, self).__init__(*args, **kwargs)
        assert_is_type(state_space, GOOSEStateSpace)
        self._state_space = state_space
        self.event_manager = EventManager(env=self)
        self.persons = _PersonContainer()
        self.devices = _DeviceContainer()

    def get_state_space(self):
        return self._state_space
