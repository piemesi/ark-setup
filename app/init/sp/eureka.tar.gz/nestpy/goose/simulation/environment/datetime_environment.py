import datetime
import logging
import pytz

from simpy import Environment

from ....validation.datetime_validation import assert_same_tzinfo, assert_valid_start_and_end_dates

logger = logging.getLogger(__name__)


class DatetimeEnvironment(Environment):
    """The DatetimeEnvironment is a Simpy environment that supports datetime objects.

    Normal Simpy environments use integers as their measure of time. The purpose of this class is to map datetime
    and timedelta objects to integers, allowing the user to interact with the environment using those objects.
    """

    def __init__(self, start_datetime, end_datetime):
        """Initializes a DatetimeEnvironment object with a start and end time of the simulation.

        Args:
            start_datetime (datetime.datetime): start time of the simulation
            end_datetime (datetime.datetime): end time of the simulation
        """
        assert_valid_start_and_end_dates(start_datetime, end_datetime)
        self._start_datetime = start_datetime
        self._end_datetime = end_datetime
        super(DatetimeEnvironment, self).__init__(initial_time=self._get_epoch_time(start_datetime))

    def _get_epoch_time(self, _datetime):
        """Returns the epoch time equivalent for the passed datetime object."""
        epoch_datetime = datetime.datetime.utcfromtimestamp(0)
        if self._start_datetime.tzinfo is not None:
            epoch_datetime = self._start_datetime.tzinfo.normalize(pytz.utc.localize(epoch_datetime))
        return (_datetime - epoch_datetime).total_seconds()

    def compute_timedelta(self, _datetime):
        """Returns timedelta object for delta between current simulation datetime and passed datetime object."""
        current_datetime = self.get_current_datetime()
        assert_valid_start_and_end_dates(current_datetime, _datetime)
        return _datetime - current_datetime

    def run_until_end_datetime(self):
        """Runs simulation until the specified end datetime."""
        current_datetime = self.get_current_datetime()
        assert_valid_start_and_end_dates(current_datetime, self._end_datetime)
        self.run(until=self._get_epoch_time(self._end_datetime))

    def timeout_until_datetime(self, _datetime):
        """Returns a timeout until the passed datetime object."""
        duration = self.compute_timedelta(_datetime)
        return self.timeout_timedelta(duration)

    def timeout_timedelta(self, timedelta):
        """Returns a timeout for the passed timedelta object."""
        return self.timeout(timedelta.total_seconds())

    def get_current_datetime(self):
        """Returns current simulation datetime object."""
        current_datetime = datetime.datetime.utcfromtimestamp(self.now)
        if self._start_datetime.tzinfo is not None:
            current_datetime = self._start_datetime.tzinfo.normalize(pytz.utc.localize(current_datetime))
        return current_datetime

    def get_start_datetime(self):
        return self._start_datetime
