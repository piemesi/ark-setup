import pandas as pd

from .events.event_emitters import Person
from .events.event_emitters.abstract_device import AbstractDevice
from .events.event_emitters.devices import Diamond, MobileDevice, Topaz
from .environment.datetime_environments import MOOSEEnvironment
from ..states.state_series_ import GroundTruthStateSeries
from ...structures.device_histories import diamond, mobile_device, topaz
from ...validation.type_validation import assert_is_type, assert_list_of_type


class Simulation(object):

    def __init__(self, env, persons, devices):
        assert_is_type(env, MOOSEEnvironment)
        assert_list_of_type(persons, Person)
        assert_list_of_type(devices, AbstractDevice)
        self._env = env
        self._persons = persons
        self._devices = devices

    @staticmethod
    def _create_device_history(device, device_pipe, device_history_cls):
        device_history = device_history_cls(device.get_identifier())
        event_logs = pd.DataFrame.from_dict(dict(device_pipe.items), orient='index')
        for event_name in event_logs.columns:
            device_history.add_event_data(event_name, event_logs[event_name].dropna().apply(pd.Series))
        return device_history

    @classmethod
    def _create_diamond_device_history(cls, device, device_pipe):
        device_history = cls._create_device_history(device, device_pipe, diamond.Diamond)
        device_history.add_event_data('SetPoints', pd.DataFrame(columns=['Category']))
        return device_history

    @classmethod
    def _create_mobile_device_history(cls, device, device_pipe):
        device_history = cls._create_device_history(device, device_pipe, mobile_device.MobileDevice)
        return device_history

    @classmethod
    def _create_topaz_device_history(cls, device, device_pipe):
        device_history = cls._create_device_history(device, device_pipe, topaz.Topaz)
        return device_history

    @classmethod
    def _create_device_histories(cls, devices):
        device_histories = []
        for device, device_pipe in devices:
            if isinstance(device, Diamond):
                device_history = cls._create_diamond_device_history(device, device_pipe)
            elif isinstance(device, MobileDevice):
                device_history = cls._create_mobile_device_history(device, device_pipe)
            elif isinstance(device, Topaz):
                device_history = cls._create_topaz_device_history(device, device_pipe)
            else:
                continue
            device_histories.append(device_history)
        return device_histories

    @staticmethod
    def _create_ground_truth_state_series(persons, state_space):
        def _compute_ground_truth(states):
            for state_label in [
                state_space.get_active_state().get_state_label(),
                state_space.get_sleep_state().get_state_label(),
                state_space.get_vacant_state().get_state_label()
            ]:
                if state_label in states.values:
                    return state_label
        person_states = []
        for person, person_pipe in persons:
            person_states.append(pd.DataFrame.from_dict(dict(person_pipe.items), orient='index'))
        person_states_frame = pd.concat(person_states, axis=1).fillna(method='pad')
        ground_truth_series = person_states_frame.apply(_compute_ground_truth, axis=1)
        return GroundTruthStateSeries(state_space=state_space, series=ground_truth_series)

    def run(self):
        for event_emitter in self._persons + self._devices:
            event_emitter.register(self._env)
        persons = [
            (person, self._env.event_manager.get_output_pipe(person.person_process))
            for person in self._persons
        ]
        devices = [
            (device, self._env.event_manager.get_output_pipe(device.logging_process))
            for device in self._devices
        ]
        self._env.run_until_end_datetime()
        device_histories = self._create_device_histories(devices)
        ground_truth_state_series = self._create_ground_truth_state_series(persons, self._env.get_state_space())
        return device_histories, ground_truth_state_series
