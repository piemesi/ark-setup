from abc import ABCMeta


class AbstractClusterBuilder(object):

    __metaclass__ = ABCMeta

    def __init__(self, data):
        self._data = data

    def __repr__(self):
        return "<{}>".format(self.__class__.__name__)

    def cluster_data(self, *args, **kwargs):
        raise NotImplementedError

    def get_clustering_features(self, *args, **kwargs):
        raise NotImplementedError

    def get_data(self):
        return self._data
