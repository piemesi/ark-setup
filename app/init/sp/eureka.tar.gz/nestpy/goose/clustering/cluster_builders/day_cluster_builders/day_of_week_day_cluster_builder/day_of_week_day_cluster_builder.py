import pandas as pd
import numpy as np

from ..abstract_day_type_cluster_builder import AbstractDayClusterBuilder
from ....clusters.day_cluster import DayCluster
from ....cluster_collections.day_cluster_collection import DayClusterCollection


class DayOfWeekDayClusterBuilder(AbstractDayClusterBuilder):
    """
    Cluster builder for grouping by day of week
    """

    def cluster_data(self):
        """
        Clusters days day-of-the-week

        Returns:
            DayTypeClusterCollection of DayTypeClusters
        """
        predictions = self.get_clustering_features(self._data)
        data_mapping = self._map_predictions_to_data(predictions, self._data)

        return DayClusterCollection(
            [DayCluster(
                i,
                pd.Series(
                    data=True,
                    index=data_mapping.loc[data_mapping == i].index
                ),
                pd.DataFrame([i], index=[i]),
                pd.DataFrame(predictions[predictions == i]),
            ) for i in range(7)]
        )

    @staticmethod
    def get_clustering_features(data):
        """
        Extract features for clustering from data

        Args:
            data: pandas.Series with PIR data

        Returns:
            pandas.Series with for each date the corresponding day-of-week
        """
        resampled_series = data.resample("D", how="max").dropna()
        return pd.Series(
            data=resampled_series.index.dayofweek.astype(np.int64),
            index=resampled_series.index
        )
