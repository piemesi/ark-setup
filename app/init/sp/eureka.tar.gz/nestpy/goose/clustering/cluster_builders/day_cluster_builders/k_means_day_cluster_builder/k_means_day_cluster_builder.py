import pandas as pd

from datetime import datetime, time
from sklearn.cluster import KMeans

from ..abstract_day_type_cluster_builder import AbstractDayClusterBuilder
from ....cluster_collections import DayClusterCollection
from ....clusters import DayCluster
from ......converters.time_constants import SECONDS_PER_HOUR
from ......validation.type_validation import assert_is_type, assert_type_in


class KMeansDayClusterBuilder(AbstractDayClusterBuilder):
    """
    This class attemps to cluster similar days together based on PIR data. It uses sklearn's KMeans algorithm with
    24 features, where each feature is the time-to-next-pir for a particular hour of the day.
    """

    @staticmethod
    def _validate_cluster_builder_inputs(curated_series, n_clusters, clip, fraction):
        assert_type_in(fraction, [int, float])
        assert_type_in(clip, [int, float])
        assert_is_type(curated_series, pd.Series)
        assert fraction > 0, "fraction needs to be positive definite"
        assert clip > 0, "clip value needs to be positive definite"
        assert (isinstance(n_clusters, int) or n_clusters == "auto"), "Unknown input type, use an integer or 'auto'"

    def cluster_data(self, target_n_clusters="auto", clip=9, fraction=0.05, random_state=None):
        """
        Clusters similar days using k-means on 24 features per day, where each feature is the time-to-next-pir for a
         particular hour of the day.
        Args:
            target_n_clusters: an integer if the desired number of clusters is known, 'auto' for automatic optimisation
            clip: maximum time-to-next-pir in hours
            fraction: minimum percentage of pir readings that need to be in a cluster for the cluster to be accepted
            random_state: (...)

        Returns:
            DayClusterCollection of DayClusters
        """
        self._validate_cluster_builder_inputs(self._data, target_n_clusters, clip, fraction)
        training_features = self.get_clustering_features(self._data, clip)
        min_pir_per_cluster = fraction * len(self._data)
        cluster_candidates = []

        if isinstance(target_n_clusters, int):
            assert target_n_clusters >= 2, "n_clusters should be 2 or higher"
            n_clusters = target_n_clusters
            while True:
                cluster_candidates = self._cluster_engine(
                    training_features,
                    self._data,
                    n_clusters,
                    random_state=random_state,
                )
                if sum(
                        [self._has_sufficient_pir(c, min_pir_per_cluster) for c in cluster_candidates]
                ) >= target_n_clusters or n_clusters > 20:
                    break
                else:
                    n_clusters += 1
        else:
            n_clusters = 1
            while True:
                n_clusters += 1
                cluster_candidates_temp = self._cluster_engine(
                    training_features,
                    self._data,
                    n_clusters,
                    random_state=random_state,
                )
                n_good, n_bad = self._count_good_bad_candidates(cluster_candidates_temp, min_pir_per_cluster)
                if n_good >= 8 or (n_good >= 3 and n_bad >= 10) or n_clusters > 20:
                    cluster_candidates = cluster_candidates_temp
                    break
                else:
                    cluster_candidates = cluster_candidates_temp

        good_clusters = [c for c in cluster_candidates if self._has_sufficient_pir(c, min_pir_per_cluster)]
        return DayClusterCollection(
            [DayCluster(
                i,
                c.get_pir_series(),
                c.get_archetype(),
                c.get_features(),
            )
             for i, c in enumerate(good_clusters)]
        )

    @classmethod
    def _count_good_bad_candidates(cls, candidates, min_pir_per_cluster):
        n_good = sum([cls._has_sufficient_pir(c, min_pir_per_cluster) for c in candidates])
        return n_good, len(candidates) - n_good

    @staticmethod
    def _create_candidates(centers, data_mapping, features, predictions):
        return [DayCluster(
            k,
            pd.Series(data=True, index=data_mapping[data_mapping == k].index),
            pd.DataFrame(
                data=[centers[k]],
                index=[k],
                columns=range(24)
            ),
            features.loc[predictions == k]
        ) for k in range(len(centers))]

    @staticmethod
    def _has_sufficient_pir(day_type_cluster, min_pir):
        return len(day_type_cluster.get_pir_series()) >= min_pir

    @classmethod
    def _cluster_engine(cls, features, data, n_clusters, random_state=None):
        if random_state is None:
            km = KMeans(n_clusters=n_clusters)
        else:
            km = KMeans(n_clusters=n_clusters, random_state=random_state)
        predictions = pd.Series(
            data=km.fit_predict(features.as_matrix()),
            index=features.index,
        )
        mapping = cls._map_predictions_to_data(predictions, data)
        return cls._create_candidates(
            km.cluster_centers_,
            mapping,
            features,
            predictions
        )

    @classmethod
    def get_clustering_features(cls, data, clip_hours):
        """
        Compute features for a series of PIR data. For every day, 24 features are created where a feature is the
         time-to-next-pir for an hour of the day.

        Args:
            data: pandas.Series object containing timestamps as indices and True as values
            clip_hours: maximum time-to-next-pir in hours

        Returns:
            pandas.DataFrame with the features as columns and the dates as rows
        """
        timestamps_mirrored = pd.Series(data=data.index.values, index=data.index)

        timestamps_mirrored_hour_index = timestamps_mirrored.resample("H", how="first", fill_method="bfill")
        full_hourly_index = pd.DatetimeIndex(
            freq="H",
            start=datetime.combine(timestamps_mirrored_hour_index.index[0].date(), time(0)),
            end=datetime.combine(timestamps_mirrored_hour_index.index[-1], time(23))
        )
        timestamps_mirrored_full_hour_index = timestamps_mirrored_hour_index.reindex(full_hourly_index).bfill()
        time_to_next_pir = timestamps_mirrored_full_hour_index - timestamps_mirrored_full_hour_index.index
        df_columns = pd.DataFrame({
            "diff": time_to_next_pir.astype("timedelta64[s]") / SECONDS_PER_HOUR,
            "date": pd.DatetimeIndex(time_to_next_pir.index.date),
            "hour": [dt.time().hour for dt in time_to_next_pir.index]
        })
        df_pivoted = df_columns.pivot(
            index="date",
            columns="hour",
            values="diff"
        ).fillna(clip_hours).clip_upper(clip_hours)
        df_without_metadata = pd.DataFrame(
            data=df_pivoted.values,
            columns=df_pivoted.columns.values,
            index=df_pivoted.index.values
        )
        dates_with_pir = cls._resample_day(data)
        return df_without_metadata.loc[dates_with_pir.index]
