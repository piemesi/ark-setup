import pandas as pd

from ...cluster_builders import AbstractClusterBuilder
from .....converters.time_converters import get_tz_naive_datetime
from .....validation.type_validation import assert_is_type


class AbstractDayClusterBuilder(AbstractClusterBuilder):

    def __init__(self, data):
        data_with_tz_naive_index = pd.Series(
            data=data.values,
            index=get_tz_naive_datetime(data.index)
        )
        super(AbstractDayClusterBuilder, self).__init__(data_with_tz_naive_index)

    def cluster_data(self, *args, **kwargs):
        raise NotImplementedError

    def get_clustering_features(self, *args, **kwargs):
        raise NotImplementedError

    @staticmethod
    def _map_predictions_to_data(predictions, data):
        """
        Returns a pandas.Series similar to the input pir_series, where the values are the id of the cluster to which the
         day belongs.
        Args:
            predictions: pd.Series of predictions for each day in the input pir_series
            data: pir_series

        Returns:
            pandas.Series with dates as indices and cluster_ids as values
        """
        assert_is_type(predictions, pd.Series)
        assert_is_type(data, pd.Series)
        series = pd.Series(
            data=data.index.date,
            index=data.index,
        )
        return series.map(predictions).dropna()

    @staticmethod
    def _resample_day(series):
        assert_is_type(series, pd.Series)
        return series.resample("D", how="max").dropna()
