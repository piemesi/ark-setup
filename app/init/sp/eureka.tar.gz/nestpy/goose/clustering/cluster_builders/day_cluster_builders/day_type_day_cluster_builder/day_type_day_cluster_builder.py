import numpy as np
import pandas as pd

from datetime import timedelta

from ..abstract_day_type_cluster_builder import AbstractDayClusterBuilder
from ....clusters.day_cluster import DayCluster
from ....cluster_collections.day_cluster_collection import DayClusterCollection
from ......validation.type_validation import assert_is_type


class DayTypeDayClusterBuilder(AbstractDayClusterBuilder):
    """
    Cluster builder for grouping weekdays and weekends
    """

    def cluster_data(self, shift=True):
        """
        Clusters weekdays and weekends
        Args:
            shift: When True, days are assumed to start at noon the previous day. Hence weekend will start at Friday
            noon. When False, the cluster builder takes midnight as separators.

        Returns:
            DayClusterCollection of DayClusters
        """
        timeshift = shift * timedelta(hours=12)
        shifted_series = self._shift(self._data, timeshift)
        shifted_predictions = self.get_clustering_features(
            self._resample_day(
                shifted_series
            )
        )
        shifted_data_mapping = self._map_predictions_to_data(shifted_predictions, shifted_series)
        data_mapping = self._shift(shifted_data_mapping, -timeshift)

        sp = self._shift(self.get_clustering_features(shifted_series), -timeshift)
        df = pd.Series(
            data=sp.values,
            index=sp.index.date
        ).reset_index().drop_duplicates()
        predictions = pd.Series(
            data=df[0].values,
            index=pd.DatetimeIndex(df["index"].values)
        )

        return DayClusterCollection(
            [DayCluster(
                i,
                pd.Series(
                    data=True,
                    index=data_mapping.loc[data_mapping == i].index
                ),
                pd.DataFrame([i], index=[i]),
                pd.DataFrame(predictions[predictions == i]),
            ) for i in range(2)]
        )

    @staticmethod
    def get_clustering_features(data):
        """
        Extract features for clustering from data

        Args:
            data: pandas.Series with PIR data

        Returns:
            pandas.Series with 0-values for weekdays and 1-values for weekends
        """
        assert_is_type(data, pd.Series)
        predictions = pd.Series(
            data=pd.Series(data.index.dayofweek >= 5).astype(np.int).values,
            index=data.index,
        )
        return predictions

    @staticmethod
    def _shift(series, td):
        assert_is_type(series, pd.Series)
        assert_is_type(td, timedelta)
        return pd.Series(
            data=series.values,
            index=series.index + td
        )
