import pandas as pd

from abc import ABCMeta

from ....validation.type_validation import assert_is_type, assert_list_of_type


class AbstractClusterCollection(object):

    __metaclass__ = ABCMeta

    def __init__(self, cluster_list):
        self._validate_cluster_list(cluster_list)
        self._cluster_list = sorted(cluster_list, key=lambda x: x.get_id())

    def __repr__(self):
        return "<{}>".format(self.__class__.__name__)

    def __hash__(self):
        return hash(frozenset(self._cluster_list))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__hash__() == other.__hash__()

    def __ne__(self, other):
        return not self.__eq__(other)

    def __len__(self):
        return len(self._cluster_list)

    def __getitem__(self, item):
        return self._cluster_list.__getitem__(item)

    @classmethod
    def _validate_cluster_list(cls, cluster_list):
        assert_is_type(cluster_list, list)
        assert_list_of_type(cluster_list, cls.get_cluster_cls())

    @staticmethod
    def get_cluster_cls():
        raise NotImplementedError

    def get_archetypes(self):
        return pd.DataFrame(
            pd.concat(
                [cluster.get_archetype() for cluster in self._cluster_list],
                axis=0,
            )
        ).sort_index()

    def get_dates(self):
        return pd.Series(
            pd.concat([cluster.get_dates() for cluster in self._cluster_list], axis=0)
        ).sort_index()

    def get_cluster_list(self):
        return self._cluster_list

    def get_features(self):
        return pd.DataFrame(
            pd.concat(
                [cluster.get_features() for cluster in self._cluster_list],
                axis=0,
            )
        ).sort_index()
