import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from datetime import timedelta

from ..abstract_cluster_collection import AbstractClusterCollection
from ...clusters.day_cluster import DayCluster
from ....parameters import AbstractParametersCollection
from ....parameters.parameters_collections import InactivityParametersCollection
from .....validation.type_validation import assert_is_type


class DayClusterCollection(AbstractClusterCollection):
    """
    This class is a wrapper around a list of DayClusters. It contains several convenience methods for applying functions
    on all DayClusters in this collection. Also it offers methods for aggregating data from all DayClusters
    """

    @staticmethod
    def get_cluster_cls():
        return DayCluster

    def day_type_analysis(self):
        """
        Analyse the distribution of the days-of-week of the days in the clusters in the collection

        Returns:
            pandas.DataFrame with counts of days and cluster_id's as indices
        """
        day_type_analysis_df = pd.DataFrame(pd.concat([cluster.day_type_analysis() for cluster in self._cluster_list]))
        if not day_type_analysis_df.index.is_unique:
            day_type_analysis_df.reset_index(drop=True, inplace=True)
        return day_type_analysis_df

    def get_number_of_days(self):
        return sum([cluster.get_number_of_days() for cluster in self._cluster_list])

    def estimate_parameters(self, parameter_estimator_cls, *args, **kwargs):
        """
        Convenience method for estimating the parameters of the underlying pir_series of the clusters in this collection

        Args:
            parameter_estimator_cls: subclass of AbstractParameterEstimator
            *args: additional args to be passed to estimate_parameters method
            **kwargs: additional kwargs to be passed to estimate_parameters method

        Returns:
            inactivity_parameters_collection object
        """
        return InactivityParametersCollection(
            [cluster.estimate_parameters(
                parameter_estimator_cls,
                *args,
                **kwargs
            ) for cluster in self._cluster_list]
        )

    def parameter_dataframe(self, parameters_collection):
        """
        Compute a pandas.DataFrame with parameters as values and dates as indices.

        Args:
            parameters_collection: subclass of AbstractParametersCollection object

        Returns:
            pandas.DataFrame
        """
        assert issubclass(parameters_collection.__class__, AbstractParametersCollection), (
            "Unknown parameters_collection class {}".format(parameters_collection.__class__)
        )
        df_list = [cluster.parameter_dataframe(parameters) for cluster, parameters in zip(
            self._cluster_list,
            parameters_collection
        )]
        parameter_dataframe = pd.DataFrame(pd.concat(df_list, axis=0)).sort_index()

        return parameter_dataframe.reindex(
            pd.date_range(
                start=parameter_dataframe.index[0],
                end=parameter_dataframe.index[-1]
            )
        ).dropna()

    def cluster_new_sample(self, new_sample):
        """
        Computes to which cluster a new sample belongs.

        Args:
            new_sample: pandas.DataFrame of the same shape as the archetypes in the cluster collection

        Returns:
            cluster object
        """
        assert_is_type(new_sample, pd.DataFrame)
        argument = np.argmin(
            [cluster.euclidian_distance(new_sample.as_matrix()) for cluster in self._cluster_list]
        )
        return self._cluster_list[argument]

    def plot_activity_probabilities(self, axes=None, bin_size=timedelta(minutes=30), *args, **kwargs):
        """
        Plots the discrete activity probabilities in bins of 'bin_size' for each cluster in a subplot.

        Args:
            bin_size: timedelta object specifying the width of the bins. Needs to fit an integer times in 24h.
            axes: list of matplotlib.Axes object to plot on
            *args: additional args to be passed to vlines method
            **kwargs: additional kwargs to be passed to vlines method

        Returns:
            matplotlib.Axes object where the data has been plotted on
        """
        if axes is None:
            f, axes = plt.subplots(nrows=len(self))
        else:
            assert len(axes) == len(self)
        return [cluster.plot_activity_probabilities(
            axis=axes[cluster.get_id()],
            bin_size=bin_size,
            *args,
            **kwargs
        ) for cluster in self._cluster_list]
