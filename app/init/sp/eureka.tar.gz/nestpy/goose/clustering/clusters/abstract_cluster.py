import pandas as pd

from abc import ABCMeta
from pandas.util.testing import assert_index_equal

from ....validation.type_validation import assert_is_type


class AbstractCluster(object):
    """
    Abstract class of a cluster, an object that contains data that are similar in some way. Needs to contain an
    archetype/cluster center, a set of features on which the clustering is based.
    """

    __metaclass__ = ABCMeta

    def __init__(self, archetype, features):
        self._validate_cluster(archetype, features)
        self._archetype = archetype
        self._features = features
        self._number_of_features = features.shape[1]

    def __repr__(self):
        return "<{}>".format(self.__class__.__name__)

    def __hash__(self):
        return hash(self._key())

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self._key() == other._key()

    def __ne__(self, other):
        return not self.__eq__(other)

    def _key(self):
        raise NotImplementedError

    @classmethod
    def _validate_cluster(cls, archetype, features):
        assert_is_type(archetype, pd.DataFrame)
        assert_is_type(features, pd.DataFrame)
        assert_index_equal(archetype.columns, features.columns)

    def get_features(self):
        return self._features

    def get_archetype(self):
        return self._archetype
