import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from datetime import timedelta

from ..abstract_cluster import AbstractCluster
from ....parameter_estimators.inactivity_parameter_estimators import WindowInactivityParameterEstimator


class DayCluster(AbstractCluster):
    """
    This class contains a pandas.Series with PIR readings from days that are similar in some way. Similarities could be
    numerical or based on e.g. day-of-week.
    """

    def __init__(self, cluster_id, pir_series, *args, **kwargs):
        super(DayCluster, self).__init__(*args, **kwargs)
        self._cluster_id = cluster_id
        self._pir_series = pir_series

    def _key(self):
        return (
            self._freeze_df(self._archetype),
            self._freeze_df(self._features),
            frozenset(self._pir_series.iteritems()),
            self._number_of_features,
            self._cluster_id,
        )

    @staticmethod
    def _freeze_df(df):
        return frozenset([(a, frozenset(b.iteritems())) for a, b in df.iterrows()])

    def estimate_parameters(self, parameter_estimator_cls, *args, **kwargs):
        """
        Convenience method for estimating the parameters of the underlying pir_series of this cluster
        Args:
            parameter_estimator_cls: subclass of AbstractParameterEstimator
            *args: additional args to be passed to estimate_parameters method
            **kwargs: additional kwargs to be passed to estimate_parameters method

        Returns:
            inactivity_parameters object
        """
        parameter_estimator = parameter_estimator_cls(self._pir_series)
        return parameter_estimator.estimate_parameters(*args, **kwargs)

    def get_id(self):
        return self._cluster_id

    def get_pir_series(self):
        return self._pir_series

    def day_type_analysis(self):
        """
        Analyse the distribution of the days-of-week of the days in the cluster

        Returns:
            pandas.DataFrame with counts of days
        """
        dates = self.get_dates()
        counts = dates.groupby(dates.index.dayofweek).count().reindex(range(7), fill_value=0)
        df = pd.DataFrame(
            data=[counts.values],
            index=[self.get_id()],
            columns=["M", "T", "W", "T", "F", "S", "S"],
        )
        df["total"] = df.sum(axis=1)
        return df

    def parameter_dataframe(self, parameters, to_time=True):
        """
        Compute a pandas.DataFrame with parameters as values and dates as indices.
        Args:
            parameters: subclass of AbstractParameters object
            to_time: convert values of DataFrame to datetime.time objects

        Returns:
            pandas.DataFrame
        """
        new_index = self.get_dates().index
        parameters_in_dataframe = parameters.to_dataframe(to_time=to_time)
        return pd.DataFrame(
            data=parameters_in_dataframe.values,
            index=[new_index[0]],
            columns=parameters_in_dataframe.columns,
        ).reindex(new_index).ffill().sort_index()

    def plot_activity_probabilities(self, axis=None, bin_size=timedelta(minutes=30), *args, **kwargs):
        """
        Plots the discrete activity probabilities in bins of 'bin_size'.

        Args:
            bin_size: timedelta object specifying the width of the bins. Needs to fit an integer times in 24h
            axis: matplotlib.Axes object to plot on
            *args: additional args to be passed to vlines method
            **kwargs: additional kwargs to be passed to vlines method

        Returns:
            matplotlib.Axes object where the data has been plotted on
        """
        if axis is None:
            _, axis = plt.subplots()
        w = WindowInactivityParameterEstimator(self._pir_series)
        w.plot_activity_probabilities(bin_size, axis=axis, *args, **kwargs)
        axis.set_title("Cluster {}: {} days".format(self.get_id(), self.get_number_of_days()))
        return axis

    def euclidian_distance(self, point):
        archetype_matrix = self._archetype.as_matrix()
        assert archetype_matrix.shape == point.shape
        return np.sqrt(np.sum(np.power(archetype_matrix - point, 2)))

    def get_dates(self):
        return pd.Series(
            data=True,
            index=self._features.index
        )

    def get_number_of_days(self):
        return self._features.shape[0]
