import pandas as pd
from nestpy.manipulators.series_manipulators import compute_timedelta_series

from .state_space import StateSpace
from ...validation.type_validation import assert_is_type


class StateSeries(object):

    def __init__(self, state_space, series):
        assert_is_type(state_space, StateSpace)
        assert_is_type(series, pd.Series)
        self._validate_series(state_space, series)
        self._series = self._rename_series(series)
        self._state_space = state_space
        self._time_in_states = None
        self._intervals = None

    def __repr__(self):
        return "<{}>".format(self.__class__.__name__)

    def __hash__(self):
        return hash((self._state_space, tuple(self._series.iteritems())))

    def __eq__(self, other):
        return (isinstance(other, self.__class__) and
                self._state_space == other._state_space and
                self._series.equals(other._series))

    def __ne__(self, other):
        return not self.__eq__(other)

    @staticmethod
    def _validate_series(state_space, series):
        for unique_state_label in series.unique():
            if not state_space.has_state_label(unique_state_label):
                raise ValueError("State label '{}' not found in {} state space.".format(unique_state_label, state_space))

    def _rename_series(self, series):
        renamed_series = series.copy()
        renamed_series.name = self.__class__.__name__
        return renamed_series

    def get_series(self):
        return self._series

    def get_state_space(self):
        return self._state_space

    def get_time_in_states(self):
        if self._time_in_states is not None:
            return self._time_in_states
        time_in_states = {state_label: pd.Timedelta(seconds=0) for state_label in self._state_space.get_state_labels()}
        timedelta_series = compute_timedelta_series(self._series.index)
        time_in_states.update(timedelta_series.groupby(self._series).sum().to_dict())
        self._time_in_states = time_in_states
        return time_in_states

    def get_intervals(self):
        if self._intervals is not None:
            return self._intervals
        timedelta_series = compute_timedelta_series(self._series.index)
        intervals = {state_label: [] for state_label in self._state_space.get_state_labels()}
        intervals.update(timedelta_series.iloc[:-1].groupby(self._series).apply(list).to_dict())
        self._intervals = intervals
        return intervals
