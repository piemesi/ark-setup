import pandas as pd

from .state_series import StateSeries
from ...validation.type_validation import assert_is_type


class StateSeriesCollection(object):

    def __init__(self, state_series_list):
        self._validate_state_series_list(state_series_list)
        self._state_series_list = state_series_list

    def __repr__(self):
        return "<{}>".format(self.__class__.__name__)

    @classmethod
    def _validate_state_series_list(cls, state_series_list):
        assert_is_type(state_series_list, list)
        for state_series in state_series_list:
            assert_is_type(state_series, StateSeries)

    def get_state_series_list(self):
        return self._state_series_list

    @staticmethod
    def _state_series_list_to_data_frame(state_series_list):
        state_series_list = [state_series for state_series in state_series_list]
        if state_series_list:
            state_series_data_frame = pd.concat(state_series_list, axis=1)
        else:
            state_series_data_frame = pd.DataFrame()
        return state_series_data_frame
