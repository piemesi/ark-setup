from .state import State
from ...validation.type_validation import assert_is_type, assert_list_of_type


class StateSpace(object):

    def __init__(self, states):
        assert_list_of_type(states, State)
        self._validate_state_uniqueness(states)
        self._states = states

    def __repr__(self):
        return "<{}>".format(self.__class__.__name__)

    def __hash__(self):
        return hash(tuple(self._states))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and set(self._states) == set(other._states)

    def __ne__(self, other):
        return not self.__eq__(other)

    def __iter__(self):
        return iter(self._states)

    def __len__(self):
        return len(self._states)

    def __getitem__(self, state_enum):
        return self.get_state(state_enum)

    @staticmethod
    def _get_state_labels(states):
        state_labels = [state.get_state_label() for state in states]
        return state_labels

    @classmethod
    def _validate_state_uniqueness(cls, states):
        unique_states = list(set(states))
        if len(unique_states) != len(states):
            raise ValueError("States must be unique.")

    def get_state(self, state_enum):
        assert_is_type(state_enum, int)
        if state_enum not in range(len(self._states)):
            raise KeyError("No state found for state enum '{}'.".format(state_enum))
        return self._states[state_enum]

    def get_states(self):
        return self._states

    def has_state(self, state):
        return state in self._states

    def get_state_labels(self):
        return self._get_state_labels(self._states)

    def has_state_label(self, state_label):
        return state_label in self.get_state_labels()
