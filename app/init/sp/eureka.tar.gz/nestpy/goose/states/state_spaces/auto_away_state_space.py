from ..state import State
from ..state_space import StateSpace


class AutoAwayStateSpace(StateSpace):

    def __init__(self, auto_away_state, home_state, manual_away_state):
        super(AutoAwayStateSpace, self).__init__([auto_away_state, home_state, manual_away_state])
        self._auto_away_state = auto_away_state
        self._home_state = home_state
        self._manual_away_state = manual_away_state

    def get_auto_away_state(self):
        return self._auto_away_state

    def get_home_state(self):
        return self._home_state

    def get_manual_away_state(self):
        return self._manual_away_state


AUTO_AWAY_STATE_SPACE = AutoAwayStateSpace(auto_away_state=State('AutoAway'),
                                           home_state=State('Home'),
                                           manual_away_state=State('ManualAway'))
