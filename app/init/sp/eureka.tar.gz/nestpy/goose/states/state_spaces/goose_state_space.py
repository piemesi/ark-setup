from ..state import State
from ..state_space import StateSpace


class GOOSEStateSpace(StateSpace):

    def __init__(self, active_state, sleep_state, unknown_state, vacant_state):
        super(GOOSEStateSpace, self).__init__([active_state, sleep_state, unknown_state, vacant_state])
        self._active_state = active_state
        self._sleep_state = sleep_state
        self._vacant_state = vacant_state
        self._unknown_state = unknown_state

    def get_active_state(self):
        return self._active_state

    def get_sleep_state(self):
        return self._sleep_state

    def get_vacant_state(self):
        return self._vacant_state

    def get_unknown_state(self):
        return self._unknown_state


OCCUPANCY_STATE_SPACE = GOOSEStateSpace(active_state=State('Active'),
                                        sleep_state=State('Sleep'),
                                        unknown_state=State('Unknown'),
                                        vacant_state=State('Vacant'))
