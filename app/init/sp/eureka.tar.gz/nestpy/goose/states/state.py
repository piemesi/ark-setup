from ...validation.type_validation import assert_is_type


class State(object):

    def __init__(self, state_label):
        assert_is_type(state_label, (basestring, bool, int, float))
        self._state_label = state_label

    def __repr__(self):
        return "<{} label={}>".format(self.__class__.__name__, self._state_label)

    def __hash__(self):
        return hash(self._state_label)

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self._state_label == other._state_label

    def __ne__(self, other):
        return not self.__eq__(other)

    def get_state_label(self):
        return self._state_label
