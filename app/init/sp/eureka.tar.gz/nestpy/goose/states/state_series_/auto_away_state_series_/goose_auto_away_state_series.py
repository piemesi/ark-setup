from ..auto_away_state_series import AutoAwayStateSeries
from ....application_process.abstract_application_processor import AbstractApplicationProcessor
from .....validation.type_validation import assert_is_type


class GOOSEAutoAwayStateSeries(AutoAwayStateSeries):

    def __init__(self, series, application_processor):
        super(GOOSEAutoAwayStateSeries, self).__init__(series)
        assert_is_type(application_processor, AbstractApplicationProcessor)
        self._application_processor = application_processor

    def __repr__(self):
        return "<{}: {}>".format(self.__class__.__name__, str(self._application_processor))

    def get_application_processor(self):
        return self._application_processor
