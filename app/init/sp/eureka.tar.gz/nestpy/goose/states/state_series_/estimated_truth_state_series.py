from ..state_series import StateSeries


class EstimatedTruthStateSeries(StateSeries):
    pass
