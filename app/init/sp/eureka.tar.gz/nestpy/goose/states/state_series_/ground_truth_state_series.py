from ..state_series import StateSeries


class GroundTruthStateSeries(StateSeries):
    pass
