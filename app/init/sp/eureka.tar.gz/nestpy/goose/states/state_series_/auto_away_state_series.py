from ..state_series import StateSeries
from ..state_spaces import AUTO_AWAY_STATE_SPACE


class AutoAwayStateSeries(StateSeries):

    def __init__(self, series):
        super(AutoAwayStateSeries, self).__init__(AUTO_AWAY_STATE_SPACE, series)
