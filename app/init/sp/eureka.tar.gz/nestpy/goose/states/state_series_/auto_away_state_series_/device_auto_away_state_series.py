from ..auto_away_state_series import AutoAwayStateSeries
from .....structures.device import Device
from .....validation.type_validation import assert_is_type


class DeviceAutoAwayStateSeries(AutoAwayStateSeries):

    def __init__(self, series, device):
        super(DeviceAutoAwayStateSeries, self).__init__(series)
        assert_is_type(device, Device)
        self._device = device

    def __repr__(self):
        return "<{}: device={}>".format(self.__class__.__name__, self._device)

    def get_device(self):
        return self._device
