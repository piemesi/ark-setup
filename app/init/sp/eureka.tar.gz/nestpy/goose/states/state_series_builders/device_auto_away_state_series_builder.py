import pandas as pd

from ..state_series import StateSeries
from ..state_series_.auto_away_state_series_ import DeviceAutoAwayStateSeries
from ..state_spaces import AUTO_AWAY_STATE_SPACE
from ...building import AbstractObjectBuilder
from ...data_collection.abstract_data_collection import AbstractDataCollection
from ....validation.type_validation import assert_is_type


class DeviceAutoAwayStateSeriesBuilder(AbstractObjectBuilder):

    _CURRENT_STATE = "CurrentState"
    _AWAY_MODE = "AwayMode"
    _AWAY_MODE_LOOKUP = {
        0: AUTO_AWAY_STATE_SPACE.get_home_state().get_state_label(),
        1: AUTO_AWAY_STATE_SPACE.get_manual_away_state().get_state_label(),
        2: AUTO_AWAY_STATE_SPACE.get_auto_away_state().get_state_label()
    }
    _ECO_MODE = "EcoMode"
    _ECO_MODE_LOOKUP = {
        "schedule": AUTO_AWAY_STATE_SPACE.get_home_state().get_state_label(),
        "manual-eco": AUTO_AWAY_STATE_SPACE.get_manual_away_state().get_state_label(),
        "auto-eco": AUTO_AWAY_STATE_SPACE.get_auto_away_state().get_state_label()
    }

    def __init__(self):
        super(DeviceAutoAwayStateSeriesBuilder, self).__init__(object_cls=DeviceAutoAwayStateSeries)

    def _get_object_base_cls(self):
        return StateSeries

    def _get_builder_config_types(self):
        return dict()

    def build(self, data_collection):
        assert_is_type(data_collection, AbstractDataCollection)
        diamond_devices = data_collection.get_diamond_devices()
        diamond_device_histories = data_collection.get_diamond_device_histories()
        for device, device_history in zip(diamond_devices, diamond_device_histories):
            if self._CURRENT_STATE in device_history.events:
                away_series = pd.Series(dtype="str")
                for mode, mode_lookup, dtype in [
                    (self._AWAY_MODE, self._AWAY_MODE_LOOKUP, "int"),
                    (self._ECO_MODE, self._ECO_MODE_LOOKUP, "str")
                ]:
                    if mode in device_history[self._CURRENT_STATE]:
                        mode_series = device_history[self._CURRENT_STATE][mode].dropna().astype(dtype)
                        away_series = away_series.append(
                            mode_series.apply(lambda key: mode_lookup.get(key)).dropna().astype("str")
                        )
                return self._object_cls(away_series.sort_index(), device)
