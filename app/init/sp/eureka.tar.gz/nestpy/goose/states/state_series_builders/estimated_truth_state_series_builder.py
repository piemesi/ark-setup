from ...building import AbstractObjectBuilder
from ...models.model_builders.estimated_truth_model_builder import (
    EstimatedTruthModelBuilder,
    OCCUPANCY_LOOK_AHEAD_ESTIMATED_TRUTH_MODEL_BUILDER_CONFIG
)
from ...sensors import SensorEventsCollection
from ...states.state_spaces import GOOSEStateSpace, OCCUPANCY_STATE_SPACE
from ...states.state_series import StateSeries
from ...states.state_series_ import EstimatedTruthStateSeries
from ....validation.type_validation import assert_is_type


OCCUPANCY_ESTIMATED_TRUTH_STATE_SERIES_BUILDER_CONFIG = dict(
    object_cls=EstimatedTruthStateSeries,
    estimated_truth_model_builder=EstimatedTruthModelBuilder(
        **OCCUPANCY_LOOK_AHEAD_ESTIMATED_TRUTH_MODEL_BUILDER_CONFIG
    ),
    state_space=OCCUPANCY_STATE_SPACE
)


class EstimatedTruthStateSeriesBuilder(AbstractObjectBuilder):

    def _get_object_base_cls(self):
        return StateSeries

    def _get_builder_config_types(self):
        return dict(
            estimated_truth_model_builder=EstimatedTruthModelBuilder,
            state_space=GOOSEStateSpace
        )

    def build(self, sensor_events_collection):
        assert_is_type(sensor_events_collection, SensorEventsCollection)
        builder_config = self._builder_config.copy()
        estimated_truth_model = builder_config.pop('estimated_truth_model_builder').build()
        estimated_truth_series = estimated_truth_model.compute_estimated_truth_series(
            sensor_events_collection
        )
        return self._object_cls(series=estimated_truth_series, **builder_config)
