"""Generalized Online Occupancy State Estimator (GOOSE)

This is a Python-based framework to prototype and evaluate a
generalized online occupancy state estimator. The goal of the
framework is to output occupancy state probabilities as an online
process. These probabilities are meant to be consumed by
'applications' to meet specific needs such as Auto Away, Auto Arm, and
Granny Awareness. See the following for more background:

* https://wiki.nestlabs.com/display/ALGO/GOOSE+v0.5+Design+Overview

The framework is designed to run a configurable 'experiment'.

An experiment consists of some or all of these stages:

- Extract
    Extract features from logs and save the features.
- Learn
    Partition the available data into training and test sets and learn
    transition and sensor models from the training features and save the models.
- Filter
    Run the online filtering process that outputs belief probabilities
    for each occupancy state based on the learned models and sensor inputs from
    the test features.
- Analyze
    Generate ROC curves for thresholded applications and analyze the
    precision/recall and F1 scores for the Away applications.
"""
