from .sensor_events import SensorEvents
from .sensor_types.boolean_sensor_types import ActivitySensorType, PresenceSensorType
from ...validation.type_validation import assert_list_of_type


class SensorEventsCollection(object):

    def __init__(self, sensor_events_list):
        self._validate_sensor_events_list(sensor_events_list)
        self._sensor_events_list = sensor_events_list

    def __repr__(self):
        return "<{}>".format(self.__class__.__name__)

    def __hash__(self):
        return hash((self.__class__, self._keys))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self._keys == other._keys

    def __ne__(self, other):
        return not self.__eq__(other)

    @property
    def _keys(self):
        return frozenset(self._sensor_events_list)

    @staticmethod
    def _validate_sensor_events_list(sensor_events_list):
        assert_list_of_type(sensor_events_list, SensorEvents)
        assert len(sensor_events_list) == len(set(sensor_events_list))

    @staticmethod
    def _get_sensors(sensor_events_list):
        return map(lambda sensor_events: sensor_events.get_sensor(), sensor_events_list)

    def _get_sensor_events_list_for_sensor_of_type(self, sensor_type_cls):
        return filter(
            lambda sensor_events: isinstance(sensor_events.get_sensor().get_sensor_type(), sensor_type_cls),
            self._sensor_events_list
        )

    def get_sensor_events_list_for_sensor_types(self, sensor_types):
        return filter(
            lambda sensor_events: sensor_events.get_sensor().get_sensor_type() in sensor_types,
            self._sensor_events_list
        )

    def get_sensor_events_for_sensor(self, sensor):
        for sensor_events in self._sensor_events_list:
            if sensor_events.get_sensor() == sensor:
                return sensor_events

    def get_sensor_events_list(self):
        return self._sensor_events_list

    def get_activity_sensor_events_list(self):
        return self._get_sensor_events_list_for_sensor_of_type(ActivitySensorType)

    def get_presence_sensor_events_list(self):
        return self._get_sensor_events_list_for_sensor_of_type(PresenceSensorType)

    def get_sensors(self):
        return self._get_sensors(self._sensor_events_list)

    def get_activity_sensors(self):
        return self._get_sensors(self.get_activity_sensor_events_list())

    def get_presence_sensors(self):
        return self._get_sensors(self.get_presence_sensor_events_list())
