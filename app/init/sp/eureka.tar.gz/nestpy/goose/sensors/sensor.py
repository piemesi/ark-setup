from .abstract_sensor_type import AbstractSensorType
from ...validation.type_validation import assert_is_type


class Sensor(object):

    def __init__(self, sensor_type, sensor_reporting_policy, device):
        assert_is_type(sensor_type, AbstractSensorType)
        assert_is_type(sensor_reporting_policy, sensor_type.get_sensor_reporting_policy_cls())
        assert_is_type(device, sensor_type.get_device_cls())
        self._sensor_type = sensor_type
        self._sensor_reporting_policy = sensor_reporting_policy
        self._device = device

    def __repr__(self):
        return "<{}: sensor_name={}, device={}>".format(
            self.__class__.__name__,
            self._sensor_type.get_sensor_name(),
            self._device
        )

    def __hash__(self):
        return hash((str(self.__class__), self._keys))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self._keys == other._keys

    def __ne__(self, other):
        return not self.__eq__(other)

    @property
    def _keys(self):
        return self._sensor_type, self._sensor_reporting_policy, self._device

    def get_sensor_type(self):
        return self._sensor_type

    def get_sensor_reporting_policy(self):
        return self._sensor_reporting_policy

    def get_device(self):
        return self._device

    def get_identifier(self):
        return "{}-{}".format(self._sensor_type.get_identifier(), self._device.get_device_id())
