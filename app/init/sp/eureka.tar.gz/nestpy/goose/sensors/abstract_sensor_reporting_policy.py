import datetime

from abc import ABCMeta, abstractmethod

from ...validation.type_validation import assert_is_type


class AbstractSensorReportingPolicy(object):
    __metaclass__ = ABCMeta

    def __init__(self, cold_shoulder_timeout):
        assert_is_type(cold_shoulder_timeout, datetime.timedelta)
        self._cold_shoulder_timeout = cold_shoulder_timeout

    def __repr__(self):
        return "<{}>".format(self.__class__.__name__)

    def __hash__(self):
        return hash((str(self.__class__), self._keys))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self._keys == other._keys

    def __ne__(self, other):
        return not self.__eq__(other)

    @property
    def _keys(self):
        return self._cold_shoulder_timeout

    @abstractmethod
    def compute_reporting_events(self, series):
        raise NotImplementedError

    def get_cold_shoulder_timeout(self):
        return self._cold_shoulder_timeout
