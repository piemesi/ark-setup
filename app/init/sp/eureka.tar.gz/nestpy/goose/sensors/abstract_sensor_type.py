from abc import ABCMeta, abstractproperty

from ...structures.device import Device
from ...validation.type_validation import assert_is_type, assert_is_subclass


class AbstractSensorType(object):
    __metaclass__ = ABCMeta

    _SENSOR_STATE_CLS = abstractproperty()
    _SENSOR_REPORTING_POLICY_CLS = abstractproperty()
    _STATE_SPACE = abstractproperty()

    def __init__(self, sensor_name, device_cls):
        assert_is_type(sensor_name, (basestring, int))
        assert_is_subclass(device_cls, Device)
        self._sensor_name = sensor_name
        self._device_cls = device_cls

    def __repr__(self):
        return "<{}: sensor_name={}, device_cls={}>".format(
            self.__class__.__name__,
            self._sensor_name,
            self._device_cls.__name__
        )

    def __hash__(self):
        return hash((str(self.__class__), self._keys))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self._keys == other._keys

    def __ne__(self, other):
        return not self.__eq__(other)

    @property
    def _keys(self):
        return self._sensor_name, str(self._device_cls)

    @classmethod
    def get_sensor_state_cls(cls):
        return cls._SENSOR_STATE_CLS

    @classmethod
    def get_sensor_reporting_policy_cls(cls):
        return cls._SENSOR_REPORTING_POLICY_CLS

    @classmethod
    def get_state_space(cls):
        return cls._STATE_SPACE

    def get_sensor_name(self):
        return self._sensor_name

    def get_device_cls(self):
        return self._device_cls

    def get_identifier(self):
        return "{}-{}".format(self._device_cls.__name__[0], self._sensor_name)
