import pandas as pd

from .sensor import Sensor
from ...validation.type_validation import assert_is_type


class SensorEvents(object):

    def __init__(self, sensor, series):
        assert_is_type(sensor, Sensor)
        self._validate_series(sensor, series)
        self._sensor = sensor
        self._series = self._rename_series(series)

    def __repr__(self):
        return "<{}: sensor={}>".format(self.__class__.__name__, self._sensor)

    def __hash__(self):
        return hash((self.__class__, self._keys))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self._keys == other._keys

    def __ne__(self, other):
        return not self.__eq__(other)

    @property
    def _keys(self):
        return self._sensor

    @staticmethod
    def _validate_series(sensor, series):
        assert_is_type(series, pd.Series)
        state_space = sensor.get_sensor_type().get_state_space()
        for event_label in series.unique():
            assert state_space.has_state_label(event_label)

    def _rename_series(self, series):
        renamed_series = series.copy()
        renamed_series.name = str(self._sensor)
        return renamed_series

    def get_sensor(self):
        return self._sensor

    def get_series(self):
        return self._series
