from ..abstract_boolean_sensor_type import AbstractBooleanSensorType
from .....structures.devices import MobileDevice


class PresenceSensorType(AbstractBooleanSensorType):
    pass


MOBILE_DEVICE_MDL_SENSOR_TYPE = PresenceSensorType(sensor_name="MDL", device_cls=MobileDevice)
