from ..abstract_boolean_sensor_type import AbstractBooleanSensorType
from .....structures.devices import DiamondDevice, TopazDevice, FlintstoneDevice, PinnaDevice, QuartzDevice


class ActivitySensorType(AbstractBooleanSensorType):
    pass


DIAMOND_PIR_SENSOR_TYPE = ActivitySensorType(sensor_name="PIR", device_cls=DiamondDevice)
DIAMOND_DIAL_TOUCH_SENSOR_TYPE = ActivitySensorType(sensor_name="DIAL_TOUCH", device_cls=DiamondDevice)
FLINTSTONE_PIR_SENSOR_TYPE = ActivitySensorType(sensor_name="PIR", device_cls=FlintstoneDevice)
PINNA_PIR_SENSOR_TYPE = ActivitySensorType(sensor_name="PIR", device_cls=PinnaDevice)
PINNA_OPENCLOSE_SENSOR_TYPE = ActivitySensorType(sensor_name="OPEN", device_cls=PinnaDevice)
QUARTZ_MOTION_SENSOR_TYPE = ActivitySensorType(sensor_name="CUEPOINT_MOTION", device_cls=QuartzDevice)
QUARTZ_AUDIO_SENSOR_TYPE = ActivitySensorType(sensor_name="CUEPOINT_AUDIO", device_cls=QuartzDevice)
TOPAZ_PIR_SENSOR_TYPE = ActivitySensorType(sensor_name="PIR", device_cls=TopazDevice)
