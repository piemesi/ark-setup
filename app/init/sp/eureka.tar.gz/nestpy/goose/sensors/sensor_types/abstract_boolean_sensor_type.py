from ..abstract_sensor_type import AbstractSensorType
from ..sensor_reporting_policies import BooleanSensorReportingPolicy
from ..sensor_states import BooleanSensorState
from ...states import State, StateSpace


class AbstractBooleanSensorType(AbstractSensorType):

    _SENSOR_STATE_CLS = BooleanSensorState
    _SENSOR_REPORTING_POLICY_CLS = BooleanSensorReportingPolicy
    _STATE_SPACE = StateSpace([State(True), State(False)])
