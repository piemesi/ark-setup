import pandas as pd

from ..abstract_sensor_events_extractor import AbstractSensorEventsExtractor
from ....manipulators.series_manipulators import drop_consecutive_duplicates, compute_timedelta_series


class MobileDeviceSensorEventsExtractor(AbstractSensorEventsExtractor):

    @staticmethod
    def _add_false_delay(boolean_series, delay):
        if not boolean_series.empty:
            boolean_series = drop_consecutive_duplicates(boolean_series)
            timedelta_series = compute_timedelta_series(boolean_series.index)
            index = pd.Series(index=boolean_series.index, data=boolean_series.index)
            index[~boolean_series & (timedelta_series > delay)] += delay
            boolean_series.index = pd.DatetimeIndex(index.values)
        return boolean_series

    @classmethod
    def extract_mdl_presence_sensor_events(cls, device_history, delay):
        fence_events_series = cls._get_event_field_series(
            device_history=device_history,
            event="fenceEvents",
            field="direction",
            dtype="str"
        )
        mdl_series = pd.Series(fence_events_series == "INSIDE")
        return cls._add_false_delay(mdl_series, delay)
