from ..abstract_sensor_events_extractor import AbstractSensorEventsExtractor


class PinnaSensorEventsExtractor(AbstractSensorEventsExtractor):

    _PIR_THRESHOLD = 50

    @classmethod
    def extract_pir_activity_sensor_events(cls, device_history):
        signal = cls._get_event_field_series(
            device_history=device_history,
            event="FullPassiveInfrared",
            field="Signal",
            dtype="float"
        )
        baseline = cls._get_event_field_series(
            device_history=device_history,
            event="FullPassiveInfrared",
            field="Baseline",
            dtype="float"
        )
        return signal - baseline >= cls._PIR_THRESHOLD

    @classmethod
    def extract_openclose_activity_sensor_events(cls, device_history):
        openclose = cls._get_event_field_series(
            device_history=device_history,
            event="OpenCloseDetector",
            field="State_enum",
            dtype="string"
        ) == 'Open'
        return openclose
