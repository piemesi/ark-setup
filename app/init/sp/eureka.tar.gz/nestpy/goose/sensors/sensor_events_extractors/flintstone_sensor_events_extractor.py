from ..abstract_sensor_events_extractor import AbstractSensorEventsExtractor


class FlintstoneSensorEventsExtractor(AbstractSensorEventsExtractor):

    _PIR_THRESHOLD = 8050

    @classmethod
    def extract_pir_activity_sensor_events(cls, device_history):
        signal = cls._get_event_field_series(
            device_history=device_history,
            event="SensorMCUPIR",
            field="PIR",
            dtype="float"
        )
        return signal >= cls._PIR_THRESHOLD
