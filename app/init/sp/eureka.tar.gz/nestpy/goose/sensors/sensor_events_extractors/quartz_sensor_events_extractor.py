from ..abstract_sensor_events_extractor import AbstractSensorEventsExtractor


class QuartzSensorEventsExtractor(AbstractSensorEventsExtractor):

    @classmethod
    def extract_has_person_events(cls, device_history):
        activity_series = cls._get_event_field_series(
            device_history=device_history,
            event="Cuepoints",
            field="has_person",
            dtype="float"
        )
        return activity_series.astype(bool)

    @classmethod
    def extract_has_person_high_confidence_events(cls, device_history):
        activity_series = cls._get_event_field_series(
            device_history=device_history,
            event="Cuepoints",
            field="has_person_high_confidence",
            dtype="float"
        )
        return activity_series.astype(bool)

    @classmethod
    def extract_has_person_talking_events(cls, device_history):
        activity_series = cls._get_event_field_series(
            device_history=device_history,
            event="Cuepoints",
            field="has_person_talking",
            dtype="float"
        )
        return activity_series.astype(bool)

    @classmethod
    def extract_has_person_talking_high_confidence_events(cls, device_history):
        activity_series = cls._get_event_field_series(
            device_history=device_history,
            event="Cuepoints",
            field="has_person_talking_high_confidence",
            dtype="float"
        )
        return activity_series.astype(bool)