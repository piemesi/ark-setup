from ..abstract_sensor_events_extractor import AbstractSensorEventsExtractor


class TopazSensorEventsExtractor(AbstractSensorEventsExtractor):

    _PIR_THRESHOLD = 100

    @classmethod
    def extract_pir_activity_sensor_events(cls, device_history):
        pir_series = cls._get_event_field_series(
            device_history=device_history,
            event="Passiveinfraredbucket",
            field="Value0",
            dtype="float"
        )
        return pir_series >= cls._PIR_THRESHOLD
