from ..abstract_sensor_events_extractor import AbstractSensorEventsExtractor


class DiamondSensorEventsExtractor(AbstractSensorEventsExtractor):

    @classmethod
    def extract_pir_activity_sensor_events(cls, device_history):
        pir_series = cls._get_event_field_series(
            device_history=device_history,
            event="BufferedPassiveInfrared",
            field="max",
            dtype="float"
        )
        threshold_series = cls._get_event_field_series(
            device_history=device_history,
            event="BufferedPassiveInfrared",
            field="threshold",
            dtype="float"
        )
        return pir_series >= threshold_series

    @classmethod
    def extract_dial_touch_activity_sensor_events(cls, device_history):
        dial_touch_series = cls._get_event_field_series(
            device_history=device_history,
            event="UserInteraction",
            field="type",
            dtype="object"
        )
        return dial_touch_series.astype("bool")
