from abc import ABCMeta, abstractmethod, abstractproperty

from .sensor import Sensor
from ...validation.type_validation import assert_is_type


class AbstractSensorState(object):
    __metaclass__ = ABCMeta

    _SENSOR_REPORTING_POLICY_CLS = abstractproperty()

    _STATE_REPORTED_TIMESTAMP = "state_reported_timestamp"

    def __init__(self, sensor):
        assert_is_type(sensor, Sensor)
        assert_is_type(sensor.get_sensor_reporting_policy(), self._SENSOR_REPORTING_POLICY_CLS)
        self._sensor = sensor
        self._sensor_state = dict()

    def __repr__(self):
        return "<{}: sensor={}>".format(self.__class__.__name__, self._sensor)

    def __hash__(self):
        return hash((self.__class__, self._keys))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self._keys == other._keys

    def __ne__(self, other):
        return not self.__eq__(other)

    @property
    def _keys(self):
        return self._sensor

    def _get_state(self, key):
        return self._sensor_state.get(key)

    def _set_state(self, key, state):
        self._sensor_state[key] = state

    def _get_state_reported_timestamp(self):
        return self._get_state(self._STATE_REPORTED_TIMESTAMP)

    def _set_state_reported_timestamp(self, timestamp):
        self._set_state(self._STATE_REPORTED_TIMESTAMP, timestamp)

    def is_online(self, timestamp):
        cold_shoulder_timeout = self._sensor.get_sensor_reporting_policy().get_cold_shoulder_timeout()
        state_reported_timestamp = self._get_state_reported_timestamp()
        return state_reported_timestamp is not None and timestamp - state_reported_timestamp <= cold_shoulder_timeout

    @abstractmethod
    def update_state(self, timestamp, reporting_event):
        raise NotImplementedError

    def get_sensor(self):
        return self._sensor
