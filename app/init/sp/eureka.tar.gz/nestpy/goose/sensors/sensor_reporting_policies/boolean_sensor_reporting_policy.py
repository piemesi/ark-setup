import datetime
import pandas as pd

from ..abstract_sensor_reporting_policy import AbstractSensorReportingPolicy
from ....generators.datetime_generators import datetime_range_generator
from ....manipulators.series_manipulators import compute_timedelta_series, drop_consecutive_duplicates
from ....validation.type_validation import assert_list_of_type, assert_series_is_dtype


class BooleanSensorReportingPolicy(AbstractSensorReportingPolicy):

    ASSERT_ENABLED = "AssertEnabled"
    REASSERT_ENABLED = "ReassertEnabled"
    ASSERT_DISABLED = "AssertDisabled"
    REASSERT_DISABLED = "ReassertDisabled"

    _BOOLEAN = "boolean"
    _TIMEDELTA = "timedelta"
    _TIMEDELTA_SECOND = "timedelta_second"

    def __init__(
            self,
            assert_enabled_delay,
            reassert_enabled_delay,
            assert_disabled_delay,
            reassert_disabled_delay,
            *args,
            **kwargs
    ):
        super(BooleanSensorReportingPolicy, self).__init__(*args, **kwargs)
        assert_list_of_type(
            [
                assert_enabled_delay,
                reassert_enabled_delay,
                assert_disabled_delay,
                reassert_disabled_delay
            ],
            datetime.timedelta
        )
        for reassert_delay in [reassert_enabled_delay, reassert_disabled_delay]:
            self._validate_reassert_delay(reassert_delay)
        self._assert_enabled_delay = assert_enabled_delay
        self._reassert_enabled_delay = reassert_enabled_delay
        self._assert_disabled_delay = assert_disabled_delay
        self._reassert_disabled_delay = reassert_disabled_delay

    @property
    def _keys(self):
        return (
            self._assert_enabled_delay,
            self._reassert_enabled_delay,
            self._assert_disabled_delay,
            self._reassert_disabled_delay,
            self._cold_shoulder_timeout
        )

    @staticmethod
    def _validate_reassert_delay(reassert_delay):
        if not reassert_delay.total_seconds() > 0:
            raise ValueError("Reassertion delays have to be nonzero.")

    def _filter_series(self, series):
        series_without_consecutive_duplicates = drop_consecutive_duplicates(series, keep_last=True)
        filter_frame = pd.DataFrame(
            {
                self._BOOLEAN: series_without_consecutive_duplicates,
                self._TIMEDELTA: compute_timedelta_series(series_without_consecutive_duplicates.index),
                self._TIMEDELTA_SECOND: compute_timedelta_series(series_without_consecutive_duplicates.index, offset=2)
            }
        )
        index_series = pd.Series(
            filter_frame[self._BOOLEAN] &
            (filter_frame[self._TIMEDELTA_SECOND] > datetime.timedelta(0)) &
            (filter_frame[self._TIMEDELTA_SECOND] - filter_frame[self._TIMEDELTA] <= self._assert_disabled_delay)
        )
        filtered_frame = pd.DataFrame(
            filter_frame.drop(filter_frame.index[index_series.shift(1).fillna(False).astype("bool")])
        )
        return drop_consecutive_duplicates(filtered_frame[self._BOOLEAN], keep_last=True)

    def compute_reporting_events(self, series):
        assert_series_is_dtype(series, "bool")
        filtered_series = self._filter_series(series)
        reporting_frame = pd.DataFrame(
            {
                self._BOOLEAN: filtered_series,
                self._TIMEDELTA: compute_timedelta_series(filtered_series.index),
                self._TIMEDELTA_SECOND: compute_timedelta_series(filtered_series.index, offset=2)
            }
        )
        reporting_events = {}
        for index, (timestamp, reporting_series) in enumerate(reporting_frame.iterrows()):
            if reporting_series.loc[self._BOOLEAN]:
                assert_delay = self._assert_enabled_delay
                assert_label = self.ASSERT_ENABLED
                reassert_delay = self._reassert_enabled_delay
                reassert_label = self.REASSERT_ENABLED
            else:
                assert_delay = self._assert_disabled_delay
                assert_label = self.ASSERT_DISABLED
                reassert_delay = self._reassert_disabled_delay
                reassert_label = self.REASSERT_DISABLED
            if reporting_series.loc[self._TIMEDELTA] > assert_delay or assert_delay.total_seconds() == 0:
                reporting_events[timestamp + assert_delay] = assert_label
                timedelta = reporting_series.loc[self._TIMEDELTA]
                if reporting_series.loc[self._BOOLEAN] and reporting_series.loc[self._TIMEDELTA_SECOND]:
                    timedelta += self._assert_disabled_delay
                if timedelta >= assert_delay + reassert_delay:
                    for index in datetime_range_generator(
                            start_datetime=timestamp + assert_delay + reassert_delay,
                            end_datetime=timestamp + timedelta,
                            interval=reassert_delay,
                            closed_left=True,
                            closed_right=False
                    ):
                        reporting_events[index] = reassert_label
        return pd.Series(reporting_events)

    def get_assert_enabled_delay(self):
        return self._assert_enabled_delay

    def get_reassert_enabled_delay(self):
        return self._reassert_enabled_delay

    def get_assert_disabled_delay(self):
        return self._assert_disabled_delay

    def get_reassert_disabled_delay(self):
        return self._reassert_disabled_delay
