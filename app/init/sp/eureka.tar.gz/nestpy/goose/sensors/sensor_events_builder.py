import types
import functools

from .abstract_sensor_type import AbstractSensorType
from .abstract_sensor_reporting_policy import AbstractSensorReportingPolicy
from .sensor import Sensor
from .sensor_events import SensorEvents
from ..building import AbstractObjectBuilder
from ...structures.device import Device
from ...structures.device_history import DeviceHistory
from ...validation.type_validation import assert_is_type


class SensorEventsBuilder(AbstractObjectBuilder):

    def __init__(self, **kwargs):
        super(SensorEventsBuilder, self).__init__(object_cls=SensorEvents, **kwargs)

    def _get_object_base_cls(self):
        return SensorEvents

    def _get_builder_config_types(self):
        return dict(
            sensor_type=AbstractSensorType,
            sensor_reporting_policy=AbstractSensorReportingPolicy,
            sensor_events_extractor=(types.MethodType, functools.partial)
        )

    def build(self, device, device_history):
        assert_is_type(device, Device)
        assert_is_type(device_history, DeviceHistory)
        sensor_events = self._object_cls(
            sensor=Sensor(
                sensor_type=self._builder_config['sensor_type'],
                sensor_reporting_policy=self._builder_config['sensor_reporting_policy'],
                device=device
            ),
            series=self._builder_config['sensor_events_extractor'](device_history)
        )
        return sensor_events
