from ..abstract_sensor_state import AbstractSensorState
from ..sensor_reporting_policies import BooleanSensorReportingPolicy


class BooleanSensorState(AbstractSensorState):

    _SENSOR_REPORTING_POLICY_CLS = BooleanSensorReportingPolicy

    _TRANSITION_ENABLED_TIMESTAMP = "transition_enabled_timestamp"
    _TRANSITION_DISABLED_TIMESTAMP = "transition_disabled_timestamp"

    def _set_transition_enabled_timestamp(self, timestamp):
        self._set_state(self._TRANSITION_ENABLED_TIMESTAMP, timestamp)

    def _set_transition_disabled_timestamp(self, timestamp):
        self._set_state(self._TRANSITION_DISABLED_TIMESTAMP, timestamp)

    def get_transition_enabled_timestamp(self):
        return self._get_state(self._TRANSITION_ENABLED_TIMESTAMP)

    def get_transition_disabled_timestamp(self):
        return self._get_state(self._TRANSITION_DISABLED_TIMESTAMP)

    def is_enabled(self):
        transition_enabled_timestamp = self.get_transition_enabled_timestamp()
        transition_disabled_timestamp = self.get_transition_disabled_timestamp()
        return (
            transition_enabled_timestamp is not None and (
                transition_disabled_timestamp is None or transition_enabled_timestamp > transition_disabled_timestamp
            )
        )

    def is_disabled(self):
        transition_enabled_timestamp = self.get_transition_enabled_timestamp()
        transition_disabled_timestamp = self.get_transition_disabled_timestamp()
        return (
            transition_disabled_timestamp is not None and (
                transition_enabled_timestamp is None or transition_disabled_timestamp >= transition_enabled_timestamp
            )
        )

    def update_state(self, timestamp, reporting_event):
        self._set_state_reported_timestamp(timestamp)
        sensor_reporting_policy = self._sensor.get_sensor_reporting_policy()
        if reporting_event == BooleanSensorReportingPolicy.ASSERT_ENABLED:
            transition_timestamp = timestamp - sensor_reporting_policy.get_assert_enabled_delay()
            self._set_transition_enabled_timestamp(transition_timestamp)
        elif reporting_event == BooleanSensorReportingPolicy.ASSERT_DISABLED:
            transition_timestamp = timestamp - sensor_reporting_policy.get_assert_disabled_delay()
            self._set_transition_disabled_timestamp(transition_timestamp)
