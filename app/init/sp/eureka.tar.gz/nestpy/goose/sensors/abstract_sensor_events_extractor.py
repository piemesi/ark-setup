import pandas as pd

from abc import ABCMeta

from ...manipulators.series_manipulators import set_unique_index


class AbstractSensorEventsExtractor(object):
    __metaclass__ = ABCMeta

    @staticmethod
    def _get_event_field_series(device_history, event, field, dtype):
        if event in device_history.events and field in device_history[event].columns:
            event_field_series = device_history[event][field]
        else:
            event_field_series = pd.Series(dtype=dtype)
        return set_unique_index(event_field_series)
