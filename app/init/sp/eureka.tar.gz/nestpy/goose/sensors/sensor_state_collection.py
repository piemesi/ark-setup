from .sensor import Sensor
from ...validation.type_validation import assert_list_of_type


class SensorStateCollection(object):

    def __init__(self, sensors):
        assert_list_of_type(sensors, Sensor)
        self._sensor_states = map(lambda sensor: sensor.get_sensor_type().get_sensor_state_cls()(sensor), sensors)

    def __repr__(self):
        return "<{}>".format(self.__class__.__name__)

    def __hash__(self):
        return hash((self.__class__, self._keys))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self._keys == other._keys

    def __ne__(self, other):
        return not self.__eq__(other)

    @property
    def _keys(self):
        return frozenset(self._sensor_states)

    def get_sensor_state_for_sensor(self, sensor):
        for sensor_state in self._sensor_states:
            if sensor_state.get_sensor() == sensor:
                return sensor_state

    def get_sensor_states_for_sensors(self, sensors):
        return filter(lambda sensor_state: sensor_state is not None, map(self.get_sensor_state_for_sensor, sensors))

    def update_sensor_state_for_sensor(self, sensor, timestamp, reporting_event):
        sensor_state = self.get_sensor_state_for_sensor(sensor)
        sensor_state.update_state(timestamp, reporting_event)

    def get_sensor_states(self):
        return self._sensor_states
