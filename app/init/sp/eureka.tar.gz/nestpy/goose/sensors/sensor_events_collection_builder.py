import datetime
import copy_reg
import functools
import types

from .sensor_events_builder import SensorEventsBuilder
from .sensor_events_collection import SensorEventsCollection
from .sensor_events_extractors import (
    DiamondSensorEventsExtractor,
    FlintstoneSensorEventsExtractor,
    MobileDeviceSensorEventsExtractor,
    PinnaSensorEventsExtractor,
    QuartzSensorEventsExtractor,
    TopazSensorEventsExtractor,
)
from .sensor_reporting_policies import BooleanSensorReportingPolicy
from .sensor_types.boolean_sensor_types import (
    DIAMOND_PIR_SENSOR_TYPE,
    DIAMOND_DIAL_TOUCH_SENSOR_TYPE,
    FLINTSTONE_PIR_SENSOR_TYPE,
    PINNA_OPENCLOSE_SENSOR_TYPE,
    PINNA_PIR_SENSOR_TYPE,
    QUARTZ_MOTION_SENSOR_TYPE,
    QUARTZ_AUDIO_SENSOR_TYPE,
    TOPAZ_PIR_SENSOR_TYPE,
    MOBILE_DEVICE_MDL_SENSOR_TYPE
)
from ..building import AbstractObjectBuilder
from ...structures.devices import (
    DiamondDevice,
    MobileDevice,
    TopazDevice,
    PinnaDevice,
    FlintstoneDevice,
    QuartzDevice
)


def _pickle_method(m):
    if m.im_self is None:
        return getattr, (m.im_class, m.im_func.func_name)
    else:
        return getattr, (m.im_self, m.im_func.func_name)

copy_reg.pickle(types.MethodType, _pickle_method)


_INFINITE_DELAY = datetime.timedelta(days=10000)

OCCUPANCY_SENSOR_EVENTS_COLLECTION_BUILDER_CONFIG = dict(
    object_cls=SensorEventsCollection,
    sensor_events_builders=[
        (
            DIAMOND_PIR_SENSOR_TYPE,
            SensorEventsBuilder(
                sensor_type=DIAMOND_PIR_SENSOR_TYPE,
                sensor_reporting_policy=BooleanSensorReportingPolicy(
                    assert_enabled_delay=datetime.timedelta(minutes=0),
                    reassert_enabled_delay=datetime.timedelta(minutes=30),
                    assert_disabled_delay=datetime.timedelta(minutes=20),
                    reassert_disabled_delay=datetime.timedelta(minutes=30),
                    cold_shoulder_timeout=datetime.timedelta(hours=2),
                ),
                sensor_events_extractor=DiamondSensorEventsExtractor.extract_pir_activity_sensor_events
            )
        ),
        (
            DIAMOND_DIAL_TOUCH_SENSOR_TYPE,
            SensorEventsBuilder(
                sensor_type=DIAMOND_DIAL_TOUCH_SENSOR_TYPE,
                sensor_reporting_policy=BooleanSensorReportingPolicy(
                    assert_enabled_delay=datetime.timedelta(minutes=0),
                    reassert_enabled_delay=_INFINITE_DELAY,
                    assert_disabled_delay=datetime.timedelta(minutes=20),
                    reassert_disabled_delay=_INFINITE_DELAY,
                    cold_shoulder_timeout=datetime.timedelta(hours=2),
                ),
                sensor_events_extractor=DiamondSensorEventsExtractor.extract_dial_touch_activity_sensor_events
            )
        ),
        (
            FLINTSTONE_PIR_SENSOR_TYPE,
            SensorEventsBuilder(
                sensor_type=FLINTSTONE_PIR_SENSOR_TYPE,
                sensor_reporting_policy=BooleanSensorReportingPolicy(
                    assert_enabled_delay=datetime.timedelta(minutes=0),
                    reassert_enabled_delay=datetime.timedelta(minutes=10),
                    assert_disabled_delay=datetime.timedelta(seconds=45),
                    reassert_disabled_delay=datetime.timedelta(seconds=45),
                    cold_shoulder_timeout=datetime.timedelta(hours=24),
                ),
                sensor_events_extractor=FlintstoneSensorEventsExtractor.extract_pir_activity_sensor_events
            )
        ),
        (
            MOBILE_DEVICE_MDL_SENSOR_TYPE,
            SensorEventsBuilder(
                sensor_type=MOBILE_DEVICE_MDL_SENSOR_TYPE,
                sensor_reporting_policy=BooleanSensorReportingPolicy(
                    assert_enabled_delay=datetime.timedelta(minutes=0),
                    reassert_enabled_delay=datetime.timedelta(days=2),
                    assert_disabled_delay=datetime.timedelta(minutes=0),
                    reassert_disabled_delay=datetime.timedelta(days=2),
                    cold_shoulder_timeout=datetime.timedelta(days=2, seconds=1),
                ),
                sensor_events_extractor=functools.partial(
                    MobileDeviceSensorEventsExtractor.extract_mdl_presence_sensor_events,
                    delay=datetime.timedelta(minutes=10)
                )
            )
        ),
        (
            PINNA_PIR_SENSOR_TYPE,
            SensorEventsBuilder(
                sensor_type=PINNA_PIR_SENSOR_TYPE,
                sensor_reporting_policy=BooleanSensorReportingPolicy(
                    assert_enabled_delay=datetime.timedelta(minutes=0),
                    reassert_enabled_delay=datetime.timedelta(minutes=10),
                    assert_disabled_delay=datetime.timedelta(seconds=45),
                    reassert_disabled_delay=datetime.timedelta(seconds=45),
                    cold_shoulder_timeout=datetime.timedelta(hours=24),
                ),
                sensor_events_extractor=PinnaSensorEventsExtractor.extract_pir_activity_sensor_events
            )

        ),
        (
            PINNA_OPENCLOSE_SENSOR_TYPE,
            SensorEventsBuilder(
                sensor_type=PINNA_OPENCLOSE_SENSOR_TYPE,
                sensor_reporting_policy=BooleanSensorReportingPolicy(
                    assert_enabled_delay=datetime.timedelta(minutes=0),
                    reassert_enabled_delay=datetime.timedelta(minutes=10),
                    assert_disabled_delay=datetime.timedelta(seconds=45),
                    reassert_disabled_delay=datetime.timedelta(seconds=45),
                    cold_shoulder_timeout=datetime.timedelta(hours=24),
                ),
                sensor_events_extractor=PinnaSensorEventsExtractor.extract_openclose_activity_sensor_events
            )
        ),
        (
            QUARTZ_MOTION_SENSOR_TYPE,
            SensorEventsBuilder(
                sensor_type=QUARTZ_MOTION_SENSOR_TYPE,
                sensor_reporting_policy=BooleanSensorReportingPolicy(
                    assert_enabled_delay=datetime.timedelta(minutes=0),
                    reassert_enabled_delay=_INFINITE_DELAY,
                    assert_disabled_delay=datetime.timedelta(minutes=0),
                    reassert_disabled_delay=_INFINITE_DELAY,
                    cold_shoulder_timeout=datetime.timedelta(days=2),
                ),
                sensor_events_extractor=QuartzSensorEventsExtractor.extract_has_person_high_confidence_events
            )
        ),
        (
            QUARTZ_AUDIO_SENSOR_TYPE,
            SensorEventsBuilder(
                sensor_type=QUARTZ_AUDIO_SENSOR_TYPE,
                sensor_reporting_policy=BooleanSensorReportingPolicy(
                    assert_enabled_delay=datetime.timedelta(minutes=0),
                    reassert_enabled_delay=_INFINITE_DELAY,
                    assert_disabled_delay=datetime.timedelta(minutes=0),
                    reassert_disabled_delay=_INFINITE_DELAY,
                    cold_shoulder_timeout=datetime.timedelta(days=2),
                ),
                sensor_events_extractor=QuartzSensorEventsExtractor.extract_has_person_talking_high_confidence_events
            )
        ),
        (
            TOPAZ_PIR_SENSOR_TYPE,
            SensorEventsBuilder(
                sensor_type=TOPAZ_PIR_SENSOR_TYPE,
                sensor_reporting_policy=BooleanSensorReportingPolicy(
                    assert_enabled_delay=datetime.timedelta(minutes=0),
                    reassert_enabled_delay=_INFINITE_DELAY,
                    assert_disabled_delay=datetime.timedelta(minutes=10),
                    reassert_disabled_delay=_INFINITE_DELAY,
                    cold_shoulder_timeout=datetime.timedelta(hours=24),
                ),
                sensor_events_extractor=TopazSensorEventsExtractor.extract_pir_activity_sensor_events
            )
        ),
    ]
)


class SensorEventsCollectionBuilder(AbstractObjectBuilder):

    def _get_object_base_cls(self):
        return SensorEventsCollection

    def _get_builder_config_types(self):
        return dict(sensor_events_builders=list)

    def build(
            self,
            diamond_devices,
            diamond_device_histories,
            flintstone_devices,
            flintstone_device_histories,
            mobile_devices,
            mobile_device_histories,
            pinna_devices,
            pinna_device_histories,
            quartz_devices,
            quartz_device_histories,
            topaz_devices,
            topaz_device_histories,
    ):
        devices_lookup = {
            DiamondDevice: (diamond_devices, diamond_device_histories),
            FlintstoneDevice: (flintstone_devices, flintstone_device_histories),
            MobileDevice: (mobile_devices, mobile_device_histories),
            PinnaDevice: (pinna_devices, pinna_device_histories),
            QuartzDevice: (quartz_devices, quartz_device_histories),
            TopazDevice: (topaz_devices, topaz_device_histories),
        }
        sensor_events_builders = self._builder_config.get('sensor_events_builders', [])
        sensor_events_list = []
        for sensor_type, sensor_events_builder in sensor_events_builders:
            devices, device_histories = devices_lookup[sensor_type.get_device_cls()]
            for device, device_history in zip(devices, device_histories):
                sensor_events = sensor_events_builder.build(device, device_history)
                sensor_events_list.append(sensor_events)
        sensor_events_collection = self._object_cls(sensor_events_list)
        return sensor_events_collection
