import pandas as pd

from abc import ABCMeta

from ..building import AbstractObjectBuilder
from ..states.state_spaces import AUTO_AWAY_STATE_SPACE, OCCUPANCY_STATE_SPACE


OCCUPANCY_VISUALIZER_BUILDER_CONFIG = dict(
    output_formats=['png'],
    area_alpha=0.7,
    state_label_colors=pd.Series(
        index=OCCUPANCY_STATE_SPACE.get_state_labels(),
        data=['red', 'blue', 'purple', 'forestgreen']
    ),
    auto_away_state_label_colors=pd.Series(
        index=AUTO_AWAY_STATE_SPACE.get_state_labels(),
        data=['forestgreen', 'red', 'blue']
    ),
    boolean_state_label_colors=pd.Series(
        index=[True, False],
        data=['red', 'forestgreen']
    )
)


class AbstractVisualizerBuilder(AbstractObjectBuilder):
    __metaclass__ = ABCMeta

    def _get_builder_config_types(self):
        return dict(
            output_formats=list,
            area_alpha=(int, float),
            state_label_colors=pd.Series,
            auto_away_state_label_colors=pd.Series,
            boolean_state_label_colors=pd.Series,
        )
