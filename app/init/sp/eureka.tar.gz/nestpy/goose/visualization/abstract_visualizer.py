import matplotlib.gridspec as gridspec
import matplotlib.pyplot as plt
import os
import pandas as pd

from abc import ABCMeta, abstractmethod, abstractproperty

from ..environment import Workspace
from ..states import State, StateSpace
from ..states.state_spaces import AUTO_AWAY_STATE_SPACE, OCCUPANCY_STATE_SPACE
from ...validation.type_validation import assert_is_type


class AbstractVisualizer(object):
    __metaclass__ = ABCMeta

    _SOURCE_DATA_CLS = abstractproperty()

    def __init__(
            self,
            source_data,
            workspace,
            output_formats,
            area_alpha,
            state_label_colors,
            auto_away_state_label_colors,
            boolean_state_label_colors
    ):
        assert_is_type(workspace, Workspace)
        assert_is_type(source_data, self._SOURCE_DATA_CLS)
        self._validate_state_label_colors(OCCUPANCY_STATE_SPACE, state_label_colors)
        self._validate_state_label_colors(AUTO_AWAY_STATE_SPACE, auto_away_state_label_colors)
        self._validate_state_label_colors(StateSpace([State(True), State(False)]), boolean_state_label_colors)
        self._source_data = source_data
        self._workspace = workspace
        self._output_formats = output_formats
        self._area_alpha = area_alpha
        self._state_label_colors = state_label_colors
        self._auto_away_state_label_colors = auto_away_state_label_colors
        self._boolean_state_label_colors = boolean_state_label_colors

    @staticmethod
    def _validate_state_label_colors(state_space, state_label_colors):
        assert_is_type(state_label_colors, pd.Series)
        for state_label in state_space.get_state_labels():
            if state_label not in state_label_colors.index:
                raise ValueError("No color found for state with state label '{}'".format(state_label))

    def _create_and_save_fig_with_subplots(
            self,
            fig_title,
            fig_subtitle,
            plotters,
            share_x_axis,
            share_y_axis,
            path,
            x_limit=None,
            y_limit=None
    ):
        if plotters:
            fig_width = max(
                map(
                    lambda plotter_row_: sum(
                        map(
                            lambda plotter_: plotter_.get_width(),
                            plotter_row_
                        )
                    ),
                    plotters
                )
            )
            row_heights = map(
                lambda plotter_row_: max(
                    map(
                        lambda plotter_: plotter_.get_height(),
                        plotter_row_
                    )
                ),
                plotters
            )
            fig_height = sum(row_heights)
            fig = plt.figure(figsize=(fig_width, fig_height))
            fig.suptitle(
                "{} \n {}".format(fig_title, fig_subtitle),
                fontsize=12,
                linespacing=1.5,
                y=(fig_height - 0.2) / fig_height
            )

            grid_spec = gridspec.GridSpec(
                nrows=fig_height,
                ncols=fig_width
            )

            axis = None
            for row_index, plotter_row in enumerate(plotters):
                row_start, row_end = sum(row_heights[:row_index]), sum(row_heights[:row_index + 1])
                column_widths = map(lambda plotter_: plotter_.get_width(), plotter_row)
                for column_index, plotter in enumerate(plotter_row):
                    column_start, column_end = sum(column_widths[:column_index]), sum(column_widths[:column_index + 1])
                    add_subplot_kwargs = dict()
                    if share_x_axis:
                        add_subplot_kwargs.update(sharex=axis)
                    if share_y_axis:
                        add_subplot_kwargs.update(sharey=axis)
                    axis = plotter.plot(
                        fig=fig,
                        subplot_spec=grid_spec[row_start:row_end, column_start:column_end],
                        **add_subplot_kwargs
                    )
                    if x_limit is not None:
                        axis.set_xlim(x_limit)
                    if y_limit is not None:
                        axis.set_ylim(y_limit)

            plt.tight_layout(rect=(0, 0, 1, (fig_height - 0.8) / fig_height))
            self._save_fig(fig, fig_title, path)
            plt.close(fig)

    def _save_fig(self, fig, fig_title, path):
        for output_format in self._output_formats:
            fig.savefig(os.path.join(path, "{}.{}".format(fig_title, output_format)))

    @abstractmethod
    def visualize(self):
        raise NotImplementedError
