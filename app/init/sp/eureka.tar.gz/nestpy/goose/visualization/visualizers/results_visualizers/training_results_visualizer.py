import datetime
import numpy as np
import pandas as pd

from functools import partial

from ..abstract_results_visualizer import AbstractResultsVisualizer
from ...abstract_plotter import AbstractPlotter
from ....features.featurizers import GapFeaturizer, SampledBooleanFeaturizer
from ....features.featurizers.gap_featurizers import BooleanGapFeaturizer
from ....models.models.sensor_models import CombinedSensorModel
from ....models.models.sensor_models.abstract_lumped_sensor_model import AbstractLumpedSensorModel
from ....models.models.sensor_models.abstract_separated_sensor_model import AbstractSeparatedSensorModel
from ....models.models.transition_models import MarkovTransitionModel
from ....results.results.training_results import TrainingResults
from ....sensors.sensor_types.boolean_sensor_types import ActivitySensorType, PresenceSensorType
from .....manipulators.datetime_manipulators import floor_datetime, ceil_datetime
from .....validation.type_validation import assert_is_type


class TrainingResultsVisualizer(AbstractResultsVisualizer):

    _SOURCE_DATA_CLS = TrainingResults

    def __init__(self, plot_per_day, *args, **kwargs):
        super(TrainingResultsVisualizer, self).__init__(*args, **kwargs)
        assert_is_type(plot_per_day, bool)
        self._plot_per_day = plot_per_day

    def _visualize_training_results(self):
        sensor_events_collection = self._source_data.get_sensor_events_collection()
        ground_truth_state_series = self._source_data.get_ground_truth_state_series()
        estimated_truth_state_series = self._source_data.get_estimated_truth_state_series()
        device_auto_away_state_series = self._source_data.get_device_auto_away_state_series()

        plotters = []
        for sensor_events in sensor_events_collection.get_sensor_events_list():
            plotters.append(
                [
                    self._SensorEventsPlotter(
                        title=str(sensor_events.get_sensor()),
                        height=1,
                        width=20,
                        area_alpha=self._area_alpha,
                        sensor_events=sensor_events
                    )
                ]
            )
        if ground_truth_state_series is not None and not ground_truth_state_series.get_series().empty:
            plotters.append(
                [
                    self._StateSeriesPlotter(
                        title=str(ground_truth_state_series),
                        height=1,
                        width=20,
                        area_alpha=self._area_alpha,
                        state_series=ground_truth_state_series.get_series(),
                        state_label_colors=self._state_label_colors
                    )
                ]
            )
        plotters.append(
            [
                self._StateSeriesPlotter(
                    title=str(estimated_truth_state_series),
                    height=1,
                    width=20,
                    area_alpha=self._area_alpha,
                    state_series=estimated_truth_state_series.get_series(),
                    state_label_colors=self._state_label_colors
                )
            ]
        )

        if device_auto_away_state_series is not None and not device_auto_away_state_series.get_series().empty:
            plotters.append(
                [
                    self._StateSeriesPlotter(
                        title=str(device_auto_away_state_series),
                        height=1,
                        width=20,
                        area_alpha=self._area_alpha,
                        state_series=device_auto_away_state_series.get_series(),
                        state_label_colors=self._auto_away_state_label_colors
                    )
                ]
            )

        estimated_truth_series = estimated_truth_state_series.get_series()
        timestamps = map(lambda timestamp: timestamp.replace(tzinfo=None), estimated_truth_series.index)
        if self._plot_per_day and timestamps:
            self._create_and_save_fig_with_subplots_per_day(
                fig_title="TrainingResults",
                fig_subtitle=str(self._source_data),
                plotters=plotters,
                share_x_axis=True,
                share_y_axis=False,
                path=self._workspace.get_plots_path(),
                start_datetime=floor_datetime(min(timestamps), datetime.timedelta(days=1)),
                end_datetime=ceil_datetime(max(timestamps), datetime.timedelta(days=1))
            )
        else:
            self._create_and_save_fig_with_subplots(
                fig_title="TrainingResults",
                fig_subtitle=str(self._source_data),
                plotters=plotters,
                share_x_axis=True,
                share_y_axis=False,
                path=self._workspace.get_plots_path()
            )

    @staticmethod
    def _time_to_hours(time):
        timedelta = (
            datetime.datetime.combine(datetime.date.today(), time) -
            datetime.datetime.combine(datetime.date.today(), datetime.time())
        )
        return timedelta.total_seconds() / 3600

    @classmethod
    def _extract_model_probabilities(cls, model, probabilities_getter, time_slice_indices, label):
        def get_probabilities_for_label(_time_slice_index, _label):
            probabilities = probabilities_getter(time_slice_index=_time_slice_index)
            if label in probabilities.index:
                probabilities_for_label = dict(probabilities.iterrows())[_label]
            else:
                probabilities_for_label = pd.Series(index=state_space.get_state_labels())
            return probabilities_for_label
        time_slicer = model.get_time_slicer()
        state_space = model.get_state_space()
        model_probabilities = pd.DataFrame.from_items(
            [
                (
                    cls._time_to_hours(time_slicer.get_time_slice(time_slice_index)[0]),
                    get_probabilities_for_label(time_slice_index, label)
                )
                for time_slice_index in time_slice_indices
            ],
            columns=state_space.get_state_labels(),
            orient="index"
        )
        return model_probabilities

    def _visualize_model_probabilities(self, fig_title, model, probabilities_getter):
        time_slicer = model.get_time_slicer()
        labels = set(
            sum(
                [
                    probabilities_getter(time_slice_index=time_slice_index).index.tolist()
                    for time_slice_index in time_slicer.get_time_slice_indices()
                ],
                []
            )
        )
        plotters = []
        for label in sorted(labels):
            plotter_row = []
            for time_slice_type, time_slice_indices in [
                (
                        "weekday",
                        time_slicer.get_weekday_time_slice_indices()
                ),
                (
                        "weekend",
                        time_slicer.get_weekend_time_slice_indices()
                )
            ]:
                plotter_row.append(
                    self._ModelProbabilitiesPlotter(
                        title="{} ({})".format(label, time_slice_type),
                        height=4,
                        width=10,
                        area_alpha=self._area_alpha,
                        model_probabilities=self._extract_model_probabilities(
                            model=model,
                            probabilities_getter=probabilities_getter,
                            time_slice_indices=time_slice_indices,
                            label=label
                        ),
                        state_label_colors=self._state_label_colors
                    )
                )
            plotters.append(plotter_row)

        self._create_and_save_fig_with_subplots(
            fig_title=fig_title,
            fig_subtitle=str(self._source_data),
            plotters=plotters,
            share_x_axis=True,
            share_y_axis=False,
            path=self._workspace.get_models_plots_path()
        )

    def _visualize_transition_model(self):
        transition_model = self._source_data.get_transition_model()
        if isinstance(transition_model, MarkovTransitionModel):
            transition_model_prior = transition_model.get_transition_model_prior()
            self._visualize_model_probabilities(
                fig_title=str(transition_model),
                model=transition_model,
                probabilities_getter=transition_model.get_local_transition_probability_matrix
            )
            if transition_model_prior is not None:
                self._visualize_model_probabilities(
                    fig_title=str(transition_model_prior),
                    model=transition_model,
                    probabilities_getter=transition_model.get_global_transition_probability_matrix
                )
                self._visualize_model_probabilities(
                    fig_title="{} (Combined)".format(str(transition_model)),
                    model=transition_model,
                    probabilities_getter=transition_model.get_combined_transition_probability_matrix
                )

    def _visualize_sensor_probability_distributions(
            self,
            fig_title,
            time_slicer,
            sensor_probability_distribution_getter
    ):
        plotters = []
        for weekday_time_slice_index, weekend_time_slice_index in zip(
                time_slicer.get_weekday_time_slice_indices(),
                time_slicer.get_weekend_time_slice_indices()
        ):
            plotter_row = []
            for time_slice_index in [weekday_time_slice_index, weekend_time_slice_index]:
                plotter_row.append(
                    self._SensorProbabilityDistributionPlotter(
                        title="{} - {} ({})".format(*time_slicer.get_time_slice(time_slice_index)),
                        height=2,
                        width=10,
                        area_alpha=self._area_alpha,
                        sensor_probability_distribution=sensor_probability_distribution_getter(
                            time_slice_index=time_slice_index
                        ),
                        state_label_colors=self._state_label_colors
                    )
                )
            plotters.append(plotter_row)

        self._create_and_save_fig_with_subplots(
            fig_title=fig_title,
            fig_subtitle=str(self._source_data),
            plotters=plotters,
            share_x_axis=True,
            share_y_axis=True,
            path=self._workspace.get_models_plots_path()
        )

    def _visualize_correlation_matrix(self, fig_title, correlation_matrix):
        plotters = [
            [
                self._CorrelationMatrixPlotter(
                    title="Correlation Matrix",
                    height=10,
                    width=10,
                    area_alpha=self._area_alpha,
                    correlation_matrix=correlation_matrix
                )
            ]
        ]
        self._create_and_save_fig_with_subplots(
            fig_title=fig_title,
            fig_subtitle=str(self._source_data),
            plotters=plotters,
            share_x_axis=True,
            share_y_axis=True,
            path=self._workspace.get_models_plots_path()
        )

    def _visualize_sensor_probability_distribution(self, fig_title, sensor_model, probability_distribution_getter):
        featurizer = sensor_model.get_featurizer()
        if isinstance(featurizer, (SampledBooleanFeaturizer, BooleanGapFeaturizer)):
            self._visualize_model_probabilities(
                fig_title=fig_title,
                model=sensor_model,
                probabilities_getter=probability_distribution_getter
            )
        elif isinstance(featurizer, GapFeaturizer):
            self._visualize_sensor_probability_distributions(
                fig_title=fig_title,
                time_slicer=sensor_model.get_time_slicer(),
                sensor_probability_distribution_getter=probability_distribution_getter
            )

    def _visualize_separated_sensor_model(self, sensor_model):
        for sensor in sensor_model.get_sensors():
            self._visualize_sensor_probability_distribution(
                fig_title="{} - {}".format(sensor_model, sensor),
                sensor_model=sensor_model,
                probability_distribution_getter=partial(
                    sensor_model.get_local_probability_distribution,
                    sensor=sensor
                )
            )
            if sensor_model.get_sensor_model_prior() is not None:
                self._visualize_sensor_probability_distribution(
                    fig_title="{} - {}".format(sensor_model.get_sensor_model_prior(), sensor),
                    sensor_model=sensor_model,
                    probability_distribution_getter=partial(
                        sensor_model.get_global_probability_distribution,
                        sensor=sensor
                    )
                )
                self._visualize_sensor_probability_distribution(
                    fig_title="{} - {} (Combined)".format(sensor_model, sensor),
                    sensor_model=sensor_model,
                    probability_distribution_getter=partial(
                        sensor_model.get_combined_probability_distribution,
                        sensor=sensor
                    )
                )

    def _visualize_lumped_sensor_model(self, sensor_model):
        self._visualize_sensor_probability_distribution(
            fig_title=str(sensor_model),
            sensor_model=sensor_model,
            probability_distribution_getter=partial(
                sensor_model.get_local_probability_distribution,
                sensors=sensor_model.get_sensors()
            )
        )
        if sensor_model.get_sensor_model_prior() is not None:
            self._visualize_sensor_probability_distribution(
                fig_title=str(sensor_model.get_sensor_model_prior()),
                sensor_model=sensor_model,
                probability_distribution_getter=partial(
                    sensor_model.get_global_probability_distribution,
                    sensors=sensor_model.get_sensors()
                )
            )
            self._visualize_sensor_probability_distribution(
                fig_title="{} (Combined)".format(sensor_model),
                sensor_model=sensor_model,
                probability_distribution_getter=partial(
                    sensor_model.get_combined_probability_distribution,
                    sensors=sensor_model.get_sensors()
                )
            )

    def _visualize_combined_sensor_model(self, sensor_model):
        self._visualize_correlation_matrix(
            fig_title="{} - Correlation Matrix".format(sensor_model),
            correlation_matrix=sensor_model.get_local_correlation_matrix()
        )
        if sensor_model.get_sensor_model_prior() is not None:
            self._visualize_correlation_matrix(
                fig_title="{} - Correlation Matrix".format(sensor_model.get_sensor_model_prior()),
                correlation_matrix=sensor_model.get_global_correlation_matrix()
            )
            self._visualize_correlation_matrix(
                fig_title="{} - Correlation Matrix (Combined)".format(sensor_model),
                correlation_matrix=sensor_model.get_combined_correlation_matrix()
            )

    def _visualize_sensor_models(self):
        sensor_model_collection = self._source_data.get_sensor_model_collection()
        sensor_models = sensor_model_collection.get_sensor_models()
        for sensor_model in sensor_models:
            if isinstance(sensor_model, AbstractSeparatedSensorModel):
                self._visualize_separated_sensor_model(sensor_model)
            elif isinstance(sensor_model, AbstractLumpedSensorModel):
                self._visualize_lumped_sensor_model(sensor_model)
                if isinstance(sensor_model, CombinedSensorModel):
                    self._visualize_combined_sensor_model(sensor_model)
                    self._visualize_separated_sensor_model(sensor_model.get_separated_sensor_model())

    def visualize(self):
        self._visualize_training_results()
        self._visualize_transition_model()
        self._visualize_sensor_models()

    class _SensorEventsPlotter(AbstractPlotter):

        def __init__(self, sensor_events, *args, **kwargs):
            super(TrainingResultsVisualizer._SensorEventsPlotter, self).__init__(*args, **kwargs)
            self._sensor_events = sensor_events

        def plot(self, fig, subplot_spec, **kwargs):
            axis = self._create_axis(fig=fig, subplot_spec=subplot_spec, **kwargs)
            series = self._sensor_events.get_series()
            if not series.empty:
                if isinstance(self._sensor_events.get_sensor().get_sensor_type(), ActivitySensorType):
                    value_series = series[series == True]
                    axis.vlines(
                        x=self._reset_tz(value_series.index),
                        ymin=np.zeros(len(value_series)),
                        ymax=np.ones(len(value_series)),
                        colors="lightgray",
                        linestyles="dotted",
                        zorder=0
                    )
                    axis.scatter(
                        x=self._reset_tz(value_series.index),
                        y=0.5 * np.ones(len(value_series)),
                        marker="x",
                        color="red",
                        zorder=1
                    )
                elif isinstance(self._sensor_events.get_sensor().get_sensor_type(), PresenceSensorType):
                    self._plot_zero_order_hold_area(
                        axis=axis,
                        x=self._reset_tz(series.index),
                        y1=np.zeros(len(series)),
                        y2=series.values
                    )
                axis.set_ylim([0, 1])
            axis.locator_params('y', nbins=1)
            return axis

    class _ModelProbabilitiesPlotter(AbstractPlotter):

        def __init__(self, model_probabilities, state_label_colors, *args, **kwargs):
            super(TrainingResultsVisualizer._ModelProbabilitiesPlotter, self).__init__(*args, **kwargs)
            self._model_probabilities = model_probabilities
            self._state_label_colors = state_label_colors

        def plot(self, fig, subplot_spec, **kwargs):
            axis = self._create_axis(fig=fig, subplot_spec=subplot_spec, **kwargs)
            for state_label in self._model_probabilities.columns:
                state_model_probabilities = self._model_probabilities[state_label]
                state_model_probabilities.loc[24] = 0
                if not state_model_probabilities.empty:
                    self._plot_zero_order_hold_line(
                        axis,
                        state_model_probabilities.index,
                        state_model_probabilities.values,
                        color=self._state_label_colors[state_label],
                        label=state_label
                    )
            axis.legend(loc=1)
            axis.set_xticks(range(0, 25, 2))
            axis.set_xlim([0, 24])
            axis.set_ylim([0, 1])
            return axis

    class _SensorProbabilityDistributionPlotter(AbstractPlotter):

        def __init__(self, sensor_probability_distribution, state_label_colors, *args, **kwargs):
            super(TrainingResultsVisualizer._SensorProbabilityDistributionPlotter, self).__init__(*args, **kwargs)
            self._sensor_probability_distribution = sensor_probability_distribution
            self._state_label_colors = state_label_colors

        def plot(self, fig, subplot_spec, **kwargs):
            axis = self._create_axis(fig=fig, subplot_spec=subplot_spec, **kwargs)
            for state_label in self._sensor_probability_distribution.columns:
                state_sensor_probability_distribution = self._sensor_probability_distribution[state_label]
                if not state_sensor_probability_distribution.empty:
                    self._plot_zero_order_hold_line(
                        axis,
                        state_sensor_probability_distribution.index,
                        state_sensor_probability_distribution.values,
                        color=self._state_label_colors[state_label],
                        label=state_label
                    )
            axis.legend(loc=1)
            return axis

    class _CorrelationMatrixPlotter(AbstractPlotter):

        def __init__(self, correlation_matrix, *args, **kwargs):
            super(TrainingResultsVisualizer._CorrelationMatrixPlotter, self).__init__(*args, **kwargs)
            self._correlation_matrix = correlation_matrix

        @staticmethod
        def _map_labels(sensors):
            return map(lambda sensor: sensor.get_identifier(), sensors)

        def plot(self, fig, subplot_spec, **kwargs):
            axis = self._create_axis(fig=fig, subplot_spec=subplot_spec, **kwargs)
            if not self._correlation_matrix.empty:
                correlation_matrix = self._correlation_matrix.copy()
                correlation_matrix.index = self._map_labels(
                    correlation_matrix.index
                )
                correlation_matrix.columns = self._map_labels(
                    correlation_matrix.columns
                )
                self._plot_matrix(
                    axis=axis,
                    matrix=correlation_matrix
                )
