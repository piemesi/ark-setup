import datetime
import matplotlib.patches as mpatches
import numpy as np

from ..abstract_results_visualizer import AbstractResultsVisualizer
from ...abstract_plotter import AbstractPlotter
from ....models.models.sensor_models.abstract_lumped_sensor_model import AbstractLumpedSensorModel
from ....models.models.sensor_models.abstract_separated_sensor_model import AbstractSeparatedSensorModel
from ....results.results.validation_results import ValidationResults
from ....sensors.sensor_reporting_policies import BooleanSensorReportingPolicy
from .....manipulators.datetime_manipulators import floor_datetime, ceil_datetime
from .....validation.type_validation import assert_is_type


class ValidationResultsVisualizer(AbstractResultsVisualizer):

    _SOURCE_DATA_CLS = ValidationResults

    def __init__(self, plot_per_day, *args, **kwargs):
        super(ValidationResultsVisualizer, self).__init__(*args, **kwargs)
        assert_is_type(plot_per_day, bool)
        self._plot_per_day = plot_per_day

    def _visualize_validation_results(self):
        sensor_events_collection = self._source_data.get_sensor_events_collection()
        sensor_model_collection = self._source_data.get_sensor_model_collection()
        filter_processor_results = self._source_data.get_filter_processor_results()
        application_processor_results = self._source_data.get_application_processor_results()
        auto_away_state_series = application_processor_results.get_state_series()
        ground_truth_state_series = self._source_data.get_ground_truth_state_series()
        estimated_truth_state_series = self._source_data.get_estimated_truth_state_series()
        device_auto_away_state_series = self._source_data.get_device_auto_away_state_series()

        plotters = []
        for sensor_model in sensor_model_collection.get_sensor_models():
            if isinstance(sensor_model, AbstractLumpedSensorModel):
                sensor_update_cache = sensor_model.get_sensor_update_cache()
                if not sensor_update_cache.empty:
                    plotters.append(
                        [
                            self._StackedProbabilitiesPlotter(
                                title=str(sensor_model),
                                height=2,
                                width=20,
                                area_alpha=self._area_alpha,
                                probabilities=sensor_update_cache.reset_index(level=1, drop=True),
                                state_label_colors=self._state_label_colors
                            )
                        ]
                    )
        for sensor_events in sensor_events_collection.get_sensor_events_list_for_sensor_types(
                filter_processor_results.get_sensor_types()
        ):
            plotters.append(
                [
                    self._ReportingEventsPlotter(
                        title=str(sensor_events.get_sensor()),
                        height=1,
                        width=20,
                        area_alpha=self._area_alpha,
                        sensor_events=sensor_events,
                        boolean_state_label_colors=self._boolean_state_label_colors
                    )
                ]
            )
            for sensor_model in sensor_model_collection.get_sensor_models():
                if isinstance(sensor_model, AbstractSeparatedSensorModel):
                    if sensor_events.get_sensor() in sensor_model.get_sensors():
                        sensor_update_cache = sensor_model.get_sensor_update_cache(sensor_events.get_sensor())
                        if not sensor_update_cache.empty:
                            plotters.append(
                                [
                                    self._StackedProbabilitiesPlotter(
                                        title=str(sensor_model),
                                        height=2,
                                        width=20,
                                        area_alpha=self._area_alpha,
                                        probabilities=sensor_update_cache.reset_index(level=1, drop=True),
                                        state_label_colors=self._state_label_colors
                                    )
                                ]
                            )
        if ground_truth_state_series is not None and not ground_truth_state_series.get_series().empty:
            plotters.append(
                [
                    self._StateSeriesPlotter(
                        title=str(ground_truth_state_series),
                        height=1,
                        width=20,
                        area_alpha=self._area_alpha,
                        state_series=ground_truth_state_series.get_series(),
                        state_label_colors=self._state_label_colors
                    )
                ]
            )
        plotters.append(
            [
                self._StateSeriesPlotter(
                    title=str(estimated_truth_state_series),
                    height=1,
                    width=20,
                    area_alpha=self._area_alpha,
                    state_series=estimated_truth_state_series.get_series(),
                    state_label_colors=self._state_label_colors
                )
            ]
        )
        if device_auto_away_state_series is not None and not device_auto_away_state_series.get_series().empty:
            plotters.append(
                [
                    self._StateSeriesPlotter(
                        title=str(device_auto_away_state_series),
                        height=1,
                        width=20,
                        area_alpha=self._area_alpha,
                        state_series=device_auto_away_state_series.get_series(),
                        state_label_colors=self._auto_away_state_label_colors
                    )
                ]
            )
        plotters.append(
            [
                self._StateSeriesPlotter(
                    title=str(auto_away_state_series),
                    height=1,
                    width=20,
                    area_alpha=self._area_alpha,
                    state_series=auto_away_state_series.get_series(),
                    state_label_colors=self._auto_away_state_label_colors
                )
            ]
        )
        plotters.append(
            [
                self._StackedProbabilitiesPlotter(
                    title=str(filter_processor_results),
                    height=3,
                    width=20,
                    area_alpha=self._area_alpha,
                    probabilities=filter_processor_results.get_belief_probabilities_sequence(),
                    state_label_colors=self._state_label_colors
                )
            ]
        )

        estimated_truth_series = estimated_truth_state_series.get_series()
        timestamps = map(lambda timestamp: timestamp.replace(tzinfo=None), estimated_truth_series.index)
        if self._plot_per_day and timestamps:
            estimated_truth_series = estimated_truth_state_series.get_series()
            timestamps = map(lambda timestamp: timestamp.replace(tzinfo=None), estimated_truth_series.index)
            self._create_and_save_fig_with_subplots_per_day(
                fig_title="ValidationResults",
                fig_subtitle=str(self._source_data),
                plotters=plotters,
                share_x_axis=True,
                share_y_axis=False,
                path=self._workspace.get_plots_path(),
                start_datetime=floor_datetime(min(timestamps), datetime.timedelta(days=1)),
                end_datetime=ceil_datetime(max(timestamps), datetime.timedelta(days=1))
            )
        else:
            self._create_and_save_fig_with_subplots(
                fig_title="ValidationResults",
                fig_subtitle=str(self._source_data),
                plotters=plotters,
                share_x_axis=True,
                share_y_axis=False,
                path=self._workspace.get_plots_path()
            )



    def visualize(self):
        self._visualize_validation_results()

    class _ReportingEventsPlotter(AbstractPlotter):

        def __init__(self, sensor_events, boolean_state_label_colors, *args, **kwargs):
            super(ValidationResultsVisualizer._ReportingEventsPlotter, self).__init__(*args, **kwargs)
            self._sensor_events = sensor_events
            self._boolean_state_label_colors = boolean_state_label_colors

        @staticmethod
        def _compute_reporting_events(sensor_events):
            sensor = sensor_events.get_sensor()
            sensor_reporting_policy = sensor.get_sensor_reporting_policy()
            return sensor_reporting_policy.compute_reporting_events(sensor_events.get_series())

        def plot(self, fig, subplot_spec, **kwargs):
            axis = self._create_axis(fig=fig, subplot_spec=subplot_spec, **kwargs)
            reporting_events = self._compute_reporting_events(self._sensor_events)
            for reporting_event in reporting_events.unique():
                if reporting_event in [
                    BooleanSensorReportingPolicy.ASSERT_ENABLED,
                    BooleanSensorReportingPolicy.REASSERT_ENABLED
                ]:
                    color = self._boolean_state_label_colors[True]
                    offset = 0.5
                else:
                    color = self._boolean_state_label_colors[False]
                    offset = -0.5

                if reporting_event in [
                    BooleanSensorReportingPolicy.ASSERT_ENABLED,
                    BooleanSensorReportingPolicy.ASSERT_DISABLED
                ]:
                    marker = "x"
                    facecolor = color
                else:
                    marker = "o"
                    facecolor = "none"
                if not reporting_events.empty:
                    series = reporting_events[reporting_events == reporting_event]
                    if not series.empty:
                        axis.vlines(
                            x=self._reset_tz(series.index),
                            ymin=-np.ones(len(series)),
                            ymax=np.ones(len(series)),
                            colors="lightgray",
                            linestyles="dotted",
                            zorder=0
                        )
                        axis.scatter(
                            x=self._reset_tz(series.index),
                            y=offset * np.ones(len(series)),
                            marker=marker,
                            facecolors=facecolor,
                            edgecolors=color,
                            zorder=1
                        )
            axis.set_ylim([-1, 1])
            axis.set_yticks([])
            return axis

    class _StackedProbabilitiesPlotter(AbstractPlotter):

        def __init__(self, probabilities, state_label_colors, *args, **kwargs):
            super(ValidationResultsVisualizer._StackedProbabilitiesPlotter, self).__init__(*args, **kwargs)
            self._probabilities = probabilities
            self._state_label_colors = state_label_colors

        def plot(self, fig, subplot_spec, **kwargs):
            axis = self._create_axis(fig=fig, subplot_spec=subplot_spec, **kwargs)
            if not self._probabilities.empty:
                probabilities_stack = self._probabilities.cumsum(axis=1)
                handles = []
                for state_index, state_label in enumerate(probabilities_stack.columns):
                    current_probabilities_stack = probabilities_stack.iloc[:, state_index].values
                    if state_index == 0:
                        previous_probabilities_stack = np.zeros(len(probabilities_stack))
                    else:
                        previous_probabilities_stack = probabilities_stack.iloc[:, state_index - 1].values
                    self._plot_zero_order_hold_area(
                        axis,
                        self._reset_tz(probabilities_stack.index),
                        previous_probabilities_stack,
                        current_probabilities_stack,
                        facecolor=self._state_label_colors[state_label]
                    )
                    handles.append(
                        mpatches.Patch(color=self._state_label_colors[state_label], label=state_label)
                    )
                axis.vlines(
                    x=self._reset_tz(self._probabilities.index),
                    ymin=np.zeros(len(self._probabilities)),
                    ymax=np.ones(len(self._probabilities)),
                    colors="lightgray",
                    zorder=0
                )
                axis.legend(handles=handles, loc=1)
                axis.set_xlim([min(self._probabilities.index), max(self._probabilities.index)])
            axis.set_ylim([0, 1])
            return axis
