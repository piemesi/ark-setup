import functools
import numpy as np
import pandas as pd

from ..abstract_visualizer import AbstractVisualizer
from ..abstract_plotter import AbstractPlotter
from ...environment.array_dict import ArrayDict


class AggregateVisualizer(AbstractVisualizer):

    _SOURCE_DATA_CLS = ArrayDict

    def _visualize_aggregate_plotter(self, fig_title, plotter):
        plotters = []
        for keys_row in np.asarray(self._source_data.keys_matrix._matrix):
            plotter_row = []
            for key in keys_row:
                experiment_results = [
                    experiment_result for experiment_result in self._source_data[key] if experiment_result.get_success()
                ]
                plotter_row.append(
                    plotter(
                        title=key,
                        width=6,
                        area_alpha=self._area_alpha,
                        experiment_results=experiment_results
                    )
                )
            plotters.append(plotter_row)

        self._create_and_save_fig_with_subplots(
            fig_title=fig_title,
            fig_subtitle="<AggregateResults>",
            plotters=plotters,
            share_x_axis=True,
            share_y_axis=False,
            path=self._workspace.get_plots_path()
        )

    def visualize(self):
        for fig_title, plotter in (
                    [
                        (
                                "TimeInAwayMultiAxis",
                                functools.partial(
                                    self._TimeInAwayHistogramMultiAxisPlotter,
                                    height=8,
                                    auto_away_state_label_colors=self._auto_away_state_label_colors
                                )
                        ),
                        (
                                "TimeInAwaySingleAxis",
                                functools.partial(
                                    self._TimeInAwayHistogramSingleAxisPlotter,
                                    height=3,
                                    auto_away_state_label_colors=self._auto_away_state_label_colors
                                )
                        ),
                        (
                                "AwayIntervals",
                                functools.partial(
                                    self._AwayIntervalsHistogramPlotter,
                                    height=8,
                                    auto_away_state_label_colors=self._auto_away_state_label_colors
                                )
                        ),
                        (
                                "TransitionDelays",
                                functools.partial(
                                    self._TransitionDelaysHistogramPlotter,
                                    height=6,
                                    boolean_state_label_colors=self._boolean_state_label_colors
                                )
                        ),
                        (
                                "ConfusionMatrix",
                                functools.partial(
                                    self._ConfusionMatrixPlotter,
                                    height=6,
                                )
                        )
                    ] +
                    [
                        (
                                "Statistic ({})".format(stat_name),
                                functools.partial(
                                    self._StatisticHistogramPlotter,
                                    height=3,
                                    stat_name=stat_name
                                )
                        )
                        for stat_name in [
                            "target_base_rate",
                            "test_base_rate",
                            "true_positive_rate",
                            "true_negative_rate",
                            "false_positive_rate",
                            "false_negative_rate",
                            "positive_predicted_value",
                            "accuracy",
                            "matthews_correlation_coefficient",
                        ]
                    ]
        ):
            self._visualize_aggregate_plotter(fig_title=fig_title, plotter=plotter)

    class _TimeInAwayHistogramMultiAxisPlotter(AbstractPlotter):

        def __init__(self, experiment_results, auto_away_state_label_colors, *args, **kwargs):
            super(AggregateVisualizer._TimeInAwayHistogramMultiAxisPlotter, self).__init__(*args, **kwargs)
            self._experiment_results = experiment_results
            self._auto_away_state_label_colors = auto_away_state_label_colors

        def plot(self, fig, subplot_spec, **kwargs):
            time_in_states = pd.DataFrame(
                map(
                    lambda experiment_result:
                    experiment_result.get_diagnostic_test_results().get_test_state_series().get_time_in_states(),
                    self._experiment_results
                )
            )
            axes = self._create_axes(
                fig=fig,
                subplot_spec=subplot_spec,
                number_of_axes=len(time_in_states.columns),
                **kwargs
            )
            for index, state_label in enumerate(time_in_states.columns):
                if not time_in_states.empty:
                    axes[index].hist(
                        time_in_states[state_label] / pd.Timedelta(minutes=1),
                        bins=np.linspace(0, 600, 50),
                        alpha=self._area_alpha,
                        facecolor=self._auto_away_state_label_colors[state_label],
                    )
                axes[index].set_title(state_label)
                axes[index].set_xlim([0, 600])

    class _TimeInAwayHistogramSingleAxisPlotter(AbstractPlotter):

        def __init__(self, experiment_results, auto_away_state_label_colors, *args, **kwargs):
            super(AggregateVisualizer._TimeInAwayHistogramSingleAxisPlotter, self).__init__(*args, **kwargs)
            self._experiment_results = experiment_results
            self._auto_away_state_label_colors = auto_away_state_label_colors

        def plot(self, fig, subplot_spec, **kwargs):
            time_in_states = pd.DataFrame(
                map(
                    lambda experiment_result:
                    experiment_result.get_diagnostic_test_results().get_test_state_series().get_time_in_states(),
                    self._experiment_results
                )
            )
            axis = self._create_axis(fig=fig, subplot_spec=subplot_spec, **kwargs)
            for index, state_label in enumerate(time_in_states.columns):
                if not time_in_states.empty:
                    axis.hist(
                        time_in_states[state_label] / pd.Timedelta(minutes=1),
                        bins=np.linspace(0, 600, 50),
                        alpha=self._area_alpha,
                        facecolor=self._auto_away_state_label_colors[state_label],
                        label=state_label
                    )
            axis.set_xlim([0, 600])

    class _AwayIntervalsHistogramPlotter(AbstractPlotter):

        def __init__(self, experiment_results, auto_away_state_label_colors, *args, **kwargs):
            super(AggregateVisualizer._AwayIntervalsHistogramPlotter, self).__init__(*args, **kwargs)
            self._experiment_results = experiment_results
            self._auto_away_state_label_colors = auto_away_state_label_colors

        def plot(self, fig, subplot_spec, **kwargs):
            intervals = pd.DataFrame(
                map(
                    lambda experiment_result:
                    experiment_result.get_diagnostic_test_results().get_test_state_series().get_intervals(),
                    self._experiment_results
                )
            )
            axes = self._create_axes(
                fig=fig,
                subplot_spec=subplot_spec,
                number_of_axes=len(intervals.columns),
                **kwargs
            )
            for index, state_label in enumerate(intervals.columns):
                state_intervals = pd.Series(sum(intervals[state_label].tolist(), []))
                if not state_intervals.empty:
                    axes[index].hist(
                        state_intervals / pd.Timedelta(minutes=1),
                        bins=np.linspace(0, 600, 50),
                        alpha=self._area_alpha,
                        facecolor=self._auto_away_state_label_colors[state_label],
                    )
                axes[index].set_title(state_label)
                axes[index].set_xlim([0, 600])

    class _TransitionDelaysHistogramPlotter(AbstractPlotter):

        def __init__(self, experiment_results, boolean_state_label_colors, *args, **kwargs):
            super(AggregateVisualizer._TransitionDelaysHistogramPlotter, self).__init__(*args, **kwargs)
            self._experiment_results = experiment_results
            self._boolean_state_label_colors = boolean_state_label_colors

        def plot(self, fig, subplot_spec, **kwargs):
            transition_delays = pd.DataFrame(
                columns=[True, False],
                data=map(
                    lambda experiment_result:
                    {
                        True: experiment_result.get_diagnostic_test_results().get_positive_transition_delays(),
                        False: experiment_result.get_diagnostic_test_results().get_negative_transition_delays()
                    },
                    self._experiment_results
                )
            )
            axes = self._create_axes(
                fig=fig,
                subplot_spec=subplot_spec,
                number_of_axes=2,
                **kwargs
            )
            for index, boolean in enumerate([True, False]):
                boolean_transition_delays = pd.Series(sum(transition_delays[boolean].tolist(), []))
                if not boolean_transition_delays.empty:
                    axes[index].hist(
                        boolean_transition_delays / pd.Timedelta(minutes=1),
                        bins=np.linspace(0, 300, 50),
                        alpha=self._area_alpha,
                        facecolor=self._boolean_state_label_colors[boolean],
                    )
                axes[index].set_title(boolean)
                axes[index].set_xlim([0, 300])

    class _StatisticHistogramPlotter(AbstractPlotter):

        def __init__(self, experiment_results, stat_name, *args, **kwargs):
            super(AggregateVisualizer._StatisticHistogramPlotter, self).__init__(*args, **kwargs)
            self._experiment_results = experiment_results
            self._stat_name = stat_name

        def plot(self, fig, subplot_spec, **kwargs):
            stat = pd.Series(
                map(
                    lambda experiment_result:
                    getattr(experiment_result.get_diagnostic_test_results(), "get_{}".format(self._stat_name))(),
                    self._experiment_results
                )
            )
            axis = self._create_axis(fig=fig, subplot_spec=subplot_spec, **kwargs)
            if not stat.empty:
                axis.hist(
                    stat,
                    bins=np.linspace(0, 1, 50),
                    alpha=self._area_alpha
                )
            axis.set_xlim([0, 1])

    class _ConfusionMatrixPlotter(AbstractPlotter):

        def __init__(self, experiment_results, *args, **kwargs):
            super(AggregateVisualizer._ConfusionMatrixPlotter, self).__init__(*args, **kwargs)
            self._experiment_results = experiment_results

        def plot(self, fig, subplot_spec, **kwargs):
            stacked_confusion_matrices = map(
                lambda experiment_result:
                experiment_result.get_diagnostic_test_results().get_confusion_matrix().stack(),
                self._experiment_results
            )
            aggregate_confusion_matrix = pd.DataFrame(stacked_confusion_matrices).mean().unstack()
            axis = self._create_axis(fig=fig, subplot_spec=subplot_spec, **kwargs)
            if not aggregate_confusion_matrix.empty:
                self._plot_matrix(
                    axis=axis,
                    matrix=aggregate_confusion_matrix / aggregate_confusion_matrix.sum()
                )
                axis.set_ylabel('True Label')
                axis.set_xlabel('Predicted Label')
