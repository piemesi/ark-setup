import datetime
import matplotlib.patches as mpatches
import numpy as np
import pandas as pd

from abc import ABCMeta

from ..abstract_visualizer import AbstractVisualizer
from ..abstract_plotter import AbstractPlotter


class AbstractResultsVisualizer(AbstractVisualizer):
    __metaclass__ = ABCMeta

    def _create_and_save_fig_with_subplots_per_day(
            self,
            fig_title,
            fig_subtitle,
            plotters,
            share_x_axis,
            share_y_axis,
            path,
            start_datetime,
            end_datetime
    ):
        for day_index in range(int((end_datetime - start_datetime).total_seconds() / (24 * 3600))):
            day_start_datetime = start_datetime + day_index * datetime.timedelta(days=1)
            day_end_datetime = start_datetime + (day_index + 1) * datetime.timedelta(days=1)
            self._create_and_save_fig_with_subplots(
                fig_title="{} ({})".format(fig_title, day_start_datetime.strftime("%Y-%m-%d")),
                fig_subtitle=fig_subtitle,
                plotters=plotters,
                share_x_axis=share_x_axis,
                share_y_axis=share_y_axis,
                path=path,
                x_limit=[day_start_datetime, day_end_datetime]
            )

    class _StateSeriesPlotter(AbstractPlotter):

        def __init__(self, state_series, state_label_colors, *args, **kwargs):
            super(AbstractResultsVisualizer._StateSeriesPlotter, self).__init__(*args, **kwargs)
            self._state_series = state_series
            self._state_label_colors = state_label_colors

        def plot(self, fig, subplot_spec, **kwargs):
            axis = self._create_axis(fig=fig, subplot_spec=subplot_spec, **kwargs)
            if not self._state_series.empty:
                handles = []
                for state_index, state_label in enumerate(self._state_label_colors.index):
                    self._plot_zero_order_hold_area(
                        axis,
                        self._reset_tz(self._state_series.index),
                        np.zeros(len(self._state_series)),
                        pd.Series(self._state_series == state_label).values,
                        facecolor=self._state_label_colors[state_label]
                    )
                    handles.append(
                        mpatches.Patch(color=self._state_label_colors[state_label], label=state_label)
                    )
                axis.legend(handles=handles, loc=1)
            axis.set_ylim([0, 1])
            axis.set_yticks([])
            return axis
