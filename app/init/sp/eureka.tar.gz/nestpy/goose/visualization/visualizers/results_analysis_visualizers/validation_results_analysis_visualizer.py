import datetime
import numpy as np
import pandas as pd

from ...abstract_visualizer import AbstractVisualizer
from ...abstract_plotter import AbstractPlotter
from ....analysis.abstract_results_analysis import AbstractResultsAnalysis


class ValidationResultsAnalysisVisualizer(AbstractVisualizer):

    _SOURCE_DATA_CLS = AbstractResultsAnalysis

    def _visualize_validation_results_analysis(self):
        goose_diagnostic_test_results = self._source_data.get_goose_diagnostic_test_results()
        goose_diagnostic_test_results_collection = self._source_data.get_goose_diagnostic_test_results_collection()
        device_diagnostic_test_results = self._source_data.get_device_diagnostic_test_results()

        plotters = [
            [
                self._ROCCurvePlotter(
                    title="ROCCurve",
                    height=8,
                    width=10,
                    area_alpha=self._area_alpha,
                    goose_diagnostic_test_results=goose_diagnostic_test_results,
                    goose_diagnostic_test_results_collection=goose_diagnostic_test_results_collection,
                    device_diagnostic_test_results=device_diagnostic_test_results
                ),
                self._DiagnosticTestResultsPlotter(
                    title="DiagnosticTestResults",
                    height=8,
                    width=10,
                    area_alpha=self._area_alpha,
                    goose_diagnostic_test_results=goose_diagnostic_test_results,
                    device_diagnostic_test_results=device_diagnostic_test_results
                )
            ],
            [
                self._TotalRatesPlotter(
                    title="TotalRates",
                    height=8,
                    width=10,
                    area_alpha=self._area_alpha,
                    goose_diagnostic_test_results=goose_diagnostic_test_results,
                    device_diagnostic_test_results=device_diagnostic_test_results
                ),
                self._TransitionDelaysPlotter(
                    title="TransitionDelays",
                    height=8,
                    width=10,
                    area_alpha=self._area_alpha,
                    goose_diagnostic_test_results=goose_diagnostic_test_results,
                    device_diagnostic_test_results=device_diagnostic_test_results
                )
            ]
        ]

        self._create_and_save_fig_with_subplots(
            fig_title="ValidationResultsAnalysis",
            fig_subtitle=str(self._source_data),
            plotters=plotters,
            share_x_axis=False,
            share_y_axis=False,
            path=self._workspace.get_plots_path()
        )

    def visualize(self):
        self._visualize_validation_results_analysis()

    class _ROCCurvePlotter(AbstractPlotter):

        def __init__(
                self,
                goose_diagnostic_test_results,
                goose_diagnostic_test_results_collection,
                device_diagnostic_test_results,
                *args,
                **kwargs
        ):
            super(ValidationResultsAnalysisVisualizer._ROCCurvePlotter, self).__init__(*args, **kwargs)
            self._goose_diagnostic_test_results = goose_diagnostic_test_results
            self._goose_diagnostic_test_results_collection = goose_diagnostic_test_results_collection
            self._device_diagnostic_test_results = device_diagnostic_test_results

        @classmethod
        def _plot_roc_curve(cls, axis, diagnostic_test_results_collection):
            diagnostic_test_results_list = diagnostic_test_results_collection.get_diagnostic_test_results_list()
            if diagnostic_test_results_list:
                roc_curve_series = pd.Series(
                    index=[diagnostic_test_results.get_false_positive_rate()
                           for diagnostic_test_results in diagnostic_test_results_list],
                    data=[diagnostic_test_results.get_true_positive_rate()
                          for diagnostic_test_results in diagnostic_test_results_list]).sort_index()
                axis.plot(
                    roc_curve_series.index,
                    roc_curve_series.values,
                    label="ROCCurve",
                    marker='x',
                    markersize=10,
                    zorder=0
                )

        @staticmethod
        def _plot_roc_point(axis, diagnostic_test_results, *args, **kwargs):
            axis.plot(
                [diagnostic_test_results.get_false_positive_rate()],
                [diagnostic_test_results.get_true_positive_rate()],
                linestyle='None',
                marker='x',
                markersize=10,
                mew=2,
                label=str(diagnostic_test_results.get_test_state_series()),
                zorder=1,
                *args,
                **kwargs
            )

        def plot(self, fig, subplot_spec, **kwargs):
            axis = self._create_axis(fig=fig, subplot_spec=subplot_spec, **kwargs)
            self._plot_roc_curve(axis, self._goose_diagnostic_test_results_collection)
            self._plot_roc_point(axis, self._goose_diagnostic_test_results, color='forestgreen')
            if self._device_diagnostic_test_results is not None:
                self._plot_roc_point(axis, self._device_diagnostic_test_results, color='red')
            axis.set_xlabel("FPR")
            axis.set_ylabel("TPR")
            axis.set_xlim([0, 1])
            axis.set_ylim([0, 1])
            axis.legend(loc=1, numpoints=1)

    class _DiagnosticTestResultsPlotter(AbstractPlotter):

        def __init__(self, goose_diagnostic_test_results, device_diagnostic_test_results, *args, **kwargs):
            super(ValidationResultsAnalysisVisualizer._DiagnosticTestResultsPlotter, self).__init__(*args, **kwargs)
            self._goose_diagnostic_test_results = goose_diagnostic_test_results
            self._device_diagnostic_test_results = device_diagnostic_test_results

        def plot(self, fig, subplot_spec, **kwargs):
            def get_diagnostic_test_results_series(diagnostic_test_results):
                return pd.Series(
                    index=[
                        "TPR (Sensitivity)",
                        "TNR (Specificity)",
                        "FPR (Fall-out)",
                        "FNR (Miss rate)",
                        "PPV (Precision)",
                        "F1 score",
                        "Accuracy",
                        "MCC"
                    ],
                    name=str(diagnostic_test_results.get_test_state_series()),
                    data=[
                        diagnostic_test_results.get_true_positive_rate(),
                        diagnostic_test_results.get_true_negative_rate(),
                        diagnostic_test_results.get_false_positive_rate(),
                        diagnostic_test_results.get_false_negative_rate(),
                        diagnostic_test_results.get_positive_predicted_value(),
                        diagnostic_test_results.get_f1_score(),
                        diagnostic_test_results.get_accuracy(),
                        diagnostic_test_results.get_matthews_correlation_coefficient()
                    ]
                )

            grouped_bar_list = [get_diagnostic_test_results_series(self._goose_diagnostic_test_results)]
            if self._device_diagnostic_test_results is not None:
                grouped_bar_list.append(get_diagnostic_test_results_series(self._device_diagnostic_test_results))
            grouped_bar_frame = pd.concat(grouped_bar_list, axis=1)

            axis = self._create_axis(fig=fig, subplot_spec=subplot_spec, **kwargs)
            self._plot_grouped_bar(axis, grouped_bar_frame, colors=['forestgreen', 'red'])
            axis.set_xticks(np.arange(len(grouped_bar_frame)) + 0.5)
            axis.set_xticklabels(grouped_bar_frame.index)
            axis.set_ylim([0, 1])
            axis.legend(loc=1)

    class _TotalRatesPlotter(AbstractPlotter):

        def __init__(self, goose_diagnostic_test_results, device_diagnostic_test_results, *args, **kwargs):
            super(ValidationResultsAnalysisVisualizer._TotalRatesPlotter, self).__init__(*args, **kwargs)
            self._goose_diagnostic_test_results = goose_diagnostic_test_results
            self._device_diagnostic_test_results = device_diagnostic_test_results

        def plot(self, fig, subplot_spec, **kwargs):
            def get_test_base_rate_series(diagnostic_test_results):
                return pd.Series(
                    index=["PercentPositive"],
                    name=str(diagnostic_test_results.get_test_state_series()),
                    data=[diagnostic_test_results.get_test_base_rate()]
                )
            grouped_bar_list = [get_test_base_rate_series(self._goose_diagnostic_test_results)]
            if self._device_diagnostic_test_results is not None:
                grouped_bar_list.append(get_test_base_rate_series(self._device_diagnostic_test_results))
            grouped_bar_list.append(
                pd.Series(
                    index=["PercentPositive"],
                    name=str(self._goose_diagnostic_test_results.get_target_state_series()),
                    data=[self._goose_diagnostic_test_results.get_target_base_rate()]
                )
            )
            grouped_bar_frame = pd.concat(grouped_bar_list, axis=1)

            axis = self._create_axis(fig=fig, subplot_spec=subplot_spec, **kwargs)
            self._plot_grouped_bar(axis, grouped_bar_frame, colors=['forestgreen', 'red', 'blue'])
            axis.set_xticks(np.arange(len(grouped_bar_frame)) + 0.5)
            axis.set_xticklabels(grouped_bar_frame.index)
            axis.set_ylim([0, 1.5 * grouped_bar_frame.max(0)[0]])
            axis.legend(loc=1)
            axis.set_xlim([0.0, 1.0])

    class _TransitionDelaysPlotter(AbstractPlotter):

        def __init__(self, goose_diagnostic_test_results, device_diagnostic_test_results, *args, **kwargs):
            super(ValidationResultsAnalysisVisualizer._TransitionDelaysPlotter, self).__init__(*args, **kwargs)
            self._goose_diagnostic_test_results = goose_diagnostic_test_results
            self._device_diagnostic_test_results = device_diagnostic_test_results

        def plot(self, fig, subplot_spec, **kwargs):
            def get_mean_timedelta(timedelta_list):
                if len(timedelta_list) > 0:
                    mean_timedelta = sum(timedelta_list, datetime.timedelta(0)) / len(timedelta_list)
                else:
                    mean_timedelta = datetime.timedelta(0)
                return mean_timedelta

            def get_transition_delays_series(diagnostic_test_results):
                transition_delays_series = pd.Series(
                    index=["PTD", "NTD", "PTA", "NTA", "MPI", "MNI", "FPI", "FNI"],
                    name=str(diagnostic_test_results.get_test_state_series()),
                    data=[
                        get_mean_timedelta(diagnostic_test_results.get_positive_transition_delays()),
                        get_mean_timedelta(diagnostic_test_results.get_negative_transition_delays()),
                        get_mean_timedelta(diagnostic_test_results.get_positive_transition_advances()),
                        get_mean_timedelta(diagnostic_test_results.get_negative_transition_advances()),
                        get_mean_timedelta(diagnostic_test_results.get_missed_positive_intervals()),
                        get_mean_timedelta(diagnostic_test_results.get_missed_negative_intervals()),
                        get_mean_timedelta(diagnostic_test_results.get_false_positive_intervals()),
                        get_mean_timedelta(diagnostic_test_results.get_false_negative_intervals())
                    ]
                )
                return transition_delays_series / np.timedelta64(1, 'm')

            grouped_bar_list = [get_transition_delays_series(self._goose_diagnostic_test_results)]
            if self._device_diagnostic_test_results is not None:
                grouped_bar_list.append(get_transition_delays_series(self._device_diagnostic_test_results))
            grouped_bar_frame = pd.concat(grouped_bar_list, axis=1)

            axis = self._create_axis(fig=fig, subplot_spec=subplot_spec, **kwargs)
            self._plot_grouped_bar(axis, grouped_bar_frame, colors=['forestgreen', 'red'])
            axis.set_title("TransitionDelays")
            axis.set_xticks(np.arange(len(grouped_bar_frame)) + 0.5)
            axis.set_xticklabels(grouped_bar_frame.index)
            axis.legend(loc=1)
