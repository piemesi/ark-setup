import matplotlib.cm as cm
import matplotlib.colors as colors
import matplotlib.gridspec as gridspec
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from abc import ABCMeta, abstractmethod


class AbstractPlotter(object):
    __metaclass__ = ABCMeta

    def __init__(self, title, height, width, area_alpha):
        self._title = title
        self._height = height
        self._width = width
        self._area_alpha = area_alpha

    @staticmethod
    def _reset_tz(datetime_index):
        return pd.DatetimeIndex(map(lambda timestamp: timestamp.replace(tzinfo=None), datetime_index))

    @classmethod
    def _plot_matrix(cls, axis, matrix, value_range=(0., 1.), cmap=plt.get_cmap('Blues')):
        vmin, vmax = value_range
        col_range_mag = (vmax - vmin)
        norm_cm = colors.Normalize(vmin=vmin, vmax=vmax)
        color_mapper = cm.ScalarMappable(norm=norm_cm, cmap=cmap)
        im = axis.imshow(matrix.values.T, interpolation='nearest', cmap=cmap, vmin=vmin, vmax=vmax)
        plt.colorbar(im, use_gridspec=True, shrink=.6)
        axis.grid(b=False)
        axis.set_xticks(range(len(matrix.index)))
        axis.set_yticks(range(len(matrix.columns)))
        axis.set_xticklabels(matrix.index, rotation=45)
        axis.set_yticklabels(matrix.columns)
        for (i, j), value in np.ndenumerate(matrix.values):
            text_color = color_mapper.to_rgba(
                vmin + (value - vmin + col_range_mag / 2.) % col_range_mag
            )
            axis.text(i, j, "%0.4f" % float(value), va='center', ha='center', color=text_color)

    @staticmethod
    def _plot_zero_order_hold_line(axis, x, y, *args, **kwargs):
        axis.plot(x.repeat(2)[1:], y.repeat(2)[:-1], *args, **kwargs)

    def _plot_zero_order_hold_area(self, axis, x, y1, y2, *args, **kwargs):
        axis.fill_between(
            x=x.repeat(2)[1:],
            y1=y1.repeat(2)[:-1],
            y2=y2.repeat(2)[:-1],
            alpha=self._area_alpha,
            edgecolor='none',
            *args,
            **kwargs
        )

    def _plot_grouped_bar(self, axis, grouped_bar_frame, colors):
        bar_width = 0.8 / len(grouped_bar_frame.columns)
        bar_offset = 0.1
        for bar_index, bar_name in enumerate(grouped_bar_frame.columns):
            axis.bar(
                np.arange(len(grouped_bar_frame)) + bar_index * bar_width + bar_offset,
                grouped_bar_frame.iloc[:, bar_index],
                bar_width,
                alpha=self._area_alpha,
                color=colors[bar_index],
                label=bar_name
            )

    def _create_axis(self, fig, subplot_spec, **kwargs):
        axis = fig.add_subplot(subplot_spec, **kwargs)
        axis.set_title(self._title)
        return axis

    def _create_axes(self, fig, subplot_spec, number_of_axes, **kwargs):
        inner_grid_spec = gridspec.GridSpecFromSubplotSpec(
            nrows=number_of_axes + 2,
            ncols=1,
            subplot_spec=subplot_spec,
            height_ratios=[1] + [100] * number_of_axes + [1],
            hspace=0.5
        )
        header_axis = fig.add_subplot(inner_grid_spec[0], **kwargs)
        header_axis.set_title(self._title, weight='bold')
        header_axis.axis('off')
        footer_axis = fig.add_subplot(inner_grid_spec[-1], **kwargs)
        footer_axis.axis('off')
        axes = []
        for axis_index in range(1, number_of_axes + 1):
            axes.append(fig.add_subplot(inner_grid_spec[axis_index], **kwargs))
        return axes

    @abstractmethod
    def plot(self, fig, subplot_spec, **kwargs):
        raise NotImplementedError

    def get_height(self):
        return self._height

    def get_width(self):
        return self._width
