from ..abstract_visualizer_builder import (
    AbstractVisualizerBuilder,
    OCCUPANCY_VISUALIZER_BUILDER_CONFIG
)
from ..visualizers.aggregate_visualizer import AggregateVisualizer
from ...building import extend_builder_config


OCCUPANCY_AGGREGATE_VISUALIZER_BUILDER_CONFIG = extend_builder_config(
    OCCUPANCY_VISUALIZER_BUILDER_CONFIG,
    object_cls=AggregateVisualizer
)


class AggregateVisualizerBuilder(AbstractVisualizerBuilder):

    def _get_object_base_cls(self):
        return AggregateVisualizer
