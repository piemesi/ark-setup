from ...abstract_visualizer_builder import (
    AbstractVisualizerBuilder,
    OCCUPANCY_VISUALIZER_BUILDER_CONFIG
)
from ...visualizers.results_analysis_visualizers import ValidationResultsAnalysisVisualizer
from ....building import extend_builder_config


OCCUPANCY_VALIDATION_RESULTS_ANALYSIS_VISUALIZER_BUILDER_CONFIG = extend_builder_config(
    OCCUPANCY_VISUALIZER_BUILDER_CONFIG,
    object_cls=ValidationResultsAnalysisVisualizer
)


class ValidationResultsAnalysisVisualizerBuilder(AbstractVisualizerBuilder):

    def _get_object_base_cls(self):
        return ValidationResultsAnalysisVisualizer
