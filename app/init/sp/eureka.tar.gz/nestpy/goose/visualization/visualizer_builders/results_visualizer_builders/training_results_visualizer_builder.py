from ...abstract_visualizer_builder import (
    AbstractVisualizerBuilder,
    OCCUPANCY_VISUALIZER_BUILDER_CONFIG
)
from ....building import extend_builder_config
from ....results.results import TrainingResults
from ....visualization.visualizers.results_visualizers import TrainingResultsVisualizer


OCCUPANCY_TRAINING_RESULTS_VISUALIZER_BUILDER_CONFIG = extend_builder_config(
    OCCUPANCY_VISUALIZER_BUILDER_CONFIG,
    object_cls=TrainingResultsVisualizer,
    plot_per_day=False
)


class TrainingResultsVisualizerBuilder(AbstractVisualizerBuilder):

    def _get_object_base_cls(self):
        return TrainingResultsVisualizer

    def _get_build_kwargs_types(self):
        return dict(source_data=TrainingResults)
