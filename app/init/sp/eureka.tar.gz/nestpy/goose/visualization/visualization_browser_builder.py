import glob
import json
import logging
import os

from distutils.dir_util import copy_tree

from ..environment.workspace import Workspace
from ..experimentation.experiment_result import ExperimentResult
from ...validation.type_validation import assert_is_type, assert_list_of_type
from ...fileutils import resource_path

logger = logging.getLogger(__name__)


class VisualizationBrowserBuilder(object):

    _BROWSER = "browser"
    _STATIC = "static"

    def __init__(self, workspace, experiment_results):
        assert_is_type(workspace, Workspace)
        assert_list_of_type(experiment_results, ExperimentResult)
        self._workspace = workspace
        self._experiment_results = experiment_results

    def _copy_to_browser_path(self, source_path, *paths):
        target_path = self._workspace.get_path(self._BROWSER, *paths)
        copy_tree(source_path, target_path)

    def _list_experiment_summaries(self):
        experiment_summaries = []
        for experiment_result in self._experiment_results:
            experiment_summaries.append(
                dict(identifier=str(experiment_result.get_experiment()),
                     success=experiment_result.get_success()))
        return experiment_summaries

    def _list_plot_paths(self):
        plot_paths = []
        for root_path, dir_names, file_names in os.walk(self._workspace.get_path(self._BROWSER)):
            for dir_name in dir_names:
                plot_paths += glob.glob(os.path.join(root_path, dir_name, "*.png"))
        return [os.path.relpath(plot_path, self._workspace.get_path(self._BROWSER)) for plot_path in plot_paths]

    def _generate_data_json(self):
        data = {
            "experiment_summaries": self._list_experiment_summaries(),
            "plots": self._list_plot_paths()
        }
        with open(os.path.join(self._workspace.get_path(self._BROWSER, "data"), "data.json"), "w") as data_file:
            json.dump(data, data_file, indent=4, sort_keys=True)

    def build_visualization_browser(self):
        self._copy_to_browser_path(resource_path("goose", "flow", "browser"))
        for experiment_result in self._experiment_results:
            experiment = experiment_result.get_experiment()
            workspace = experiment.get_experiment_workspace()
            self._copy_to_browser_path(workspace.get_plots_path(),
                                       self._STATIC,
                                       str(workspace.get_experiment_id()),
                                       os.path.relpath(workspace.get_plots_path(), workspace.get_base_path()))
        self._generate_data_json()
        logger.info(
            (
                "To view the GOOSE Visualization Browser on OS X, run one of the following commands.\n\n"
                "Open in Safari:\n"
                "\topen -a Safari {target_path}/index.html\n"
                "Start a server (required for Chrome to server up static assets):\n"
                "\tcd {target_path} && python -m SimpleHTTPServer 8000\n"
            ).format(target_path=self._workspace.get_path(self._BROWSER))
        )
