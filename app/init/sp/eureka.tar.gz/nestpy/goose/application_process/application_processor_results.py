from ..states import StateSeries
from ...validation.type_validation import assert_is_type


class ApplicationProcessorResults(object):

    def __init__(self, state_series):
        assert_is_type(state_series, StateSeries)
        self._state_series = state_series

    def __repr__(self):
        return "<{}>".format(self.__class__.__name__)

    def get_state_series(self):
        return self._state_series
