from .abstract_application_processor import AbstractApplicationProcessor
from .application_processors import DualThresholdAutoAwayApplicationProcessor
from .application_processor_results import ApplicationProcessorResults
from ..building import AbstractObjectBuilder
from ..states.state_spaces import OCCUPANCY_STATE_SPACE


OCCUPANCY_APPLICATION_PROCESSOR_RESULTS_BUILDER_CONFIG = dict(
    object_cls=ApplicationProcessorResults,
    application_processor=DualThresholdAutoAwayApplicationProcessor(
        state_space=OCCUPANCY_STATE_SPACE,
        vacant_probability_threshold=0.5,
        buffer_probability_threshold=0.1
    )
)


class ApplicationProcessorResultsBuilder(AbstractObjectBuilder):

    def _get_object_base_cls(self):
        return ApplicationProcessorResults

    def _get_builder_config_types(self):
        return dict(
            application_processor=AbstractApplicationProcessor
        )

    def build(self, filter_processor_results):
        belief_probabilities_sequence = filter_processor_results.get_belief_probabilities_sequence()
        state_series = self._builder_config.get('application_processor').compute_state_series(
            belief_probabilities_sequence
        )
        return self._object_cls(state_series)
