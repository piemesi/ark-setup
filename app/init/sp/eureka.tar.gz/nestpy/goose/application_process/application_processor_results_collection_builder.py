import numpy as np

from .abstract_application_processor import AbstractApplicationProcessor
from .application_processors import DualThresholdAutoAwayApplicationProcessor
from .application_processor_results import ApplicationProcessorResults
from .application_processor_results_collection import ApplicationProcessorResultsCollection
from ..building import AbstractObjectBuilder
from ..states.state_spaces import OCCUPANCY_STATE_SPACE


OCCUPANCY_APPLICATION_PROCESSOR_RESULTS_COLLECTION_BUILDER_CONFIG = dict(
    object_cls=ApplicationProcessorResultsCollection,
    application_processors=[
        DualThresholdAutoAwayApplicationProcessor(
            state_space=OCCUPANCY_STATE_SPACE,
            vacant_probability_threshold=vacant_probability_threshold,
            buffer_probability_threshold=buffer_probability_threshold
        )
        for vacant_probability_threshold in np.linspace(0.01, 0.99, 5)
        for buffer_probability_threshold in np.linspace(0.05, 0.4, 5)
    ]
)


class ApplicationProcessorResultsCollectionBuilder(AbstractObjectBuilder):

    def _get_object_base_cls(self):
        return ApplicationProcessorResultsCollection

    def _get_builder_config_types(self):
        return dict(
            application_processors=AbstractApplicationProcessor
        )

    def build(self, filter_processor_results):
        belief_probabilities_sequence = filter_processor_results.get_belief_probabilities_sequence()
        application_processor_results_list = []
        for application_processor in self._builder_config.get('application_processors'):
            state_series = application_processor.compute_state_series(belief_probabilities_sequence)
            application_processor_results = ApplicationProcessorResults(state_series)
            application_processor_results_list.append(application_processor_results)
        return self._object_cls(application_processor_results_list)
