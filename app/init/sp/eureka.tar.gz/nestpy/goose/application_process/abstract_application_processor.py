import pandas as pd

from abc import ABCMeta, abstractmethod
from numpy.testing.utils import assert_allclose

from ..states.state_spaces.goose_state_space import GOOSEStateSpace
from ...validation.type_validation import assert_is_type


class AbstractApplicationProcessor(object):
    __metaclass__ = ABCMeta

    def __init__(self, state_space):
        assert_is_type(state_space, GOOSEStateSpace)
        self._state_space = state_space

    def __repr__(self):
        return "<{}>".format(self.__class__.__name__)

    def _key(self):
        return self._state_space

    def __hash__(self):
        return hash(self._key())

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self._key() == other._key()

    def __ne__(self, other):
        return not self.__eq__(other)

    def _validate_belief_probabilities_sequence(self, belief_probabilities_sequence):
        assert_is_type(belief_probabilities_sequence, pd.DataFrame)
        assert_allclose(belief_probabilities_sequence.sum(axis=1), 1)
        for state_label in belief_probabilities_sequence.columns:
            if not self._state_space.has_state_label(state_label):
                raise ValueError("State label '{}' not found in specified state space.".format(state_label))

    @abstractmethod
    def _get_state_series_cls(self):
        raise NotImplementedError

    @abstractmethod
    def _compute_state_series(self, belief_probabilities_sequence):
        raise NotImplementedError

    def compute_state_series(self, belief_probabilities_sequence):
        self._validate_belief_probabilities_sequence(belief_probabilities_sequence)
        state_series_cls = self._get_state_series_cls()
        return state_series_cls(
            series=self._compute_state_series(belief_probabilities_sequence),
            application_processor=self
        )

    def get_state_space(self):
        return self._state_space
