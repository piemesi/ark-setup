from .application_processor_results import ApplicationProcessorResults
from ...validation.type_validation import assert_list_of_type


class ApplicationProcessorResultsCollection(object):

    def __init__(self, application_processor_results_list):
        assert_list_of_type(application_processor_results_list, ApplicationProcessorResults)
        self._application_processor_results_list = application_processor_results_list

    def __repr__(self):
        return "<{}>".format(self.__class__.__name__)

    def get_application_processor_results_list(self):
        return self._application_processor_results_list
