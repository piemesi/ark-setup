import pandas as pd

from ..abstract_application_processor import AbstractApplicationProcessor
from ...states.state_spaces import AUTO_AWAY_STATE_SPACE
from ...states.state_series_.auto_away_state_series_ import GOOSEAutoAwayStateSeries
from ....validation.type_validation import assert_type_in


class DualThresholdAutoAwayApplicationProcessor(AbstractApplicationProcessor):

    def __init__(self, vacant_probability_threshold, buffer_probability_threshold, *args, **kwargs):
        super(DualThresholdAutoAwayApplicationProcessor, self).__init__(*args, **kwargs)
        for threshold in [vacant_probability_threshold, buffer_probability_threshold]:
            assert_type_in(threshold, [int, float])
        self._vacant_probability_threshold = vacant_probability_threshold
        self._buffer_probability_threshold = buffer_probability_threshold

    def __repr__(self):
        return "<{}: {}>".format(self.__class__.__name__, str(self))

    def __str__(self):
        return "vacant_probability_threshold={}, buffer_probability_threshold={}".format(
            self._vacant_probability_threshold,
            self._buffer_probability_threshold
        )

    def _key(self):
        return self._state_space, self._vacant_probability_threshold, self._buffer_probability_threshold

    def _get_state_series_cls(self):
        return GOOSEAutoAwayStateSeries

    def _compute_state_series(self, belief_probabilities_sequence):
        auto_away_state_label = AUTO_AWAY_STATE_SPACE.get_auto_away_state().get_state_label()
        home_state_label = AUTO_AWAY_STATE_SPACE.get_home_state().get_state_label()
        vacant_state_label = self._state_space.get_vacant_state().get_state_label()
        vacant_belief_probabilities_sequence = belief_probabilities_sequence[vacant_state_label]
        auto_away_series = pd.Series(index=vacant_belief_probabilities_sequence.index)
        if not auto_away_series.empty:
            auto_away_series.iloc[0] = home_state_label
        auto_away_series[
            vacant_belief_probabilities_sequence >
            self._vacant_probability_threshold + self._buffer_probability_threshold
        ] = auto_away_state_label
        auto_away_series[
            vacant_belief_probabilities_sequence <
            self._vacant_probability_threshold - self._buffer_probability_threshold
        ] = home_state_label
        return auto_away_series.fillna(method='pad')

    def get_vacant_probability_threshold(self):
        return self._vacant_probability_threshold

    def get_buffer_probability_threshold(self):
        return self._buffer_probability_threshold
