from abc import ABCMeta

from ..building.abstract_object_builder import AbstractObjectBuilder
from ..environment import TimeSlicer
from ..states import StateSpace


class AbstractModelBuilder(AbstractObjectBuilder):
    __metaclass__ = ABCMeta

    def _get_builder_config_types(self):
        return dict(
            state_space=StateSpace
        )
