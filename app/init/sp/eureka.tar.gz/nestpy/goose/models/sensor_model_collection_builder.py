from .model_builders.sensor_model_builder import (
    SensorModelBuilder,
    OCCUPANCY_DIRICHLET_MULTINOMIAL_SENSOR_MODEL_BUILDER_CONFIG,
    OCCUPANCY_BOOLEAN_DIRICHLET_MULTINOMIAL_SENSOR_MODEL_BUILDER_CONFIG,
    OCCUPANCY_ABSENCE_MULTI_SENSOR_MODEL_BUILDER_CONFIG,
    OCCUPANCY_MULTI_SENSOR_MODEL_BUILDER_CONFIG,
    OCCUPANCY_COMBINED_SENSOR_MODEL_BUILDER_CONFIG,
    OCCUPANCY_BASELINE_SENSOR_MODEL_BUILDER_CONFIG
)
from .sensor_model_collection import SensorModelCollection
from ..building import AbstractObjectBuilder
from ..sensors import Sensor
from ..sensors.sensor_types.boolean_sensor_types import (
    DIAMOND_PIR_SENSOR_TYPE,
    DIAMOND_DIAL_TOUCH_SENSOR_TYPE,
    FLINTSTONE_PIR_SENSOR_TYPE,
    MOBILE_DEVICE_MDL_SENSOR_TYPE,
    PINNA_OPENCLOSE_SENSOR_TYPE,
    PINNA_PIR_SENSOR_TYPE,
    QUARTZ_MOTION_SENSOR_TYPE,
    QUARTZ_AUDIO_SENSOR_TYPE,
    TOPAZ_PIR_SENSOR_TYPE
)
from ...validation.type_validation import assert_list_of_type


OCCUPANCY_SENSOR_MODEL_COLLECTION_BUILDER_CONFIG = dict(
    object_cls=SensorModelCollection,
    sensor_model_builders=[
        (
            [
                DIAMOND_PIR_SENSOR_TYPE,
                DIAMOND_DIAL_TOUCH_SENSOR_TYPE,
                FLINTSTONE_PIR_SENSOR_TYPE,
                PINNA_OPENCLOSE_SENSOR_TYPE,
                PINNA_PIR_SENSOR_TYPE,
                QUARTZ_MOTION_SENSOR_TYPE,
                QUARTZ_AUDIO_SENSOR_TYPE,
                TOPAZ_PIR_SENSOR_TYPE
            ],
            SensorModelBuilder(**OCCUPANCY_DIRICHLET_MULTINOMIAL_SENSOR_MODEL_BUILDER_CONFIG)
        )
    ]
)

OCCUPANCY_MULTI_SENSOR_MODEL_COLLECTION_BUILDER_CONFIG = dict(
    object_cls=SensorModelCollection,
    sensor_model_builders=[
        (
            [
                DIAMOND_PIR_SENSOR_TYPE,
                DIAMOND_DIAL_TOUCH_SENSOR_TYPE,
                TOPAZ_PIR_SENSOR_TYPE
            ],
            SensorModelBuilder(**OCCUPANCY_MULTI_SENSOR_MODEL_BUILDER_CONFIG)
        )
    ]
)

OCCUPANCY_MULTI_FAST_EXIT_SENSOR_MODEL_COLLECTION_BUILDER_CONFIG = dict(
    object_cls=SensorModelCollection,
    sensor_model_builders=[
        (
            [
                DIAMOND_PIR_SENSOR_TYPE,
                DIAMOND_DIAL_TOUCH_SENSOR_TYPE,
                TOPAZ_PIR_SENSOR_TYPE
            ],
            SensorModelBuilder(**OCCUPANCY_MULTI_SENSOR_MODEL_BUILDER_CONFIG)
        ),
        (
            [
                MOBILE_DEVICE_MDL_SENSOR_TYPE
            ],
            SensorModelBuilder(**OCCUPANCY_ABSENCE_MULTI_SENSOR_MODEL_BUILDER_CONFIG)
        )
    ]
)

OCCUPANCY_COMBINED_SENSOR_MODEL_COLLECTION_BUILDER_CONFIG = dict(
    object_cls=SensorModelCollection,
    sensor_model_builders=[
        (
            [
                DIAMOND_PIR_SENSOR_TYPE,
                DIAMOND_DIAL_TOUCH_SENSOR_TYPE,
                TOPAZ_PIR_SENSOR_TYPE
            ],
            SensorModelBuilder(**OCCUPANCY_COMBINED_SENSOR_MODEL_BUILDER_CONFIG)
        )
    ]
)

OCCUPANCY_BASELINE_SENSOR_MODEL_COLLECTION_BUILDER_CONFIG = dict(
    object_cls=SensorModelCollection,
    sensor_model_builders=[
        (
            [
                DIAMOND_PIR_SENSOR_TYPE,
                DIAMOND_DIAL_TOUCH_SENSOR_TYPE,
                TOPAZ_PIR_SENSOR_TYPE
            ],
            SensorModelBuilder(**OCCUPANCY_BASELINE_SENSOR_MODEL_BUILDER_CONFIG)
        )
    ]
)

OCCUPANCY_ALL_SENSOR_MODEL_COLLECTION_BUILDER_CONFIG = dict(
    object_cls=SensorModelCollection,
    sensor_model_builders=[
        (
            [
                DIAMOND_PIR_SENSOR_TYPE,
                DIAMOND_DIAL_TOUCH_SENSOR_TYPE,
                FLINTSTONE_PIR_SENSOR_TYPE,
                PINNA_OPENCLOSE_SENSOR_TYPE,
                PINNA_PIR_SENSOR_TYPE,
                QUARTZ_MOTION_SENSOR_TYPE,
                QUARTZ_AUDIO_SENSOR_TYPE,
                TOPAZ_PIR_SENSOR_TYPE
            ],
            SensorModelBuilder(**OCCUPANCY_DIRICHLET_MULTINOMIAL_SENSOR_MODEL_BUILDER_CONFIG)
        ),
        (
            [
                DIAMOND_PIR_SENSOR_TYPE,
                DIAMOND_DIAL_TOUCH_SENSOR_TYPE,
                FLINTSTONE_PIR_SENSOR_TYPE,
                PINNA_OPENCLOSE_SENSOR_TYPE,
                PINNA_PIR_SENSOR_TYPE,
                QUARTZ_MOTION_SENSOR_TYPE,
                QUARTZ_AUDIO_SENSOR_TYPE,
                TOPAZ_PIR_SENSOR_TYPE
            ],
            SensorModelBuilder(**OCCUPANCY_BOOLEAN_DIRICHLET_MULTINOMIAL_SENSOR_MODEL_BUILDER_CONFIG)
        ),
        (
            [
                DIAMOND_PIR_SENSOR_TYPE,
                DIAMOND_DIAL_TOUCH_SENSOR_TYPE,
                TOPAZ_PIR_SENSOR_TYPE
            ],
            SensorModelBuilder(**OCCUPANCY_MULTI_SENSOR_MODEL_BUILDER_CONFIG)
        ),
        (
            [
                DIAMOND_PIR_SENSOR_TYPE,
                DIAMOND_DIAL_TOUCH_SENSOR_TYPE,
                TOPAZ_PIR_SENSOR_TYPE
            ],
            SensorModelBuilder(**OCCUPANCY_COMBINED_SENSOR_MODEL_BUILDER_CONFIG)
        )
    ]
)


class SensorModelCollectionBuilder(AbstractObjectBuilder):

    def _get_object_base_cls(self):
        return SensorModelCollection

    def _get_builder_config_types(self):
        return dict(sensor_model_builders=list)

    def build(self, sensors):
        assert_list_of_type(sensors, Sensor)
        sensor_model_builders = self._builder_config.get('sensor_model_builders')
        sensor_models = []
        for sensor_types, sensor_model_builder in sensor_model_builders:
            sensor_model = sensor_model_builder.build(
                sensors=filter(lambda _sensor: _sensor.get_sensor_type() in sensor_types, sensors)
            )
            sensor_models.append(sensor_model)
        return self._object_cls(sensor_models=sensor_models)
