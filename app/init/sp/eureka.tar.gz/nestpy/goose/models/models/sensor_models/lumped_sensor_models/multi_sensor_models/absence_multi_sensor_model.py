from ..multi_sensor_model import MultiSensorModel
from ......sensors.sensor_types.boolean_sensor_types import ActivitySensorType, PresenceSensorType


class AbsenceMultiSensorModel(MultiSensorModel):
    """This MultiSensorModel leverages absence information from our presence sensors.

    The AbsenceMultiSensorModel has to be instantiated with a set of presence sensors. In real time this model is only
    evaluated right after all presence sensors are disabled, up until the point where one or more sensors are enabled.
    """

    _SENSOR_TYPE_CLS = PresenceSensorType

    @staticmethod
    def _filter_sensor_states(sensor_states, sensor_type_cls, timestamp):
        return filter(
            lambda sensor_state: (
                isinstance(sensor_state.get_sensor().get_sensor_type(), sensor_type_cls) and
                sensor_state.is_online(timestamp)
            ),
            sensor_states
        )

    @classmethod
    def _get_most_recent_activity_timestamp(cls, sensor_state_collection, current_timestamp):
        activity_sensor_states = cls._filter_sensor_states(
            sensor_states=sensor_state_collection.get_sensor_states(),
            sensor_type_cls=ActivitySensorType,
            timestamp=current_timestamp
        )
        most_recent_activity_timestamps = sum(
            [
                map(
                    lambda sensor_state: current_timestamp,
                    filter(lambda sensor_state: sensor_state.is_enabled(), activity_sensor_states)
                ),
                map(
                    lambda sensor_state: sensor_state.get_transition_disabled_timestamp(),
                    filter(lambda sensor_state: sensor_state.is_disabled(), activity_sensor_states)
                )
            ],
            []
        )
        if most_recent_activity_timestamps:
            most_recent_activity_timestamp = max(most_recent_activity_timestamps)
        else:
            most_recent_activity_timestamp = None
        return most_recent_activity_timestamp

    def _get_most_recent_absence_timestamp(self, sensor_state_collection, current_timestamp):
        presence_sensor_states = self._filter_sensor_states(
            sensor_states=sensor_state_collection.get_sensor_states_for_sensors(self._sensors),
            sensor_type_cls=PresenceSensorType,
            timestamp=current_timestamp
        )
        if presence_sensor_states and all(map(lambda sensor_state: sensor_state.is_disabled(), presence_sensor_states)):
            most_recent_absence_timestamp = max(
                map(
                    lambda sensor_state: sensor_state.get_transition_disabled_timestamp(),
                    presence_sensor_states
                )
            )
        else:
            most_recent_absence_timestamp = None
        return most_recent_absence_timestamp

    def _compute_lumped_feature_series(
            self,
            sensor_state_collection,
            previous_update_timestamp,
            current_update_timestamp
    ):
        lumped_feature_series = super(AbsenceMultiSensorModel, self)._compute_lumped_feature_series(
            sensor_state_collection=sensor_state_collection,
            previous_update_timestamp=previous_update_timestamp,
            current_update_timestamp=current_update_timestamp
        )
        most_recent_absence_timestamp = self._get_most_recent_absence_timestamp(
            sensor_state_collection=sensor_state_collection,
            current_timestamp=current_update_timestamp
        )
        if most_recent_absence_timestamp:
            most_recent_activity_timestamp = self._get_most_recent_activity_timestamp(
                sensor_state_collection=sensor_state_collection,
                current_timestamp=current_update_timestamp
            )
            if not most_recent_activity_timestamp or most_recent_absence_timestamp > most_recent_activity_timestamp:
                return lumped_feature_series[lumped_feature_series.index > most_recent_absence_timestamp]
        return lumped_feature_series[slice(0)]
