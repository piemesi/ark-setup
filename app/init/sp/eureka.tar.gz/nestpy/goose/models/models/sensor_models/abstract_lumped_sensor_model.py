import pandas as pd

from abc import ABCMeta, abstractmethod

from ..abstract_sensor_model import AbstractSensorModel
from ....environment.frozen_dict import FrozenDict
from ....sensors.sensor_types.abstract_boolean_sensor_type import AbstractBooleanSensorType
from .....validation.type_validation import assert_list_of_type, assert_is_subclass


class AbstractLumpedSensorModel(AbstractSensorModel):
    """Core abstraction of the lumped sensor model classes.

    Lumped sensor models make the assumption that the underlying sensors may be lumped into one sensor. Implementation
    classes are responsible for implementing methods that return the probability distributions for a list of sensors.
    """
    __metaclass__ = ABCMeta

    _SENSOR_TYPE_CLS = AbstractBooleanSensorType

    def __init__(self, sensor_type_cls, *args, **kwargs):
        super(AbstractLumpedSensorModel, self).__init__(*args, **kwargs)
        assert_is_subclass(sensor_type_cls, self._SENSOR_TYPE_CLS)
        assert_list_of_type(map(lambda sensor: sensor.get_sensor_type(), self._sensors), sensor_type_cls)
        self._sensor_type_cls = sensor_type_cls
        self._sensor_update_cache = {}
        self._probability_distribution_cache = {}

    @property
    def _keys(self):
        return super(AbstractLumpedSensorModel, self)._keys + (self._sensor_type_cls, )

    @abstractmethod
    def get_local_probability_distribution(self, sensors, time_slice_index):
        """Method that returns the local probability distribution for a list of sensors and time slice.

        Args:
            sensors (list of Sensor): list of sensors for which to get the local probability distribution
            time_slice_index (int): time slice index

        Returns:
            pandas.DataFrame: local probability distributions across each of the states in the state space
        """
        raise NotImplementedError

    @abstractmethod
    def get_global_probability_distribution(self, sensors, time_slice_index):
        """Method that returns the global probability distribution for a list of sensors and time slice.

        Args:
            sensors (list of Sensor): list of sensors for which to get the global probability distribution
            time_slice_index (int): time slice index

        Returns:
            pandas.DataFrame: global probability distributions across each of the states in the state space
        """
        raise NotImplementedError

    @abstractmethod
    def get_combined_probability_distribution(self, sensors, time_slice_index):
        """Method that returns the combined probability distribution for a list of sensors and time slice.

        Args:
            sensors (list of Sensor): list of sensors for which to get the combined probability distribution
            time_slice_index (int): time slice index

        Returns:
            pandas.DataFrame: combined probability distributions across each of the states in the state space
        """
        raise NotImplementedError

    def get_probability_distribution(self, sensors, time_slice_index):
        probability_distribution = self._probability_distribution_cache.get((frozenset(sensors), time_slice_index))
        if probability_distribution is None:
            if self._sensor_model_prior is not None:
                probability_distribution = self.get_combined_probability_distribution(sensors, time_slice_index)
            else:
                probability_distribution = self.get_local_probability_distribution(sensors, time_slice_index)
            self._probability_distribution_cache[(frozenset(sensors), time_slice_index)] = probability_distribution
        return probability_distribution

    def _get_sensors_by_sensor_type_cls(self, sensors):
        return {
            sensor_type_cls: filter(lambda sensor: isinstance(sensor.get_sensor_type(), sensor_type_cls), sensors)
            for sensor_type_cls in [self._sensor_type_cls]
        }

    @staticmethod
    def _compute_frozen_dict_series(frame):
        frozen_dict_series = pd.Series(
            index=frame.index,
            data=map(lambda (_, series): FrozenDict(series.dropna().to_dict()), frame.iterrows())
        )
        return frozen_dict_series

    def _compute_lumped_feature_series(
            self,
            sensor_state_collection,
            previous_update_timestamp,
            current_update_timestamp
    ):
        feature_frame = pd.DataFrame(
            {
                sensor_type_cls.__name__: self._featurizer.featurize_sensor_states(
                    sensor_states=sensor_state_collection.get_sensor_states_for_sensors(sensors),
                    previous_update_timestamp=previous_update_timestamp,
                    current_update_timestamp=current_update_timestamp
                )
                for sensor_type_cls, sensors in self._get_sensors_by_sensor_type_cls(self._sensors).items()
            }
        )
        feature_series = self._compute_frozen_dict_series(feature_frame)
        return feature_series

    def compute_sensor_updates(self, sensor_state_collection, previous_update_timestamp, current_update_timestamp):
        feature_series = self._compute_lumped_feature_series(
            sensor_state_collection=sensor_state_collection,
            previous_update_timestamp=previous_update_timestamp,
            current_update_timestamp=current_update_timestamp
        )
        sensors = map(
            lambda sensor_state: sensor_state.get_sensor(),
            filter(
                lambda sensor_state:
                sensor_state.is_online(previous_update_timestamp) and sensor_state.get_sensor() in self._sensors,
                sensor_state_collection.get_sensor_states()
            )
        )
        sensor_updates = []
        for timestamp, observation in feature_series.iteritems():
            time_slice_index = self._time_slicer.get_time_slice_index(timestamp)
            probability_distribution = self.get_probability_distribution(sensors, time_slice_index)
            if observation in probability_distribution.index:
                try:
                    probabilities = probability_distribution.loc[observation]
                except KeyError:
                    probabilities = dict(probability_distribution.iterrows())[observation]
            else:
                probabilities = pd.Series(index=self._state_space.get_state_labels(), data=0.)
            self._sensor_update_cache[(timestamp, observation)] = probabilities.to_dict()
            sensor_updates.append((timestamp, probabilities))
        return sensor_updates

    def get_sensor_type_cls(self):
        return self._sensor_type_cls

    def get_sensor_update_cache(self):
        sensor_update_cache = pd.DataFrame.from_dict(self._sensor_update_cache, orient="index")
        sensor_update_cache.sort_index(axis=1, inplace=True)
        return (sensor_update_cache.T / sensor_update_cache.sum(axis=1).values).T
