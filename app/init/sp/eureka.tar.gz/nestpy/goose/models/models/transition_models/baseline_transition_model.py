from ..abstract_transition_model import AbstractTransitionModel


class BaselineTransitionModel(AbstractTransitionModel):

    def train(self, state_series):
        pass

    def compute_transition_updates(self, previous_update_timestamp, current_update_timestamp):
        return []

    def get_parameters(self):
        return {}
