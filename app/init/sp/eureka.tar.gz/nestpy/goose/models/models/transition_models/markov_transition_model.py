import datetime
import pandas as pd

from ..transition_model_priors import MarkovTransitionModelPrior
from ..abstract_transition_model import AbstractTransitionModel
from .....generators.datetime_generators import rounded_datetime_range_generator
from .....manipulators.datetime_manipulators import ceil_datetime
from .....manipulators.series_manipulators import zero_order_hold_resample
from .....validation.type_validation import assert_is_type


class MarkovTransitionModel(AbstractTransitionModel):

    _TRANSITION_MODEL_PRIOR_CLS = MarkovTransitionModelPrior

    _OLD_STATE = "old_state"
    _NEW_STATE = "new_state"
    _SAME_DATE = "same_date"

    _TRANSITION_COUNT_MATRICES = "transition_count_matrices"

    def __init__(self, sample_time, *args, **kwargs):
        super(MarkovTransitionModel, self).__init__(*args, **kwargs)
        assert_is_type(sample_time, datetime.timedelta)
        self._sample_time = sample_time
        if self._transition_model_prior is not None:
            self._assert_attributes_equal(
                self._transition_model_prior,
                ["_time_slicer", "_state_space", "_sample_time"]
            )
        self._transition_count_matrices = self._initialize_transition_count_matrices()

    @property
    def _keys(self):
        return super(MarkovTransitionModel, self)._keys + (self._sample_time, )

    def _initialize_transition_count_matrices(self):
        transition_count_matrices = [
            pd.DataFrame(
                index=self._state_space.get_state_labels(),
                columns=self._state_space.get_state_labels(),
                data=0
            )
            for _ in self._time_slicer.get_time_slice_indices()
        ]
        return transition_count_matrices

    def _compute_transition_count_matrix(self, state_series):
        state_transition_counts = []
        date_series = pd.Series(index=state_series.index, data=state_series.index.date)
        transition_state_frame = pd.DataFrame(
            {
                self._OLD_STATE: state_series.shift(1),
                self._NEW_STATE: state_series,
                self._SAME_DATE: date_series.shift(1) == date_series
            }
        )
        for state_label in self._state_space.get_state_labels():
            transitioned_states = transition_state_frame.loc[
                (transition_state_frame[self._OLD_STATE] == state_label) & transition_state_frame[self._SAME_DATE],
                self._NEW_STATE
            ]
            state_transition_counts.append((state_label, transitioned_states.value_counts().sort_index()))
        transition_count_matrix = pd.DataFrame.from_items(state_transition_counts).fillna(value=0).astype('int').T
        return transition_count_matrix

    def train(self, state_series):
        self._assert_attributes_equal(state_series, ["_state_space"])
        sampled_state_series = zero_order_hold_resample(state_series.get_series(), self._sample_time)
        for time_slice_index in self._time_slicer.get_time_slice_indices():
            time_sliced_state_series = self._time_slicer.get_time_sliced_series(
                series=sampled_state_series,
                time_slice_index=time_slice_index
            )
            transition_count_matrix = self._compute_transition_count_matrix(time_sliced_state_series)
            self._transition_count_matrices[time_slice_index] = (
                self._transition_count_matrices[time_slice_index]
                .add(transition_count_matrix, fill_value=0)
                .astype('int')
            )

    @staticmethod
    def _compute_transition_probability_matrix(transition_count_matrix):
        transition_count_matrix = transition_count_matrix.copy()
        transition_count_matrix.loc[transition_count_matrix.sum(1) == 0] = 1
        return (transition_count_matrix.T / transition_count_matrix.sum(1)).T

    def get_local_transition_probability_matrix(self, time_slice_index):
        transition_probability_matrix = self._compute_transition_probability_matrix(
            self._transition_count_matrices[time_slice_index]
        )
        return transition_probability_matrix

    def get_global_transition_probability_matrix(self, time_slice_index):
        self._assert_has_transition_model_prior()
        transition_probability_matrix = self._compute_transition_probability_matrix(
            self._transition_model_prior.get_transition_count_matrix(time_slice_index)
        )
        return transition_probability_matrix

    def get_combined_transition_probability_matrix(self, time_slice_index):
        self._assert_has_transition_model_prior()
        observation_counts = self._transition_count_matrices[time_slice_index].sum(axis=1)
        prior_weights = observation_counts.apply(self._transition_model_prior.get_prior_weight_func())
        transition_probability_matrix = (
            (prior_weights * self.get_global_transition_probability_matrix(time_slice_index).T).T +
            ((1 - prior_weights) * self.get_local_transition_probability_matrix(time_slice_index).T).T
        )
        return transition_probability_matrix

    def get_transition_probability_matrix(self, time_slice_index):
        if self._transition_model_prior is not None:
            transition_probability_matrix = self.get_combined_transition_probability_matrix(time_slice_index)
        else:
            transition_probability_matrix = self.get_local_transition_probability_matrix(time_slice_index)
        return transition_probability_matrix

    def compute_transition_updates(self, previous_update_timestamp, current_update_timestamp):
        ceil_previous_update_timestamp = ceil_datetime(previous_update_timestamp, self._sample_time)
        ceil_current_update_timestamp = ceil_datetime(current_update_timestamp, self._sample_time)
        timestamps = rounded_datetime_range_generator(
            start_datetime=ceil_previous_update_timestamp,
            end_datetime=ceil_current_update_timestamp,
            interval=self._sample_time,
            closed_left=False,
            closed_right=True
        )
        transition_updates = []
        for timestamp in timestamps:
            time_slice_index = self._time_slicer.get_time_slice_index(timestamp)
            transition_probability_matrix = self.get_transition_probability_matrix(time_slice_index)
            transition_updates.append((timestamp, transition_probability_matrix))
        return transition_updates

    def get_parameters(self):
        return {self._TRANSITION_COUNT_MATRICES: self._transition_count_matrices}

    def get_transition_count_matrix(self, time_slice_index):
        return self._transition_count_matrices[time_slice_index]

    def get_sample_time(self):
        return self._sample_time
