import datetime
import itertools
import pandas as pd

from ..abstract_sensor_model_prior import AbstractSensorModelPrior
from ....environment import FrozenList
from ....features.featurizers import SampledBooleanFeaturizer, BooleanGapFeaturizer
from ....sensors.sensor_types.abstract_boolean_sensor_type import AbstractBooleanSensorType
from .....validation.type_validation import assert_is_type, assert_is_subclass, assert_list_of_type


class CombinedSensorModelPrior(AbstractSensorModelPrior):

    _FEATURIZER_CLS = (SampledBooleanFeaturizer, BooleanGapFeaturizer)

    _LEFT = 'left'
    _RIGHT = 'right'
    _OVERLAP = 'overlap'

    _PRIOR_OVERLAP_COUNTS = "prior_overlap_counts"

    def __init__(self, sensor_type_cls, overlap_timedelta, *args, **kwargs):
        super(CombinedSensorModelPrior, self).__init__(*args, **kwargs)
        assert_is_subclass(sensor_type_cls, AbstractBooleanSensorType)
        assert_list_of_type(self._sensor_types, sensor_type_cls)
        assert_is_type(overlap_timedelta, datetime.timedelta)
        self._sensor_type_cls = sensor_type_cls
        self._overlap_timedelta = overlap_timedelta
        self._prior_overlap_counts = self._initialize_prior_overlap_counts()

    @property
    def _keys(self):
        return super(CombinedSensorModelPrior, self)._keys + (self._sensor_type_cls, self._overlap_timedelta)

    @staticmethod
    def _compute_combined_sets(items):
        combined_sets = map(FrozenList, itertools.combinations_with_replacement(items, 2))
        return combined_sets

    def _initialize_prior_overlap_counts(self):
        overlap_counts = pd.DataFrame(
            index=self._compute_combined_sets(self._sensor_types),
            columns=[self._LEFT, self._RIGHT, self._OVERLAP],
            data=0
        )
        return overlap_counts

    @classmethod
    def _compute_prior_overlap_counts(cls, overlap_counts):
        def map_overlap_counts(combined_sensor_set, sensor_counts):
            sensor_type_counts = sensor_counts[[cls._LEFT, cls._RIGHT, cls._OVERLAP]]
            combined_sensor_types = map(lambda sensor: sensor.get_sensor_type(), sorted(combined_sensor_set, key=hash))
            if len(set(combined_sensor_types)) == len(combined_sensor_types):
                index = map(combined_sensor_types.index, sorted(combined_sensor_types, key=hash))
                sensor_type_counts.iloc[[0, 1]] = sensor_type_counts.iloc[index].values
            return FrozenList(combined_sensor_types), sensor_type_counts
        prior_overlap_counts = pd.DataFrame.from_items(
            items=map(
                lambda (combined_sensor_set, counts): map_overlap_counts(combined_sensor_set, counts),
                overlap_counts.iterrows()
            ),
            columns=[cls._LEFT, cls._RIGHT, cls._OVERLAP],
            orient="index"
        )
        return prior_overlap_counts.groupby(level=0).sum()

    def incorporate_sensor_models(self, sensor_models):
        for sensor_model in sensor_models:
            self._assert_attributes_equal(
                sensor_model,
                ["_time_slicer", "_state_space", "_featurizer", "_sensor_type_cls", "_overlap_timedelta"]
            )
            overlap_counts = sensor_model.get_overlap_counts()
            prior_overlap_counts = self._compute_prior_overlap_counts(overlap_counts)
            self._prior_overlap_counts = (
                self._prior_overlap_counts.add(prior_overlap_counts, fill_value=0).astype('int').groupby(level=0).sum()
            )

    def get_parameters(self):
        parameters = {self._PRIOR_OVERLAP_COUNTS: self._prior_overlap_counts}
        return parameters

    def get_prior_overlap_counts(self):
        return self._prior_overlap_counts
