import datetime
import pandas as pd

from ..abstract_estimated_truth_model import AbstractEstimatedTruthModel
from ....states.state_spaces import GOOSEStateSpace
from .....generators.datetime_generators import rounded_datetime_range_generator
from .....manipulators.datetime_manipulators import ceil_datetime, floor_datetime
from .....manipulators.frame_manipulators import filter_valid_range as frame_filter_valid_range
from .....manipulators.series_manipulators import (
    compute_timedelta_series,
    drop_consecutive_duplicates,
    filter_valid_range as series_filter_valid_range
)
from .....validation.type_validation import assert_list_of_type


class LookAheadEstimatedTruthModel(AbstractEstimatedTruthModel):

    _STATE_SPACE_CLS = GOOSEStateSpace

    _ABSENCE_WITHOUT_ACTIVITY = "absence_without_activity"
    _ACTIVITY_BASED_ESTIMATED_TRUTH_SERIES = "activity_based_estimated_truth_series"
    _ANY_ACTIVITY_SERIES = "any_activity_series"
    _ANY_PRESENCE_SERIES = "any_presence_series"
    _ANY_PRESENCE_INDEX = "any_presence_index"
    _PRESENCE_TRANSITION_ACTIVITY_SERIES = "presence_transition_activity_series"
    _TIMEDELTA_SERIES = "timedelta_series"
    _TRUNCATED_PRESENCE_SERIES = "truncated_presence_series"
    _SLEEP_SERIES = "sleep_series"

    _DAY_TIMEDELTA = datetime.timedelta(days=1)

    def __init__(
            self,
            weekday_bed_time,
            weekday_early_bed_time,
            weekday_wake_up_time,
            weekday_early_wake_up_time,
            weekday_late_wake_up_time,
            weekend_bed_time,
            weekend_early_bed_time,
            weekend_wake_up_time,
            weekend_early_wake_up_time,
            weekend_late_wake_up_time,
            minimum_activity_duration,
            minimum_sleep_activity_duration,
            inactivity_window,
            sleep_inactivity_window,
            weekday_overnight_presence_indicator_time,
            weekend_overnight_presence_indicator_time,
            *args,
            **kwargs
    ):
        super(LookAheadEstimatedTruthModel, self).__init__(*args, **kwargs)
        assert_list_of_type(
            [
                weekday_bed_time,
                weekday_early_bed_time,
                weekday_wake_up_time,
                weekday_early_wake_up_time,
                weekday_late_wake_up_time,
                weekend_bed_time,
                weekend_early_bed_time,
                weekend_wake_up_time,
                weekend_early_wake_up_time,
                weekend_late_wake_up_time,
                weekday_overnight_presence_indicator_time,
                weekend_overnight_presence_indicator_time
            ],
            datetime.time
        )
        assert_list_of_type(
            [
                minimum_activity_duration,
                minimum_sleep_activity_duration,
                inactivity_window,
                sleep_inactivity_window
            ],
            datetime.timedelta
        )
        assert inactivity_window > minimum_activity_duration
        assert sleep_inactivity_window > minimum_sleep_activity_duration
        self._weekday_bed_time = weekday_bed_time
        self._weekday_early_bed_time = weekday_early_bed_time
        self._weekday_wake_up_time = weekday_wake_up_time
        self._weekday_early_wake_up_time = weekday_early_wake_up_time
        self._weekday_late_wake_up_time = weekday_late_wake_up_time
        self._weekend_bed_time = weekend_bed_time
        self._weekend_early_bed_time = weekend_early_bed_time
        self._weekend_wake_up_time = weekend_wake_up_time
        self._weekend_early_wake_up_time = weekend_early_wake_up_time
        self._weekend_late_wake_up_time = weekend_late_wake_up_time
        self._minimum_activity_duration = minimum_activity_duration
        self._minimum_sleep_activity_duration = minimum_sleep_activity_duration
        self._inactivity_window = inactivity_window
        self._sleep_inactivity_window = sleep_inactivity_window
        self._weekday_overnight_presence_indicator_time = weekday_overnight_presence_indicator_time
        self._weekend_overnight_presence_indicator_time = weekend_overnight_presence_indicator_time

    @staticmethod
    def _time_to_timedelta(time):
        return datetime.timedelta(
            hours=time.hour,
            minutes=time.minute,
            seconds=time.second,
            microseconds=time.microsecond
        )

    @staticmethod
    def _allowed_to_fall_asleep_on_persistent_day(timestamp, bed_time, wake_up_time):
        if wake_up_time < bed_time:
            return not (wake_up_time <= timestamp.time() < bed_time)
        else:
            return bed_time <= timestamp.time() < wake_up_time

    @staticmethod
    def _allowed_to_fall_asleep_on_transition_day(
            timestamp,
            bed_time_before_transition,
            wake_up_time_before_transition,
            bed_time_after_transition,
            wake_up_time_after_transition
    ):
        if wake_up_time_after_transition < bed_time_after_transition:
            if wake_up_time_before_transition < bed_time_before_transition:
                return not (wake_up_time_before_transition <= timestamp.time() < bed_time_after_transition)
            else:
                return (
                    bed_time_before_transition <= timestamp.time() < wake_up_time_before_transition or
                    bed_time_after_transition <= timestamp.time()
                )
        else:
            if wake_up_time_before_transition < bed_time_before_transition:
                return not (wake_up_time_before_transition <= timestamp.time())
            else:
                return bed_time_before_transition <= timestamp.time() < wake_up_time_before_transition

    @classmethod
    def _allowed_to_fall_asleep(
            cls,
            timestamp,
            weekday_bed_time,
            weekday_wake_up_time,
            weekend_bed_time,
            weekend_wake_up_time
    ):
        if timestamp.weekday() in range(4):
            return cls._allowed_to_fall_asleep_on_persistent_day(
                timestamp=timestamp,
                bed_time=weekday_bed_time,
                wake_up_time=weekday_wake_up_time
            )
        elif timestamp.weekday() == 4:
            return cls._allowed_to_fall_asleep_on_transition_day(
                timestamp=timestamp,
                bed_time_before_transition=weekday_bed_time,
                wake_up_time_before_transition=weekday_wake_up_time,
                bed_time_after_transition=weekend_bed_time,
                wake_up_time_after_transition=weekend_wake_up_time
            )
        elif timestamp.weekday() == 5:
            return cls._allowed_to_fall_asleep_on_persistent_day(
                timestamp=timestamp,
                bed_time=weekend_bed_time,
                wake_up_time=weekend_wake_up_time
            )
        elif timestamp.weekday() == 6:
            return cls._allowed_to_fall_asleep_on_transition_day(
                timestamp=timestamp,
                bed_time_before_transition=weekend_bed_time,
                wake_up_time_before_transition=weekend_wake_up_time,
                bed_time_after_transition=weekday_bed_time,
                wake_up_time_after_transition=weekday_wake_up_time
            )

    def allowed_to_fall_asleep(self, timestamp):
        return self._allowed_to_fall_asleep(
            timestamp=timestamp,
            weekday_bed_time=self._weekday_early_bed_time,
            weekday_wake_up_time=self._weekday_early_wake_up_time,
            weekend_bed_time=self._weekend_early_bed_time,
            weekend_wake_up_time=self._weekend_early_wake_up_time
        )

    def overnight_presence_indicated(self, timestamp):
        return self._allowed_to_fall_asleep(
            timestamp=timestamp,
            weekday_bed_time=self._weekday_overnight_presence_indicator_time,
            weekday_wake_up_time=self._weekday_early_wake_up_time,
            weekend_bed_time=self._weekend_overnight_presence_indicator_time,
            weekend_wake_up_time=self._weekend_early_wake_up_time
        )

    @classmethod
    def _time_until_next_wake_up_on_persistent_day(cls, timestamp, wake_up_time):
        if timestamp.time() > wake_up_time:
            return cls._DAY_TIMEDELTA - cls._time_to_timedelta(timestamp.time()) + cls._time_to_timedelta(wake_up_time)
        else:
            return cls._time_to_timedelta(wake_up_time) - cls._time_to_timedelta(timestamp.time())

    @classmethod
    def _time_until_next_wake_up_on_transition_day(
            cls,
            timestamp,
            wake_up_time_before_transition,
            wake_up_time_after_transition
    ):
        if timestamp.time() > wake_up_time_before_transition:
            return (
                cls._DAY_TIMEDELTA -
                cls._time_to_timedelta(timestamp.time()) +
                cls._time_to_timedelta(wake_up_time_after_transition)
            )
        else:
            return cls._time_to_timedelta(wake_up_time_before_transition) - cls._time_to_timedelta(timestamp.time())

    @classmethod
    def _time_until_next_wake_up(cls, timestamp, weekday_wake_up_time, weekend_wake_up_time):
        if timestamp.weekday() in range(4):
            return cls._time_until_next_wake_up_on_persistent_day(
                timestamp=timestamp,
                wake_up_time=weekday_wake_up_time
            )
        elif timestamp.weekday() == 4:
            return cls._time_until_next_wake_up_on_transition_day(
                timestamp=timestamp,
                wake_up_time_before_transition=weekday_wake_up_time,
                wake_up_time_after_transition=weekend_wake_up_time
            )
        elif timestamp.weekday() == 5:
            return cls._time_until_next_wake_up_on_persistent_day(
                timestamp=timestamp,
                wake_up_time=weekend_wake_up_time
            )
        elif timestamp.weekday() == 6:
            return cls._time_until_next_wake_up_on_transition_day(
                timestamp=timestamp,
                wake_up_time_before_transition=weekend_wake_up_time,
                wake_up_time_after_transition=weekday_wake_up_time
            )

    def time_until_next_late_wake_up(self, timestamp):
        return self._time_until_next_wake_up(
            timestamp=timestamp,
            weekday_wake_up_time=self._weekday_late_wake_up_time,
            weekend_wake_up_time=self._weekend_late_wake_up_time
        )

    @classmethod
    def _time_until_next_sleep_on_persistent_day(cls, timestamp, bed_time):
        if timestamp.time() > bed_time:
            return cls._DAY_TIMEDELTA - cls._time_to_timedelta(timestamp.time()) + cls._time_to_timedelta(bed_time)
        else:
            return cls._time_to_timedelta(bed_time) - cls._time_to_timedelta(timestamp.time())

    @classmethod
    def _time_until_next_sleep_on_transition_day(
            cls,
            timestamp,
            bed_time_before_transition,
            bed_time_after_transition,
            wake_up_time_before_transition
    ):
        if wake_up_time_before_transition < bed_time_before_transition:
            if timestamp.time() < bed_time_after_transition:
                return cls._time_to_timedelta(bed_time_after_transition)
            else:
                return (
                    cls._DAY_TIMEDELTA -
                    cls._time_to_timedelta(timestamp.time()) +
                    cls._time_to_timedelta(bed_time_after_transition)
                )
        else:
            if timestamp.time() < bed_time_before_transition:
                return cls._time_to_timedelta(bed_time_before_transition) - cls._time_to_timedelta(timestamp.time())
            else:
                if timestamp.time() < bed_time_after_transition:
                    return cls._time_to_timedelta(bed_time_after_transition) - cls._time_to_timedelta(timestamp.time())
                else:
                    return (
                        cls._DAY_TIMEDELTA -
                        cls._time_to_timedelta(timestamp.time()) +
                        cls._time_to_timedelta(bed_time_after_transition)
                    )

    @classmethod
    def _time_until_next_sleep(
            cls,
            timestamp,
            weekday_bed_time,
            weekend_bed_time,
            weekday_wake_up_time,
            weekend_wake_up_time
    ):
        if timestamp.weekday() in range(4):
            return cls._time_until_next_sleep_on_persistent_day(
                timestamp=timestamp,
                bed_time=weekday_bed_time
            )
        elif timestamp.weekday() == 4:
            return cls._time_until_next_sleep_on_transition_day(
                timestamp=timestamp,
                bed_time_before_transition=weekday_bed_time,
                bed_time_after_transition=weekend_bed_time,
                wake_up_time_before_transition=weekday_wake_up_time
            )
        elif timestamp.weekday() == 5:
            return cls._time_until_next_sleep_on_persistent_day(
                timestamp=timestamp,
                bed_time=weekend_bed_time
            )
        elif timestamp.weekday() == 6:
            return cls._time_until_next_sleep_on_transition_day(
                timestamp=timestamp,
                bed_time_before_transition=weekend_bed_time,
                bed_time_after_transition=weekday_bed_time,
                wake_up_time_before_transition=weekend_wake_up_time
            )

    def time_until_next_sleep(self, timestamp):
        return self._time_until_next_sleep(
            timestamp=timestamp,
            weekday_bed_time=self._weekday_bed_time,
            weekend_bed_time=self._weekend_bed_time,
            weekday_wake_up_time=self._weekday_wake_up_time,
            weekend_wake_up_time=self._weekend_wake_up_time
        )

    @classmethod
    def _compute_sleep_series_on_persistent_day(cls, timestamp, bed_time, wake_up_time):
        assert timestamp.time() == datetime.time.min
        sleep_series = pd.Series(
            {
                timestamp + cls._time_to_timedelta(bed_time): True,
                timestamp + cls._time_to_timedelta(wake_up_time): False
            }
        )
        return sleep_series.sort_index()

    @classmethod
    def _compute_sleep_series_on_transition_day(
            cls,
            timestamp,
            bed_time_before_transition,
            wake_up_time_before_transition,
            bed_time_after_transition,
            wake_up_time_after_transition
    ):
        sleep_dict = {timestamp + cls._time_to_timedelta(wake_up_time_before_transition): False}
        if wake_up_time_before_transition >= bed_time_before_transition:
            sleep_dict.update({timestamp + cls._time_to_timedelta(bed_time_before_transition): True})
        if bed_time_after_transition > wake_up_time_after_transition:
            sleep_dict.update({timestamp + cls._time_to_timedelta(bed_time_after_transition): True})
        return pd.Series(sleep_dict).sort_index()

    @classmethod
    def _compute_sleep_series(
            cls,
            start_timestamp,
            end_timestamp,
            weekday_bed_time,
            weekday_wake_up_time,
            weekend_bed_time,
            weekend_wake_up_time
    ):
        day_timestamps = list(
            rounded_datetime_range_generator(
                start_datetime=floor_datetime(start_timestamp, cls._DAY_TIMEDELTA),
                end_datetime=ceil_datetime(end_timestamp, cls._DAY_TIMEDELTA),
                interval=cls._DAY_TIMEDELTA,
                closed_left=True,
                closed_right=False
            )
        )
        sleep_list = []
        for day_timestamp in day_timestamps:
            day_timestamp = pd.Timestamp(day_timestamp.date(), tz=day_timestamp.tzinfo)
            if day_timestamp.weekday() in range(4):
                sleep_list.append(
                    cls._compute_sleep_series_on_persistent_day(
                        timestamp=day_timestamp,
                        bed_time=weekday_bed_time,
                        wake_up_time=weekday_wake_up_time
                    )
                )
            elif day_timestamp.weekday() == 4:
                sleep_list.append(
                    cls._compute_sleep_series_on_transition_day(
                        timestamp=day_timestamp,
                        bed_time_before_transition=weekday_bed_time,
                        wake_up_time_before_transition=weekday_wake_up_time,
                        bed_time_after_transition=weekend_bed_time,
                        wake_up_time_after_transition=weekend_wake_up_time
                    )
                )
            elif day_timestamp.weekday() == 5:
                sleep_list.append(
                    cls._compute_sleep_series_on_persistent_day(
                        timestamp=day_timestamp,
                        bed_time=weekend_bed_time,
                        wake_up_time=weekend_wake_up_time
                    )
                )
            elif day_timestamp.weekday() == 6:
                sleep_list.append(
                    cls._compute_sleep_series_on_transition_day(
                        timestamp=day_timestamp,
                        bed_time_before_transition=weekend_bed_time,
                        wake_up_time_before_transition=weekend_wake_up_time,
                        bed_time_after_transition=weekday_bed_time,
                        wake_up_time_after_transition=weekday_wake_up_time
                    )
                )
        sleep_series = pd.Series(pd.concat(sleep_list, axis=0))
        return sleep_series[(sleep_series.index >= start_timestamp) & (sleep_series.index < end_timestamp)]

    def compute_sleep_series(self, start_timestamp, end_timestamp):
        return self._compute_sleep_series(
            start_timestamp=start_timestamp,
            end_timestamp=end_timestamp,
            weekday_bed_time=self._weekday_bed_time,
            weekday_wake_up_time=self._weekday_wake_up_time,
            weekend_bed_time=self._weekend_bed_time,
            weekend_wake_up_time=self._weekend_wake_up_time
        )

    def _compute_presence_transition_activity(self, any_presence_series):
        def get_minimum_activity_duration(_timestamp):
            if self.allowed_to_fall_asleep(_timestamp):
                return self._minimum_sleep_activity_duration
            else:
                return self._minimum_activity_duration
        any_presence_series = pd.Series(drop_consecutive_duplicates(any_presence_series).astype("bool"))
        combined_frame = pd.DataFrame(
            {
                self._ANY_PRESENCE_SERIES: any_presence_series,
                self._TIMEDELTA_SERIES: compute_timedelta_series(any_presence_series.index)
            }
        )
        presence_transition_activity_dict = {}
        for timestamp, (presence, timedelta) in combined_frame.iterrows():
            if presence and timedelta:
                presence_transition_activity_dict.update({timestamp: True, timestamp + timedelta: False})
                presence_minimum_activity_duration, absence_minimum_activity_duration = map(
                    get_minimum_activity_duration,
                    [timestamp, timestamp + timedelta]
                )
                if timedelta > presence_minimum_activity_duration + absence_minimum_activity_duration:
                    presence_transition_activity_dict.update(
                        {
                            timestamp + presence_minimum_activity_duration: False,
                            timestamp + timedelta - absence_minimum_activity_duration: True
                        }
                    )
        return drop_consecutive_duplicates(pd.Series(presence_transition_activity_dict).sort_index(), keep_last=True)

    def _compute_absence_without_activity(self, any_activity_series, any_presence_series):
        any_presence_series = pd.Series(drop_consecutive_duplicates(any_presence_series).astype("bool"))
        combined_frame = pd.DataFrame(
            {
                self._ANY_ACTIVITY_SERIES: any_activity_series,
                self._ANY_PRESENCE_INDEX: pd.Series(index=any_presence_series.index, data=any_presence_series.index)
            }
        )
        combined_frame[self._ANY_PRESENCE_INDEX] = combined_frame[self._ANY_PRESENCE_INDEX].fillna(method="pad")
        combined_frame[self._ANY_ACTIVITY_SERIES] = combined_frame[self._ANY_ACTIVITY_SERIES].fillna(False)
        grouped_activity = combined_frame[self._ANY_ACTIVITY_SERIES].groupby(
            combined_frame[self._ANY_PRESENCE_INDEX].values
        )
        absence_without_activity = pd.Series(
            index=any_presence_series.index,
            data=(grouped_activity.sum() == 0) & ~any_presence_series
        )
        return absence_without_activity

    def _compute_activity_based_estimated_truth_series(self, any_activity_series):
        active_state_label = self._state_space.get_active_state().get_state_label()
        sleep_state_label = self._state_space.get_sleep_state().get_state_label()
        vacant_state_label = self._state_space.get_vacant_state().get_state_label()
        timedelta_series = compute_timedelta_series(any_activity_series.index)
        activity_based_estimated_truth_dict = {}
        for activity_timestamp, inactivity_window in timedelta_series.iteritems():
            activity_based_estimated_truth_dict.update({activity_timestamp: active_state_label})
            if self.allowed_to_fall_asleep(activity_timestamp):
                if inactivity_window > self.time_until_next_late_wake_up(activity_timestamp):
                    activity_based_estimated_truth_dict.update(
                        {activity_timestamp + self._minimum_activity_duration: vacant_state_label}
                    )
                elif inactivity_window > self._sleep_inactivity_window:
                    activity_based_estimated_truth_dict.update(
                        {activity_timestamp + self._minimum_sleep_activity_duration: sleep_state_label}
                    )
            elif self.overnight_presence_indicated(activity_timestamp):
                if inactivity_window > self.time_until_next_late_wake_up(activity_timestamp):
                    activity_based_estimated_truth_dict.update(
                        {activity_timestamp + self._minimum_activity_duration: vacant_state_label}
                    )
                elif inactivity_window > max(self._inactivity_window, self.time_until_next_sleep(activity_timestamp)):
                    activity_based_estimated_truth_dict.update(
                        {activity_timestamp + self.time_until_next_sleep(activity_timestamp): sleep_state_label}
                    )
            else:
                if inactivity_window > self._inactivity_window:
                    activity_based_estimated_truth_dict.update(
                        {activity_timestamp + self._minimum_activity_duration: vacant_state_label}
                    )
        return drop_consecutive_duplicates(pd.Series(activity_based_estimated_truth_dict).sort_index(), keep_last=True)

    def _compute_presence_based_estimated_truth_series(self, any_presence_series):
        active_state_label = self._state_space.get_active_state().get_state_label()
        sleep_state_label = self._state_space.get_sleep_state().get_state_label()
        unknown_state_label = self._state_space.get_unknown_state().get_state_label()
        vacant_state_label = self._state_space.get_vacant_state().get_state_label()
        combined_truth_frame = pd.DataFrame(
            {
                self._ANY_PRESENCE_SERIES: any_presence_series,
                self._TRUNCATED_PRESENCE_SERIES: any_presence_series.isnull(),
                self._PRESENCE_TRANSITION_ACTIVITY_SERIES: self._compute_presence_transition_activity(
                    any_presence_series=any_presence_series
                ),
                self._SLEEP_SERIES: self.compute_sleep_series(
                    start_timestamp=floor_datetime(
                        min(any_presence_series.index) - self._DAY_TIMEDELTA,
                        self._DAY_TIMEDELTA
                    ),
                    end_timestamp=ceil_datetime(
                        max(any_presence_series.index),
                        self._DAY_TIMEDELTA
                    )
                )
            }
        )
        for column in combined_truth_frame.columns:
            combined_truth_frame[column] = series_filter_valid_range(combined_truth_frame[column]).fillna(method="pad")
        combined_truth_frame = frame_filter_valid_range(combined_truth_frame, subset=[self._ANY_PRESENCE_SERIES])
        combined_truth_frame = combined_truth_frame.fillna(value=False).astype("bool")
        presence_based_estimated_truth_series = pd.Series(index=combined_truth_frame.index)
        # Label all presence during the daytime as active
        presence_based_estimated_truth_series[
            combined_truth_frame[self._ANY_PRESENCE_SERIES] &
            ~combined_truth_frame[self._TRUNCATED_PRESENCE_SERIES] &
            ~combined_truth_frame[self._SLEEP_SERIES]
        ] = active_state_label
        # Label all presence during the nighttime as sleep
        presence_based_estimated_truth_series[
            combined_truth_frame[self._ANY_PRESENCE_SERIES] &
            ~combined_truth_frame[self._TRUNCATED_PRESENCE_SERIES] &
            combined_truth_frame[self._SLEEP_SERIES]
        ] = sleep_state_label
        # Label all absence as vacant
        presence_based_estimated_truth_series[
            ~combined_truth_frame[self._ANY_PRESENCE_SERIES] &
            ~combined_truth_frame[self._TRUNCATED_PRESENCE_SERIES]
        ] = vacant_state_label
        # Label edges of presence (enters and exits) as active
        presence_based_estimated_truth_series[
            combined_truth_frame[self._PRESENCE_TRANSITION_ACTIVITY_SERIES] &
            ~combined_truth_frame[self._TRUNCATED_PRESENCE_SERIES]
        ] = active_state_label
        # Label periods where cold shoulder timeout was hit as unknown
        presence_based_estimated_truth_series[
            combined_truth_frame[self._TRUNCATED_PRESENCE_SERIES]
        ] = unknown_state_label
        return drop_consecutive_duplicates(presence_based_estimated_truth_series, keep_last=True)

    def _compute_activity_and_presence_based_estimated_truth_series(self, any_activity_series, any_presence_series):
        active_state_label = self._state_space.get_active_state().get_state_label()
        sleep_state_label = self._state_space.get_sleep_state().get_state_label()
        vacant_state_label = self._state_space.get_vacant_state().get_state_label()
        unknown_state_label = self._state_space.get_unknown_state().get_state_label()
        activity_based_estimated_truth_series = self._compute_activity_based_estimated_truth_series(any_activity_series)
        combined_truth_frame = pd.DataFrame(
            {
                self._ACTIVITY_BASED_ESTIMATED_TRUTH_SERIES: activity_based_estimated_truth_series,
                self._ANY_PRESENCE_SERIES: any_presence_series,
                self._TRUNCATED_PRESENCE_SERIES: any_presence_series.isnull(),
                self._ABSENCE_WITHOUT_ACTIVITY: self._compute_absence_without_activity(
                    any_activity_series=any_activity_series,
                    any_presence_series=any_presence_series
                ),
                self._PRESENCE_TRANSITION_ACTIVITY_SERIES: self._compute_presence_transition_activity(
                    any_presence_series=any_presence_series
                ),
                self._SLEEP_SERIES: self.compute_sleep_series(
                    start_timestamp=floor_datetime(
                        min(min(any_activity_series.index), min(any_presence_series.index)) - self._DAY_TIMEDELTA,
                        self._DAY_TIMEDELTA
                    ),
                    end_timestamp=ceil_datetime(
                        max(max(any_activity_series.index), max(any_presence_series.index)),
                        self._DAY_TIMEDELTA
                    )
                )
            }
        )
        for column in combined_truth_frame.columns:
            combined_truth_frame[column] = series_filter_valid_range(combined_truth_frame[column]).fillna(method="pad")
        combined_truth_frame = frame_filter_valid_range(
            combined_truth_frame,
            subset=[self._ACTIVITY_BASED_ESTIMATED_TRUTH_SERIES, self._ANY_PRESENCE_SERIES]
        )
        combined_truth_frame[self._ACTIVITY_BASED_ESTIMATED_TRUTH_SERIES] = (
            combined_truth_frame[self._ACTIVITY_BASED_ESTIMATED_TRUTH_SERIES].fillna(unknown_state_label)
        )
        for column in [
            self._ABSENCE_WITHOUT_ACTIVITY,
            self._ANY_PRESENCE_SERIES,
            self._TRUNCATED_PRESENCE_SERIES,
            self._PRESENCE_TRANSITION_ACTIVITY_SERIES,
            self._SLEEP_SERIES
        ]:
            combined_truth_frame[column] = combined_truth_frame[column].fillna(value=False).astype("bool")
        activity_and_presence_based_estimated_truth_series = (
            combined_truth_frame[self._ACTIVITY_BASED_ESTIMATED_TRUTH_SERIES]
        )
        # Label all presence during the daytime as active (which was previously labeled vacant or unknown)
        activity_and_presence_based_estimated_truth_series.loc[
            activity_and_presence_based_estimated_truth_series.isin(
                [
                    vacant_state_label,
                    unknown_state_label
                ]
            ) &
            combined_truth_frame[self._ANY_PRESENCE_SERIES] &
            ~combined_truth_frame[self._TRUNCATED_PRESENCE_SERIES] &
            ~combined_truth_frame[self._SLEEP_SERIES]
        ] = active_state_label
        # Label all presence during the nighttime as vacant (which was previously labeled vacant or unknown)
        activity_and_presence_based_estimated_truth_series.loc[
            activity_and_presence_based_estimated_truth_series.isin(
                [
                    vacant_state_label,
                    unknown_state_label
                ]
            ) &
            combined_truth_frame[self._ANY_PRESENCE_SERIES] &
            ~combined_truth_frame[self._TRUNCATED_PRESENCE_SERIES] &
            combined_truth_frame[self._SLEEP_SERIES]
        ] = sleep_state_label
        # Label all absence periods without any activity as active (which weren't already labeled vacant)
        activity_and_presence_based_estimated_truth_series.loc[
            activity_and_presence_based_estimated_truth_series.isin(
                [
                    active_state_label,
                    sleep_state_label,
                    unknown_state_label
                ]
            ) &
            combined_truth_frame[self._ABSENCE_WITHOUT_ACTIVITY] &
            ~combined_truth_frame[self._TRUNCATED_PRESENCE_SERIES]
        ] = vacant_state_label
        # Label edges of presence (enters and exits) as active
        activity_and_presence_based_estimated_truth_series.loc[
            activity_and_presence_based_estimated_truth_series.isin(
                [
                    sleep_state_label,
                    vacant_state_label,
                    unknown_state_label
                ]
            ) &
            combined_truth_frame[self._PRESENCE_TRANSITION_ACTIVITY_SERIES] &
            ~combined_truth_frame[self._TRUNCATED_PRESENCE_SERIES]
        ] = active_state_label
        return drop_consecutive_duplicates(activity_and_presence_based_estimated_truth_series, keep_last=True)

    def compute_estimated_truth_series(self, sensor_events_collection):
        any_activity_series = self._compute_any_activity_series(sensor_events_collection)
        any_presence_series = self._compute_any_presence_series(sensor_events_collection)
        if not any_activity_series.empty and not any_presence_series.empty:
            estimated_truth_series = self._compute_activity_and_presence_based_estimated_truth_series(
                any_activity_series=any_activity_series,
                any_presence_series=any_presence_series
            )
        elif not any_activity_series.empty:
            estimated_truth_series = self._compute_activity_based_estimated_truth_series(any_activity_series)
        elif not any_presence_series.empty:
            estimated_truth_series = self._compute_presence_based_estimated_truth_series(any_presence_series)
        else:
            estimated_truth_series = pd.Series()
        return estimated_truth_series

    def get_parameters(self):
        return {}
