import datetime
import pandas as pd

from ..abstract_sensor_model import AbstractSensorModel
from ....states.state_spaces import GOOSEStateSpace
from .....validation.type_validation import assert_list_of_type, assert_is_type


class BaselineSensorModel(AbstractSensorModel):

    def __init__(self, wake_up_time, bed_time, vacant_timedelta, *args, **kwargs):
        super(BaselineSensorModel, self).__init__(*args, **kwargs)
        assert_list_of_type([wake_up_time, bed_time], datetime.time)
        assert_is_type(vacant_timedelta, datetime.timedelta)
        assert_is_type(self._state_space, GOOSEStateSpace)
        self._wake_up_time = wake_up_time
        self._bed_time = bed_time
        self._vacant_timedelta = vacant_timedelta

    def train(self, state_series, sensor_events_collection):
        pass

    def _allowed_to_transition_to_vacant(self, timestamp):
        if self._wake_up_time < self._bed_time:
            return self._wake_up_time <= timestamp.time() < self._bed_time
        else:
            return not (self._bed_time <= timestamp.time() < self._wake_up_time)

    def _get_sensor_probabilities(self, state):
        sensor_probabilities = pd.Series(index=self._state_space.get_state_labels(), data=0.)
        sensor_probabilities.loc[state.get_state_label()] = 1.
        return sensor_probabilities

    def compute_sensor_updates(self, sensor_state_collection, previous_update_timestamp, current_update_timestamp):
        sensor_states = sensor_state_collection.get_sensor_states_for_sensors(self._sensors)
        online_sensor_states = filter(
            lambda sensor_state: sensor_state.is_online(previous_update_timestamp),
            sensor_states
        )
        sensor_updates = []
        if online_sensor_states:
            if all(map(lambda sensor_state: sensor_state.is_disabled(), online_sensor_states)):
                if self._allowed_to_transition_to_vacant(current_update_timestamp):
                    transition_disabled_timestamp = max(
                        map(
                            lambda sensor_state: sensor_state.get_transition_disabled_timestamp(),
                            online_sensor_states
                        )
                    )
                    transition_to_vacant_timestamp = transition_disabled_timestamp + self._vacant_timedelta
                    if current_update_timestamp >= transition_to_vacant_timestamp:
                        sensor_probabilities = self._get_sensor_probabilities(self._state_space.get_vacant_state())
                        sensor_updates.append((current_update_timestamp, sensor_probabilities))
            else:
                sensor_probabilities = self._get_sensor_probabilities(self._state_space.get_active_state())
                sensor_updates.append((current_update_timestamp, sensor_probabilities))
        return sensor_updates

    def get_parameters(self):
        return {}

    def get_wake_up_time(self):
        return self._wake_up_time

    def get_bed_time(self):
        return self._bed_time

    def get_vacant_timedelta(self):
        return self._vacant_timedelta
