import itertools
import numpy as np
import pandas as pd


from ..abstract_lumped_sensor_model import AbstractLumpedSensorModel
from ...sensor_model_priors import MultiSensorModelPrior
from .....environment.frozen_dict import FrozenDict
from .....features.featurizers import SampledBooleanFeaturizer
from ......validation.type_validation import assert_is_type


class MultiSensorModel(AbstractLumpedSensorModel):

    _FEATURIZER_CLS = SampledBooleanFeaturizer
    _SENSOR_MODEL_PRIOR_CLS = MultiSensorModelPrior

    _JOINT_OBSERVATION_SERIES = "joint_observation_series"
    _STATE_SERIES = "state_series"

    _JOINT_OBSERVATION_COUNTS = "joint_observation_counts"

    def __init__(self, cardinality, *args, **kwargs):
        super(MultiSensorModel, self).__init__(*args, **kwargs)
        assert_is_type(cardinality, int)
        self._cardinality = cardinality
        if self._sensor_model_prior is not None:
            self._assert_attributes_equal(
                self._sensor_model_prior,
                ["_time_slicer", "_state_space", "_featurizer"]
            )
        self._joint_observation_counts = self._initialize_joint_observation_counts()

    @property
    def _keys(self):
        return super(MultiSensorModel, self)._keys + (self._cardinality, )

    def _initialize_joint_observation_counts(self):
        joint_observation_counts = (
            [
                pd.DataFrame(columns=self._state_space.get_state_labels()).astype("int")
                for _ in self._time_slicer.get_time_slice_indices()
            ]
        )
        return joint_observation_counts

    def _compute_joint_observation_counts(self, training_frame):
        joint_observation_counts_list = []
        for state_label in self._state_space.get_state_labels():
            state_training_instances = training_frame[training_frame.loc[:, self._STATE_SERIES] == state_label]
            joint_observations = state_training_instances.loc[:, self._JOINT_OBSERVATION_SERIES].tolist()
            joint_observation_counts = pd.Series(
                {
                    observation: joint_observations.count(observation)
                    for observation in set(joint_observations)
                }
            )
            joint_observation_counts_list.append((state_label, joint_observation_counts))
        joint_observation_counts = pd.DataFrame.from_items(joint_observation_counts_list).fillna(value=0).astype("int")
        return joint_observation_counts

    def _compute_training_frame(self, state_series, sensor_events_collection):
        feature_frame = pd.DataFrame(
            {
                sensor: self._featurizer.featurize_sensor_events(
                    sensor_events_collection.get_sensor_events_for_sensor(sensor)
                )
                for sensor in self._sensors
            }
        )
        sampled_state_series, _ = state_series.get_series().align(pd.Series(index=feature_frame.index))
        training_frame = pd.DataFrame(
            {
                self._STATE_SERIES: sampled_state_series.fillna(method="pad").loc[feature_frame.index],
                self._JOINT_OBSERVATION_SERIES: self._compute_frozen_dict_series(feature_frame)
            }
        )
        return training_frame

    def train(self, state_series, sensor_events_collection):
        training_frame = self._compute_training_frame(state_series, sensor_events_collection)
        for time_slice_index in self._time_slicer.get_time_slice_indices():
            time_sliced_training_frame = self._time_slicer.get_time_sliced_series(
                series=training_frame,
                time_slice_index=time_slice_index
            )
            joint_observation_counts = self._compute_joint_observation_counts(time_sliced_training_frame)
            self._joint_observation_counts[time_slice_index] = (
                self._joint_observation_counts[time_slice_index]
                .add(joint_observation_counts, fill_value=0)
                .astype('int')
                .groupby(level=0)
                .sum()
            )

    @staticmethod
    def _filter_items_superset(joint_observation_counts, joint_observation):
        return joint_observation_counts.loc[
            joint_observation_counts.index.map(
                lambda _joint_observation: set(_joint_observation.items()) >= set(joint_observation.items())
            )
        ]

    @staticmethod
    def _filter_keys_superset(joint_observation_counts, joint_observation):
        return joint_observation_counts.loc[
            joint_observation_counts.index.map(
                lambda _joint_observation: set(_joint_observation.keys()) >= set(joint_observation.keys())
            )
        ]

    def _compute_local_joint_probability(self, joint_observation, time_slice_index):
        joint_observation_counts = self._joint_observation_counts[time_slice_index]
        numerator_joint_observation_counts = self._filter_items_superset(
            joint_observation_counts=joint_observation_counts,
            joint_observation=joint_observation
        )
        denominator_joint_observation_counts = self._filter_keys_superset(
            joint_observation_counts=joint_observation_counts,
            joint_observation=joint_observation
        )
        joint_probability = (
            numerator_joint_observation_counts.sum(axis=0) /
            denominator_joint_observation_counts.sum(axis=0)
        )
        return joint_probability

    @staticmethod
    def _filter_item_counts_superset(prior_joint_observation_counts, joint_observation):
        mapped_joint_observation = joint_observation.agg_by_mapped_items(
            mapping_func=lambda (sensor, observation): (sensor.get_sensor_type(), observation),
            agg_func=len
        )
        return prior_joint_observation_counts.loc[
            prior_joint_observation_counts.index.map(
                lambda prior_joint_observation: all(
                    map(
                        lambda ((sensor_type, observation), count): (
                            prior_joint_observation.get((sensor_type, observation)) >= count
                        ),
                        mapped_joint_observation.items()
                    )
                )
            )
        ]

    @staticmethod
    def _filter_key_counts_superset(prior_joint_observation_counts, joint_observation):
        def sum_counts_by_sensor_type(prior_joint_observation):
            return prior_joint_observation.agg_by_mapped_items(
                mapping_func=lambda ((sensor_type, observation), count): sensor_type,
                agg_func=lambda group: sum(map(lambda ((sensor_type, observation), count): count, group))
            )
        mapped_joint_observation = joint_observation.agg_by_mapped_items(
            mapping_func=lambda (sensor, observation): sensor.get_sensor_type(),
            agg_func=len
        )
        return prior_joint_observation_counts.loc[
            prior_joint_observation_counts.index.map(
                lambda prior_joint_observation: all(
                    map(
                        lambda (sensor_type, count): (
                            sum_counts_by_sensor_type(prior_joint_observation).get(sensor_type) >= count
                        ),
                        mapped_joint_observation.items()
                    )
                )
            )
        ]

    def _compute_global_joint_probability(self, joint_observation, time_slice_index):
        prior_joint_observation_counts = self._sensor_model_prior.get_prior_joint_observation_counts(time_slice_index)
        numerator_prior_joint_observation_counts = self._filter_item_counts_superset(
            prior_joint_observation_counts=prior_joint_observation_counts,
            joint_observation=joint_observation
        )
        denominator_prior_joint_observation_counts = self._filter_key_counts_superset(
            prior_joint_observation_counts=prior_joint_observation_counts,
            joint_observation=joint_observation
        )
        joint_probability = (
            numerator_prior_joint_observation_counts.sum(axis=0) /
            denominator_prior_joint_observation_counts.sum(axis=0)
        )
        return joint_probability

    def _compute_combined_joint_probability(self, joint_observation, time_slice_index):
        joint_observation_counts = self._joint_observation_counts[time_slice_index]
        filtered_joint_observation_counts = self._filter_keys_superset(
            joint_observation_counts=joint_observation_counts,
            joint_observation=joint_observation
        )
        observation_counts = filtered_joint_observation_counts.sum(axis=0)
        local_joint_probability = self._compute_local_joint_probability(joint_observation, time_slice_index)
        global_joint_probability = self._compute_global_joint_probability(joint_observation, time_slice_index)
        prior_weights = observation_counts.apply(self._sensor_model_prior.get_prior_weight_func())
        prior_weights[global_joint_probability.isnull()] = 0
        combined_joint_probability = (
            (prior_weights * global_joint_probability).add(
                (1 - prior_weights) * local_joint_probability,
                fill_value=0
            )
        )
        return combined_joint_probability

    def _compute_joint_probabilities_frame(self, joint_probability_computer, sensors, time_slice_index):
        joint_probabilities = dict()
        allowed_sensors = set(sensors) & set(self._sensors)
        allowed_cardinality = min(self._cardinality, len(allowed_sensors))
        if allowed_cardinality > 0:
            joint_observations = map(
                lambda joint_sensors: FrozenDict(zip(joint_sensors, [False] * allowed_cardinality)),
                itertools.combinations(allowed_sensors, allowed_cardinality)
            )
            for joint_observation in joint_observations:
                joint_probabilities[joint_observation] = joint_probability_computer(
                    joint_observation=joint_observation,
                    time_slice_index=time_slice_index
                )
        if joint_probabilities:
            joint_probabilities_frame = pd.DataFrame.from_dict(joint_probabilities, orient="index")
        else:
            joint_probabilities_frame = pd.DataFrame(columns=self._state_space.get_state_labels()).astype("float")
        return joint_probabilities_frame

    def _compute_probability_distribution(self, joint_probability_computer, sensors, time_slice_index):
        probability_distribution_dict = {}
        for sensor_type_cls, _sensors in self._get_sensors_by_sensor_type_cls(sensors).items():
            joint_probabilities_frame = self._compute_joint_probabilities_frame(
                joint_probability_computer=joint_probability_computer,
                sensors=_sensors,
                time_slice_index=time_slice_index
            )
            probability_distribution_dict.update(
                {
                    FrozenDict({sensor_type_cls.__name__: True}): 1 - joint_probabilities_frame.min(),
                    FrozenDict({sensor_type_cls.__name__: False}): joint_probabilities_frame.min()
                }
            )
        probability_distribution = pd.DataFrame.from_dict(probability_distribution_dict, orient="index")
        return probability_distribution.fillna(value=0.0)

    def get_local_probability_distribution(self, sensors, time_slice_index):
        return self._compute_probability_distribution(
            joint_probability_computer=self._compute_local_joint_probability,
            sensors=sensors,
            time_slice_index=time_slice_index
        )

    def get_global_probability_distribution(self, sensors, time_slice_index):
        self._assert_has_sensor_model_prior()
        return self._compute_probability_distribution(
            joint_probability_computer=self._compute_global_joint_probability,
            sensors=sensors,
            time_slice_index=time_slice_index
        )

    def get_combined_probability_distribution(self, sensors, time_slice_index):
        self._assert_has_sensor_model_prior()
        return self._compute_probability_distribution(
            joint_probability_computer=self._compute_combined_joint_probability,
            sensors=sensors,
            time_slice_index=time_slice_index
        )

    def get_parameters(self):
        return {self._JOINT_OBSERVATION_COUNTS: self._joint_observation_counts}

    def get_joint_observation_counts(self, time_slice_index):
        return self._joint_observation_counts[time_slice_index]

    def get_cardinality(self):
        return self._cardinality
