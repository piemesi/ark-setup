import pandas as pd

from ..abstract_sensor_model_prior import AbstractSensorModelPrior


class DirichletMultinomialSensorModelPrior(AbstractSensorModelPrior):

    _HYPERPARAMETERS = "hyperparameters"

    def __init__(self, *args, **kwargs):
        super(DirichletMultinomialSensorModelPrior, self).__init__(*args, **kwargs)
        self._hyperparameters = self._initialize_hyperparameters()

    def _initialize_hyperparameters(self):
        hyperparameters = {
            sensor_type: [
                pd.DataFrame(columns=self._state_space.get_state_labels()).astype('int')
                for _ in self._time_slicer.get_time_slice_indices()
            ]
            for sensor_type in self._sensor_types
        }
        return hyperparameters

    def incorporate_sensor_models(self, sensor_models):
        for sensor_model in sensor_models:
            self._assert_attributes_equal(sensor_model, ["_time_slicer", "_state_space", "_featurizer"])
            for sensor in sensor_model.get_sensors():
                for time_slice_index in self._time_slicer.get_time_slice_indices():
                    hyperparameters = sensor_model.get_hyperparameters(sensor, time_slice_index)
                    self._hyperparameters[sensor.get_sensor_type()][time_slice_index] = (
                        self._hyperparameters[sensor.get_sensor_type()][time_slice_index]
                        .add(hyperparameters, fill_value=0)
                        .astype('int')
                    )

    def get_parameters(self):
        parameters = {self._HYPERPARAMETERS: self._hyperparameters}
        return parameters

    def get_hyperparameters(self, sensor_type, time_slice_index):
        return self._hyperparameters[sensor_type][time_slice_index]
