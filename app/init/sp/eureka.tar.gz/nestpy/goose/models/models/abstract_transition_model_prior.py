import numpy as np

from abc import ABCMeta, abstractmethod
from collections import Callable

from ..abstract_model import AbstractModel
from ....validation.type_validation import assert_is_type


def exp_prior_weight_func(count, prior_weight_constant):
    return np.e ** -(prior_weight_constant * count)


class AbstractTransitionModelPrior(AbstractModel):
    """Core abstraction of the transition model prior classes.

    Transition model priors are initialized with a prior weight function. Implementation classes are responsible for
    implementing a routine for incorporating transition models.
    """
    __metaclass__ = ABCMeta

    def __init__(self, prior_weight_func, *args, **kwargs):
        """Initializes a transition model prior object with a prior weight function.

        Args:
            prior_weight_func (func): prior weight function
            *args: side arguments
            **kwargs: keyword side arguments
        """
        super(AbstractTransitionModelPrior, self).__init__(*args, **kwargs)
        self._assert_valid_prior_weight_func(prior_weight_func)
        self._prior_weight_func = prior_weight_func

    @staticmethod
    def _assert_valid_prior_weight_func(prior_weight_func):
        assert_is_type(prior_weight_func, Callable)
        assert 1 >= prior_weight_func(0) >= prior_weight_func(10e9) >= 0

    @abstractmethod
    def incorporate_transition_models(self, transition_models):
        """Routine for incorporating a list of transition models, to be defined by implementation classes.

        Args:
            transition_models (list of AbstractTransitionModel): transition models to be incorporated
        """
        raise NotImplementedError

    def get_prior_weight_func(self):
        return self._prior_weight_func
