import pandas as pd

from ..abstract_sensor_model_prior import AbstractSensorModelPrior
from ....features.featurizers import SampledBooleanFeaturizer
from ....sensors.sensor_types.abstract_boolean_sensor_type import AbstractBooleanSensorType
from .....validation.type_validation import assert_is_subclass, assert_list_of_type


class MultiSensorModelPrior(AbstractSensorModelPrior):

    _FEATURIZER_CLS = SampledBooleanFeaturizer

    _PRIOR_OBSERVATION_COUNTS = "prior_observation_counts"

    def __init__(self, *args, **kwargs):
        super(MultiSensorModelPrior, self).__init__(*args, **kwargs)
        self._prior_joint_observation_counts = self._initialize_prior_joint_observation_counts()

    def _initialize_prior_joint_observation_counts(self):
        prior_joint_observation_counts = (
            [
                pd.DataFrame(columns=self._state_space.get_state_labels()).astype("int")
                for _ in self._time_slicer.get_time_slice_indices()
            ]
        )
        return prior_joint_observation_counts

    @staticmethod
    def _compute_prior_joint_observation_counts(joint_observation_counts):
        prior_joint_observation_counts = joint_observation_counts.set_index(
            joint_observation_counts.index.map(
                lambda joint_observation: joint_observation.agg_by_mapped_items(
                    mapping_func=lambda (sensor, observation): (sensor.get_sensor_type(), observation),
                    agg_func=len
                )
            )
        )
        return prior_joint_observation_counts.groupby(level=0).sum()

    def incorporate_sensor_models(self, sensor_models):
        for sensor_model in sensor_models:
            self._assert_attributes_equal(
                sensor_model,
                ["_time_slicer", "_state_space", "_featurizer"]
            )
            for time_slice_index in self._time_slicer.get_time_slice_indices():
                joint_observation_counts = sensor_model.get_joint_observation_counts(time_slice_index)
                prior_joint_observation_counts = self._compute_prior_joint_observation_counts(joint_observation_counts)
                self._prior_joint_observation_counts[time_slice_index] = (
                    self._prior_joint_observation_counts[time_slice_index]
                    .add(prior_joint_observation_counts, fill_value=0)
                    .astype('int')
                    .groupby(level=0)
                    .sum()
                )

    def get_parameters(self):
        parameters = {self._PRIOR_OBSERVATION_COUNTS: self._prior_joint_observation_counts}
        return parameters

    def get_prior_joint_observation_counts(self, time_slice_index):
        return self._prior_joint_observation_counts[time_slice_index]
