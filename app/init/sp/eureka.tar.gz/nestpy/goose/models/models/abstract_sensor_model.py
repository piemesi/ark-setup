from abc import ABCMeta, abstractmethod

from .abstract_sensor_model_prior import AbstractSensorModelPrior
from ..abstract_model import AbstractModel
from ...features.abstract_featurizer import AbstractFeaturizer
from ...sensors import Sensor
from ....validation.type_validation import assert_is_type, assert_list_of_type


class AbstractSensorModel(AbstractModel):
    """Core abstraction of the sensor model classes.

    Sensor models are initialized with a featurizer, list of sensors and optionally a sensor model prior.
    Implementation classes are responsible for implementing routines for training and computation of sensor updates.
    """
    __metaclass__ = ABCMeta

    _FEATURIZER_CLS = AbstractFeaturizer
    _SENSOR_MODEL_PRIOR_CLS = AbstractSensorModelPrior

    def __init__(self, featurizer, sensors, sensor_model_prior=None, *args, **kwargs):
        """Initializes a sensor model object with a featurizer, list of sensors and sensor model prior.

        Args:
            featurizer (AbstractFeaturizer): featurizer
            sensors (list of Sensor): list of sensors
            sensor_model_prior (AbstractSensorModelPrior): sensor model prior
            *args: side arguments
            **kwargs: keyword side arguments
        """
        super(AbstractSensorModel, self).__init__(*args, **kwargs)
        assert_is_type(featurizer, self._FEATURIZER_CLS)
        assert_list_of_type(sensors, Sensor)
        if sensor_model_prior is not None:
            assert_is_type(sensor_model_prior, self._SENSOR_MODEL_PRIOR_CLS)
        self._featurizer = featurizer
        self._sensors = sensors
        self._sensor_model_prior = sensor_model_prior

    @property
    def _keys(self):
        return super(AbstractSensorModel, self)._keys + (
            self._featurizer,
            frozenset(self._sensors),
            self._sensor_model_prior
        )

    def _assert_has_sensor_model_prior(self):
        if self._sensor_model_prior is None:
            raise AssertionError("Sensor model prior has not been specified.")

    @abstractmethod
    def train(self, state_series, sensor_events_collection):
        """Training routine of the sensor model, to be defined by implementation classes.

        Args:
            state_series (StateSeries): state series
            sensor_events_collection (SensorEventsCollection): sensor events collection
        """
        raise NotImplementedError

    @abstractmethod
    def compute_sensor_updates(self, sensor_state_collection, previous_update_timestamp, current_update_timestamp):
        """Routine for computing sensor updates for a given time frame, to be defined by implementation classes.

        Args:
            sensor_state_collection (SensorStateCollection): sensor state collection
            previous_update_timestamp (datetime.datetime): previous update timestamp
            current_update_timestamp (datetime.datetime): current update timestamp

        Returns:
            list of (datetime.datetime, pandas.Series): sensor updates to be used in the filter processor
        """
        raise NotImplementedError

    def get_featurizer(self):
        return self._featurizer

    def get_sensors(self):
        return self._sensors

    def get_sensor_model_prior(self):
        return self._sensor_model_prior

    def get_sensor_model_prior_cls(self):
        return self._SENSOR_MODEL_PRIOR_CLS
