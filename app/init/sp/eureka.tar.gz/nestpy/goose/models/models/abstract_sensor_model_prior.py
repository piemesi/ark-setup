import numpy as np

from abc import ABCMeta, abstractmethod
from collections import Callable

from ..abstract_model import AbstractModel
from ...features.abstract_featurizer import AbstractFeaturizer
from ...sensors.abstract_sensor_type import AbstractSensorType
from ....validation.type_validation import assert_is_type, assert_list_of_type


def exp_prior_weight_func(count, prior_weight_constant):
    return np.e ** -(prior_weight_constant * count)


class AbstractSensorModelPrior(AbstractModel):
    """Core abstraction of the sensor model prior classes.

    Sensor model priors are initialized with a featurizer, list of sensor types and a prior weight function.
    Implementation classes are responsible for implementing a routine for incorporating sensor models.
    """
    __metaclass__ = ABCMeta

    _FEATURIZER_CLS = AbstractFeaturizer

    def __init__(self, featurizer, sensor_types, prior_weight_func, *args, **kwargs):
        """Initializes a sensor model prior object with a featurizer, list of sensor types and a prior weight function.

        Args:
            featurizer (AbstractFeaturizer): featurizer
            sensor_types (list of AbstractSensorType): list of sensor types
            prior_weight_func (func): prior weight function
            *args: side arguments
            **kwargs: keyword side arguments
        """
        super(AbstractSensorModelPrior, self).__init__(*args, **kwargs)
        assert_is_type(featurizer, self._FEATURIZER_CLS)
        assert_list_of_type(sensor_types, AbstractSensorType)
        self._assert_valid_prior_weight_func(prior_weight_func)
        self._featurizer = featurizer
        self._sensor_types = sensor_types
        self._prior_weight_func = prior_weight_func

    @property
    def _keys(self):
        return super(AbstractSensorModelPrior, self)._keys + (self._featurizer, frozenset(self._sensor_types))

    @staticmethod
    def _assert_valid_prior_weight_func(prior_weight_func):
        assert_is_type(prior_weight_func, Callable)
        assert 1 >= prior_weight_func(0) >= prior_weight_func(10e9) >= 0

    @abstractmethod
    def incorporate_sensor_models(self, sensor_models):
        """Routine for incorporating a list of sensor models, to be defined by implementation classes.

        Args:
            sensor_models (list of AbstractSensorModel): sensor models to be incorporated
        """
        raise NotImplementedError

    def get_featurizer(self):
        return self._featurizer

    def get_sensor_types(self):
        return self._sensor_types

    def get_prior_weight_func(self):
        return self._prior_weight_func
