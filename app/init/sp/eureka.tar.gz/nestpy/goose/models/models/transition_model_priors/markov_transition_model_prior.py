import datetime
import pandas as pd

from ..abstract_transition_model_prior import AbstractTransitionModelPrior
from .....validation.type_validation import assert_is_type


class MarkovTransitionModelPrior(AbstractTransitionModelPrior):

    _TRANSITION_COUNT_MATRICES = "transition_count_matrices"

    def __init__(self, sample_time, *args, **kwargs):
        super(MarkovTransitionModelPrior, self).__init__(*args, **kwargs)
        assert_is_type(sample_time, datetime.timedelta)
        self._sample_time = sample_time
        self._transition_count_matrices = self._initialize_transition_count_matrices()

    @property
    def _keys(self):
        return super(MarkovTransitionModelPrior, self)._keys + (self._sample_time, )

    def _initialize_transition_count_matrices(self):
        transition_count_matrices = [
            pd.DataFrame(
                index=self._state_space.get_state_labels(),
                columns=self._state_space.get_state_labels(),
                data=0
            )
            for _ in self._time_slicer.get_time_slice_indices()
        ]
        return transition_count_matrices

    def incorporate_transition_models(self, transition_models):
        for transition_model in transition_models:
            self._assert_attributes_equal(transition_model, ["_time_slicer", "_state_space", "_sample_time"])
            for time_slice_index in self._time_slicer.get_time_slice_indices():
                transition_count_matrix = transition_model.get_transition_count_matrix(time_slice_index)
                self._transition_count_matrices[time_slice_index] = (
                    self._transition_count_matrices[time_slice_index]
                    .add(transition_count_matrix, fill_value=0)
                    .astype('int')
                )

    def get_parameters(self):
        return {self._TRANSITION_COUNT_MATRICES: self._transition_count_matrices}

    def get_transition_count_matrix(self, time_slice_index):
        return self._transition_count_matrices[time_slice_index]

    def get_sample_time(self):
        return self._sample_time
