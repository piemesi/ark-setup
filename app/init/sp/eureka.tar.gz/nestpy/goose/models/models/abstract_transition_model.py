from abc import ABCMeta, abstractmethod

from .abstract_transition_model_prior import AbstractTransitionModelPrior
from ..abstract_model import AbstractModel
from ....validation.type_validation import assert_is_type


class AbstractTransitionModel(AbstractModel):
    """Core abstraction of the transition model classes.

    Transition models are initialized optionally with a transition model prior. Implementation classes are responsible
    for implementing routines for training and the computation of transition updates.
    """
    __metaclass__ = ABCMeta

    _TRANSITION_MODEL_PRIOR_CLS = AbstractTransitionModelPrior

    def __init__(self, transition_model_prior=None, *args, **kwargs):
        """Initializes a transition model object with a transition model prior.

        Args:
            transition_model_prior (AbstractTransitionModelPrior): transition model prior
            *args: side arguments
            **kwargs: keyword side arguments
        """
        super(AbstractTransitionModel, self).__init__(*args, **kwargs)
        if transition_model_prior is not None:
            assert_is_type(transition_model_prior, self._TRANSITION_MODEL_PRIOR_CLS)
        self._transition_model_prior = transition_model_prior

    @property
    def _keys(self):
        return super(AbstractTransitionModel, self)._keys + (self._transition_model_prior, )

    def _assert_has_transition_model_prior(self):
        if self._transition_model_prior is None:
            raise AssertionError("Transition model prior has not been specified.")

    @abstractmethod
    def train(self, state_series):
        """Training routine of the transition model, to be defined by implementation classes.

        Args:
            state_series (StateSeries): state series
        """
        raise NotImplementedError

    @abstractmethod
    def compute_transition_updates(self, previous_update_timestamp, current_update_timestamp):
        """Routine for computing transition updates for a given time frame, to be defined by implementation classes.

        Args:
            previous_update_timestamp (datetime.datetime): previous update timestamp
            current_update_timestamp (datetime.datetime): current update timestamp

        Returns:
            list of (datetime.datetime, pandas.DataFrame): transition updates to be used in the filter processor
        """
        raise NotImplementedError

    def get_transition_model_prior(self):
        return self._transition_model_prior

    def get_transition_model_prior_cls(self):
        return self._TRANSITION_MODEL_PRIOR_CLS
