import pandas as pd

from abc import ABCMeta, abstractmethod

from ..abstract_sensor_model import AbstractSensorModel


class AbstractSeparatedSensorModel(AbstractSensorModel):
    """Core abstraction of the separated sensor model classes.

    Separated sensor models make the assumption that each of the underlying sensors are independent. Implementation
    classes are responsible for implementing methods that return the probability distributions for individual sensors.
    """
    __metaclass__ = ABCMeta

    def __init__(self, *args, **kwargs):
        super(AbstractSeparatedSensorModel, self).__init__(*args, **kwargs)
        self._sensor_update_cache = {sensor: {} for sensor in self._sensors}
        self._probability_distribution_cache = {}

    @abstractmethod
    def get_local_probability_distribution(self, sensor, time_slice_index):
        """Method that returns the local probability distribution for a given sensor and time slice.

        Args:
            sensor (Sensor): sensor for which to get the local probability distribution
            time_slice_index (int): time slice index

        Returns:
            pandas.DataFrame: local probability distribution across each of the states in the state space
        """
        raise NotImplementedError

    @abstractmethod
    def get_global_probability_distribution(self, sensor, time_slice_index):
        """Method that returns the global probability distribution for a given sensor and time slice.

        Args:
            sensor (Sensor): sensor for which to get the global probability distribution
            time_slice_index (int): time slice index

        Returns:
            pandas.DataFrame: global probability distribution across each of the states in the state space
        """
        raise NotImplementedError

    @abstractmethod
    def get_combined_probability_distribution(self, sensor, time_slice_index):
        """Method that returns the combined probability distribution for a given sensor and time slice.

        Args:
            sensor (Sensor): sensor for which to get the combined probability distribution
            time_slice_index (int): time slice index

        Returns:
            pandas.DataFrame: combined probability distribution across each of the states in the state space
        """
        raise NotImplementedError

    def get_probability_distribution(self, sensor, time_slice_index):
        probability_distribution = self._probability_distribution_cache.get((sensor, time_slice_index))
        if probability_distribution is None:
            if self._sensor_model_prior is not None:
                probability_distribution = self.get_combined_probability_distribution(sensor, time_slice_index)
            else:
                probability_distribution = self.get_local_probability_distribution(sensor, time_slice_index)
            self._probability_distribution_cache[(sensor, time_slice_index)] = probability_distribution
        return probability_distribution

    def _compute_sensor_updates_for_sensor(self, sensor_state, previous_update_timestamp, current_update_timestamp):
        feature_series = self._featurizer.featurize_sensor_states(
            sensor_states=[sensor_state],
            previous_update_timestamp=previous_update_timestamp,
            current_update_timestamp=current_update_timestamp
        )
        sensor_updates = []
        for timestamp, observation in feature_series.iteritems():
            time_slice_index = self._time_slicer.get_time_slice_index(timestamp)
            probability_distribution = self.get_probability_distribution(sensor_state.get_sensor(), time_slice_index)
            if observation in probability_distribution.index:
                probabilities = probability_distribution.loc[observation]
            else:
                probabilities = pd.Series(index=self._state_space.get_state_labels(), data=0.)
            self._sensor_update_cache[sensor_state.get_sensor()][(timestamp, observation)] = probabilities.to_dict()
            sensor_updates.append((timestamp, probabilities))
        return sensor_updates

    def compute_sensor_updates(self, sensor_state_collection, previous_update_timestamp, current_update_timestamp):
        sensor_updates = []
        for sensor in self._sensors:
            sensor_state = sensor_state_collection.get_sensor_state_for_sensor(sensor)
            sensor_updates += self._compute_sensor_updates_for_sensor(
                sensor_state=sensor_state,
                previous_update_timestamp=previous_update_timestamp,
                current_update_timestamp=current_update_timestamp
            )
        return sorted(sensor_updates, key=lambda (timestamp, probabilities): timestamp)

    def get_sensor_update_cache(self, sensor):
        sensor_update_cache = pd.DataFrame.from_dict(self._sensor_update_cache[sensor], orient="index")
        sensor_update_cache.sort_index(axis=1, inplace=True)
        return (sensor_update_cache.T / sensor_update_cache.sum(axis=1).values).T
