import numpy as np
import pandas as pd

from abc import ABCMeta, abstractmethod

from ..abstract_model import AbstractModel
from ...features.featurizers import SampledBooleanFeaturizer
from ...sensors.abstract_sensor_type import AbstractSensorType
from ...states.state_series_ import EstimatedTruthStateSeries
from ....manipulators.series_manipulators import compute_timedelta_series
from ....validation.type_validation import assert_is_type, assert_list_of_type


class AbstractEstimatedTruthModel(AbstractModel):
    """Core abstraction of the estimated truth model classes.

    Estimated truth models are initialized with a list of sensor types. Implementation classes are responsible for
    implementing a routine for computing the estimated truth state series.
    """
    __metaclass__ = ABCMeta

    _FEATURIZER_CLS = SampledBooleanFeaturizer

    def __init__(self, sensor_types, featurizer=None, *args, **kwargs):
        """Initializes an estimated truth model object with a list of sensor types.

        Args:
            sensor_types (list of AbstractSensorType): list of sensor types
            featurizer (AbstractFeaturizer): featurizer (optional)
            *args: side arguments
            **kwargs: keyword side arguments
        """
        super(AbstractEstimatedTruthModel, self).__init__(*args, **kwargs)
        assert_list_of_type(sensor_types, AbstractSensorType)
        if featurizer is not None:
            assert_is_type(featurizer, self._FEATURIZER_CLS)
        self._sensor_types = sensor_types
        self._featurizer = featurizer

    @property
    def _keys(self):
        return super(AbstractEstimatedTruthModel, self)._keys + (frozenset(self._sensor_types), )

    def _filter_sensor_events(self, sensor_events_list):
        return filter(
            lambda sensor_events: sensor_events.get_sensor().get_sensor_type() in self._sensor_types,
            sensor_events_list
        )

    def _featurize_sensor_events(self, sensor_events):
        if self._featurizer is not None:
            return self._featurizer.featurize_sensor_events(sensor_events=sensor_events)
        else:
            return sensor_events.get_series()

    def _compute_truncated_presence_series(self, presence_sensor_events):
        sensor_reporting_policy = presence_sensor_events.get_sensor().get_sensor_reporting_policy()
        cold_shoulder_timeout = sensor_reporting_policy.get_cold_shoulder_timeout()
        presence_series = self._featurize_sensor_events(presence_sensor_events)
        if not presence_series.empty:
            timedelta_series = compute_timedelta_series(presence_series.index)
            truncation_timestamps = timedelta_series.index[timedelta_series > cold_shoulder_timeout]
            truncated_series = pd.Series(index=truncation_timestamps + cold_shoulder_timeout)
            truncated_presence_series = presence_series.append(truncated_series).sort_index()
        else:
            truncated_presence_series = presence_series
        return truncated_presence_series

    def _compute_any_presence_series(self, sensor_events_collection):
        presence_sensor_events_list = self._filter_sensor_events(
            sensor_events_collection.get_presence_sensor_events_list()
        )
        truncated_presence_series_dict = {
            presence_sensor_events.get_sensor(): self._compute_truncated_presence_series(presence_sensor_events)
            for presence_sensor_events in presence_sensor_events_list
        }
        presence_data_frame = pd.DataFrame(truncated_presence_series_dict)
        truncated_presence_data_frame = pd.DataFrame(
            {
                sensor: truncated_presence_series.isnull()
                for sensor, truncated_presence_series in truncated_presence_series_dict.items()
            }
        )
        any_presence_series = presence_data_frame.fillna(method="pad").any(axis=1)
        any_presence_series[truncated_presence_data_frame.fillna(method="pad").all(axis=1)] = np.nan
        return any_presence_series

    def _compute_any_activity_series(self, sensor_events_collection):
        activity_sensor_events_list = self._filter_sensor_events(
            sensor_events_collection.get_activity_sensor_events_list()
        )
        activity_frame = pd.DataFrame(
            {
                sensor_events.get_sensor(): self._featurize_sensor_events(sensor_events)
                for sensor_events in activity_sensor_events_list if not sensor_events.get_series().empty
            }
        )
        activity_series = activity_frame.any(axis=1)
        any_activity_series = activity_series[activity_series]
        return any_activity_series

    @abstractmethod
    def compute_estimated_truth_series(self, sensor_events_collection):
        """Routine for computing the estimated truth state series, to be defined by implementation classes.

        Args:
            sensor_events_collection (SensorEventsCollection): sensor events collection

        Returns:
            EstimatedTruthStateSeries: estimated truth state series
        """
        raise NotImplementedError
