import datetime
import itertools
import numpy as np
import pandas as pd

from ..abstract_lumped_sensor_model import AbstractLumpedSensorModel
from ..abstract_separated_sensor_model import AbstractSeparatedSensorModel
from ...sensor_model_priors import CombinedSensorModelPrior
from .....environment import FrozenDict, FrozenList
from .....features.featurizers import BooleanGapFeaturizer, SampledBooleanFeaturizer
from ......manipulators.series_manipulators import compute_timedelta_series
from ......validation.type_validation import assert_is_type, assert_is_subclass


class CombinedSensorModel(AbstractLumpedSensorModel):

    _FEATURIZER_CLS = (SampledBooleanFeaturizer, BooleanGapFeaturizer)
    _SENSOR_MODEL_PRIOR_CLS = CombinedSensorModelPrior

    _LEFT = 'left'
    _RIGHT = 'right'
    _OVERLAP = 'overlap'
    _TIMEDELTA = 'timedelta'

    _OVERLAP_COUNTS = "overlap_counts"

    def __init__(self, overlap_timedelta, sensor_model_builder, *args, **kwargs):
        super(CombinedSensorModel, self).__init__(*args, **kwargs)
        assert_is_type(overlap_timedelta, datetime.timedelta)
        assert_is_subclass(sensor_model_builder.get_object_cls(), AbstractSeparatedSensorModel)
        self._overlap_timedelta = overlap_timedelta
        self._separated_sensor_model = sensor_model_builder.build(sensors=self._sensors)
        if self._sensor_model_prior is not None:
            self._assert_attributes_equal(
                self._sensor_model_prior,
                ["_time_slicer", "_state_space", "_featurizer", "_sensor_type_cls", "_overlap_timedelta"]
            )
        self._overlap_counts = self._initialize_overlap_counts()

    @property
    def _keys(self):
        return super(CombinedSensorModel, self)._keys + (self._overlap_timedelta, self._separated_sensor_model)

    @staticmethod
    def _compute_combined_sets(items):
        combined_sets = map(FrozenList, itertools.combinations(items, 2))
        return combined_sets

    def _initialize_overlap_counts(self):
        overlap_counts = pd.DataFrame(
            index=self._compute_combined_sets(self._sensors),
            columns=[self._LEFT, self._RIGHT, self._OVERLAP, self._TIMEDELTA],
            data=0
        )
        return overlap_counts

    @classmethod
    def _compute_overlap_series(cls, left_boolean_series, right_boolean_series, overlap_timedelta):
        if not left_boolean_series.empty and not right_boolean_series.empty:
            correlation_frame = pd.DataFrame.from_items(
                [
                    (left_boolean_series.name, left_boolean_series[left_boolean_series]),
                    (right_boolean_series.name, right_boolean_series[right_boolean_series])
                ],
            ).fillna(value=False)
            correlation_frame.columns = [cls._LEFT, cls._RIGHT]
            correlation_frame[cls._TIMEDELTA] = compute_timedelta_series(correlation_frame.index)
            overlap_series = (
                correlation_frame[cls._LEFT] &
                (
                    correlation_frame[cls._RIGHT] |
                    (
                        ((correlation_frame[cls._TIMEDELTA] <= overlap_timedelta) &
                         correlation_frame[cls._RIGHT].shift(-1).fillna(value=False)) |
                        ((correlation_frame[cls._TIMEDELTA].shift(1) <= overlap_timedelta) &
                         correlation_frame[cls._RIGHT].shift(1).fillna(value=False))
                    )
                )
            )
        else:
            overlap_series = pd.Series()
        return overlap_series

    @classmethod
    def _compute_overlap_count(cls, left_boolean_series, right_boolean_series, overlap_timedelta):
        left_overlap_series = cls._compute_overlap_series(left_boolean_series, right_boolean_series, overlap_timedelta)
        right_overlap_series = cls._compute_overlap_series(right_boolean_series, left_boolean_series, overlap_timedelta)
        return min(left_overlap_series.sum(), right_overlap_series.sum())

    def _compute_overlap_counts(self, sensor_events_collection):
        def _get_series_for_sensor(_sensor):
            sensor_events = sensor_events_collection.get_sensor_events_for_sensor(_sensor)
            return sensor_events.get_series()
        overlap_counts = self._initialize_overlap_counts()
        for combined_sensor_set in self._compute_combined_sets(self._sensors):
            for sensor, column in zip(combined_sensor_set, [self._LEFT, self._RIGHT]):
                overlap_counts.loc[combined_sensor_set, column] = _get_series_for_sensor(sensor).sum()
            left_boolean_series, right_boolean_series = map(_get_series_for_sensor, combined_sensor_set)
            overlap_counts.loc[combined_sensor_set, self._OVERLAP] = self._compute_overlap_count(
                left_boolean_series=left_boolean_series,
                right_boolean_series=right_boolean_series,
                overlap_timedelta=pd.to_timedelta(self._overlap_timedelta)
            )
            if not left_boolean_series.empty and not right_boolean_series.empty:
                timedelta = (
                    min(map(max, [left_boolean_series.index, right_boolean_series.index])) -
                    max(map(min, [left_boolean_series.index, right_boolean_series.index]))
                )
            else:
                timedelta = datetime.timedelta(seconds=0)
            overlap_counts.loc[combined_sensor_set, self._TIMEDELTA] = int(timedelta.total_seconds())
        return overlap_counts

    def _compute_pairwise_correlation_coefficients(self, overlap_counts):
        pairwise_correlation_coefficients = pd.Series(index=overlap_counts.index)
        overlap_counts_dict = dict(overlap_counts.iterrows())
        for combined_sensor_set in overlap_counts.index:
            left_count = overlap_counts_dict[combined_sensor_set][self._LEFT]
            right_count = overlap_counts_dict[combined_sensor_set][self._RIGHT]
            overlap_count = overlap_counts_dict[combined_sensor_set][self._OVERLAP]
            if left_count > 0 and right_count > 0:
                correlation_coefficient = overlap_count / np.sqrt(left_count * right_count)
            else:
                correlation_coefficient = 0.
            pairwise_correlation_coefficients.loc[combined_sensor_set] = correlation_coefficient
        return pairwise_correlation_coefficients

    def _get_local_pairwise_correlation_coefficients(self):
        pairwise_correlation_coefficients = self._compute_pairwise_correlation_coefficients(self._overlap_counts)
        return pairwise_correlation_coefficients

    def _get_global_pairwise_correlation_coefficients(self):
        prior_overlap_counts = self._sensor_model_prior.get_prior_overlap_counts()
        overlap_counts_dict = {
            combined_sensor_set: dict(prior_overlap_counts.iterrows()).get(
                FrozenList(
                    map(
                        lambda sensor: sensor.get_sensor_type(),
                        combined_sensor_set
                    )
                ),
                pd.DataFrame(columns=[self._LEFT, self._RIGHT, self._OVERLAP])
            )
            for combined_sensor_set in self._compute_combined_sets(self._sensors)
        }
        if overlap_counts_dict:
            overlap_counts = pd.DataFrame.from_dict(overlap_counts_dict, orient="index")
        else:
            overlap_counts = pd.DataFrame(columns=[self._LEFT, self._RIGHT, self._OVERLAP])
        pairwise_correlation_coefficients = self._compute_pairwise_correlation_coefficients(overlap_counts)
        return pairwise_correlation_coefficients

    def _get_combined_pairwise_correlation_coefficients(self):
        observation_counts = self._overlap_counts[self._TIMEDELTA]
        local_pairwise_correlation_coefficients = self._get_local_pairwise_correlation_coefficients()
        global_pairwise_correlation_coefficients = self._get_global_pairwise_correlation_coefficients()
        prior_weights = observation_counts.apply(self._sensor_model_prior.get_prior_weight_func())
        prior_weights[global_pairwise_correlation_coefficients.isnull()] = 0
        combined_pairwise_correlation_coefficients = (
            (prior_weights * global_pairwise_correlation_coefficients).add(
                (1 - prior_weights) * local_pairwise_correlation_coefficients,
                fill_value=0
            )
        )
        return combined_pairwise_correlation_coefficients

    def train(self, state_series, sensor_events_collection):
        self._separated_sensor_model.train(state_series, sensor_events_collection)
        overlap_counts = self._compute_overlap_counts(sensor_events_collection)
        self._overlap_counts = (
            self._overlap_counts.add(overlap_counts, fill_value=0).fillna(value=0).astype(int).groupby(level=0).sum()
        )

    def _get_probabilities_for_sensor(self, probability_distribution_getter, sensor, time_slice_index, observation):
        probability_distribution = probability_distribution_getter(
            sensor=sensor,
            time_slice_index=(
                time_slice_index *
                (
                    self._separated_sensor_model.get_time_slicer().get_time_slices_per_day() //
                    self._time_slicer.get_time_slices_per_day()
                )
            )
        )
        if observation in probability_distribution.index:
            probabilities = probability_distribution.loc[observation]
        else:
            probabilities = pd.Series(index=self._state_space.get_state_labels(), data=0.)
        probabilities[probability_distribution.sum(axis=0) == 0] = np.nan
        return probabilities

    def _compute_pairwise_symmetric_differences_frame(
            self,
            probability_distribution_getter,
            pairwise_correlation_coefficients,
            sensors,
            time_slice_index
    ):
        pairwise_symmetric_differences = dict()
        for sensor in sensors:
            sensor_probabilities = self._get_probabilities_for_sensor(
                probability_distribution_getter=probability_distribution_getter,
                sensor=sensor,
                time_slice_index=time_slice_index,
                observation=True
            )
            pairwise_symmetric_differences[sensor] = 1 - sensor_probabilities
        pairwise_correlation_coefficients_dict = dict(pairwise_correlation_coefficients.iteritems())
        for combined_sensor_set in self._compute_combined_sets(sensors):
            correlation_coefficient = pairwise_correlation_coefficients_dict[combined_sensor_set]
            left_probabilities, right_probabilities = map(
                lambda _sensor: self._get_probabilities_for_sensor(
                    probability_distribution_getter=probability_distribution_getter,
                    sensor=_sensor,
                    time_slice_index=time_slice_index,
                    observation=True
                ),
                combined_sensor_set
            )
            pairwise_intersection = pd.DataFrame(
                [
                    correlation_coefficient * np.sqrt(left_probabilities * right_probabilities),
                    left_probabilities,
                    right_probabilities
                ],
            )
            pairwise_symmetric_differences[combined_sensor_set] = (
                1 - left_probabilities - right_probabilities + pairwise_intersection.min()
            )
        if pairwise_symmetric_differences:
            pairwise_symmetric_differences_frame = pd.DataFrame.from_dict(
                pairwise_symmetric_differences,
                orient="index"
            )
        else:
            pairwise_symmetric_differences_frame = pd.DataFrame(columns=self._state_space.get_state_labels())
        return pairwise_symmetric_differences_frame

    def _compute_probability_distribution(
            self,
            probability_distribution_getter,
            pairwise_correlation_coefficients,
            sensors,
            time_slice_index
    ):
        probability_distribution_dict = {}
        for sensor_type_cls, sensors_ in self._get_sensors_by_sensor_type_cls(sensors).items():
            pairwise_symmetric_differences_frame = self._compute_pairwise_symmetric_differences_frame(
                probability_distribution_getter=probability_distribution_getter,
                pairwise_correlation_coefficients=pairwise_correlation_coefficients,
                sensors=sensors_,
                time_slice_index=time_slice_index
            )
            probability_distribution_dict.update(
                {
                    FrozenDict({sensor_type_cls.__name__: True}): 1 - pairwise_symmetric_differences_frame.min(),
                    FrozenDict({sensor_type_cls.__name__: False}): pairwise_symmetric_differences_frame.min()
                }
            )
        probability_distribution = pd.DataFrame.from_dict(probability_distribution_dict, orient="index")
        return probability_distribution.fillna(value=0.0)

    def get_local_probability_distribution(self, sensors, time_slice_index):
        return self._compute_probability_distribution(
            probability_distribution_getter=self._separated_sensor_model.get_local_probability_distribution,
            pairwise_correlation_coefficients=self._get_local_pairwise_correlation_coefficients(),
            sensors=sensors,
            time_slice_index=time_slice_index
        )

    def get_global_probability_distribution(self, sensors, time_slice_index):
        self._assert_has_sensor_model_prior()
        return self._compute_probability_distribution(
            probability_distribution_getter=self._separated_sensor_model.get_global_probability_distribution,
            pairwise_correlation_coefficients=self._get_global_pairwise_correlation_coefficients(),
            sensors=sensors,
            time_slice_index=time_slice_index
        )

    def get_combined_probability_distribution(self, sensors, time_slice_index):
        self._assert_has_sensor_model_prior()
        return self._compute_probability_distribution(
            probability_distribution_getter=self._separated_sensor_model.get_combined_probability_distribution,
            pairwise_correlation_coefficients=self._get_combined_pairwise_correlation_coefficients(),
            sensors=sensors,
            time_slice_index=time_slice_index
        )

    def _compute_correlation_matrix(self, pairwise_correlation_coefficients):
        correlation_matrix = pd.DataFrame(
            index=self._sensors,
            columns=self._sensors,
            data=np.eye(len(self._sensors))
        )
        for (left_sensor, right_sensor), correlation_coefficient in pairwise_correlation_coefficients.iteritems():
            correlation_matrix.loc[left_sensor, right_sensor] = correlation_coefficient
            correlation_matrix.loc[right_sensor, left_sensor] = correlation_coefficient
        return correlation_matrix

    def get_local_correlation_matrix(self):
        local_pairwise_correlation_coefficients = self._get_local_pairwise_correlation_coefficients()
        local_correlation_matrix = self._compute_correlation_matrix(local_pairwise_correlation_coefficients)
        return local_correlation_matrix

    def get_global_correlation_matrix(self):
        self._assert_has_sensor_model_prior()
        global_pairwise_correlation_coefficients = self._get_global_pairwise_correlation_coefficients()
        global_correlation_matrix = self._compute_correlation_matrix(global_pairwise_correlation_coefficients)
        return global_correlation_matrix

    def get_combined_correlation_matrix(self):
        self._assert_has_sensor_model_prior()
        combined_pairwise_correlation_coefficients = self._get_combined_pairwise_correlation_coefficients()
        combined_correlation_matrix = self._compute_correlation_matrix(combined_pairwise_correlation_coefficients)
        return combined_correlation_matrix

    def get_parameters(self):
        return {self._OVERLAP_COUNTS: self._overlap_counts}

    def get_overlap_counts(self):
        return self._overlap_counts

    def get_overlap_timedelta(self):
        return self._overlap_timedelta

    def get_separated_sensor_model(self):
        return self._separated_sensor_model
