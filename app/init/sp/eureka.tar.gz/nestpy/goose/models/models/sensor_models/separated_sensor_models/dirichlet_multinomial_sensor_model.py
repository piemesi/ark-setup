import pandas as pd

from ..abstract_separated_sensor_model import AbstractSeparatedSensorModel
from ...sensor_model_priors import DirichletMultinomialSensorModelPrior


class DirichletMultinomialSensorModel(AbstractSeparatedSensorModel):

    _SENSOR_MODEL_PRIOR_CLS = DirichletMultinomialSensorModelPrior

    _STATE_SERIES = "state_series"
    _FEATURE_SERIES = "feature_series"

    _HYPERPARAMETERS = "hyperparameters"

    def __init__(self, *args, **kwargs):
        super(DirichletMultinomialSensorModel, self).__init__(*args, **kwargs)
        if self._sensor_model_prior is not None:
            self._assert_attributes_equal(
                self._sensor_model_prior,
                ["_time_slicer", "_state_space", "_featurizer"]
            )
        self._hyperparameters = self._initialize_hyperparameters()

    def _initialize_hyperparameters(self):
        hyperparameters = {
            sensor: [
                pd.DataFrame(columns=self._state_space.get_state_labels()).astype('int')
                for _ in self._time_slicer.get_time_slice_indices()
            ]
            for sensor in self._sensors
        }
        return hyperparameters

    def _compute_training_frame(self, state_series, sensor_events):
        feature_series = self._featurizer.featurize_sensor_events(sensor_events)
        sampled_state_series, _ = state_series.get_series().align(pd.Series(index=feature_series.index))
        training_frame = pd.DataFrame.from_items(
            [
                (
                    self._STATE_SERIES,
                    sampled_state_series.fillna(method="pad").loc[feature_series.index]
                ),
                (
                    self._FEATURE_SERIES,
                    feature_series
                )
            ]
        )
        return training_frame

    def _compute_hyperparameters(self, training_frame):
        state_hyperparameters = []
        for state_label in self._state_space.get_state_labels():
            state_training_frame = training_frame.loc[training_frame[self._STATE_SERIES] == state_label]
            observation_counts = state_training_frame[self._FEATURE_SERIES].value_counts().sort_index()
            state_hyperparameters.append((state_label, observation_counts))
        hyperparameters = pd.DataFrame.from_items(state_hyperparameters).fillna(value=0).astype('int')
        return hyperparameters

    def train(self, state_series, sensor_events_collection):
        for sensor in self._sensors:
            sensor_events = sensor_events_collection.get_sensor_events_for_sensor(sensor)
            training_frame = self._compute_training_frame(state_series, sensor_events)
            for time_slice_index in self._time_slicer.get_time_slice_indices():
                time_sliced_training_frame = self._time_slicer.get_time_sliced_series(
                    series=training_frame,
                    time_slice_index=time_slice_index
                )
                hyperparameters = self._compute_hyperparameters(time_sliced_training_frame)
                self._hyperparameters[sensor][time_slice_index] = (
                    self._hyperparameters[sensor][time_slice_index]
                    .add(hyperparameters, fill_value=0)
                    .astype('int')
                )

    @staticmethod
    def _compute_probability_distribution(hyperparameters):
        return (hyperparameters / hyperparameters.sum(axis=0).replace(0, 1)).astype('float')

    def get_local_probability_distribution(self, sensor, time_slice_index):
        sensor_probability_distribution = self._compute_probability_distribution(
            self._hyperparameters[sensor][time_slice_index]
        )
        return sensor_probability_distribution

    def get_global_probability_distribution(self, sensor, time_slice_index):
        self._assert_has_sensor_model_prior()
        sensor_probability_distribution = self._compute_probability_distribution(
            self._sensor_model_prior.get_hyperparameters(sensor.get_sensor_type(), time_slice_index)
        )
        return sensor_probability_distribution

    def get_combined_probability_distribution(self, sensor, time_slice_index):
        self._assert_has_sensor_model_prior()
        observation_counts = self._hyperparameters[sensor][time_slice_index].sum(axis=0)
        prior_weights = observation_counts.apply(self._sensor_model_prior.get_prior_weight_func())
        sensor_probability_distribution = (
            (prior_weights * self.get_global_probability_distribution(sensor, time_slice_index)).add(
                (1 - prior_weights) * self.get_local_probability_distribution(sensor, time_slice_index),
                fill_value=0
            )
        )
        return sensor_probability_distribution

    def get_parameters(self):
        return {self._HYPERPARAMETERS: self._hyperparameters}

    def get_hyperparameters(self, sensor, time_slice_index):
        return self._hyperparameters[sensor][time_slice_index]
