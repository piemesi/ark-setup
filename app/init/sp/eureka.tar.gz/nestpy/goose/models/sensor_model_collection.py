from .models.abstract_sensor_model import AbstractSensorModel
from ..sensors import Sensor, SensorEventsCollection
from ...validation.type_validation import assert_is_type, assert_list_of_type


class SensorModelCollection(object):

    def __init__(self,  sensor_models):
        self._validate_sensor_models(sensor_models, AbstractSensorModel)
        self._sensor_models = sensor_models

    def __repr__(self):
        return "<{}>".format(self.__class__.__name__)

    def __hash__(self):
        return hash(self._keys)

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self._keys == other._keys

    def __ne__(self, other):
        return not self.__eq__(other)

    @property
    def _keys(self):
        return frozenset(self._sensor_models)

    @classmethod
    def _validate_sensor_models(cls, sensor_models, sensor_model_cls):
        assert_list_of_type(sensor_models, sensor_model_cls)
        if len(set(map(lambda sensor_model: sensor_model.get_state_space(), sensor_models))) > 1:
            raise ValueError("State spaces across sensor models have to be consistent.")

    def train(self, state_series, sensor_events_collection):
        assert_is_type(sensor_events_collection, SensorEventsCollection)
        for sensor_model in self._sensor_models:
            sensor_model.train(state_series, sensor_events_collection)

    def get_sensor_models(self):
        return self._sensor_models
