import datetime

from ..abstract_model_builder import AbstractModelBuilder
from ..models.abstract_estimated_truth_model import AbstractEstimatedTruthModel
from ..models.estimated_truth_models import LookAheadEstimatedTruthModel
from ...features.featurizers import SampledBooleanFeaturizer
from ...sensors.abstract_sensor_type import AbstractSensorType
from ...sensors.sensor_types.boolean_sensor_types import (
    DIAMOND_PIR_SENSOR_TYPE,
    DIAMOND_DIAL_TOUCH_SENSOR_TYPE,
    MOBILE_DEVICE_MDL_SENSOR_TYPE,
    QUARTZ_MOTION_SENSOR_TYPE,
    QUARTZ_AUDIO_SENSOR_TYPE,
    TOPAZ_PIR_SENSOR_TYPE
)
from ...states.state_spaces import GOOSEStateSpace, OCCUPANCY_STATE_SPACE


OCCUPANCY_LOOK_AHEAD_ESTIMATED_TRUTH_MODEL_BUILDER_CONFIG = dict(
    object_cls=LookAheadEstimatedTruthModel,
    state_space=OCCUPANCY_STATE_SPACE,
    sensor_types=[
        DIAMOND_PIR_SENSOR_TYPE,
        DIAMOND_DIAL_TOUCH_SENSOR_TYPE,
        MOBILE_DEVICE_MDL_SENSOR_TYPE,
        QUARTZ_MOTION_SENSOR_TYPE,
        QUARTZ_AUDIO_SENSOR_TYPE,
        TOPAZ_PIR_SENSOR_TYPE
    ],
    featurizer=SampledBooleanFeaturizer(sample_time=datetime.timedelta(minutes=5)),
    weekday_bed_time=datetime.time(hour=23),
    weekday_early_bed_time=datetime.time(hour=20),
    weekday_wake_up_time=datetime.time(hour=7),
    weekday_early_wake_up_time=datetime.time(hour=6),
    weekday_late_wake_up_time=datetime.time(hour=10),
    weekend_bed_time=datetime.time(hour=0),
    weekend_early_bed_time=datetime.time(hour=20),
    weekend_wake_up_time=datetime.time(hour=8),
    weekend_early_wake_up_time=datetime.time(hour=7),
    weekend_late_wake_up_time=datetime.time(hour=11),
    minimum_activity_duration=datetime.timedelta(minutes=5),
    minimum_sleep_activity_duration=datetime.timedelta(minutes=5),
    inactivity_window=datetime.timedelta(hours=2),
    sleep_inactivity_window=datetime.timedelta(hours=1),
    weekday_overnight_presence_indicator_time=datetime.time(hour=18),
    weekend_overnight_presence_indicator_time=datetime.time(hour=18)
)


class EstimatedTruthModelBuilder(AbstractModelBuilder):

    def _get_object_base_cls(self):
        return AbstractEstimatedTruthModel

    def _get_builder_config_types(self):
        return dict(
            super(EstimatedTruthModelBuilder, self)._get_builder_config_types(),
            state_space=GOOSEStateSpace,
            sensor_types=AbstractSensorType,
            weekday_bed_time=datetime.time,
            weekday_early_bed_time=datetime.time,
            weekday_wake_up_time=datetime.time,
            weekday_early_wake_up_time=datetime.time,
            weekday_late_wake_up_time=datetime.time,
            weekend_bed_time=datetime.time,
            weekend_early_bed_time=datetime.time,
            weekend_wake_up_time=datetime.time,
            weekend_early_wake_up_time=datetime.time,
            weekend_late_wake_up_time=datetime.time,
            weekday_overnight_presence_indicator_time=datetime.time,
            weekend_overnight_presence_indicator_time=datetime.time,
            minimum_activity_duration=datetime.timedelta,
            minimum_sleep_activity_duration=datetime.timedelta
        )
