import datetime
import sys

from ..abstract_model_builder import AbstractModelBuilder
from ..models.abstract_sensor_model import AbstractSensorModel
from ..models.sensor_models import (
    BaselineSensorModel,
    CombinedSensorModel,
    DirichletMultinomialSensorModel,
    MultiSensorModel,
    AbsenceMultiSensorModel
)
from ..models.sensor_model_priors import (
    CombinedSensorModelPrior,
    DirichletMultinomialSensorModelPrior,
    MultiSensorModelPrior
)
from ...building.abstract_object_builder import extend_builder_config
from ...environment import TimeSlicer
from ...features.abstract_featurizer import AbstractFeaturizer
from ...features.featurizers import BooleanGapFeaturizer, GapFeaturizer, SampledBooleanFeaturizer
from ...priors.prior_cache import PriorCache
from ...sensors import Sensor
from ...sensors.sensor_types.boolean_sensor_types import ActivitySensorType, PresenceSensorType
from ...states.state_spaces import OCCUPANCY_STATE_SPACE


class SensorModelBuilder(AbstractModelBuilder):

    def _get_object_base_cls(self):
        return AbstractSensorModel

    def _get_builder_config_types(self):
        builder_config_types = super(SensorModelBuilder, self)._get_builder_config_types()
        builder_config_types.update(featurizer=AbstractFeaturizer)
        return builder_config_types

    def _get_build_kwargs_types(self):
        return dict(sensors=Sensor)


OCCUPANCY_DIRICHLET_MULTINOMIAL_SENSOR_MODEL_BUILDER_CONFIG = dict(
    object_cls=DirichletMultinomialSensorModel,
    time_slicer=TimeSlicer(time_slices_per_day=6),
    state_space=OCCUPANCY_STATE_SPACE,
    featurizer=GapFeaturizer(
        gap_time=datetime.timedelta(minutes=5),
        gap_time_limit=datetime.timedelta(hours=12)
    ),
    sensor_model_prior=PriorCache.load_sensor_model_prior(
        sensor_model_prior_cls=DirichletMultinomialSensorModelPrior,
        featurizer_cls=GapFeaturizer
    )
)

OCCUPANCY_BOOLEAN_DIRICHLET_MULTINOMIAL_SENSOR_MODEL_BUILDER_CONFIG = dict(
    object_cls=DirichletMultinomialSensorModel,
    time_slicer=TimeSlicer(time_slices_per_day=24),
    state_space=OCCUPANCY_STATE_SPACE,
    featurizer=BooleanGapFeaturizer(
        gap_time=datetime.timedelta(minutes=5),
        gap_time_limit=datetime.timedelta(hours=1e8)
    ),
    sensor_model_prior=PriorCache.load_sensor_model_prior(
        sensor_model_prior_cls=DirichletMultinomialSensorModelPrior,
        featurizer_cls=BooleanGapFeaturizer
    )
)

OCCUPANCY_ABSENCE_MULTI_SENSOR_MODEL_BUILDER_CONFIG = dict(
    object_cls=AbsenceMultiSensorModel,
    time_slicer=TimeSlicer(time_slices_per_day=24),
    state_space=OCCUPANCY_STATE_SPACE,
    featurizer=SampledBooleanFeaturizer(sample_time=datetime.timedelta(minutes=5)),
    sensor_type_cls=PresenceSensorType,
    cardinality=2
)

OCCUPANCY_MULTI_SENSOR_MODEL_BUILDER_CONFIG = dict(
    object_cls=MultiSensorModel,
    time_slicer=TimeSlicer(time_slices_per_day=24),
    state_space=OCCUPANCY_STATE_SPACE,
    featurizer=SampledBooleanFeaturizer(sample_time=datetime.timedelta(minutes=5)),
    sensor_type_cls=ActivitySensorType,
    cardinality=2,
    sensor_model_prior=PriorCache.load_sensor_model_prior(
        sensor_model_prior_cls=MultiSensorModelPrior,
        featurizer_cls=SampledBooleanFeaturizer
    )
)

OCCUPANCY_PERFECT_MULTI_SENSOR_MODEL_BUILDER_CONFIG = extend_builder_config(
    OCCUPANCY_MULTI_SENSOR_MODEL_BUILDER_CONFIG,
    cardinality=sys.maxint
)

OCCUPANCY_COMBINED_SENSOR_MODEL_BUILDER_CONFIG = dict(
    object_cls=CombinedSensorModel,
    time_slicer=TimeSlicer(time_slices_per_day=24),
    state_space=OCCUPANCY_STATE_SPACE,
    featurizer=BooleanGapFeaturizer(
        gap_time=datetime.timedelta(minutes=5),
        gap_time_limit=datetime.timedelta(days=1e8)
    ),
    sensor_type_cls=ActivitySensorType,
    overlap_timedelta=datetime.timedelta(minutes=5),
    sensor_model_builder=SensorModelBuilder(**OCCUPANCY_BOOLEAN_DIRICHLET_MULTINOMIAL_SENSOR_MODEL_BUILDER_CONFIG),
    sensor_model_prior=PriorCache.load_sensor_model_prior(
        sensor_model_prior_cls=CombinedSensorModelPrior,
        featurizer_cls=BooleanGapFeaturizer
    )
)

OCCUPANCY_BASELINE_SENSOR_MODEL_BUILDER_CONFIG = dict(
    object_cls=BaselineSensorModel,
    time_slicer=TimeSlicer(time_slices_per_day=1),
    state_space=OCCUPANCY_STATE_SPACE,
    featurizer=SampledBooleanFeaturizer(sample_time=datetime.timedelta(minutes=5)),
    wake_up_time=datetime.time(hour=8),
    bed_time=datetime.time(hour=20),
    vacant_timedelta=datetime.timedelta(minutes=60)
)
