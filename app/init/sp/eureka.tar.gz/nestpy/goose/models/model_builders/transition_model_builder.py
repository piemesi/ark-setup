import datetime

from ..abstract_model_builder import AbstractModelBuilder
from ..models.abstract_transition_model import AbstractTransitionModel
from ..models.transition_models import BaselineTransitionModel, MarkovTransitionModel
from ..models.transition_model_priors import MarkovTransitionModelPrior
from ...environment import TimeSlicer
from ...priors.prior_cache import PriorCache
from ...states.state_spaces import OCCUPANCY_STATE_SPACE


OCCUPANCY_MARKOV_TRANSITION_MODEL_BUILDER_CONFIG = dict(
    object_cls=MarkovTransitionModel,
    time_slicer=TimeSlicer(time_slices_per_day=24),
    state_space=OCCUPANCY_STATE_SPACE,
    sample_time=datetime.timedelta(minutes=5),
    transition_model_prior=PriorCache.load_transition_model_prior(MarkovTransitionModelPrior)
)

OCCUPANCY_BASELINE_TRANSITION_MODEL_BUILDER_CONFIG = dict(
    object_cls=BaselineTransitionModel,
    time_slicer=TimeSlicer(time_slices_per_day=1),
    state_space=OCCUPANCY_STATE_SPACE
)


class TransitionModelBuilder(AbstractModelBuilder):

    def _get_object_base_cls(self):
        return AbstractTransitionModel
