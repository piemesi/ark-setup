from collections import Callable
from functools import partial

from .transition_model_builder import OCCUPANCY_MARKOV_TRANSITION_MODEL_BUILDER_CONFIG
from ..abstract_model_builder import AbstractModelBuilder
from ..models.abstract_transition_model_prior import AbstractTransitionModelPrior, exp_prior_weight_func
from ..models.transition_model_priors import MarkovTransitionModelPrior


OCCUPANCY_MARKOV_TRANSITION_MODEL_PRIOR_BUILDER_CONFIG = dict(
    object_cls=MarkovTransitionModelPrior,
    time_slicer=OCCUPANCY_MARKOV_TRANSITION_MODEL_BUILDER_CONFIG["time_slicer"],
    state_space=OCCUPANCY_MARKOV_TRANSITION_MODEL_BUILDER_CONFIG["state_space"],
    sample_time=OCCUPANCY_MARKOV_TRANSITION_MODEL_BUILDER_CONFIG["sample_time"],
    prior_weight_func=partial(exp_prior_weight_func, prior_weight_constant=1.2e-2)
)


class TransitionModelPriorBuilder(AbstractModelBuilder):

    def _get_object_base_cls(self):
        return AbstractTransitionModelPrior

    def _get_builder_config_types(self):
        builder_config_types = super(TransitionModelPriorBuilder, self)._get_builder_config_types()
        builder_config_types.update(prior_weight_func=Callable)
        return builder_config_types
