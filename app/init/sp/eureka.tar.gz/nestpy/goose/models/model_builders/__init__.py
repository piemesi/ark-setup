def prior_weight_func(count, prior_weight_constant):
    return np.e ** -(prior_weight_constant * count)
