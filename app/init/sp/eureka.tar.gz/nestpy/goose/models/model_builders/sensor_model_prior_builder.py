from collections import Callable
from functools import partial

from .sensor_model_builder import (
    OCCUPANCY_DIRICHLET_MULTINOMIAL_SENSOR_MODEL_BUILDER_CONFIG,
    OCCUPANCY_BOOLEAN_DIRICHLET_MULTINOMIAL_SENSOR_MODEL_BUILDER_CONFIG,
    OCCUPANCY_MULTI_SENSOR_MODEL_BUILDER_CONFIG,
    OCCUPANCY_COMBINED_SENSOR_MODEL_BUILDER_CONFIG
)
from ..abstract_model_builder import AbstractModelBuilder
from ..models.abstract_sensor_model_prior import AbstractSensorModelPrior, exp_prior_weight_func
from ..models.sensor_model_priors import (
    CombinedSensorModelPrior,
    DirichletMultinomialSensorModelPrior,
    MultiSensorModelPrior
)
from ...features.abstract_featurizer import AbstractFeaturizer
from ...sensors.abstract_sensor_type import AbstractSensorType


OCCUPANCY_DIRICHLET_MULTINOMIAL_SENSOR_MODEL_PRIOR_BUILDER_CONFIG = dict(
    object_cls=DirichletMultinomialSensorModelPrior,
    time_slicer=OCCUPANCY_DIRICHLET_MULTINOMIAL_SENSOR_MODEL_BUILDER_CONFIG["time_slicer"],
    state_space=OCCUPANCY_DIRICHLET_MULTINOMIAL_SENSOR_MODEL_BUILDER_CONFIG["state_space"],
    featurizer=OCCUPANCY_DIRICHLET_MULTINOMIAL_SENSOR_MODEL_BUILDER_CONFIG["featurizer"],
    prior_weight_func=partial(exp_prior_weight_func, prior_weight_constant=3e-3)
)

OCCUPANCY_BOOLEAN_DIRICHLET_MULTINOMIAL_SENSOR_MODEL_PRIOR_BUILDER_CONFIG = dict(
    object_cls=DirichletMultinomialSensorModelPrior,
    time_slicer=OCCUPANCY_BOOLEAN_DIRICHLET_MULTINOMIAL_SENSOR_MODEL_BUILDER_CONFIG["time_slicer"],
    state_space=OCCUPANCY_BOOLEAN_DIRICHLET_MULTINOMIAL_SENSOR_MODEL_BUILDER_CONFIG["state_space"],
    featurizer=OCCUPANCY_BOOLEAN_DIRICHLET_MULTINOMIAL_SENSOR_MODEL_BUILDER_CONFIG["featurizer"],
    prior_weight_func=partial(exp_prior_weight_func, prior_weight_constant=1.2e-2)
)

OCCUPANCY_MULTI_SENSOR_MODEL_PRIOR_BUILDER_CONFIG = dict(
    object_cls=MultiSensorModelPrior,
    time_slicer=OCCUPANCY_MULTI_SENSOR_MODEL_BUILDER_CONFIG["time_slicer"],
    state_space=OCCUPANCY_MULTI_SENSOR_MODEL_BUILDER_CONFIG["state_space"],
    featurizer=OCCUPANCY_MULTI_SENSOR_MODEL_BUILDER_CONFIG["featurizer"],
    prior_weight_func=partial(exp_prior_weight_func, prior_weight_constant=1.2e-2)
)

OCCUPANCY_COMBINED_SENSOR_MODEL_PRIOR_BUILDER_CONFIG = dict(
    object_cls=CombinedSensorModelPrior,
    time_slicer=OCCUPANCY_COMBINED_SENSOR_MODEL_BUILDER_CONFIG["time_slicer"],
    state_space=OCCUPANCY_COMBINED_SENSOR_MODEL_BUILDER_CONFIG["state_space"],
    featurizer=OCCUPANCY_COMBINED_SENSOR_MODEL_BUILDER_CONFIG["featurizer"],
    sensor_type_cls=OCCUPANCY_COMBINED_SENSOR_MODEL_BUILDER_CONFIG["sensor_type_cls"],
    overlap_timedelta=OCCUPANCY_COMBINED_SENSOR_MODEL_BUILDER_CONFIG["overlap_timedelta"],
    prior_weight_func=partial(exp_prior_weight_func, prior_weight_constant=1.667e-6)
)


class SensorModelPriorBuilder(AbstractModelBuilder):

    def _get_object_base_cls(self):
        return AbstractSensorModelPrior

    def _get_builder_config_types(self):
        builder_config_types = super(SensorModelPriorBuilder, self)._get_builder_config_types()
        builder_config_types.update(featurizer=AbstractFeaturizer, prior_weight_func=Callable)
        return builder_config_types

    def _get_build_kwargs_types(self):
        return dict(sensor_types=AbstractSensorType)
