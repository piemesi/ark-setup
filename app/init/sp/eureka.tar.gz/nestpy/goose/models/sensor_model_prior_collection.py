from .sensor_model_collection import SensorModelCollection
from .models.abstract_sensor_model_prior import AbstractSensorModelPrior
from ...validation.type_validation import assert_is_type, assert_list_of_type


class SensorModelPriorCollection(object):

    def __init__(self, sensor_model_priors):
        assert_list_of_type(sensor_model_priors, AbstractSensorModelPrior)
        self._sensor_model_priors = sensor_model_priors

    def __repr__(self):
        return "<{}>".format(self.__class__.__name__)

    def __hash__(self):
        return hash(self._keys)

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self._keys == other._keys

    def __ne__(self, other):
        return not self.__eq__(other)

    @property
    def _keys(self):
        return frozenset(self._sensor_model_priors)

    def get_sensor_model_prior_of_type(self, sensor_model_prior_cls, featurizer):
        for sensor_model_prior in self._sensor_model_priors:
            if (isinstance(sensor_model_prior, sensor_model_prior_cls) and
                    isinstance(sensor_model_prior.get_featurizer(), featurizer.__class__)):
                return sensor_model_prior

    def incorporate_sensor_model_collection(self, sensor_model_collection):
        assert_is_type(sensor_model_collection, SensorModelCollection)
        for sensor_model in sensor_model_collection.get_sensor_models():
            sensor_model_prior = self.get_sensor_model_prior_of_type(
                sensor_model_prior_cls=sensor_model.get_sensor_model_prior_cls(),
                featurizer=sensor_model.get_featurizer()
            )
            if sensor_model_prior is not None:
                sensor_model_prior.incorporate_sensor_models([sensor_model])

    def get_sensor_model_priors(self):
        return self._sensor_model_priors
