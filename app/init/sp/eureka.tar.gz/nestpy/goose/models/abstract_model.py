from abc import ABCMeta, abstractmethod

from ..environment import TimeSlicer
from ..states.state_space import StateSpace
from ...validation.type_validation import assert_is_type


class AbstractModel(object):
    """Core abstraction of the model classes.

    Models are initialized with a state space and optional time slicer. Implementation classes should implement
    a method that returns the learned parameters of the model.
    """
    __metaclass__ = ABCMeta

    def __init__(self, state_space, time_slicer=None):
        """Initializes a model object with a state space and optional time slicer.

        Args:
            state_space (StateSpace): state space
            time_slicer (TimeSlicer): time slicer (optional)
        """
        assert_is_type(state_space, StateSpace)
        if time_slicer is not None:
            assert_is_type(time_slicer, TimeSlicer)
        self._state_space = state_space
        self._time_slicer = time_slicer

    def __repr__(self):
        return "<{}>".format(self.__class__.__name__)

    def __hash__(self):
        return hash(self._keys)

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self._keys == other._keys

    def __ne__(self, other):
        return not self.__eq__(other)

    @property
    def _keys(self):
        return self._state_space, self._time_slicer

    def _assert_attributes_equal(self, other, attributes):
        for attribute in attributes:
            if getattr(self, attribute) != getattr(other, attribute):
                raise AssertionError("Attribute '{}' for '{}' and '{}' not equal.".format(attribute, self, other))

    @abstractmethod
    def get_parameters(self):
        """Method that returns the learned parameters of the model, to be defined by implementation classes.

        Returns:
            dict: the learned parameters of the model
        """
        raise NotImplementedError

    def get_state_space(self):
        return self._state_space

    def get_time_slicer(self):
        return self._time_slicer
