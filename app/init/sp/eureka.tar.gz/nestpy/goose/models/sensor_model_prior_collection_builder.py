from .sensor_model_prior_collection import SensorModelPriorCollection
from .model_builders.sensor_model_prior_builder import (
    SensorModelPriorBuilder,
    OCCUPANCY_DIRICHLET_MULTINOMIAL_SENSOR_MODEL_PRIOR_BUILDER_CONFIG,
    OCCUPANCY_BOOLEAN_DIRICHLET_MULTINOMIAL_SENSOR_MODEL_PRIOR_BUILDER_CONFIG,
    OCCUPANCY_MULTI_SENSOR_MODEL_PRIOR_BUILDER_CONFIG,
    OCCUPANCY_COMBINED_SENSOR_MODEL_PRIOR_BUILDER_CONFIG
)
from ..building import AbstractObjectBuilder
from ..sensors.sensor_types.boolean_sensor_types import (
    DIAMOND_PIR_SENSOR_TYPE,
    DIAMOND_DIAL_TOUCH_SENSOR_TYPE,
    FLINTSTONE_PIR_SENSOR_TYPE,
    PINNA_OPENCLOSE_SENSOR_TYPE,
    PINNA_PIR_SENSOR_TYPE,
    QUARTZ_MOTION_SENSOR_TYPE,
    QUARTZ_AUDIO_SENSOR_TYPE,
    TOPAZ_PIR_SENSOR_TYPE
)


OCCUPANCY_ALL_SENSOR_MODEL_PRIOR_COLLECTION_BUILDER_CONFIG = dict(
    object_cls=SensorModelPriorCollection,
    sensor_types=[
        DIAMOND_PIR_SENSOR_TYPE,
        DIAMOND_DIAL_TOUCH_SENSOR_TYPE,
        FLINTSTONE_PIR_SENSOR_TYPE,
        PINNA_OPENCLOSE_SENSOR_TYPE,
        PINNA_PIR_SENSOR_TYPE,
        QUARTZ_MOTION_SENSOR_TYPE,
        QUARTZ_AUDIO_SENSOR_TYPE,
        TOPAZ_PIR_SENSOR_TYPE
    ],
    sensor_model_prior_builders=[
        SensorModelPriorBuilder(**OCCUPANCY_DIRICHLET_MULTINOMIAL_SENSOR_MODEL_PRIOR_BUILDER_CONFIG),
        SensorModelPriorBuilder(**OCCUPANCY_BOOLEAN_DIRICHLET_MULTINOMIAL_SENSOR_MODEL_PRIOR_BUILDER_CONFIG),
        SensorModelPriorBuilder(**OCCUPANCY_MULTI_SENSOR_MODEL_PRIOR_BUILDER_CONFIG),
        SensorModelPriorBuilder(**OCCUPANCY_COMBINED_SENSOR_MODEL_PRIOR_BUILDER_CONFIG),
    ]
)


class SensorModelPriorCollectionBuilder(AbstractObjectBuilder):

    def _get_object_base_cls(self):
        return SensorModelPriorCollection

    def _get_builder_config_types(self):
        return dict(sensor_model_prior_builders=list)

    def build(self):
        sensor_types = self._builder_config.get('sensor_types')
        sensor_model_prior_builders = self._builder_config.get('sensor_model_prior_builders')
        sensor_model_priors = []
        for sensor_model_prior_builder in sensor_model_prior_builders:
            sensor_model_prior = sensor_model_prior_builder.build(sensor_types=sensor_types)
            sensor_model_priors.append(sensor_model_prior)
        return self._object_cls(sensor_model_priors=sensor_model_priors)
