import json

from ..building import AbstractObjectBuilder
from ..environment.object_builder import object_builder
from ..environment.workspace_builder import WorkspaceBuilder, GOOSE_WORKSPACE_BUILDER_CONFIG
from ..environment.workspaces.experiment_workspace_builder import (
    ExperimentWorkspaceBuilder,
    GOOSE_EXPERIMENT_WORKSPACE_BUILDER_CONFIG
)
from ..experimentation import ExperimentScheduler


class ExperimentSchedulerBuilder(AbstractObjectBuilder):

    def __init__(self, parallel=False):
        super(ExperimentSchedulerBuilder, self).__init__(object_cls=ExperimentScheduler, parallel=parallel)

    def _get_object_base_cls(self):
        return ExperimentScheduler

    def build(self, schedule_id, experiment_configs):
        experiments = []
        for experiment_config in experiment_configs:
            experiment_builder = experiment_config.pop('experiment_builder')
            experiment = experiment_builder.build(
                experiment_workspace_builder=ExperimentWorkspaceBuilder(
                    workspace_id=schedule_id,
                    **GOOSE_EXPERIMENT_WORKSPACE_BUILDER_CONFIG
                ),
                **experiment_config
            )
            experiments.append(experiment)
        workspace = WorkspaceBuilder(**GOOSE_WORKSPACE_BUILDER_CONFIG).build(workspace_id=schedule_id)
        experiment_scheduler = self._object_cls(workspace, experiments, self._builder_config['parallel'])
        return experiment_scheduler

    def build_from_json(self, schedule_id, json_path):
        with open(json_path) as json_file:
            json_data = json.load(json_file)
            experiment_configs = object_builder(json_data)
        return self.build(schedule_id, experiment_configs)
