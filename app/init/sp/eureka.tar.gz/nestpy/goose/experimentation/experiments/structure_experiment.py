from ..abstract_experiment import AbstractExperiment
from ...environment.workspace_cache import cache_to_workspace
from ....validation.type_validation import assert_is_type


class StructureExperiment(AbstractExperiment):

    def __init__(
            self,
            structure_id,
            tier,
            flintstone_device_ids=None,
            pinna_device_ids=None,
            *args,
            **kwargs
    ):
        kwargs.setdefault('experiment_id', structure_id)
        super(StructureExperiment, self).__init__(*args, **kwargs)
        assert_is_type(structure_id, int)
        assert_is_type(tier, basestring)
        self._structure_id = structure_id
        self._flintstone_device_ids = flintstone_device_ids or []
        self._pinna_device_ids = pinna_device_ids or []
        self._tier = tier

    def __repr__(self):
        return "<{}: structure_id={}>".format(self.__class__.__name__, self._structure_id)

    def _key(self):
        return super(StructureExperiment, self)._key() + (self._structure_id, self._tier)

    @cache_to_workspace(load_from_cache=True, save_to_cache=True)
    def _build_training_data_collection(self):
        training_data_collection = self._data_collection_builder.build(
            start_date=self._training_start_date,
            end_date=self._training_end_date,
            structure_id=self._structure_id,
            tier=self._tier,
            flintstone_device_ids=self._flintstone_device_ids,
            pinna_device_ids=self._pinna_device_ids,
        )
        return training_data_collection

    @cache_to_workspace(load_from_cache=True, save_to_cache=True)
    def _build_validation_data_collection(self):
        validation_data_collection = self._data_collection_builder.build(
            start_date=self._validation_start_date,
            end_date=self._validation_end_date,
            structure_id=self._structure_id,
            tier=self._tier,
            flintstone_device_ids=self._flintstone_device_ids,
            pinna_device_ids=self._pinna_device_ids,
        )
        return validation_data_collection

    def get_tier(self):
        return self._tier

    def get_structure_id(self):
        return self._structure_id
