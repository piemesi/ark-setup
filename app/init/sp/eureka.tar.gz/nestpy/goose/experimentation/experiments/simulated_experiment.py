from ..abstract_experiment import AbstractExperiment
from ...environment.workspace_cache import cache_to_workspace


class SimulatedExperiment(AbstractExperiment):

    def __init__(
            self,
            simulation_id,
            simulation_builder,
            *args,
            **kwargs
    ):
        super(SimulatedExperiment, self).__init__(
            experiment_id=kwargs.pop('experiment_id', simulation_id),
            *args,
            **kwargs
        )
        self._simulation_id = simulation_id
        self._simulation_builder = simulation_builder

    def __repr__(self):
        return "<{}: simulation_id={}>".format(self.__class__.__name__, self._simulation_id)

    def _key(self):
        return super(SimulatedExperiment, self)._key() + (self._simulation_id, self._simulation_builder)

    @cache_to_workspace(load_from_cache=True, save_to_cache=True)
    def _build_training_data_collection(self):
        training_data_collection = self._data_collection_builder.build(
            start_date=self._training_start_date,
            end_date=self._training_end_date,
            simulation_id=self._simulation_id,
            simulation_builder=self._simulation_builder
        )
        return training_data_collection

    @cache_to_workspace(load_from_cache=True, save_to_cache=True)
    def _build_validation_data_collection(self):
        validation_data_collection = self._data_collection_builder.build(
            start_date=self._validation_start_date,
            end_date=self._validation_end_date,
            simulation_id=self._simulation_id,
            simulation_builder=self._simulation_builder
        )
        return validation_data_collection

    def get_simulation_id(self):
        return self._simulation_id
