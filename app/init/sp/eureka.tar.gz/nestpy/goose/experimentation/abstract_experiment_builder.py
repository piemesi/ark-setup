import datetime

from abc import ABCMeta

from ..analysis.results_analysis_builder import OCCUPANCY_VALIDATION_RESULTS_ANALYSIS_BUILDER_CONFIG
from ..analysis.results_analysis_builder import ResultsAnalysisBuilder
from ..application_process.application_processor_results_builder import (
    ApplicationProcessorResultsBuilder,
    OCCUPANCY_APPLICATION_PROCESSOR_RESULTS_BUILDER_CONFIG
)
from ..application_process.application_processor_results_collection_builder import (
    ApplicationProcessorResultsCollectionBuilder,
    OCCUPANCY_APPLICATION_PROCESSOR_RESULTS_COLLECTION_BUILDER_CONFIG
)
from ..building import AbstractObjectBuilder
from ..data_collection.abstract_data_collection_builder import AbstractDataCollectionBuilder
from ..filter_process.filter_processor_results_builder import (
    FilterProcessorResultsBuilder,
    OCCUPANCY_FILTER_PROCESSOR_RESULTS_BUILDER_CONFIG
)
from ..models.sensor_model_collection_builder import (
    SensorModelCollectionBuilder,
    OCCUPANCY_MULTI_FAST_EXIT_SENSOR_MODEL_COLLECTION_BUILDER_CONFIG
)
from ..models.model_builders.transition_model_builder import (
    TransitionModelBuilder,
    OCCUPANCY_MARKOV_TRANSITION_MODEL_BUILDER_CONFIG
)
from ..sensors.sensor_events_collection_builder import (
    SensorEventsCollectionBuilder,
    OCCUPANCY_SENSOR_EVENTS_COLLECTION_BUILDER_CONFIG
)
from ..states.state_series_builders import DeviceAutoAwayStateSeriesBuilder
from ..states.state_series_builders.estimated_truth_state_series_builder import (
    EstimatedTruthStateSeriesBuilder,
    OCCUPANCY_ESTIMATED_TRUTH_STATE_SERIES_BUILDER_CONFIG
)
from ..visualization.visualizer_builders.results_visualizer_builders.training_results_visualizer_builder import (
    TrainingResultsVisualizerBuilder,
    OCCUPANCY_TRAINING_RESULTS_VISUALIZER_BUILDER_CONFIG
)
from ..visualization.visualizer_builders.results_visualizer_builders.validation_results_visualizer_builder import (
    ValidationResultsVisualizerBuilder,
    OCCUPANCY_VALIDATION_RESULTS_VISUALIZER_BUILDER_CONFIG
)
from ..visualization.visualizer_builders.results_analysis_visualizer_builders \
    .validation_results_analysis_visualizer_builder import (
        ValidationResultsAnalysisVisualizerBuilder,
        OCCUPANCY_VALIDATION_RESULTS_ANALYSIS_VISUALIZER_BUILDER_CONFIG
    )


OCCUPANCY_EXPERIMENT_BUILDER_CONFIG = dict(
    sensor_events_collection_builder=SensorEventsCollectionBuilder(
        **OCCUPANCY_SENSOR_EVENTS_COLLECTION_BUILDER_CONFIG
    ),
    state_series_builder=EstimatedTruthStateSeriesBuilder(
        **OCCUPANCY_ESTIMATED_TRUTH_STATE_SERIES_BUILDER_CONFIG
    ),
    device_auto_away_state_series_builder=DeviceAutoAwayStateSeriesBuilder(),
    transition_model_builder=TransitionModelBuilder(
        **OCCUPANCY_MARKOV_TRANSITION_MODEL_BUILDER_CONFIG
    ),
    sensor_model_collection_builder=SensorModelCollectionBuilder(
        **OCCUPANCY_MULTI_FAST_EXIT_SENSOR_MODEL_COLLECTION_BUILDER_CONFIG
    ),
    filter_processor_results_builder=FilterProcessorResultsBuilder(
        **OCCUPANCY_FILTER_PROCESSOR_RESULTS_BUILDER_CONFIG
    ),
    application_processor_results_builder=ApplicationProcessorResultsBuilder(
        **OCCUPANCY_APPLICATION_PROCESSOR_RESULTS_BUILDER_CONFIG
    ),
    application_processor_results_collection_builder=ApplicationProcessorResultsCollectionBuilder(
        **OCCUPANCY_APPLICATION_PROCESSOR_RESULTS_COLLECTION_BUILDER_CONFIG
    ),
    training_results_visualizer_builder=TrainingResultsVisualizerBuilder(
        **OCCUPANCY_TRAINING_RESULTS_VISUALIZER_BUILDER_CONFIG
    ),
    validation_results_visualizer_builder=ValidationResultsVisualizerBuilder(
        **OCCUPANCY_VALIDATION_RESULTS_VISUALIZER_BUILDER_CONFIG
    ),
    validation_results_analysis_builder=ResultsAnalysisBuilder(
        **OCCUPANCY_VALIDATION_RESULTS_ANALYSIS_BUILDER_CONFIG
    ),
    validation_results_analysis_visualizer_builder=ValidationResultsAnalysisVisualizerBuilder(
        **OCCUPANCY_VALIDATION_RESULTS_ANALYSIS_VISUALIZER_BUILDER_CONFIG
    )
)


class AbstractExperimentBuilder(AbstractObjectBuilder):
    __metaclass__ = ABCMeta

    def _get_builder_config_types(self):
        return dict(
            data_collection_builder=AbstractDataCollectionBuilder,
            sensor_events_collection_builder=SensorEventsCollectionBuilder,
            state_series_builder=EstimatedTruthStateSeriesBuilder,
            device_auto_away_state_series_builder=DeviceAutoAwayStateSeriesBuilder,
            transition_model_builder=TransitionModelBuilder,
            sensor_model_collection_builder=SensorModelCollectionBuilder,
            filter_processor_results_builder=FilterProcessorResultsBuilder,
            application_processor_results_builder=ApplicationProcessorResultsBuilder,
            application_processor_results_collection_builder=ApplicationProcessorResultsCollectionBuilder,
            training_results_visualizer_builder=TrainingResultsVisualizerBuilder,
            validation_results_visualizer_builder=ValidationResultsVisualizerBuilder,
            validation_results_analysis_builder=ResultsAnalysisBuilder,
            validation_results_analysis_visualizer_builder=ValidationResultsAnalysisVisualizerBuilder,
        )

    def _get_build_kwargs_types(self):
        return dict(
            training_start_date=datetime.datetime,
            training_end_date=datetime.datetime,
            validation_start_date=datetime.datetime,
            validation_end_date=datetime.datetime,
        )
