from ..environment.array_dict import ArrayDict
from ..environment.workspace import Workspace
from ..environment.workspace_cache import WorkspaceCache, cache_to_workspace
from ...validation.type_validation import assert_is_type


class MultiExperimentScheduler(object):

    def __init__(self, workspace, aggregate_visualizer_builder, experiment_scheduler_ad):
        assert_is_type(workspace, Workspace)
        assert_is_type(experiment_scheduler_ad, ArrayDict)
        self._workspace = workspace
        self._aggregate_visualizer_builder = aggregate_visualizer_builder
        self._experiment_scheduler_ad = experiment_scheduler_ad
        self._workspace_cache = WorkspaceCache(workspace=self._workspace)

    def run(self):
        experiment_results = ArrayDict(keys_matrix=self._experiment_scheduler_ad.keys_matrix)
        for key, experiment_scheduler in self._experiment_scheduler_ad.iteritems():
            experiment_results[key] = experiment_scheduler.run()
        self._aggregate_visualizer_builder.build(experiment_results, self._workspace).visualize()

    def get_workspace(self):
        return self._workspace

    def get_experiment_scheduler_ad(self):
        return self._experiment_scheduler_ad
