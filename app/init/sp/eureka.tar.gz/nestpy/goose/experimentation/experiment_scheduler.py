import logging
import random
import time

from .experiment_result import ExperimentResult
from ..environment.workspace import Workspace
from ..environment.workspace_cache import WorkspaceCache, cache_to_workspace
from ..visualization.visualization_browser_builder import VisualizationBrowserBuilder
from ...scriptutils import parallelize
from ...validation.type_validation import assert_is_type

logger = logging.getLogger(__name__)

_RUN_DELAY_SECONDS = 5


def _run_experiment(experiment):
    delay = random.random() * _RUN_DELAY_SECONDS
    logger.info("Waiting {} seconds before running {}".format(delay, experiment.get_experiment_id()))
    time.sleep(delay)
    try:
        logger.info("Running {}".format(experiment.get_experiment_id()))
        (
            training_results,
            validation_results,
            validation_results_analysis,
        ) = experiment.run()
        diagnostic_test_results = validation_results_analysis.get_goose_diagnostic_test_results()
        success = True
    except Exception, e:
        logger.exception(e)
        diagnostic_test_results = None
        success = False
    return ExperimentResult(
        experiment,
        diagnostic_test_results,
        success,
    )


class ExperimentScheduler(object):

    def __init__(self, workspace, experiments, parallel):
        assert_is_type(workspace, Workspace)
        self._workspace = workspace
        self._experiments = experiments
        self._parallel = parallel
        self._workspace_cache = WorkspaceCache(workspace=self._workspace)

    @cache_to_workspace(load_from_cache=True, save_to_cache=True)
    def _build_experiment_results(self):
        if self._parallel:
            experiment_results = self._parallel_run_experiments()
        else:
            experiment_results = self._serial_run_experiments()
        return experiment_results

    def run(self):
        experiment_results = self._build_experiment_results()
        self._generate_visualization_browser(experiment_results)
        return experiment_results

    def _serial_run_experiments(self):
        experiment_results = []
        for experiment in self._experiments:
            experiment_results.append(_run_experiment(experiment))
        return experiment_results

    def _parallel_run_experiments(self, threads=10):
        _, experiment_results = zip(*parallelize(self._experiments, threads, _run_experiment))
        return list(experiment_results)

    def _generate_visualization_browser(self, experiment_results):
        visualization_browser_builder = VisualizationBrowserBuilder(self._workspace, experiment_results)
        visualization_browser_builder.build_visualization_browser()

    def get_workspace(self):
        return self._workspace

    def get_experiments(self):
        return self._experiments
