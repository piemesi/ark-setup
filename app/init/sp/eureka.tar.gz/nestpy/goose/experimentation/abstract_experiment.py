from abc import ABCMeta, abstractmethod

from ..analysis.results_analysis_builder import ResultsAnalysisBuilder
from ..application_process.application_processor_results_builder import ApplicationProcessorResultsBuilder
from ..application_process.application_processor_results_collection_builder import (
    ApplicationProcessorResultsCollectionBuilder
)
from ..data_collection.abstract_data_collection_builder import AbstractDataCollectionBuilder
from ..environment.workspace_cache import WorkspaceCache, cache_to_workspace
from ..environment.workspaces.experiment_workspace_builder import ExperimentWorkspaceBuilder
from ..filter_process.filter_processor_results_builder import FilterProcessorResultsBuilder
from ..models.sensor_model_collection_builder import SensorModelCollectionBuilder
from ..models.model_builders.transition_model_builder import TransitionModelBuilder
from ..results.results_builders import TrainingResultsBuilder, ValidationResultsBuilder
from ..sensors.sensor_events_collection_builder import SensorEventsCollectionBuilder
from ..states.state_series_builders import DeviceAutoAwayStateSeriesBuilder, EstimatedTruthStateSeriesBuilder
from ..visualization.visualizer_builders.results_visualizer_builders import (
    TrainingResultsVisualizerBuilder,
    ValidationResultsVisualizerBuilder
)
from ..visualization.visualizer_builders.results_analysis_visualizer_builders\
    .validation_results_analysis_visualizer_builder import ValidationResultsAnalysisVisualizerBuilder
from ...validation.datetime_validation import assert_valid_start_and_end_dates
from ...validation.type_validation import assert_types, assert_type_in


class AbstractExperiment(object):
    __metaclass__ = ABCMeta

    def __init__(
            self,
            experiment_id,
            training_start_date,
            training_end_date,
            validation_start_date,
            validation_end_date,
            experiment_workspace_builder,
            data_collection_builder,
            sensor_events_collection_builder,
            state_series_builder,
            device_auto_away_state_series_builder,
            transition_model_builder,
            sensor_model_collection_builder,
            filter_processor_results_builder,
            application_processor_results_builder,
            application_processor_results_collection_builder,
            training_results_visualizer_builder,
            validation_results_visualizer_builder,
            validation_results_analysis_builder,
            validation_results_analysis_visualizer_builder
    ):
        assert_type_in(experiment_id, [basestring, int])
        assert_valid_start_and_end_dates(training_start_date, training_end_date)
        assert_valid_start_and_end_dates(validation_start_date, validation_end_date)
        assert_types([
            (experiment_workspace_builder, ExperimentWorkspaceBuilder),
            (data_collection_builder, AbstractDataCollectionBuilder),
            (sensor_events_collection_builder, SensorEventsCollectionBuilder),
            (state_series_builder, EstimatedTruthStateSeriesBuilder),
            (device_auto_away_state_series_builder, DeviceAutoAwayStateSeriesBuilder),
            (transition_model_builder, TransitionModelBuilder),
            (sensor_model_collection_builder, SensorModelCollectionBuilder),
            (filter_processor_results_builder, FilterProcessorResultsBuilder),
            (application_processor_results_builder, ApplicationProcessorResultsBuilder),
            (application_processor_results_collection_builder, ApplicationProcessorResultsCollectionBuilder),
            (training_results_visualizer_builder, TrainingResultsVisualizerBuilder),
            (validation_results_visualizer_builder, ValidationResultsVisualizerBuilder),
            (validation_results_analysis_builder, ResultsAnalysisBuilder),
            (validation_results_analysis_visualizer_builder, ValidationResultsAnalysisVisualizerBuilder),
        ])
        self._experiment_id = experiment_id
        self._training_start_date = training_start_date
        self._training_end_date = training_end_date
        self._validation_start_date = validation_start_date
        self._validation_end_date = validation_end_date
        self._experiment_workspace_builder = experiment_workspace_builder
        self._data_collection_builder = data_collection_builder
        self._sensor_events_collection_builder = sensor_events_collection_builder
        self._state_series_builder = state_series_builder
        self._device_auto_away_state_series_builder = device_auto_away_state_series_builder
        self._transition_model_builder = transition_model_builder
        self._sensor_model_collection_builder = sensor_model_collection_builder
        self._filter_processor_results_builder = filter_processor_results_builder
        self._application_processor_results_builder = application_processor_results_builder
        self._application_processor_results_collection_builder = application_processor_results_collection_builder
        self._training_results_visualizer_builder = training_results_visualizer_builder
        self._validation_results_visualizer_builder = validation_results_visualizer_builder
        self._validation_results_analysis_builder = validation_results_analysis_builder
        self._validation_results_analysis_visualizer_builder = validation_results_analysis_visualizer_builder
        self._experiment_workspace = self._build_experiment_workspace()
        self._workspace_cache = WorkspaceCache(workspace=self._experiment_workspace)

    def __repr__(self):
        return "<{}>".format(self.__class__.__name__)

    def __hash__(self):
        return hash(self._key())

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self._key() == other._key()

    def __ne__(self, other):
        return not self.__eq__(other)

    def _key(self):
        return (
            self._data_collection_builder,
            self._sensor_events_collection_builder,
            self._state_series_builder,
            self._device_auto_away_state_series_builder,
            self._transition_model_builder,
            self._sensor_model_collection_builder,
            self._filter_processor_results_builder,
            self._application_processor_results_builder,
            self._application_processor_results_collection_builder,
        )

    def run(self):
        training_results = self._build_training_results()
        training_results_visualizer = self._build_training_results_visualizer(
            experiment_workspace=self._experiment_workspace,
            training_results=training_results
        )
        training_results_visualizer.visualize()
        validation_results = self._build_validation_results(training_results)
        validation_results_visualizer = self._build_validation_results_visualizer(
            experiment_workspace=self._experiment_workspace,
            validation_results=validation_results
        )
        validation_results_visualizer.visualize()
        validation_results_analysis = self._build_validation_results_analysis(
            validation_results=validation_results,
            experiment_id=self._experiment_id
        )
        validation_results_analysis_visualizer = self._build_validation_results_analysis_visualizer(
            experiment_workspace=self._experiment_workspace,
            validation_results_analysis=validation_results_analysis
        )
        validation_results_analysis_visualizer.visualize()
        return training_results, validation_results, validation_results_analysis

    def _build_experiment_workspace(self):
        experiment_workspace = self._experiment_workspace_builder.build(experiment_id=self._experiment_id)
        return experiment_workspace

    @cache_to_workspace(load_from_cache=False, save_to_cache=False)
    def _build_sensor_events_collection(self, data_collection):
        sensor_events_collection = self._sensor_events_collection_builder.build(
            diamond_devices=data_collection.get_diamond_devices(),
            diamond_device_histories=data_collection.get_diamond_device_histories(),
            flintstone_devices=data_collection.get_flintstone_devices(),
            flintstone_device_histories=data_collection.get_flintstone_device_histories(),
            mobile_devices=data_collection.get_mobile_devices(),
            mobile_device_histories=data_collection.get_mobile_device_histories(),
            pinna_devices=data_collection.get_pinna_devices(),
            pinna_device_histories=data_collection.get_pinna_device_histories(),
            quartz_devices=data_collection.get_quartz_devices(),
            quartz_device_histories=data_collection.get_quartz_device_histories(),
            topaz_devices=data_collection.get_topaz_devices(),
            topaz_device_histories=data_collection.get_topaz_device_histories(),
        )
        return sensor_events_collection

    @cache_to_workspace(load_from_cache=False, save_to_cache=False)
    def _build_state_series(self, sensor_events_collection):
        state_series = self._state_series_builder.build(sensor_events_collection)
        return state_series

    @cache_to_workspace(load_from_cache=False, save_to_cache=False)
    def _build_device_auto_away_state_series(self, data_collection):
        device_auto_away_state_series = self._device_auto_away_state_series_builder.build(data_collection)
        return device_auto_away_state_series

    @cache_to_workspace(load_from_cache=False, save_to_cache=False)
    def _build_and_train_transition_model(self, state_series):
        transition_model = self._transition_model_builder.build()
        transition_model.train(state_series)
        return transition_model

    @cache_to_workspace(load_from_cache=False, save_to_cache=False)
    def _build_and_train_sensor_model_collection(self, state_series, sensor_events_collection):
        sensors = sensor_events_collection.get_sensors()
        sensor_model_collection = self._sensor_model_collection_builder.build(sensors)
        sensor_model_collection.train(state_series, sensor_events_collection)
        return sensor_model_collection

    @cache_to_workspace(load_from_cache=False, save_to_cache=False)
    def _build_filter_processor_results(self, transition_model, sensor_model_collection, sensor_events_collection):
        filter_processor_results = self._filter_processor_results_builder.build(
            transition_model=transition_model,
            sensor_model_collection=sensor_model_collection,
            sensor_events_collection=sensor_events_collection
        )
        return filter_processor_results

    @cache_to_workspace(load_from_cache=False, save_to_cache=False)
    def _build_application_processor_results(self, filter_processor_results):
        application_processor_results = self._application_processor_results_builder.build(filter_processor_results)
        return application_processor_results

    @cache_to_workspace(load_from_cache=False, save_to_cache=False)
    def _build_application_processor_results_collection(self, filter_processor_results):
        application_processor_results_collection = (
            self._application_processor_results_collection_builder.build(filter_processor_results)
        )
        return application_processor_results_collection

    @cache_to_workspace(load_from_cache=True, save_to_cache=True)
    def _build_validation_results_analysis(self, validation_results, experiment_id):
        validation_results_analysis_builder = self._validation_results_analysis_builder
        return validation_results_analysis_builder.build(results=validation_results, experiment_id=experiment_id)

    @staticmethod
    def _build_results(results_builder, *args, **kwargs):
        results = results_builder.build(*args, **kwargs)
        return results

    @abstractmethod
    def _build_training_data_collection(self):
        raise NotImplementedError

    @abstractmethod
    def _build_validation_data_collection(self):
        raise NotImplementedError

    @cache_to_workspace(load_from_cache=True, save_to_cache=True)
    def _build_training_results(self):
        training_data_collection = self._build_training_data_collection()
        sensor_events_collection = self._build_sensor_events_collection(training_data_collection)
        estimated_truth_state_series = self._build_state_series(sensor_events_collection)
        device_auto_away_state_series = self._build_device_auto_away_state_series(training_data_collection)
        transition_model = self._build_and_train_transition_model(estimated_truth_state_series)
        sensor_model_collection = self._build_and_train_sensor_model_collection(
            estimated_truth_state_series,
            sensor_events_collection
        )
        training_results = self._build_results(
            TrainingResultsBuilder(),
            experiment_id=self._experiment_id,
            data_collection=training_data_collection,
            sensor_events_collection=sensor_events_collection,
            transition_model=transition_model,
            sensor_model_collection=sensor_model_collection,
            estimated_truth_state_series=estimated_truth_state_series,
            ground_truth_state_series=training_data_collection.get_ground_truth_state_series(),
            device_auto_away_state_series=device_auto_away_state_series
        )
        return training_results

    @cache_to_workspace(load_from_cache=True, save_to_cache=True)
    def _build_validation_results(self, training_results):
        validation_data_collection = self._build_validation_data_collection()
        sensor_events_collection = self._build_sensor_events_collection(validation_data_collection)
        estimated_truth_state_series = self._build_state_series(sensor_events_collection)
        device_auto_away_state_series = self._build_device_auto_away_state_series(validation_data_collection)
        filter_processor_results = self._build_filter_processor_results(
            transition_model=training_results.get_transition_model(),
            sensor_model_collection=training_results.get_sensor_model_collection(),
            sensor_events_collection=sensor_events_collection,
        )
        application_processor_results = self._build_application_processor_results(filter_processor_results)
        application_processor_results_collection = self._build_application_processor_results_collection(
            filter_processor_results=filter_processor_results
        )
        validation_results = self._build_results(
            ValidationResultsBuilder(),
            experiment_id=self._experiment_id,
            data_collection=validation_data_collection,
            sensor_events_collection=sensor_events_collection,
            sensor_model_collection=training_results.get_sensor_model_collection(),
            filter_processor_results=filter_processor_results,
            application_processor_results=application_processor_results,
            application_processor_results_collection=application_processor_results_collection,
            estimated_truth_state_series=estimated_truth_state_series,
            ground_truth_state_series=validation_data_collection.get_ground_truth_state_series(),
            device_auto_away_state_series=device_auto_away_state_series
        )
        return validation_results

    @staticmethod
    def _build_experiment_cache(experiment_workspace):
        return WorkspaceCache(workspace=experiment_workspace)

    @cache_to_workspace(load_from_cache=False, save_to_cache=False)
    def _build_training_results_visualizer(self, experiment_workspace, training_results):
        results_visualizer = self._training_results_visualizer_builder.build(
            workspace=experiment_workspace,
            source_data=training_results
        )
        return results_visualizer

    @cache_to_workspace(load_from_cache=False, save_to_cache=False)
    def _build_validation_results_visualizer(self, experiment_workspace, validation_results):
        results_visualizer = self._validation_results_visualizer_builder.build(
            workspace=experiment_workspace,
            source_data=validation_results
        )
        return results_visualizer

    @cache_to_workspace(load_from_cache=False, save_to_cache=False)
    def _build_validation_results_analysis_visualizer(self, experiment_workspace, validation_results_analysis):
        results_analysis_visualizer = self._validation_results_analysis_visualizer_builder.build(
            workspace=experiment_workspace,
            source_data=validation_results_analysis
        )
        return results_analysis_visualizer

    def get_experiment_id(self):
        return self._experiment_id

    def get_training_start_date(self):
        return self._training_start_date

    def get_training_end_date(self):
        return self._training_end_date

    def get_validation_start_date(self):
        return self._validation_start_date
    
    def get_validation_end_date(self):
        return self._validation_end_date

    def get_experiment_workspace(self):
        return self._experiment_workspace
