from abc import ABCMeta
from types import NoneType

from .abstract_experiment import AbstractExperiment
from ..analysis.diagnostic_test_results import DiagnosticTestResults
from ...validation.type_validation import assert_is_type


class ExperimentResult(object):
    __metaclass__ = ABCMeta

    def __init__(
            self,
            experiment,
            diagnostic_test_results,
            success
    ):
        assert_is_type(experiment, AbstractExperiment)
        assert_is_type(success, bool)
        assert_is_type(diagnostic_test_results, (NoneType, DiagnosticTestResults))
        self._experiment = experiment
        self._diagnostic_test_results = diagnostic_test_results
        self._success = success

    def get_experiment(self):
        return self._experiment

    def get_diagnostic_test_results(self):
        return self._diagnostic_test_results

    def get_success(self):
        return self._success
