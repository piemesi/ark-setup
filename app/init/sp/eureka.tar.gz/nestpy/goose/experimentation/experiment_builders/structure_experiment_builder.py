from ..abstract_experiment_builder import AbstractExperimentBuilder, OCCUPANCY_EXPERIMENT_BUILDER_CONFIG
from ..experiments.structure_experiment import StructureExperiment
from ...building import extend_builder_config
from ...data_collection.data_collection_builders.structure_data_collection_builder import (
    StructureDataCollectionBuilder,
    OCCUPANCY_STRUCTURE_DATA_COLLECTION_BUILDER_CONFIG
)


OCCUPANCY_STRUCTURE_EXPERIMENT_BUILDER_CONFIG = extend_builder_config(
    OCCUPANCY_EXPERIMENT_BUILDER_CONFIG,
    object_cls=StructureExperiment,
    data_collection_builder=StructureDataCollectionBuilder(
        **OCCUPANCY_STRUCTURE_DATA_COLLECTION_BUILDER_CONFIG
    )
)


class StructureExperimentBuilder(AbstractExperimentBuilder):

    def _get_object_base_cls(self):
        return StructureExperiment

    def _get_build_kwargs_types(self):
        build_kwarg_types = super(StructureExperimentBuilder, self)._get_build_kwargs_types()
        build_kwarg_types.update(
            structure_id=int,
            tier=basestring,
        )
        return build_kwarg_types
