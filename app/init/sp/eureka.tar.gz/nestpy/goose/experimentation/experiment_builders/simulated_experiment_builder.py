from ..abstract_experiment_builder import AbstractExperimentBuilder, OCCUPANCY_EXPERIMENT_BUILDER_CONFIG
from ..experiments.simulated_experiment import SimulatedExperiment
from ...building import extend_builder_config
from ...data_collection.data_collection_builders.simulated_data_collection_builder import (
    SimulatedDataCollectionBuilder,
    OCCUPANCY_SIMULATED_DATA_COLLECTION_BUILDER_CONFIG
)
from ...simulation.simulation_builder import SimulationBuilder


OCCUPANCY_SIMULATED_EXPERIMENT_BUILDER_CONFIG = extend_builder_config(
    OCCUPANCY_EXPERIMENT_BUILDER_CONFIG,
    object_cls=SimulatedExperiment,
    data_collection_builder=SimulatedDataCollectionBuilder(
        **OCCUPANCY_SIMULATED_DATA_COLLECTION_BUILDER_CONFIG
    )
)


class SimulatedExperimentBuilder(AbstractExperimentBuilder):

    def _get_object_base_cls(self):
        return SimulatedExperiment

    def _get_build_kwargs_types(self):
        build_kwarg_types = super(SimulatedExperimentBuilder, self)._get_build_kwargs_types()
        build_kwarg_types.update(
            simulation_id=(basestring, int),
            simulation_builder=SimulationBuilder,
        )
        return build_kwarg_types
