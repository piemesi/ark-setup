from copy import deepcopy

from .multi_experiment_scheduler import MultiExperimentScheduler
from ..building import AbstractObjectBuilder
from ..environment.array_dict import ArrayDict
from ..environment.workspace_builder import WorkspaceBuilder, GOOSE_WORKSPACE_BUILDER_CONFIG
from ..experimentation.experiment_scheduler_builder import ExperimentSchedulerBuilder
from ..visualization.visualizer_builders.aggregate_visualizer_builder import (
    AggregateVisualizerBuilder,
    OCCUPANCY_AGGREGATE_VISUALIZER_BUILDER_CONFIG
)
from ...validation.type_validation import assert_is_type


OCCUPANCY_MULTI_EXPERIMENT_SCHEDULER_BUILDER_CONFIG = dict(
    object_cls=MultiExperimentScheduler,
    aggregate_visualizer_builder=AggregateVisualizerBuilder(
        **OCCUPANCY_AGGREGATE_VISUALIZER_BUILDER_CONFIG
    ),
    parallel=False,
)


class MultiExperimentSchedulerBuilder(AbstractObjectBuilder):

    def _get_object_base_cls(self):
        return MultiExperimentScheduler

    def _get_builder_config_types(self):
        return dict(
            aggregate_visualizer_builder=AggregateVisualizerBuilder,
            parallel=bool,
        )

    def build(self, multi_schedule_id, experiment_scheduler_ad):
        workspace = WorkspaceBuilder(**GOOSE_WORKSPACE_BUILDER_CONFIG).build(workspace_id=multi_schedule_id)
        aggregate_visualizer_builder = self._builder_config['aggregate_visualizer_builder']
        multi_experiment_scheduler = self._object_cls(workspace, aggregate_visualizer_builder, experiment_scheduler_ad)
        return multi_experiment_scheduler

    def build_from_experiment_scheduler(self, experiment_scheduler):
        key = experiment_scheduler.get_workspace().get_workspace_id()
        experiment_scheduler_ad = ArrayDict({key: experiment_scheduler})
        return self.build(key, experiment_scheduler_ad)

    def build_from_builders_instances(self, multi_schedule_id, builders, instances, instance_common_kwargs=None):
        instance_common_kwargs = instance_common_kwargs or {}
        experiment_scheduler_ad = ArrayDict(keys_matrix=builders.keys_matrix)
        for key, builder in builders.iteritems():
            for build_kwargs in instances:
                build_kwargs.update(
                    experiment_builder=builder,
                    **instance_common_kwargs
                )
            experiment_scheduler_ad[key] = ExperimentSchedulerBuilder(
                parallel=self._builder_config['parallel']
            ).build('{}__{}'.format(multi_schedule_id, key), instances)
        return self.build(multi_schedule_id, experiment_scheduler_ad)

    def build_from_builders_instances_params(
            self,
            multi_schedule_id,
            builders,
            instances,
            param_lists,
            builder_order=None,
            param_order=None,
            instance_common_kwargs=None
    ):
        assert_is_type(param_lists, dict)
        assert_is_type(builders, dict)
        param_order = param_order or param_lists.keys()
        builder_order = builder_order or builders.keys()
        builders_out = {}
        keys_matrix = []

        for param_name in param_order:
            params = param_lists[param_name]
            arrangement_row = []
            for build_name in builder_order:
                builder = deepcopy(builders[build_name])
                if not isinstance(params, list):
                    params = [params]
                for p in params:
                    builder = builder.new_builder_with_parameter(**p)
                key = "{}_{}".format(build_name, param_name)
                arrangement_row.append(key)
                builders_out[key] = builder
            keys_matrix.append(arrangement_row)
        return self.build_from_builders_instances(
            multi_schedule_id,
            ArrayDict(builders_out, keys_matrix=keys_matrix),
            instances,
            instance_common_kwargs=instance_common_kwargs
        )

    def build_from_builder_instances_params(
            self,
            multi_schedule_id,
            builder,
            instances,
            param_lists,
            param_arrangement=None,
            instance_common_kwargs=None
    ):
        assert_is_type(param_lists, dict)
        builders_out = {}
        keys_matrix = []

        for param_row in param_arrangement:
            arrangement_row = []
            for param_name in param_row:
                params = param_lists[param_name]
                builder = deepcopy(builder)
                if not isinstance(params, list):
                    params = [params]
                for p in params:
                    builder = builder.new_builder_with_parameter(**p)
                arrangement_row.append(param_name)
                builders_out[param_name] = builder
            keys_matrix.append(arrangement_row)
        return self.build_from_builders_instances(
            multi_schedule_id,
            ArrayDict(builders_out, keys_matrix=keys_matrix),
            instances,
            instance_common_kwargs=instance_common_kwargs
        )
