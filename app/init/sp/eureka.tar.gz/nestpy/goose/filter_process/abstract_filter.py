from abc import ABCMeta, abstractmethod

from ..states.state_spaces.goose_state_space import GOOSEStateSpace
from ...validation.type_validation import assert_is_type


class AbstractFilter(object):
    __metaclass__ = ABCMeta

    def __init__(self, state_space, lower_clip):
        assert_is_type(state_space, GOOSEStateSpace)
        assert_is_type(lower_clip, float)
        self._state_space = state_space
        self._lower_clip = lower_clip

    @staticmethod
    def _normalize_probabilities(probabilities):
        return probabilities / probabilities.sum()

    @classmethod
    def _lower_clip_and_normalize_probabilities(cls, probabilities, lower_clip):
        clipped_probabilities = cls._normalize_probabilities(probabilities)
        clipped_probabilities[clipped_probabilities <= lower_clip] = lower_clip
        clipped_probabilities[clipped_probabilities > lower_clip] = (
            (1 - clipped_probabilities.tolist().count(lower_clip) * lower_clip) *
            clipped_probabilities[clipped_probabilities > lower_clip]
        )
        return clipped_probabilities

    def incorporate_any_presence(self, belief_probabilities, any_presence):
        vacant_state_label = self._state_space.get_vacant_state().get_state_label()
        updated_belief_probabilities = belief_probabilities.copy()
        if any_presence:
            updated_belief_probabilities.loc[vacant_state_label] = 0.0
        return self._lower_clip_and_normalize_probabilities(updated_belief_probabilities, self._lower_clip)

    @abstractmethod
    def process_sensor_update(self, belief_probabilities, sensor_probabilities):
        raise NotImplementedError

    @abstractmethod
    def process_transition_update(self, belief_probabilities, transition_probability_matrix):
        raise NotImplementedError

    def get_state_space(self):
        return self._state_space

    def get_lower_clip(self):
        return self._lower_clip
