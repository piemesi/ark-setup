import itertools
import logging
import operator
import pandas as pd

from .abstract_filter import AbstractFilter
from ..models.sensor_model_collection import SensorModelCollection
from ..models.models.abstract_transition_model import AbstractTransitionModel
from ..sensors import SensorEventsCollection, SensorStateCollection
from ..sensors.abstract_sensor_type import AbstractSensorType
from ..sensors.sensor_types.boolean_sensor_types import PresenceSensorType
from ...validation.type_validation import assert_is_type, assert_list_of_type

logger = logging.getLogger(__name__)


class FilterProcessor(object):

    def __init__(self, state_space, sensor_types, filter, transition_model, sensor_model_collection):
        self._validate_filter(state_space, filter)
        assert_list_of_type(sensor_types, AbstractSensorType)
        self._validate_transition_model(state_space, transition_model)
        self._validate_sensor_model_collection(state_space, sensor_model_collection)
        self._state_space = state_space
        self._sensor_types = sensor_types
        self._filter = filter
        self._transition_model = transition_model
        self._sensor_model_collection = sensor_model_collection

    def __repr__(self):
        return "<{}>".format(self.__class__.__name__)

    @staticmethod
    def _validate_filter(state_space, filter):
        assert_is_type(filter, AbstractFilter)
        if filter.get_state_space() != state_space:
            raise ValueError("State space of filter needs to be the same as specified state space")

    @staticmethod
    def _validate_transition_model(state_space, transition_model):
        assert_is_type(transition_model, AbstractTransitionModel)
        if transition_model.get_state_space() != state_space:
            raise ValueError("State space of transition model needs to be the same as specified state space")

    @staticmethod
    def _validate_sensor_model_collection(state_space, sensor_model_collection):
        assert_is_type(sensor_model_collection, SensorModelCollection)
        for sensor_model in sensor_model_collection.get_sensor_models():
            if sensor_model.get_state_space() != state_space:
                raise ValueError("State space of sensor models need to be the same as specified state space")

    def _validate_belief_probabilities(self, belief_probabilities):
        assert_is_type(belief_probabilities, pd.Series)
        for state_label in belief_probabilities.index:
            if not self._state_space.has_state_label(state_label):
                raise ValueError("State label '{}' not found in specified state space.".format(state_label))
        if belief_probabilities.sum() != 1:
            raise ValueError("Belief probabilities must add up to one.")

    @staticmethod
    def _log_transition_update(timestamp, transition_probability_matrix):
        logger.debug(
            "{timestamp}: Processing transition update '{transition_update}'".format(
                timestamp=timestamp,
                transition_update=transition_probability_matrix.to_dict()
            )
        )

    @staticmethod
    def _log_sensor_update(timestamp, sensor_probabilities):
        logger.debug(
            "{timestamp}: Processing sensor update '{sensor_update}'".format(
                timestamp=timestamp,
                sensor_update=sensor_probabilities.to_dict()
            )
        )

    @staticmethod
    def _log_belief_probabilities(timestamp, belief_probabilities):
        logger.debug(
            "{timestamp}: Updated belief probabilities '{belief_probabilities}'".format(
                timestamp=timestamp,
                belief_probabilities=belief_probabilities.to_dict()
            )
        )

    @staticmethod
    def _any_presence(sensor_state_collection, timestamp):
        presence_sensor_states = filter(
            lambda sensor_state: isinstance(sensor_state.get_sensor().get_sensor_type(), PresenceSensorType),
            sensor_state_collection.get_sensor_states()
        )
        for presence_sensor_state in presence_sensor_states:
            if presence_sensor_state.is_online(timestamp) and presence_sensor_state.is_enabled():
                return True
        return False

    def _compute_sensor_updates(self, sensor_state_collection, previous_update_timestamp, update_timestamp):
        sensor_updates = []
        sensor_models = self._sensor_model_collection.get_sensor_models()
        for sensor_model in sensor_models:
            sensor_probabilities_sequence = sensor_model.compute_sensor_updates(
                sensor_state_collection=sensor_state_collection,
                previous_update_timestamp=previous_update_timestamp,
                current_update_timestamp=update_timestamp
            )
            sensor_updates += sensor_probabilities_sequence
        return sensor_updates

    def _compute_transition_updates(self, previous_update_timestamp, update_timestamp):
        transition_updates = self._transition_model.compute_transition_updates(
            previous_update_timestamp=previous_update_timestamp,
            current_update_timestamp=update_timestamp
        )
        return transition_updates

    def _process_updates(self, initial_belief_probabilities, sensor_updates, transition_updates):
        grouped_sensor_updates = map(
            lambda (timestamp, iterable): (timestamp, map(operator.itemgetter(1), iterable)),
            itertools.groupby(sensor_updates, operator.itemgetter(0))
        )
        grouped_sensor_update_timestamps = map(operator.itemgetter(0), grouped_sensor_updates)
        transition_update_timestamps = map(operator.itemgetter(0), transition_updates)
        belief_probabilities_sequence = []
        for update_timestamp in sorted(set(grouped_sensor_update_timestamps) | set(transition_update_timestamps)):
            belief_probabilities = self._get_latest_belief_probabilities(
                initial_belief_probabilities=initial_belief_probabilities,
                belief_probabilities_sequence=belief_probabilities_sequence
            )
            if update_timestamp in transition_update_timestamps:
                transition_probability_matrix = dict(transition_updates)[update_timestamp]
                self._log_transition_update(update_timestamp, transition_probability_matrix)
                belief_probabilities = self._filter.process_transition_update(
                    belief_probabilities=belief_probabilities,
                    transition_probability_matrix=transition_probability_matrix
                )
                self._log_belief_probabilities(update_timestamp, belief_probabilities)
            if update_timestamp in grouped_sensor_update_timestamps:
                for sensor_probabilities in dict(grouped_sensor_updates)[update_timestamp]:
                    self._log_sensor_update(update_timestamp, sensor_probabilities)
                    belief_probabilities = self._filter.process_sensor_update(
                        belief_probabilities=belief_probabilities,
                        sensor_probabilities=sensor_probabilities
                    )
                    self._log_belief_probabilities(update_timestamp, belief_probabilities)
            belief_probabilities_sequence.append((update_timestamp, belief_probabilities))
        return belief_probabilities_sequence

    @staticmethod
    def _get_latest_belief_probabilities(initial_belief_probabilities, belief_probabilities_sequence):
        if belief_probabilities_sequence:
            latest_belief_probabilities = belief_probabilities_sequence[-1][1]
        else:
            latest_belief_probabilities = initial_belief_probabilities
        return latest_belief_probabilities

    @staticmethod
    def _compute_reporting_events(sensor_events):
        sensor = sensor_events.get_sensor()
        sensor_reporting_policy = sensor.get_sensor_reporting_policy()
        return sensor, sensor_reporting_policy.compute_reporting_events(sensor_events.get_series())

    def compute_belief_probabilities_sequence(self, initial_belief_probabilities, sensor_events_collection):
        assert_is_type(sensor_events_collection, SensorEventsCollection)
        self._validate_belief_probabilities(initial_belief_probabilities)

        reporting_frame = pd.DataFrame(
            {
                sensor: reporting_events
                for sensor, reporting_events in map(
                    self._compute_reporting_events,
                    sensor_events_collection.get_sensor_events_list_for_sensor_types(self._sensor_types)
                )
                if not reporting_events.empty
            }
        )
        sensors = map(
            lambda sensor_events: sensor_events.get_sensor(),
            sensor_events_collection.get_sensor_events_list()
        )
        sensor_state_collection = SensorStateCollection(sensors)

        internal_belief_probabilities_sequence = []
        belief_probabilities_sequence = []

        for index, (reporting_timestamp, reporting_series) in enumerate(reporting_frame.iterrows()):
            reporting_sensors = reporting_series[reporting_series.notnull()].index.tolist()
            for reporting_sensor in reporting_sensors:
                reporting_event = reporting_series.loc[reporting_sensor]
                sensor_state_collection.update_sensor_state_for_sensor(
                    sensor=reporting_sensor,
                    timestamp=reporting_timestamp,
                    reporting_event=reporting_event
                )
            if index > 0:
                previous_reporting_timestamp = reporting_frame.index[index - 1]
                latest_belief_probabilities = self._get_latest_belief_probabilities(
                    initial_belief_probabilities=initial_belief_probabilities,
                    belief_probabilities_sequence=internal_belief_probabilities_sequence
                )
                sensor_updates = self._compute_sensor_updates(
                    sensor_state_collection=sensor_state_collection,
                    previous_update_timestamp=previous_reporting_timestamp,
                    update_timestamp=reporting_timestamp
                )
                transition_updates = self._compute_transition_updates(
                    previous_update_timestamp=previous_reporting_timestamp,
                    update_timestamp=reporting_timestamp
                )
                belief_probabilities_sequence_updates = self._process_updates(
                    initial_belief_probabilities=latest_belief_probabilities,
                    sensor_updates=sensor_updates,
                    transition_updates=transition_updates
                )
                internal_belief_probabilities_sequence += belief_probabilities_sequence_updates
                current_belief_probabilities = self._get_latest_belief_probabilities(
                    initial_belief_probabilities=initial_belief_probabilities,
                    belief_probabilities_sequence=internal_belief_probabilities_sequence
                )
                belief_probabilities_sequence.append(
                    (
                        reporting_timestamp,
                        self._filter.incorporate_any_presence(
                            current_belief_probabilities,
                            self._any_presence(sensor_state_collection, reporting_timestamp)
                        )
                    )
                )
        return pd.DataFrame.from_dict(dict(belief_probabilities_sequence), orient="index")

    def get_state_space(self):
        return self._state_space

    def get_sensor_types(self):
        return self._sensor_types

    def get_filter(self):
        return self._filter

    def get_transition_model(self):
        return self._transition_model

    def get_sensor_model_collection(self):
        return self._sensor_model_collection
