from ..abstract_filter import AbstractFilter


class DiscreteBayesFilter(AbstractFilter):

    def process_sensor_update(self, belief_probabilities, sensor_probabilities):
        if sensor_probabilities.sum() == 0:
            updated_belief_probabilities = belief_probabilities
        else:
            updated_belief_probabilities = self._lower_clip_and_normalize_probabilities(
                belief_probabilities * sensor_probabilities,
                self._lower_clip
            )
        return updated_belief_probabilities

    def process_transition_update(self, belief_probabilities, transition_probability_matrix):
        updated_belief_probabilities = self._lower_clip_and_normalize_probabilities(
            transition_probability_matrix.T.dot(belief_probabilities),
            self._lower_clip
        )
        return updated_belief_probabilities
