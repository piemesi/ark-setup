import pandas as pd

from .abstract_filter import AbstractFilter
from .filters import DiscreteBayesFilter
from .filter_processor import FilterProcessor
from .filter_processor_results import FilterProcessorResults
from ..building import AbstractObjectBuilder
from ..sensors.sensor_types.boolean_sensor_types import (
    DIAMOND_PIR_SENSOR_TYPE,
    DIAMOND_DIAL_TOUCH_SENSOR_TYPE,
    FLINTSTONE_PIR_SENSOR_TYPE,
    MOBILE_DEVICE_MDL_SENSOR_TYPE,
    PINNA_OPENCLOSE_SENSOR_TYPE,
    PINNA_PIR_SENSOR_TYPE,
    QUARTZ_MOTION_SENSOR_TYPE,
    QUARTZ_AUDIO_SENSOR_TYPE,
    TOPAZ_PIR_SENSOR_TYPE
)
from ..states.state_space import StateSpace
from ..states.state_spaces import OCCUPANCY_STATE_SPACE


OCCUPANCY_FILTER_PROCESSOR_RESULTS_BUILDER_CONFIG = dict(
    object_cls=FilterProcessorResults,
    state_space=OCCUPANCY_STATE_SPACE,
    sensor_types=[
        DIAMOND_PIR_SENSOR_TYPE,
        DIAMOND_DIAL_TOUCH_SENSOR_TYPE,
        FLINTSTONE_PIR_SENSOR_TYPE,
        MOBILE_DEVICE_MDL_SENSOR_TYPE,
        PINNA_PIR_SENSOR_TYPE,
        PINNA_OPENCLOSE_SENSOR_TYPE,
        QUARTZ_MOTION_SENSOR_TYPE,
        QUARTZ_AUDIO_SENSOR_TYPE,
        TOPAZ_PIR_SENSOR_TYPE
    ],
    filter=DiscreteBayesFilter(
        state_space=OCCUPANCY_STATE_SPACE,
        lower_clip=1e-9
    ),
    initial_belief_probabilities=pd.Series(
        index=OCCUPANCY_STATE_SPACE.get_state_labels(),
        data=(1. / len(OCCUPANCY_STATE_SPACE))
    )
)


class FilterProcessorResultsBuilder(AbstractObjectBuilder):

    def _get_object_base_cls(self):
        return FilterProcessorResults

    def _get_builder_config_types(self):
        return dict(
            state_space=StateSpace,
            filter=AbstractFilter,
            initial_belief_probabilities=pd.Series
        )

    def build(self, transition_model, sensor_model_collection, sensor_events_collection):
        filter_processor = FilterProcessor(
            state_space=self._builder_config['state_space'],
            sensor_types=self._builder_config['sensor_types'],
            filter=self._builder_config['filter'],
            transition_model=transition_model,
            sensor_model_collection=sensor_model_collection
        )
        belief_probabilities_sequence = filter_processor.compute_belief_probabilities_sequence(
            initial_belief_probabilities=self._builder_config['initial_belief_probabilities'],
            sensor_events_collection=sensor_events_collection
        )
        return self._object_cls(
            state_space=self._builder_config['state_space'],
            sensor_types=self._builder_config['sensor_types'],
            belief_probabilities_sequence=belief_probabilities_sequence
        )
