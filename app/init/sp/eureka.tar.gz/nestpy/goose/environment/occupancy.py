class Occupancy(object):

    Active = 0
    Passive = 1
    Sleep = 2
    Vacant = 3

    @classmethod
    def states(cls):
        return [cls.Active, cls.Passive, cls.Sleep, cls.Vacant]

    @classmethod
    def name(cls, state):

        if state == cls.Active:
            return 'Active'
        if state == cls.Passive:
            return 'Passive'
        if state == cls.Sleep:
            return 'Sleep'
        if state == cls.Vacant:
            return 'Vacant'
