import dill
import functools
import logging
import os

from abc import ABCMeta

from . import Workspace
from ...validation.type_validation import assert_is_type

logger = logging.getLogger(__name__)


def cache_to_workspace(key=None, arg_names=None, load_from_cache=True, save_to_cache=True):
    """Decorator which caches the output of a particular method to the workspace.

    Args:
        key (str): Key used for creating the file name, defaults to class and function name
        arg_names (list of str): Names of arguments whose values will be added to the file name
        load_from_cache (bool): If True (default) load cache if present and build it if not. If False, do not load
                                cache and *overwrite cache with new result*
        save_to_cache (bool): If True (default) save to cache. If False, do not save to cache

    Returns:
        _cache_to_workspace (function): Decorator factory function
    """
    def _cache_to_workspace(method):
        @functools.wraps(method)
        def wrapped(self, *args, **kwargs):
            cache_key = key if key is not None else "{}.{}".format(self.__class__.__name__, method.func_name)
            if arg_names is not None:
                cache_key += "({})".format(
                    ", ".join(map(lambda arg_name: "{}={}".format(arg_name, kwargs.get(arg_name)), arg_names))
                )
            obj = None
            if load_from_cache:
                logger.info("Trying to load '{}' for '{}'".format(cache_key, self))
                obj = self._workspace_cache.load_object(cache_key)
            if obj is None:
                logger.info("Building '{}' for '{}'".format(cache_key, self))
                obj = method(self, *args, **kwargs)
                if save_to_cache:
                    logger.info("Caching '{}' for '{}'".format(cache_key, self))
                    self._workspace_cache.save_object(cache_key, obj)
            else:
                logger.info("Loaded '{}' for '{}'".format(cache_key, self))
            return obj
        return wrapped
    return _cache_to_workspace


class WorkspaceCache(object):
    __metaclass__ = ABCMeta

    def __init__(self, workspace):
        assert_is_type(workspace, Workspace)
        self._workspace = workspace

    def _get_cache_path(self, key):
        return os.path.join(
            self._workspace.get_data_path(),
            "{}.pickle".format(key)
        )

    def save_object(self, key, obj):
        dill.dump(
            obj=obj,
            file=open(self._get_cache_path(key), "wb"),
            protocol=dill.HIGHEST_PROTOCOL
        )

    def load_object(self, key):
        if os.path.exists(self._get_cache_path(key)):
            return dill.load(open(self._get_cache_path(key), "rb"))
        else:
            return None
