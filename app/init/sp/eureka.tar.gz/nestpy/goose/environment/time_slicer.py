import datetime
import numpy as np

from nestpy.validation.type_validation import assert_is_type


class TimeSlicer(object):

    _DAY_TIMEDELTA = datetime.timedelta(days=1)

    def __init__(self, time_slices_per_day):
        self._validate_time_slices_per_day(time_slices_per_day)
        self._time_slices_per_day = time_slices_per_day
        self._timedelta_per_time_slice = self._DAY_TIMEDELTA / self._time_slices_per_day

    def __repr__(self):
        return "<{}: time_slices_per_day={}>".format(
            self.__class__.__name__,
            self._time_slices_per_day
        )

    def __hash__(self):
        return hash(self._key())

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self._key() == other._key()

    def __ne__(self, other):
        return not self.__eq__(other)

    def _key(self):
        return self._time_slices_per_day

    @staticmethod
    def _validate_time_slices_per_day(time_slices_per_day):
        assert_is_type(time_slices_per_day, int)
        if not time_slices_per_day >= 1:
            raise ValueError("Time slices per day must be greater than or equal to 1")

    def _get_days_of_week(self, time_slice_index):
        if time_slice_index < self._time_slices_per_day:
            days_of_week = range(5)
        else:
            days_of_week = range(5, 7)
        return days_of_week

    def get_time_slice_index(self, timestamp):
        timedelta = datetime.timedelta(
            hours=timestamp.hour,
            minutes=timestamp.minute,
            seconds=timestamp.second,
            microseconds=long(timestamp.microsecond)
        )
        time_slice_index = int(timedelta.total_seconds() / self._timedelta_per_time_slice.total_seconds())
        if timestamp.weekday() in range(5, 7):
            time_slice_index += self._time_slices_per_day
        return time_slice_index

    def get_time_slice_indices(self):
        time_slice_indices = range(2 * self._time_slices_per_day)
        return time_slice_indices

    def get_weekday_time_slice_indices(self):
        time_slice_indices = range(self._time_slices_per_day)
        return time_slice_indices

    def get_weekend_time_slice_indices(self):
        time_slice_indices = range(self._time_slices_per_day, 2 * self._time_slices_per_day)
        return time_slice_indices

    def get_time_slice(self, time_slice_index):
        time_slice_count = np.mod(time_slice_index, self._time_slices_per_day)
        time_slice_start = (datetime.datetime.min + time_slice_count * self._timedelta_per_time_slice).time()
        time_slice_end = (datetime.datetime.min + (time_slice_count + 1) * self._timedelta_per_time_slice).time()
        days_of_week = self._get_days_of_week(time_slice_index)
        return time_slice_start, time_slice_end, days_of_week

    def get_time_slices(self):
        time_slices = []
        for time_slice_index in self.get_time_slice_indices():
            time_slices.append(self.get_time_slice(time_slice_index))
        return time_slices

    def get_time_sliced_series(self, series, time_slice_index):
        if not series.empty:
            time_slice_start, time_slice_end, days_of_week = self.get_time_slice(time_slice_index)
            time_sliced_series = series[np.in1d(series.index.dayofweek, days_of_week)]
            if self._time_slices_per_day > 1 and not time_sliced_series.empty:
                time_sliced_series = time_sliced_series.between_time(
                    time_slice_start,
                    time_slice_end,
                    include_end=False
                )
        else:
            time_sliced_series = series
        return time_sliced_series

    def get_time_slices_per_day(self):
        return self._time_slices_per_day

    def get_timedelta_per_time_slice(self):
        return self._timedelta_per_time_slice
