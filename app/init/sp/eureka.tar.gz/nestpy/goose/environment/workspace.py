import os
import shutil

from ...validation.type_validation import assert_is_type, assert_type_in


class Workspace(object):

    _PLOTS = "plots"
    _DATA = "data"

    def __init__(self, root_path, workspace_id):
        assert_is_type(root_path, basestring)
        assert_type_in(workspace_id, [basestring, int])
        self._root_path = root_path
        self._workspace_id = workspace_id

    def __repr__(self):
        return "<{}>".format(self.__class__.__name__)

    @staticmethod
    def _initialize_path(path):
        if not os.path.exists(path):
            os.makedirs(path)

    def _get_base_path(self):
        return os.path.join(self._root_path, str(self._workspace_id))

    def tear_down(self):
        if os.path.exists(self._get_base_path()):
            shutil.rmtree(self._get_base_path())

    def get_path(self, *path_args):
        path = os.path.join(self._get_base_path(), *path_args)
        self._initialize_path(path)
        return path

    def get_base_path(self):
        return self.get_path()

    def get_root_path(self):
        return self._root_path

    def get_workspace_id(self):
        return self._workspace_id

    def get_data_path(self):
        return self.get_path(self._DATA)

    def get_plots_path(self):
        return self.get_path(self._PLOTS)
