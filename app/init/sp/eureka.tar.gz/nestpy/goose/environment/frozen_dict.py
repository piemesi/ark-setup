import itertools

from collections import Mapping


class FrozenDict(Mapping):

    def __init__(self, *args, **kwargs):
        self._dict = dict(*args, **kwargs)

    def __repr__(self):
        return "{}({})".format(self.__class__.__name__, self._dict)

    def __hash__(self):
        return hash(frozenset(self._dict.items()))

    def __iter__(self):
        return iter(self._dict)

    def __len__(self):
        return len(self._dict)

    def __getitem__(self, key):
        return self._dict[key]

    def agg_by_mapped_items(self, mapping_func, agg_func):
        return FrozenDict(
            map(
                lambda (key, grouper): (key, agg_func(list(grouper))),
                itertools.groupby(sorted(self.items(), key=lambda item: hash(mapping_func(item))), mapping_func)
            )
        )
