import importlib


def _import_from_name(name):
    module_name, cls_name = name.rsplit(".", 1)
    return getattr(importlib.import_module(module_name), cls_name)


def object_builder(data):
    if isinstance(data, dict):
        object_cls_name = data.get('__cls')
        if object_cls_name is not None:
            object_cls = _import_from_name(object_cls_name)
            config_name = data.get('__config')
            if config_name is not None:
                config = _import_from_name(config_name)
            else:
                config = dict()
            kwargs = data.get('__kwargs')
            if kwargs is not None:
                config.update(object_builder(kwargs))
            return object_cls(**config)
        else:
            return {key: object_builder(value) for key, value in data.iteritems()}
    elif hasattr(data, '__iter__'):
        return type(data)(map(object_builder, data))
    else:
        return data
