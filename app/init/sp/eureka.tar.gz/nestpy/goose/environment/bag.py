class Bag:

    def __init__(self, **entries):
        self.__dict__.update(entries)

    def __str__(self):
        return self.__dict__.__str__()

    def values(self):
        return self.__dict__.values()
