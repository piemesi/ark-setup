from collections import Set


class FrozenList(Set):

    def __init__(self, *args, **kwargs):
        self._list = list(*args, **kwargs)

    def __repr__(self):
        return "{}({})".format(self.__class__.__name__, self._list)

    def __hash__(self):
        return self._hash()

    def __iter__(self):
        return iter(self._list)

    def __len__(self):
        return len(self._list)

    def __contains__(self, key):
        return key in self._list
