from collections import Mapping, OrderedDict


class MatrixDict(Mapping):
    """A MatrixDict is a matrix shaped container for associating key/value pairs.

    Example:
        One initializes a MatrixDict with a list of key/value mappings, or with an existing MatrixDict.

        >>> matrix_dict = MatrixDict([[("a", 1), ("b", 2)], [("c", 3), ("d", 4)]])
        >>> matrix_dict.keys()
        ['a', 'b', 'c', 'd']
        >>> matrix_dict.items()
        [('a', 1), ('b', 2), ('c', 3), ('d', 4)]
        >>> matrix_dict.keys_matrix()
        [['a', 'b'], ['c', 'd']]
        >>> matrix_dict.items_matrix()
        [[('a', 1), ('b', 2)], [('c', 3), ('d', 4)]]

        >>> matrix_dict = MatrixDict([dict(a=1, b=2), dict(c=3, d=4)])
        >>> matrix_dict.transpose()
        MatrixDict([[('a', 1), ('c', 3)], [('b', 2), ('d', 4)]])
    """

    def __init__(self, matrix_dict):
        if isinstance(matrix_dict, MatrixDict):
            matrix_dict = matrix_dict.items_matrix()
        self._validate_matrix_dict(matrix_dict)
        self._ordered_dict = reduce(lambda x, y: OrderedDict(OrderedDict(x), **OrderedDict(y)), matrix_dict, dict())
        self._keys_matrix = map(lambda items: OrderedDict(items).keys(), matrix_dict)

    def __repr__(self):
        return "{}({})".format(self.__class__.__name__, self.items_matrix())

    def __iter__(self):
        return iter(self._ordered_dict)

    def __len__(self):
        return len(self._ordered_dict)

    def __eq__(self, other):
        return self.items_matrix() == other.items_matrix()

    def __getitem__(self, key):
        return self._ordered_dict[key]

    def __setitem__(self, key, value):
        if key not in self._ordered_dict:
            raise KeyError(key)
        self._ordered_dict[key] = value

    @staticmethod
    def _validate_matrix_dict(matrix_dict):
        if len(set(sum(map(lambda x: dict(x).keys(), matrix_dict), []))) != sum(map(len, matrix_dict)):
            raise ValueError("Keys must be unique.")
        if len(set(map(len, matrix_dict))) > 1:
            raise ValueError("Number of items per row needs to be consistent.")

    def transpose(self):
        return MatrixDict(map(list, zip(*self.items_matrix())))

    def keys_matrix(self):
        return self._keys_matrix

    def values_matrix(self):
        return map(lambda keys: map(lambda key: self._ordered_dict[key], keys), self._keys_matrix)

    def items_matrix(self):
        return map(lambda keys: map(lambda key: (key, self._ordered_dict[key]), keys), self._keys_matrix)
