import os

from .workspace import Workspace
from ..building import AbstractObjectBuilder
from ... import env


GOOSE_WORKSPACE_BUILDER_CONFIG = dict(
    object_cls=Workspace,
    root_path=os.path.join(env.cache_destination(), 'goose')
)


class WorkspaceBuilder(AbstractObjectBuilder):

    def _get_object_base_cls(self):
        return Workspace

    def _get_builder_config_types(self):
        return dict(root_path=basestring)
