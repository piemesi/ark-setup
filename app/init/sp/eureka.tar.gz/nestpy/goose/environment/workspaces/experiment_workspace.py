import os

from ..workspace import Workspace
from ....validation.type_validation import assert_type_in


class ExperimentWorkspace(Workspace):

    _MODELS = "models"
    _EXPERIMENTS = "experiments"
    _EXPERIMENT_ID = "experiment_id"

    def __init__(self, experiment_id, *args, **kwargs):
        super(ExperimentWorkspace, self).__init__(*args, **kwargs)
        assert_type_in(experiment_id, [basestring, int])
        self._experiment_id = experiment_id

    def __repr__(self):
        return "<{}: {}={}>".format(self.__class__.__name__, self._EXPERIMENT_ID, self._experiment_id)

    def _get_base_path(self):
        return os.path.join(self._root_path, str(self._workspace_id), self._EXPERIMENTS, str(self._experiment_id))

    def get_models_plots_path(self):
        return self.get_path(self._PLOTS, self._MODELS)

    def get_experiment_id(self):
        return self._experiment_id
