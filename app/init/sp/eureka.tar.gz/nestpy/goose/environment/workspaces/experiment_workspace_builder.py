import os

from .experiment_workspace import ExperimentWorkspace
from ..workspace_builder import WorkspaceBuilder
from .... import env


GOOSE_EXPERIMENT_WORKSPACE_BUILDER_CONFIG = dict(
    object_cls=ExperimentWorkspace,
    root_path=os.path.join(env.cache_destination(), 'goose')
)


class ExperimentWorkspaceBuilder(WorkspaceBuilder):

    def _get_object_base_cls(self):
        return ExperimentWorkspace
