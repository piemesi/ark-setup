import numpy as np

from ...validation.type_validation import assert_list_of_type


class Matrix(object):
    def __init__(self, matrix):
        if isinstance(matrix, Matrix):
            self._matrix = matrix._matrix
        else:
            self._matrix = np.asmatrix(matrix, dtype='object')

    def __getitem__(self, item):
        return self._matrix[item]

    @property
    def shape(self):
        return self._matrix.shape

    @property
    def flat(self):
        return self._matrix.flat

    def has_key(self, key):
        return all([
            len(key) == 2,
            key[0] < self._matrix.shape[0],
            key[1] < self._matrix.shape[1]
        ])


class ArrayDict(object):
    '''
    Dictionary that maintains a two-dimensional structure for its keys.
    Useful for keeping track of a table of keyed objects.
    Item access is as for dictionaries, but int tuples may be used to select by coordinate:

    x = ArrayDict({'q': 1, 'w': 2}, keys_matrix=[['q'], ['w']])
    x['w'] == x[0, 1] == 2

    keys_matrix may be any iterator of iterators or numpy array or matrix;
    'row', 'col', or None arrange automatically, but in random order; if None, a nearly-square shape will be found.
    '''

    NULL_KEY = None

    def __init__(self, value_dict=None, keys_matrix=None):
        if value_dict is None:
            if keys_matrix is None:
                raise ValueError('must specify either dict or key_matrix')
            value_dict = [(key, None) for key in keys_matrix.flat]
        self._value_dict = dict(value_dict)
        assert_list_of_type(self._value_dict.keys(), basestring)
        if self.NULL_KEY in self.keys():
            raise ValueError("invalid key")
        self._keys_matrix = self._arrange(keys_matrix)
        self._validate_keys_matrix()

    def __getitem__(self, key):
        key = self._get_key(key)
        return self._value_dict[key]

    def __setitem__(self, key, value):
        key = self._get_key(key)
        if not self.has_key(key):
            raise KeyError(key)
        self._value_dict[key] = value

    @classmethod
    def from_key_value_lol(cls, kv_lol):
        flat = sum(kv_lol, [])
        arrangement = np.array(zip(*flat)[0]).reshape(len(kv_lol), len(kv_lol[0]))
        return cls(flat, keys_matrix=arrangement)

    def _get_key(self, key):
        if isinstance(key, tuple):
            if not self.keys_matrix.has_key(key):
                raise KeyError(key)
            key = self._keys_matrix[key[0], key[1]]
            if key == self.NULL_KEY:
                raise KeyError(key)
        return key

    def _arrange(self, arrangement):
        def chunk(l, d):
            out = []
            while l:
                if len(l) >= d:
                    ext = l[:d]
                else:
                    ext = l[:d] + [self.NULL_KEY] * (d - len(l))
                out.append(ext)
                l = l[d:]
            return out

        if arrangement is None:
            dim = int(np.ceil(len(self.keys()) ** 0.5))
            out = Matrix(chunk(self.keys(), dim))
        elif isinstance(arrangement, basestring) and arrangement == 'row':
            out = Matrix([self.keys()])
        elif isinstance(arrangement, basestring) and arrangement == 'col':
            out = Matrix([[name] for name in self.keys()])
        else:
            if isinstance(arrangement, (list, tuple)):
                if len(arrangement[-1]) < len(arrangement[0]):
                    arrangement[-1] += [self.NULL_KEY] * (len(arrangement[0]) - len(arrangement[-1]))
            out = Matrix(arrangement)
        return out

    def _validate_keys_matrix(self):
        null = {self.NULL_KEY}
        if not set(self._keys_matrix.flat) | null == set(self.keys()) | null:
            raise ValueError(
                'invalid key matrix, not all keys represented: {}'.format(set(self.keys()) - set(self._keys_matrix.flat))
            )

    @property
    def keys_matrix(self):
        return self._keys_matrix

    def keys(self):
        return self._value_dict.keys()

    def values(self):
        return self._value_dict.values()

    def has_key(self, key):
        return not key == self.NULL_KEY and key in self.keys()

    def iteritems(self):
        return self._value_dict.iteritems()

    def iter_coords(self):
        for i in xrange(self.keys_matrix.shape[0]):
            for j in xrange(self.keys_matrix.shape[1]):
                if self._keys_matrix[i, j] == self.NULL_KEY:
                    continue
                yield i, j
