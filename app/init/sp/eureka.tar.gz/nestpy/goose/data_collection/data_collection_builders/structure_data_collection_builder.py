import logging
import os
import pandas as pd

from ..abstract_data_collection_builder import AbstractDataCollectionBuilder, OCCUPANCY_DATA_COLLECTION_BUILDER_CONFIG
from ..data_collections.structure_data_collection import StructureDataCollection
from ...building.abstract_object_builder import extend_builder_config
from ...environment.workspace_cache import cache_to_workspace
from ....env import cache_destination
from ....sql.sql_lookup import lookup_mobile_device_ids, lookup_devices_in_structure, lookup_structure
from ....structures.device_histories import diamond, flintstone, mobile_device, pinna, quartz, topaz
from ....structures.devices import (
    DiamondDevice,
    FlintstoneDevice,
    MobileDevice,
    PinnaDevice,
    QuartzDevice,
    TopazDevice,
)
from ....validation.datetime_validation import assert_valid_start_and_end_dates
from ....validation.type_validation import assert_is_type

logger = logging.getLogger(__name__)


OCCUPANCY_STRUCTURE_DATA_COLLECTION_BUILDER_CONFIG = extend_builder_config(
    OCCUPANCY_DATA_COLLECTION_BUILDER_CONFIG,
    object_cls=StructureDataCollection,
    load_from_device_history_cache=False,  # This assumes having a HDF store called 'device_history_cache.h5'
    load_diamond=True,
    load_flintstone=True,
    load_mobile_device=True,
    load_pinna=True,
    load_quartz=False,
    load_topaz=True,
)


class StructureDataCollectionBuilder(AbstractDataCollectionBuilder):

    _DEVICE_HISTORY_CACHE_PATH = os.path.join(cache_destination(), "device_history_cache.h5")
    _DIAMOND_DEVICE_TYPES = [
        "amber",
        "amber2",
        "diamond",
        "j49",
        "diamond3"
    ]
    _TOPAZ_DEVICE_TYPES = [
        "topaz",
        "topaz2"
    ]
    _QUARTZ_DEVICE_TYPES = [
        "quartz"
    ]
    _DIAMOND_EVENT_TYPES = [
        "BufferedPassiveInfrared",
        "CurrentState",
        "UserInteraction",
    ]
    _FLINTSTONE_EVENT_TYPES = [
        "SensorMCUPIR"
    ]
    _MOBILE_DEVICE_EVENT_TYPES = [
        "fenceEvents"
    ]
    _PINNA_EVENT_TYPES = [
        "OpenCloseDetector",
        "FullPassiveInfrared"
    ]
    _QUARTZ_EVENT_TYPES = [
        "has_person",
        "has_person_high_confidence",
        "has_person_talking",
        "has_person_talking_high_confidence"
    ]
    _TOPAZ_EVENT_TYPES = [
        "Passiveinfraredbucket"
    ]

    def _get_object_base_cls(self):
        return StructureDataCollection

    @classmethod
    def _load_device_history_from_cache(
            cls,
            device_history_cls,
            event_types,
            device_id,
            device_type,
            start_date,
            end_date
    ):
        device_history = device_history_cls(device_id)
        for event_type in event_types:
            try:
                event = pd.read_hdf(
                    cls._DEVICE_HISTORY_CACHE_PATH,
                    os.path.join(device_type, device_id, event_type)
                )
                device_history.add_event_data(
                    event_type,
                    event[(event.index >= start_date) & (event.index < end_date)].sort_index()
                )
            except (IOError, KeyError):
                logger.warning(
                    "Could not find event '{}' for device '{}' in cache.".format(
                        event_type,
                        device_id
                    )
                )
        return device_history

    @cache_to_workspace(arg_names=["structure_id", "start_date", "end_date"], save_to_cache=False)
    def build(
            self,
            start_date,
            end_date,
            structure_id,
            tier,
            flintstone_device_ids=None,
            pinna_device_ids=None
    ):
        assert_valid_start_and_end_dates(start_date, end_date)
        assert_is_type(structure_id, int)

        diamond_devices = []
        diamond_device_histories = []
        flintstone_devices = []
        flintstone_device_histories = []
        mobile_devices = []
        mobile_device_histories = []
        pinna_devices = []
        pinna_device_histories = []
        quartz_devices = []
        quartz_device_histories = []
        topaz_devices = []
        topaz_device_histories = []

        load_from_device_history_cache = self._builder_config.get("load_from_device_history_cache", False)

        if load_from_device_history_cache:
            devices_structures = pd.read_hdf(
                self._DEVICE_HISTORY_CACHE_PATH,
                os.path.join("structures", "devices")
            )
            structures = pd.read_hdf(
                self._DEVICE_HISTORY_CACHE_PATH,
                os.path.join("structures", "structures")
            )
            devices_in_structure = devices_structures.loc[[structure_id]]
            structure_uuid = structures.loc[structure_id, "structure_uuid"]
        else:
            devices_in_structure = lookup_devices_in_structure(structure_id=structure_id, tier=tier)
            structure_uuid = lookup_structure(structure_id=structure_id, tier=tier).loc["structure_uuid"]

        try:
            if load_from_device_history_cache:
                mobile_devices_structures = pd.read_hdf(
                    self._DEVICE_HISTORY_CACHE_PATH,
                    os.path.join("structures", "mobile_devices")
                )
                mobile_device_ids = mobile_devices_structures.loc[[structure_id]].tolist()
            else:
                mobile_device_ids = lookup_mobile_device_ids(structure_id, tier)
        except Exception as e:
            logger.error(e)
            mobile_device_ids = []

        for device_type, device_cls, device_history_cls, devices, device_histories, device_ids, event_types in [
            (
                    "diamond",
                    DiamondDevice,
                    diamond.Diamond,
                    diamond_devices,
                    diamond_device_histories,
                    devices_in_structure.loc[
                        devices_in_structure["device_type"].isin(self._DIAMOND_DEVICE_TYPES),
                        "mac_address"
                    ],
                    self._DIAMOND_EVENT_TYPES
            ),
            (
                    "flintstone",
                    FlintstoneDevice,
                    flintstone.Flintstone,
                    flintstone_devices,
                    flintstone_device_histories,
                    flintstone_device_ids,
                    self._FLINTSTONE_EVENT_TYPES
            ),
            (
                    "mobile_device",
                    MobileDevice,
                    mobile_device.MobileDevice,
                    mobile_devices,
                    mobile_device_histories,
                    mobile_device_ids,
                    self._MOBILE_DEVICE_EVENT_TYPES
            ),
            (
                    "pinna",
                    PinnaDevice,
                    pinna.Pinna,
                    pinna_devices,
                    pinna_device_histories,
                    pinna_device_ids,
                    self._PINNA_EVENT_TYPES
            ),
            (
                    "quartz",
                    QuartzDevice,
                    quartz.Quartz,
                    quartz_devices,
                    quartz_device_histories,
                    devices_in_structure.loc[
                        devices_in_structure["device_type"].isin(self._QUARTZ_DEVICE_TYPES),
                        "device_uuid"
                    ],
                    self._QUARTZ_EVENT_TYPES
            ),
            (
                    "topaz",
                    TopazDevice,
                    topaz.Topaz,
                    topaz_devices,
                    topaz_device_histories,
                    devices_in_structure.loc[
                        devices_in_structure["device_type"].isin(self._TOPAZ_DEVICE_TYPES),
                        "mac_address"
                    ],
                    self._TOPAZ_EVENT_TYPES
            )
        ]:
            if self._builder_config.get("load_{}".format(device_type), False):
                if device_ids is not None:
                    for device_id in device_ids:
                        try:
                            device = device_cls(device_id, structure_id=structure_id)
                            if load_from_device_history_cache:
                                device_history = self._load_device_history_from_cache(
                                    device_history_cls=device_history_cls,
                                    event_types=event_types,
                                    device_id=device_id,
                                    device_type=device_type,
                                    start_date=start_date,
                                    end_date=end_date
                                )
                            else:
                                device_history = device_history_cls.load(
                                    device_id=device_id,
                                    tier=tier,
                                    start_date=start_date,
                                    end_date=end_date,
                                    event_types=event_types
                                )
                            if isinstance(device_history, mobile_device.MobileDevice):
                                device_history.filter_structure(structure_uuid=structure_uuid)
                            if device_history.has_events():
                                devices.append(device)
                                device_histories.append(device_history)
                        except Exception as e:
                            logger.error(e)

        data_collection = self._object_cls(
            structure_id=structure_id,
            diamond_devices=diamond_devices,
            diamond_device_histories=diamond_device_histories,
            flintstone_devices=flintstone_devices,
            flintstone_device_histories=flintstone_device_histories,
            mobile_devices=mobile_devices,
            mobile_device_histories=mobile_device_histories,
            pinna_devices=pinna_devices,
            pinna_device_histories=pinna_device_histories,
            quartz_devices=quartz_devices,
            quartz_device_histories=quartz_device_histories,
            topaz_devices=topaz_devices,
            topaz_device_histories=topaz_device_histories,
        )
        data_collection.to_local_time()
        return data_collection
