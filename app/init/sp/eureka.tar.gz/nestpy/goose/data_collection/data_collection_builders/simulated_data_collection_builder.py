from ..abstract_data_collection_builder import AbstractDataCollectionBuilder, OCCUPANCY_DATA_COLLECTION_BUILDER_CONFIG
from ..data_collections.simulated_data_collection import SimulatedDataCollection
from ...building.abstract_object_builder import extend_builder_config
from ...environment.workspace_cache import cache_to_workspace
from ....structures.devices import DiamondDevice, MobileDevice, QuartzDevice, TopazDevice
from ....structures.device_histories import diamond, mobile_device, quartz, topaz
from ....validation.datetime_validation import assert_valid_start_and_end_dates


OCCUPANCY_SIMULATED_DATA_COLLECTION_BUILDER_CONFIG = extend_builder_config(
    OCCUPANCY_DATA_COLLECTION_BUILDER_CONFIG,
    object_cls=SimulatedDataCollection,
    load_diamond=True,
    load_flintstone=True,
    load_mobile_device=True,
    load_pinna=True,
    load_quartz=False,
    load_topaz=True,
)


class SimulatedDataCollectionBuilder(AbstractDataCollectionBuilder):

    def _get_object_base_cls(self):
        return SimulatedDataCollection

    @cache_to_workspace(arg_names=["simulation_id", "start_date", "end_date"], save_to_cache=False)
    def build(self, start_date, end_date, simulation_id, simulation_builder):
        assert_valid_start_and_end_dates(start_date, end_date)

        simulation = simulation_builder.build(start_datetime=start_date, end_datetime=end_date)
        device_histories, ground_truth_state_series = simulation.run()

        diamond_devices = []
        diamond_device_histories = []
        mobile_devices = []
        mobile_device_histories = []
        quartz_devices = []
        quartz_device_histories = []
        topaz_devices = []
        topaz_device_histories = []

        if self._builder_config['load_diamond']:
            diamond_device_histories = self._filter_device_histories(device_histories, diamond.Diamond)
            for device_history in diamond_device_histories:
                device = DiamondDevice(mac_address=device_history.unique_device_id)
                diamond_devices.append(device)

        if self._builder_config['load_mobile_device']:
            mobile_device_histories = self._filter_device_histories(device_histories, mobile_device.MobileDevice)
            for device_history in mobile_device_histories:
                device = MobileDevice(device_id=device_history.unique_device_id)
                mobile_devices.append(device)

        if self._builder_config['load_quartz']:
            quartz_device_histories = self._filter_device_histories(device_histories, quartz.Quartz)
            for device_history in quartz_device_histories:
                device = QuartzDevice(device_id=device_history.unique_device_id)
                quartz_devices.append(device)

        if self._builder_config['load_topaz']:
            topaz_device_histories = self._filter_device_histories(device_histories, topaz.Topaz)
            for device_history in topaz_device_histories:
                device = TopazDevice(mac_address=device_history.unique_device_id)
                topaz_devices.append(device)

        data_collection = self._object_cls(
            simulation_id=simulation_id,
            ground_truth_state_series=ground_truth_state_series,
            diamond_devices=diamond_devices,
            diamond_device_histories=diamond_device_histories,
            flintstone_devices=[],
            flintstone_device_histories=[],
            mobile_devices=mobile_devices,
            mobile_device_histories=mobile_device_histories,
            pinna_devices=[],
            pinna_device_histories=[],
            quartz_devices=quartz_devices,
            quartz_device_histories=quartz_device_histories,
            topaz_devices=topaz_devices,
            topaz_device_histories=topaz_device_histories,
        )
        return data_collection
