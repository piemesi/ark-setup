from abc import ABCMeta

from ..building.abstract_object_builder import AbstractObjectBuilder
from ..environment.workspace_cache import WorkspaceCache
from ..environment.workspace_builder import WorkspaceBuilder, GOOSE_WORKSPACE_BUILDER_CONFIG

OCCUPANCY_DATA_COLLECTION_BUILDER_CONFIG = dict(
    workspace_builder=WorkspaceBuilder(**GOOSE_WORKSPACE_BUILDER_CONFIG)
)


class AbstractDataCollectionBuilder(AbstractObjectBuilder):
    __metaclass__ = ABCMeta

    _DATA_COLLECTIONS = "data_collections"

    def __init__(self, workspace_builder, *args, **kwargs):
        super(AbstractDataCollectionBuilder, self).__init__(*args, **kwargs)
        workspace = workspace_builder.build(workspace_id=self._DATA_COLLECTIONS)
        self._workspace_cache = WorkspaceCache(workspace=workspace)

    @staticmethod
    def _filter_device_histories(device_histories, device_history_cls):
        return [device_history for device_history in device_histories if isinstance(device_history, device_history_cls)]

    def _get_builder_config_types(self):
        return dict(
            load_diamond=bool,
            load_flintstone=bool,
            load_mobile_device=bool,
            load_pinna=bool,
            load_quartz=bool,
            load_topaz=bool,
        )
