from ..abstract_data_collection import AbstractDataCollection
from ....validation.type_validation import assert_is_type
from ...states.state_series_.ground_truth_state_series import GroundTruthStateSeries


class SimulatedDataCollection(AbstractDataCollection):

    def __init__(self, simulation_id, ground_truth_state_series, *args, **kwargs):
        super(SimulatedDataCollection, self).__init__(*args, **kwargs)
        assert_is_type(ground_truth_state_series, GroundTruthStateSeries)
        self._simulation_id = simulation_id
        self._ground_truth_state_series = ground_truth_state_series

    def get_simulation_id(self):
        return self._simulation_id
