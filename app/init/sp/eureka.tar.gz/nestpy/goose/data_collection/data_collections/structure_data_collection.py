from ..abstract_data_collection import AbstractDataCollection
from ....structures.device_history import DeviceHistory
from ....validation.type_validation import assert_is_type, assert_list_of_type


class StructureDataCollection(AbstractDataCollection):

    def __init__(self, structure_id, *args, **kwargs):
        super(StructureDataCollection, self).__init__(*args, **kwargs)
        for device_histories in [
            self._diamond_device_histories,
            self._flintstone_device_histories,
            self._mobile_device_histories,
            self._pinna_device_histories,
            self._quartz_device_histories,
            self._topaz_device_histories
        ]:
            assert_list_of_type(device_histories, DeviceHistory)
        assert_is_type(structure_id, int)
        self._structure_id = structure_id

    def get_structure_id(self):
        return self._structure_id
