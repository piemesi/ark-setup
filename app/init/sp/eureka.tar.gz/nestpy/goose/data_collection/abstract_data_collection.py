import datetime

from abc import ABCMeta

from ...structures.device import Device
from ...structures.device_history_base import DeviceHistoryBase
from ...validation.type_validation import assert_is_type, assert_list_of_type
from ...manipulators.frame_manipulators import set_unique_index


class AbstractDataCollection(object):
    __metaclass__ = ABCMeta

    def __init__(
            self,
            diamond_devices,
            diamond_device_histories,
            flintstone_devices,
            flintstone_device_histories,
            mobile_devices,
            mobile_device_histories,
            pinna_devices,
            pinna_device_histories,
            quartz_devices,
            quartz_device_histories,
            topaz_devices,
            topaz_device_histories,
            ground_truth_state_series=None,
    ):
        for devices in [
            diamond_devices,
            flintstone_devices,
            mobile_devices,
            pinna_devices,
            quartz_devices,
            topaz_devices
        ]:
            assert_list_of_type(devices, Device)
        for device_histories in [
            diamond_device_histories,
            flintstone_device_histories,
            mobile_device_histories,
            pinna_device_histories,
            quartz_device_histories,
            topaz_device_histories
        ]:
            assert_list_of_type(device_histories, DeviceHistoryBase)
            for dh in device_histories:
                for event in dh:
                    if dh[event].index.duplicated().any():
                        dh.add_event_data(event, set_unique_index(dh[event]))

        self._diamond_devices = diamond_devices
        self._diamond_device_histories = diamond_device_histories
        self._flintstone_devices = flintstone_devices
        self._flintstone_device_histories = flintstone_device_histories
        self._mobile_devices = mobile_devices
        self._mobile_device_histories = mobile_device_histories
        self._pinna_devices = pinna_devices
        self._pinna_device_histories = pinna_device_histories
        self._quartz_devices = quartz_devices
        self._quartz_device_histories = quartz_device_histories
        self._topaz_devices = topaz_devices
        self._topaz_device_histories = topaz_device_histories
        self._ground_truth_state_series = ground_truth_state_series

    def get_diamond_devices(self):
        return self._diamond_devices

    def get_diamond_device_histories(self):
        return self._diamond_device_histories

    def get_flintstone_devices(self):
        return self._flintstone_devices

    def get_flintstone_device_histories(self):
        return self._flintstone_device_histories

    def get_mobile_devices(self):
        return self._mobile_devices

    def get_mobile_device_histories(self):
        return self._mobile_device_histories

    def get_pinna_devices(self):
        return self._pinna_devices

    def get_pinna_device_histories(self):
        return self._pinna_device_histories

    def get_quartz_devices(self):
        return self._quartz_devices

    def get_quartz_device_histories(self):
        return self._quartz_device_histories

    def get_topaz_devices(self):
        return self._topaz_devices

    def get_topaz_device_histories(self):
        return self._topaz_device_histories

    def get_devices(self):
        return (
            self._diamond_devices +
            self._flintstone_devices +
            self._mobile_devices +
            self._pinna_devices +
            self._quartz_devices +
            self._topaz_devices
        )

    def get_device_histories(self):
        return (
            self._diamond_device_histories +
            self._flintstone_device_histories +
            self._mobile_device_histories +
            self._pinna_device_histories +
            self._quartz_device_histories +
            self._topaz_device_histories
        )

    def get_timezone(self):
        if not self._diamond_device_histories:
            raise ValueError("At least one Diamond device history is required to find the timezone.")
        timezones = []
        for diamond_device_history in self._diamond_device_histories:
            timezone = diamond_device_history.get_timezone()
            if timezone is not None:
                timezones.append(timezone)
        if not timezones:
            raise ValueError("No valid timezone found in Diamond device histories.")
        if not all(timezone == timezones[0] for timezone in timezones):
            raise ValueError("Discrepancy found between timezones: '{}'.".format(timezones))
        return timezones[0]

    def to_timezone(self, timezone):
        assert_is_type(timezone, datetime.tzinfo)
        for device_history in self.get_device_histories():
            device_history.to_timezone(timezone)

    def to_local_time(self):
        self.to_timezone(self.get_timezone())

    def get_ground_truth_state_series(self):
        return self._ground_truth_state_series
