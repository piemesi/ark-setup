from abc import ABCMeta, abstractmethod


class AbstractParameterEstimator(object):
    """
    Abstract class for a parameter estimator. Only required method is estimate_parameters().
    """
    __metaclass__ = ABCMeta

    def __repr__(self):
        return "<{}>".format(self.__class__.__name__)

    @abstractmethod
    def estimate_parameters(self, *args, **kwargs):
        raise NotImplementedError
