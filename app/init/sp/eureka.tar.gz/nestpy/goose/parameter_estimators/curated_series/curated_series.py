import os
import pandas as pd

from ...data_collection.data_collection_builders.structure_data_collection_builder import \
    OCCUPANCY_STRUCTURE_DATA_COLLECTION_BUILDER_CONFIG
from ...data_collection.data_collection_builders.structure_data_collection_builder import \
    StructureDataCollectionBuilder
from ...features.feature_series_collection_builders.batch_feature_series_collection_builder import \
    OCCUPANCY_BATCH_FEATURE_SERIES_COLLECTION_BUILDER_CONFIG
from ...features.feature_series_collection_builders import BatchFeatureSeriesCollectionBuilder
from .... import env
from ....groups.function_applicators import device_history_loader
from ....sql.sql_lookup import lookup_device
from ....validation.datetime_validation import assert_valid_start_and_end_dates


class CuratedSeries(object):
    """
    The CuratedSeries object is a temporary convenience method for prototyping parameter estimators. It allows the user
    to store pickled event logs locally so it doesn't need to be processed every time a parameter estimator is launched.

    This module will be deprecated after the parameter estimator module has been finalised.
    """

    def __init__(self, identifier, start_date, end_date, tier="ft", cache_location=env.cache_destination()):
        """
        Method will check whether a pickled file exists for this exact device and these exact start/end dates. If not
        it will download and reprocess the S3 logs and create a pickle file. After instantiating, use get_series() to
        obtain pandas series with curated PIR data.

        Args:
            identifier: structure id or mac
            start_date: datetime object indicating start
            end_date: datetime object indicating end
            cache_location: location where logs and pickled files should be stored. Defaults to eureka-cache.
        """
        assert_valid_start_and_end_dates(start_date, end_date)

        self._identifier = identifier
        self._tier = tier
        self._cache_location = cache_location
        self._path_to_pickle = "{}/{}-{}-{}.pckl".format(
            self._cache_location,
            self._identifier,
            start_date.strftime("%Y-%m-%d"),
            end_date.strftime("%Y-%m-%d")
        )

        if not os.path.exists(self._path_to_pickle):
            self._start_date = start_date
            self._end_date = end_date
            self._series = self._from_s3(dump_pickle=True).sort_index()
        else:
            self._series = self._from_pickle(self._path_to_pickle).sort_index()

    def __repr__(self):
        return "<{}>".format(self.__class__.__name__)

    @staticmethod
    def _from_pickle(path):
        try:
            pandas_frame = pd.read_pickle(path)
            if isinstance(pandas_frame, pd.DataFrame):
                pandas_frame = pandas_frame.any(axis=1)
            return pandas_frame
        except IOError:
            print("Could not load %s" % path)

    def _from_s3(self, dump_pickle=True):
        if isinstance(self._identifier, int):
            series = self._structure_loader(self._identifier,
                                            self._start_date,
                                            self._end_date,
                                            self._tier,
                                            dump_pickle)
        else:
            series = self._device_loader(self._identifier,
                                         self._start_date,
                                         self._end_date,
                                         dump_pickle)
        return series

    def _structure_loader(self, structure_id, start_date, end_date, tier, dump_pickle):
        data_collection_builder = StructureDataCollectionBuilder(
            **OCCUPANCY_STRUCTURE_DATA_COLLECTION_BUILDER_CONFIG
        )
        data_collection = data_collection_builder.build(
            start_date,
            end_date,
            structure_id,
            None,
            tier
        )

        feature_series_collection_builder = BatchFeatureSeriesCollectionBuilder(
            **OCCUPANCY_BATCH_FEATURE_SERIES_COLLECTION_BUILDER_CONFIG
        )
        feature_series_collection = feature_series_collection_builder.build(
            data_collection.get_diamond_devices(),
            data_collection.get_diamond_device_histories(),
            data_collection.get_hiddenite_ble_scanner_devices(),
            data_collection.get_hiddenite_ble_scanner_device_histories(),
            data_collection.get_hiddenite_mobile_devices(),
            data_collection.get_hiddenite_mobile_device_histories(),
            data_collection.get_topaz_devices(),
            data_collection.get_topaz_device_histories()
        )

        data_frame = feature_series_collection.get_activity_feature_series_data_frame()
        any_series = data_frame.any(axis=1)
        series = any_series[any_series]
        if dump_pickle:
            self._dump_to_pickle(series, self._path_to_pickle)
        return series

    def _device_loader(self, mac, start_date, end_date, dump_pickle):
        dh = device_history_loader(lookup_device(mac),
                                   to_local_time=True,
                                   event_types=["BufferedPassiveInfrared"],
                                   start_date=start_date,
                                   end_date=end_date,
                                   cache_destination=self._cache_location)

        boolean = pd.Series(dh.BufferedPassiveInfrared["max"] > dh.BufferedPassiveInfrared["threshold"])
        series = boolean[boolean]
        if dump_pickle:
            self._dump_to_pickle(series, self._path_to_pickle)
        return series

    @staticmethod
    def _dump_to_pickle(series, path):
        series.to_pickle(path)
        return

    def get_identifier(self):
        return self._identifier

    def get_series(self):
        return self._series
