import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from abc import ABCMeta
from datetime import time, timedelta

from .....converters.time_constants import MINUTES_PER_DAY, MINUTES_PER_HOUR, SECONDS_PER_MINUTE
from .....manipulators.periodic_series import PeriodicSeries
from .....validation.type_validation import assert_is_type


class InactivityWindow(object):
    """
    The InactivityWindow object describes a period of lower activity in a series of activity probability. The most
    important methods of this class are the get_score method, which computes the quality (how 'inactive' the window
    actually is) and the get_fit_data method, which yields the discrete probabilities of transitioning within a certain
    bin.
    """
    __metaclass__ = ABCMeta

    LINEAR_REGRESSOR_WEIGHTS = [-0.8184, -2.0099, 1.0485, 0.9681, 2.0068]

    def __init__(self, periodic_series, start_index, end_index):
        assert_is_type(periodic_series, PeriodicSeries)
        self._periodic_series = periodic_series.get_rebased_periodic_series(start_index)
        self._period = self._periodic_series.get_period()
        self._start_index = start_index
        self._end_index = end_index + (start_index > end_index) * self._period
        self._boolean_window = self._get_boolean_window(
            self._periodic_series,
            self._start_index,
            self._end_index
        )
        self._validate_inactivity_window(
            self._periodic_series,
            self._boolean_window,
            self._start_index,
            self._end_index
        )

    def __repr__(self):
        return "<{}>".format(self.__class__.__name__)

    def _key(self):
        return (
            self._periodic_series,
            self._start_index,
            self._end_index
        )

    def __hash__(self):
        return hash(self._key())

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self._key() == other._key()

    def __ne__(self, other):
        return not self.__eq__(other)

    @staticmethod
    def _validate_inactivity_window(periodic_series, boolean_window, start_index, end_index):
        assert start_index in periodic_series.get_series().index.values
        assert (end_index in periodic_series.get_series().index.values or
                end_index == periodic_series.get_series().index[1] + periodic_series.get_period()), "Could not find index {} in \n{}".format(end_index, periodic_series)
        assert start_index < end_index
        assert boolean_window.index[0] == start_index == periodic_series.get_series().index[0]

    @staticmethod
    def _get_boolean_window(periodic_series, start_index, end_index):
        index = periodic_series.get_series().index
        return pd.Series(
            data=(start_index <= index.values) & (index.values < end_index),
            index=index,
            dtype=bool
        )

    def get_boolean_series(self, rebase=0):
        """
        Compute boolean pandas Series showing which indices are part of the InactivityWindow

        Args:
            rebase: index to rebase the periodic series on (defaults to 0)

        Returns:
            pandas Series object with boolean values
        """
        return PeriodicSeries(
            self._boolean_window,
            self._period
        ).get_rebased_periodic_series(rebase).get_series().astype(bool)

    def get_series(self, rebase=0):
        return self._periodic_series.get_rebased_periodic_series(rebase).get_series()

    def get_values(self):
        return self._periodic_series.get_series()[self._boolean_window]

    def get_period(self):
        return self._period

    def get_start(self):
        return self._start_index

    def get_end(self):
        return self._end_index

    def get_periodic_series(self, rebase=0):
        return self._periodic_series.get_rebased_periodic_series(rebase)

    def get_score(self):
        """
        Compute quality InactivityWindow by assessing the following properties: window_length, window_mean_value,
        difference between the left bin and the minimum, difference between the right bin and the minimum and
        the minimum value in the window. These properties are weighted using the LINEAR_REGRESSOR_WEIGHTS and then
        summed to form the score.

        Returns:
            float representing the score, approximately within [0, 1].
        """
        return np.dot(self.get_properties(), self.LINEAR_REGRESSOR_WEIGHTS)

    def get_properties(self):
        """
        Compute the following properties of the InactivityWindow: indow_length, window_mean_value, difference between
        the left bin and the minimum, difference between the right bin and the minimum and the minimum value in the
        window.

        Returns:
            tuple of 5 properties
        """
        series_max = self.get_series().max()
        return (
            self._property_window_length(norm=self._period),
            self._property_window_mean(norm=series_max),
            self._property_diff_left_min(norm=series_max),
            self._property_diff_right_min(norm=series_max),
            self._property_min(norm=series_max)
        )

    def _property_window_mean(self, norm=1):
        return self.get_values().mean() / norm

    def _property_window_length(self, norm=1):
        return (self._end_index - self._start_index) / norm

    def _property_diff_left_min(self, norm=1):
        return (self.get_values().iloc[0] - self.get_values().min()) / norm

    def _property_diff_right_min(self, norm=1):
        return (self.get_values().iloc[-1] - self.get_values().min()) / norm

    def _property_min(self, norm=1):
        return self.get_values().min() / norm

    def get_fit_data(self):
        """
        Compute the discrete probabilities of transitioning from active to inactive and vice versa as a function of
        bins. These series can be used to fit a continuous distribution to.

        Returns:
            tuple of two pandas Series; one for the start distribution, and one for the end. The end distribution is
            indexed backwards from the end of the InactivityWindow to the beginning. The start distribution is indexed
            from the beginning of the InactivityWindow to the end.
        """
        inside_window = self._periodic_series.get_series()[:self.get_end()].iloc[:-1]
        pdf_start = self._downhill_smoothing(inside_window).diff(-1).dropna()
        pdf_start.iloc[len(pdf_start) / 2:] = self._downhill_smoothing(pdf_start.iloc[len(pdf_start) / 2:])

        pdf_end = self._downhill_smoothing(inside_window.sort_index(ascending=False)).diff(-1).dropna()
        pdf_end.iloc[len(pdf_end) / 2:] = self._downhill_smoothing(pdf_end.iloc[len(pdf_end) / 2:])

        return (
            pdf_start / pdf_start.sum(),
            pdf_end / pdf_end.sum()
        )

    @staticmethod
    def _downhill_smoothing(series):
        return series.cummin()

    @staticmethod
    def _set_24h_xticks(axis, start=0, end=MINUTES_PER_DAY, granularity_minutes=30):
        """
        Sets the ticks and labels of the x-axis to granularity_minutes intervals.

        Args:
            axis: matplotlib.Axes object to plot on
            start: start of plot (defaults to 0)
            end: end of plot (defaults to 24*60 minutes)
            granularity_minutes: interval at which ticks and labels are placed (defaults to 30 minutes)

        Returns:
            matplotlib.Axes object
        """
        labels = [time(
            hour=int(m // MINUTES_PER_HOUR),
            minute=int(m % MINUTES_PER_HOUR),
        ).strftime("%H:%M") for m in np.arange(start, end, granularity_minutes, dtype=np.int)]
        axis.set_xticks(
            np.arange(start, end + granularity_minutes, granularity_minutes)
        )
        axis.set_xticklabels(labels + [labels[0]], rotation=90)
        axis.set_xlim(start, end)
        return axis

    @staticmethod
    def _assert_axis(axis):
        """
        Asserts an axis is created if None is passed.

        Args:
            axis: matplotlib.Axes class or None

        Returns:
            matplotlib.Axes object
        """
        if axis is None:
            _, axis = plt.subplots()
        assert_is_type(axis, plt.Axes)
        return axis

    def plot(self, bin_size, axis=None, *args, **kwargs):
        """
        Shows a bar plot of the activity distribution with the InactivityWindow marked blue.

        Args:
            bin_size: datetime.timedelta specifying bin size
            axis: matplotlib.Axes object to plot on
            *args: additional args to be passed to vlines method
            **kwargs: additional kwargs to be passed to vlines method

        Returns:
            matplotlib.Axes object where the data has been plotted on
        """
        axis = self._assert_axis(axis)
        assert_is_type(bin_size, timedelta)
        bin_size_minute = int(bin_size.total_seconds() * SECONDS_PER_MINUTE)
        active_series = ~self.get_boolean_series() * self.get_series()
        inactive_series = self.get_series() * self.get_boolean_series()
        axis.bar(
            inactive_series.index.values,
            inactive_series.values,
            align="edge",
            width=bin_size_minute,
            color="cornflowerblue",
            *args,
            **kwargs
        )
        axis.bar(
            self.get_boolean_series().index.values,
            self.get_boolean_series().values,
            align="edge",
            width=bin_size_minute,
            color="cornflowerblue",
            linewidth=0,
            alpha=0.2,
            *args,
            **kwargs
        )
        axis.bar(
            active_series.index.values,
            active_series.values,
            align="edge",
            width=bin_size_minute,
            color="tomato",
            *args,
            **kwargs
        )
        axis.set_ylim(0, 1)
        self._set_24h_xticks(axis)
        return axis
