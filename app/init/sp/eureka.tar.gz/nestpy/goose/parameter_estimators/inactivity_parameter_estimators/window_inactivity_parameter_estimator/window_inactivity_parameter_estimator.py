import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from datetime import time, timedelta

from .inactivity_window import InactivityWindow
from ..abstract_inactivity_parameter_estimator import AbstractInactivityParameterEstimator
from ....parameters import InactivityParameters, InactivityTransitionDistribution
from .....converters.time_constants import (MINUTES_PER_DAY,
                                            MINUTES_PER_HOUR,
                                            SECONDS_PER_MINUTE)
from .....manipulators.periodic_series import PeriodicSeries
from .....manipulators.series_manipulators import drop_consecutive_duplicates
from .....validation.type_validation import assert_is_type


class WindowInactivityParameterEstimator(AbstractInactivityParameterEstimator):

    def estimate_parameters(self, bin_size, window_time=time(hour=4)):
        """
        Estimate common periods of inactivity based on PIR data.

        Args:
            bin_size: timedelta object specifying the width of the bins. Needs to fit an integer times in 24h.
            window_time: return a particular set of InactivityParameters, options are a datetime.time object or "best".

        Returns:
            an InactivityParametersCollection object that contains a set of InactivityParameters, which together span
            the entire 24h period.
        """
        if isinstance(window_time, str):
            window_time = window_time.lower()
        assert isinstance(window_time, time) or window_time == "best", (
            "Unknown argument for window_time ({}). Please use 'best' or a datetime.time object".format(window_time)
        )
        self._validate_bin_size(bin_size)
        bin_size_minute = int(bin_size.total_seconds() / SECONDS_PER_MINUTE)
        approved_windows, rejected_windows = self._classify_windows(
            self._get_window_candidates(
                self.activity_probabilities(self._pir_series, bin_size),
                bin_size,
            )
        )

        inactivity_parameters_list = [InactivityParameters(
            InactivityTransitionDistribution(
                approved_window.get_fit_data()[0],
                bin_size_minute,
                MINUTES_PER_DAY
            ),
            InactivityTransitionDistribution(
                approved_window.get_fit_data()[1],
                bin_size_minute,
                MINUTES_PER_DAY
            ),
            approved_window.get_score(),
        ) for approved_window in approved_windows]

        if isinstance(window_time, time):
            inactivity_parameters = self.get_night_inactivity_parameters(
                inactivity_parameters_list,
                window_time=window_time
            )
        else:
            inactivity_parameters = self.get_best_inactivity_parameters(inactivity_parameters_list)
        return inactivity_parameters

    @staticmethod
    def get_night_inactivity_parameters(inactivity_parameter_list, window_time=time(hour=4)):
        """
        Finds the InactivityParameters instance in which night_time is contained.

        Args:
            inactivity_parameter_list: list of InactivityParameters instances
            window_time: datetime.time object

        Returns:
            InactivityParameters object
        """
        assert_is_type(window_time, time)
        enclose_window_time = [
            inact_params for inact_params in inactivity_parameter_list if inact_params.in_window(window_time)
            ]
        assert len(enclose_window_time) == 1, (
            "Found {} InactivityParameter sets that include window_time={}, expected 1".format(len(enclose_window_time),
                                                                                               window_time)
        )
        return enclose_window_time[0]

    @staticmethod
    def get_best_inactivity_parameters(inactivity_parameter_list):
        """
        Returns best inactivity parameter set, based on the score of the corresponding InactivityWindow

        Args:
            inactivity_parameter_list: list of InactivityParameters instances

        Returns:
            InactivityParameters object
        """
        return sorted(inactivity_parameter_list, key=lambda x: x.get_score())[-1]

    @classmethod
    def activity_probabilities(cls, pir_series, bin_size):
        """
        Compute the probabilities of seeing activity as a function of discrete time, based on historical PIR
        data.

        Args:
            pir_series: pandas Series
            bin_size: timedelta object specifying the width of the bins. Needs to fit an integer times in 24h

        Returns:
            a PeriodicSeries object with period 24h and an underlying series with values in range [0,1], corresponding
            to the probability of seeing activity in a particular bin.
        """
        bin_size_minutes = int(bin_size.total_seconds() / SECONDS_PER_MINUTE)
        resampled_series = cls._any_activity(pir_series, bin_size)
        activity_counts = resampled_series.groupby(resampled_series.index.time).count()
        activity_counts_float_index = cls._reindex_time_as_float_minute(activity_counts).reindex(
            np.arange(0, MINUTES_PER_DAY, bin_size_minutes, dtype=np.int),
            fill_value=0
        )

        activity_probabilities = activity_counts_float_index / max(cls._get_active_days(resampled_series), 1)
        return PeriodicSeries(activity_probabilities, MINUTES_PER_DAY)

    @staticmethod
    def _get_flux_points(periodic_series):
        first_derivative = periodic_series.apply_periodic_function(pd.Series.diff).get_series()
        first_derivative_periodic = PeriodicSeries(
            np.sign(first_derivative[first_derivative != 0]),
            periodic_series.get_period(),
        )
        second_derivative = first_derivative_periodic.apply_periodic_function(pd.Series.diff).apply_periodic_function(
            pd.Series.shift,
            -1,
        ).get_series()
        second_derivative_sign = np.sign(second_derivative)

        maxs = second_derivative_sign[second_derivative_sign == -1].index.tolist()
        mins = second_derivative_sign[second_derivative_sign == 1].index.tolist()
        return maxs, mins

    @classmethod
    def _get_window_candidates(cls, periodic_series, bin_size):
        assert_is_type(bin_size, timedelta)
        assert_is_type(periodic_series, PeriodicSeries)

        bin_size_minutes = int(bin_size.total_seconds() / SECONDS_PER_MINUTE)

        duplicate_dropped_ps = PeriodicSeries(
            periodic_series.apply_periodic_function(drop_consecutive_duplicates).get_series().dropna(),
            periodic_series.get_period(),
        )
        maxs, _ = cls._get_flux_points(duplicate_dropped_ps)
        sorted_max_values = periodic_series.get_series()[maxs].sort(inplace=False, ascending=False)
        unique_start_end_points = []
        for i in range(len(sorted_max_values)):
            separators = sorted(sorted_max_values.iloc[:i + 1].index.values)
            separators.append(separators[0] + periodic_series.get_period())
            combinations = [
                (separators[j], separators[j + 1]) for j in range(len(separators) - 1)
                ]
            unique_start_end_points.extend([c for c in combinations if c not in unique_start_end_points])
        return [InactivityWindow(
            periodic_series,
            start,
            end + bin_size_minutes
        ) for start, end in unique_start_end_points]

    @staticmethod
    def _classify_windows(windows):
        sorted_windows = sorted(windows, key=lambda x: x.get_score(), reverse=True)
        approved_windows, rejected_windows = list(), list()

        for window in sorted_windows:
            if all([
                       (window.get_boolean_series() & approved_window.get_boolean_series()).sum() <= 2
                       for approved_window in approved_windows
            ]):
                approved_windows.append(window)
            else:
                rejected_windows.append(window)
        return approved_windows, rejected_windows

    @staticmethod
    def _set_24h_xticks(axis, start=0, end=MINUTES_PER_DAY, granularity_minutes=30):
        """
        Sets the ticks and labels of the x-axis to granularity_minutes intervals.

        Args:
            axis: matplotlib.Axes object to plot on
            start: start of plot (defaults to 0)
            end: end of plot (defaults to 24*60 minutes)
            granularity_minutes: interval at which ticks and labels are placed (defaults to 30 minutes)

        Returns:
            matplotlib.Axes object
        """
        labels = [time(
            hour=int(m // MINUTES_PER_HOUR),
            minute=int(m % MINUTES_PER_HOUR),
        ).strftime("%H:%M") for m in np.arange(start, end, granularity_minutes, dtype=np.int)]
        axis.set_xticks(
            np.arange(start, end + granularity_minutes, granularity_minutes)
        )
        axis.set_xticklabels(labels + [labels[0]], rotation=90)
        axis.set_xlim(start, end)
        return axis

    def plot_activity_probabilities(self, bin_size, axis=None, color="tomato", *args, **kwargs):
        """
        Plots the discrete activity probabilities in bins of 'bin_size'.

        Args:
            bin_size: timedelta object specifying the width of the bins. Needs to fit an integer times in 24h
            axis: matplotlib.Axes object to plot on
            color: bar color
            *args: additional args to be passed to vlines method
            **kwargs: additional kwargs to be passed to vlines method

        Returns:
            matplotlib.Axes object where the data has been plotted on
        """
        activity_probabilities = self.activity_probabilities(self._pir_series, bin_size).get_series()
        axis = self._assert_axis(axis)

        axis.bar(
            activity_probabilities.index.values,
            activity_probabilities.values,
            width=bin_size.total_seconds() / SECONDS_PER_MINUTE,
            color=color,
            align="edge",
            *args,
            **kwargs
        )
        self._set_24h_xticks(axis)
        axis.set_ylim(0, 1)
        axis.set_ylabel("Activity Probability")
        axis.set_xlabel("Time of day")
        return axis

    @staticmethod
    def plot_window_classification_summary(approved, rejected, bin_size, *args, **kwargs):
        """
        Plots all possible InactivityWindows as subplots. Plots of in the left column are approved, plots in the right
        rejected.

        Args:
            approved: list of approved InactivityWindows
            rejected: list of rejected InactivityWindows
            bin_size: datetime.timedelta object representing bin size
            *args: additional args to be passed to plot method
            **kwargs: additional kwargs to be passed to plot method

        Returns:
            matplotlib.Axes object where the data has been plotted on
        """
        assert_is_type(bin_size, timedelta)
        max_rows = max(len(rejected), len(approved))
        _, axes = plt.subplots(nrows=max_rows, ncols=2)
        if max_rows == 1:
            approved[0].plot(bin_size, axis=axes[0], *args, **kwargs)
            axes[0].set_title("Score: {}".format(approved[0].get_score()))
            rejected[0].plot(bin_size, axis=axes[1], *args, **kwargs)
            axes[1].set_title("Score: {}".format(rejected[0].get_score()))
        else:
            for i, w in enumerate(approved):
                w.plot(bin_size, axis=axes[i, 0], *args, **kwargs)
                axes[i, 0].set_title("Score: {}".format(w.get_score()))
            for i, w in enumerate(rejected):
                w.plot(bin_size, axis=axes[i, 1], *args, **kwargs)
                axes[i, 1].set_title("Score: {}".format(w.get_score()))
        return axes
