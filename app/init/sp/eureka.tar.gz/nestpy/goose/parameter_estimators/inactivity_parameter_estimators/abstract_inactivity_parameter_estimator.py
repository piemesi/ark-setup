import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from abc import abstractmethod
from datetime import time, timedelta

from ..abstract_parameter_estimator import AbstractParameterEstimator
from ....converters.time_constants import (MINUTES_PER_DAY,
                                           MINUTES_PER_HOUR,
                                           SECONDS_PER_MINUTE)
from ....converters.time_converters import time_to_hour_float, get_tz_naive_datetime
from ....validation.type_validation import assert_index_is_dtype, assert_is_type, assert_index_dtype_in


class AbstractInactivityParameterEstimator(AbstractParameterEstimator):
    """
    Abstract class for functions that estimate periods of inactivity (such as sleep or work) for structures or devices.
    All classes inheriting from this class need to be initiated with a pandas Series.
    """

    def __init__(self, pir_series):
        super(AbstractInactivityParameterEstimator, self).__init__()
        self._validate_series(pir_series)
        self._pir_series = pd.Series(
            data=True,
            index=get_tz_naive_datetime(pir_series.index)
        )

    @abstractmethod
    def estimate_parameters(self, *args, **kwargs):
        raise NotImplementedError

    def get_pir(self):
        return self._pir_series

    @staticmethod
    def _validate_series(series):
        assert_is_type(series, pd.Series)
        assert series.all(), "All values in series must be true"
        assert_index_is_dtype(series.index, np.dtype('<M8[ns]'))

    @classmethod
    def _validate_bin_size(cls, bin_size):
        """
        Checks that a bin_size fits an integer times in an hour.

        Args:
            bin_size: timedelta object
        """
        assert_is_type(bin_size, timedelta)
        assert (
            (MINUTES_PER_HOUR / cls._timedelta_to_minutes(bin_size)) % 1 == 0 or
            ()
        ), (
            "Bin size does not fit an integer amount in an hour"
        )

    @classmethod
    def _any_activity(cls, series, bin_size):
        assert_is_type(series, pd.Series)
        assert_is_type(bin_size, timedelta)
        any_series = series.resample("{}min".format(cls._timedelta_to_minutes(bin_size)), how="max").dropna()
        return pd.Series(data=True, index=any_series.index)

    @staticmethod
    def _timedelta_to_minutes(td):
        return int(td.total_seconds() / SECONDS_PER_MINUTE)

    @staticmethod
    def _get_active_days(series, min_activities_per_day=1):
        """
        Computes the amount of days where at least 'min_activities_per_day' entries are present.

        Args:
            series: pandas Series object
            min_activities_per_day: minimum amount of samples per day in order for a day to be considered 'active'

        Returns:
            amount of active days as integer

        """
        return pd.Series(data=series.groupby(series.index.date).count() >= min_activities_per_day).sum()

    @staticmethod
    def _reindex_time_as_float_minute(series):
        """
        Reindexes a pandas Series with a time index to a float index where the float represents the number of
        minutes since midnight.

        Args:
            series: pandas Series with a time index

        Returns:
            pandas Series with float index

        """
        assert_index_is_dtype(series.index, time)
        return pd.Series(
            data=series.values,
            index=[int(time_to_hour_float(t) * MINUTES_PER_HOUR) for t in series.index]
        )

    @classmethod
    def _force_24h_index(cls, series, bin_size):
        """
        Forces equally distributed time index with bin_size intervals. Fills nans with 0.
        Args:
            series: pandas.Series with a float/int index
            bin_size: timedelta object specifying the width of the bins. Needs to fit an integer times in 24h

        Returns:

        """
        assert_is_type(series, pd.Series)
        assert_index_dtype_in(series.index, [float, int])
        assert_is_type(bin_size, timedelta)
        return series.reindex(
            np.arange(0, MINUTES_PER_DAY, cls._timedelta_to_minutes(bin_size), dtype=np.int),
            fill_value=0
        )

    @staticmethod
    def _assert_axis(axis):
        """
        Asserts an axis is created if None is passed.

        Args:
            axis: matplotlib.Axes class or None

        Returns:
            matplotlib.Axes object
        """
        if axis is None:
            _, axis = plt.subplots()
        assert_is_type(axis, plt.Axes)
        return axis
