import numpy as np
import pandas as pd

from datetime import date, datetime, time, timedelta

from ..abstract_inactivity_parameter_estimator import AbstractInactivityParameterEstimator
from ....parameters import InactivityParameters, InactivityTransitionDistribution
from .....converters.time_constants import (MINUTES_PER_DAY,
                                            MINUTES_PER_HOUR,
                                            SECONDS_PER_MINUTE)
from .....converters.time_converters import time_to_hour_float
from .....manipulators.periodic_series import PeriodicSeries
from .....validation.type_validation import assert_is_type


class NightlyThresholdInactivityParameterEstimator(AbstractInactivityParameterEstimator):

    def __init__(self, pir_series):
        super(NightlyThresholdInactivityParameterEstimator, self).__init__(pir_series)

    def estimate_parameters(self, bin_size, threshold=time(hour=4), limit=timedelta(hours=8)):
        """
        Estimate bed and wake-up times based on PIR readings by assuming the last pir before threshold is the bedtime
        and the first pir after threshold is the wake-up time. Bedtimes before (threshold-limit) and
        wake-up times after (threshold+limit) are ignored.

        Args:
            bin_size: timedelta object specifying the width of the bins. Needs to fit an integer times in 24h
            threshold: datetime.time which acts as the boundary between bedtimes and wake-up times.
            limit: timdelta which deals with extreme outliers. Bedtimes before (threshold-limit) and
             wake-up times after (threshold+limit) are ignored.

        Returns:
            an InactivityParameters object that describes the transition probabilities of going to bed and waking up
            as a function of time.
        """
        self._validate_bin_size(bin_size)
        assert_is_type(threshold, time)
        assert_is_type(limit, timedelta)

        bin_size_minute = bin_size.total_seconds() / SECONDS_PER_MINUTE
        start_pdf, end_pdf = self._estimate_pdfs(
            self._pir_series,
            bin_size,
            threshold,
            limit,
        )
        return InactivityParameters(
            InactivityTransitionDistribution(start_pdf, bin_size_minute, MINUTES_PER_DAY),
            InactivityTransitionDistribution(end_pdf, bin_size_minute, MINUTES_PER_DAY),
        )

    def _estimate_pdfs(self, series, bin_size, threshold_time, limit):
        """
        Estimate two discrete probability density functions (for waking up and going to bed) from pir data.

        Args:
            series: pandas.Series object containing timestamps as indices and True as values
            bin_size: timedelta object specifying the width of the bins. Needs to fit an integer times in 24h
            threshold_time: datetime.time which acts as the boundary between bedtimes and wake-up times.
            limit: timdelta which deals with extreme outliers. Bedtimes before (threshold-limit) and
            wake-up times after (threshold+limit) are ignored.

        Returns:
            two pandas.Series with discrete transition probabilities for transitioning from activity to inactivity and
             vice versa

        """
        bin_size_minute = self._timedelta_to_minutes(bin_size)
        lower_limit_minute = self._minutes_since_midnight(self._time_plus_timedelta(threshold_time, -limit))
        threshold_minute = time_to_hour_float(threshold_time)*MINUTES_PER_HOUR

        bed_times_count, wake_up_times_counts = self._bed_wakeup_counts(series, bin_size, threshold_time, limit)

        bed_times_probabilities = bed_times_count / max(bed_times_count.sum(), 1)
        wake_up_probabilities = wake_up_times_counts / max(wake_up_times_counts.sum(), 1)

        periodic_bed_time_probabilities = PeriodicSeries(
            bed_times_probabilities,
            MINUTES_PER_DAY
        ).get_rebased_periodic_series(lower_limit_minute)

        bed_times_start_index = periodic_bed_time_probabilities.get_series()[
            periodic_bed_time_probabilities.get_series() > 0
            ].index[0]
        bed_time_probabilities_rebased = periodic_bed_time_probabilities.get_rebased_periodic_series(
            bed_times_start_index
        ).get_series()

        periodic_wake_up_time_probabilities = PeriodicSeries(
            wake_up_probabilities,
            MINUTES_PER_DAY
        ).get_rebased_periodic_series(threshold_minute)
        wake_up_times_start_index = periodic_wake_up_time_probabilities.get_series()[
                                        periodic_wake_up_time_probabilities.get_series() > 0
                                        ].index[-1] + bin_size_minute
        wake_up_time_probabilities_rebased = periodic_wake_up_time_probabilities.get_rebased_periodic_series(
            wake_up_times_start_index
        ).get_series().sort_index(ascending=False)

        return bed_time_probabilities_rebased, wake_up_time_probabilities_rebased

    @classmethod
    def _bed_wakeup_counts(cls, series, bin_size, threshold_time, limit):
        assert_is_type(bin_size, timedelta)
        assert_is_type(threshold_time, time)
        assert_is_type(limit, timedelta)

        lower_limit = cls._time_plus_timedelta(threshold_time, -limit)
        upper_limit = cls._time_plus_timedelta(threshold_time, +limit)

        threshold_timedelta = timedelta(
            hours=threshold_time.hour,
            minutes=threshold_time.minute,
            seconds=threshold_time.second,
        )

        series_shifted_time = pd.Series(
            data=series.index,
            index=series.index - threshold_timedelta
        )

        bed_times_rev = pd.Series(
            data=series_shifted_time.groupby(lambda x: x.date).last(),
            index=series.groupby(series.index.date).any().index
        ).dropna()
        bed_times = pd.Series(
            data=bed_times_rev.index,
            index=bed_times_rev
        )

        wake_up_times_rev = pd.Series(
            data=series_shifted_time.groupby(lambda x: x.date).first(),
            index=series.groupby(series.index.date).any().index
        ).dropna()
        wake_up_times = pd.Series(
            data=wake_up_times_rev.index,
            index=wake_up_times_rev
        )

        limited_bed_times = bed_times[
            (bed_times.index.time >= lower_limit) | (bed_times.index.time <= threshold_time)
            ]
        limited_wake_up_times = wake_up_times[wake_up_times.index.time <= upper_limit]

        limited_bed_times_resample = cls._any_activity(limited_bed_times, bin_size)
        limited_wake_up_times_resample = cls._any_activity(limited_wake_up_times, bin_size)

        bed_times_count_float = cls._series_to_24h_counts(limited_bed_times_resample, bin_size)
        wake_up_times_count_float = cls._series_to_24h_counts(limited_wake_up_times_resample, bin_size)

        return bed_times_count_float, wake_up_times_count_float

    @classmethod
    def _series_to_24h_counts(cls, series, bin_size):
        if series.any():
            counts = series.groupby(series.index.time).count()
            counts_float_index = cls._reindex_time_as_float_minute(counts)
        else:
            counts_float_index = pd.Series(data=0, index=[0])
        return cls._force_24h_index(counts_float_index, bin_size)

    @staticmethod
    def _minutes_since_midnight(t):
        assert_is_type(t, time)
        return time_to_hour_float(t)*MINUTES_PER_HOUR

    @staticmethod
    def _time_plus_timedelta(t, td):
        assert_is_type(t, time)
        assert_is_type(td, timedelta)
        zero_datetime = datetime.combine(
            date(2015, 1, 1),
            t
        )
        return (zero_datetime+td).time()

