from ..results import ValidationResults
from ..abstract_results_builder import AbstractResultsBuilder


class ValidationResultsBuilder(AbstractResultsBuilder):

    def __init__(self):
        super(ValidationResultsBuilder, self).__init__(object_cls=ValidationResults)
