from ..results import TrainingResults
from ..abstract_results_builder import AbstractResultsBuilder


class TrainingResultsBuilder(AbstractResultsBuilder):

    def __init__(self):
        super(TrainingResultsBuilder, self).__init__(object_cls=TrainingResults)
