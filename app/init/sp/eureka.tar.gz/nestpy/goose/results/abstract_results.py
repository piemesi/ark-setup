from abc import ABCMeta

from ..data_collection.abstract_data_collection import AbstractDataCollection
from ..models.sensor_model_collection import SensorModelCollection
from ..sensors import SensorEventsCollection
from ..states.state_series_ import EstimatedTruthStateSeries, GroundTruthStateSeries
from ..states.state_series_.auto_away_state_series_ import DeviceAutoAwayStateSeries
from ...validation.type_validation import assert_is_type, assert_type_in


class AbstractResults(object):
    __metaclass__ = ABCMeta

    def __init__(self,
                 experiment_id,
                 data_collection,
                 sensor_events_collection,
                 estimated_truth_state_series,
                 sensor_model_collection,
                 ground_truth_state_series=None,
                 device_auto_away_state_series=None):
        assert_type_in(experiment_id, [basestring, int])
        assert_is_type(data_collection, AbstractDataCollection)
        assert_is_type(sensor_events_collection, SensorEventsCollection)
        assert_is_type(estimated_truth_state_series, EstimatedTruthStateSeries)
        assert_is_type(sensor_model_collection, SensorModelCollection)
        if ground_truth_state_series is not None:
            assert_is_type(ground_truth_state_series, GroundTruthStateSeries)
        if device_auto_away_state_series is not None:
            assert_is_type(device_auto_away_state_series, DeviceAutoAwayStateSeries)
        self._experiment_id = experiment_id
        self._data_collection = data_collection
        self._sensor_events_collection = sensor_events_collection
        self._estimated_truth_state_series = estimated_truth_state_series
        self._ground_truth_state_series = ground_truth_state_series
        self._device_auto_away_state_series = device_auto_away_state_series
        self._sensor_model_collection = sensor_model_collection

    def __repr__(self):
        return "<{}: experiment_id={}>".format(self.__class__.__name__, self._experiment_id)

    def get_experiment_id(self):
        return self._experiment_id

    def get_data_collection(self):
        return self._data_collection

    def get_sensor_events_collection(self):
        return self._sensor_events_collection

    def get_estimated_truth_state_series(self):
        return self._estimated_truth_state_series

    def get_ground_truth_state_series(self):
        return self._ground_truth_state_series

    def get_device_auto_away_state_series(self):
        return self._device_auto_away_state_series

    def get_sensor_model_collection(self):
        return self._sensor_model_collection
