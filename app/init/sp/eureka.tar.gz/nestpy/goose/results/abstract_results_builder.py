from abc import ABCMeta

from .abstract_results import AbstractResults
from ..building.abstract_object_builder import AbstractObjectBuilder


class AbstractResultsBuilder(AbstractObjectBuilder):
    __metaclass__ = ABCMeta

    def _get_object_base_cls(self):
        return AbstractResults
