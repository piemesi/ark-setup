from ..abstract_results import AbstractResults
from ...application_process.application_processor_results import ApplicationProcessorResults
from ...application_process.application_processor_results_collection import (
    ApplicationProcessorResultsCollection
)
from ...filter_process.filter_processor_results import FilterProcessorResults
from ....validation.type_validation import assert_is_type


class ValidationResults(AbstractResults):

    def __init__(self,
                 filter_processor_results,
                 application_processor_results,
                 application_processor_results_collection,
                 *args,
                 **kwargs):
        super(ValidationResults, self).__init__(*args, **kwargs)
        assert_is_type(filter_processor_results, FilterProcessorResults)
        assert_is_type(application_processor_results, ApplicationProcessorResults)
        assert_is_type(application_processor_results_collection, ApplicationProcessorResultsCollection)
        self._filter_processor_results = filter_processor_results
        self._application_processor_results = application_processor_results
        self._application_processor_results_collection = application_processor_results_collection

    def get_filter_processor_results(self):
        return self._filter_processor_results

    def get_application_processor_results(self):
        return self._application_processor_results

    def get_application_processor_results_collection(self):
        return self._application_processor_results_collection
