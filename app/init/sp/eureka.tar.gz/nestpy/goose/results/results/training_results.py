from ..abstract_results import AbstractResults
from ...models.models.abstract_transition_model import AbstractTransitionModel
from ....validation.type_validation import assert_is_type


class TrainingResults(AbstractResults):

    def __init__(self, transition_model, *args, **kwargs):
        super(TrainingResults, self).__init__(*args, **kwargs)
        assert_is_type(transition_model, AbstractTransitionModel)
        self._transition_model = transition_model

    def get_transition_model(self):
        return self._transition_model
