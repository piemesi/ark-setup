# pylint: disable=invalid-name,no-member
import json
import logging
import os
import sys

import numpy as np
import pandas as pd

from ..converters import time_converters
from .cpp_enums import parse_cpp_enum_to_dict, parse_cpp_enums_to_dict_of_dicts
from .tvd_utils import remove_raw_values


logger = logging.getLogger(__name__)


# many options for event-specific parsing:
#  1. use a dictionary to lookup values given keys
#    a. dictionary loaded from a c++ enum (see nlSentence_Played parser)
#    b. dictionary loaded from a json resource file (see spoken_where_id parser)
#    c. dictionary hardcoded in this file (see auto_away_state)
#  2. define a function is run on a specific column in an event dataframe (see serial_number parser)
#  3. define a operation that is run on the whole event dataframe (see remove_raw_values)


name_conversion = {'spoken_where_id':'spoken_where'}
with open(os.path.join(os.path.dirname(os.path.realpath(__file__)), 'topaz_definitions', 'spoken_where_id.json')) as data_file:
    spoken_where_id = json.load(data_file)


auto_away_state = parse_cpp_enum_to_dict("""
    enum auto_away_state {
        nlAutoAwayStatePresent = 0,
        nlAutoAwayStateAbsent = 1,
    };
    """)


reset_reason = parse_cpp_enum_to_dict("""
    enum{
        kResetReasonPOR           = 0x01,
        kResetReasonLVD           = 0x02,
        kResetReasonResetAsserted = 0x04,
        kResetReasonWakup         = 0x08,
        kResetReasonWatchdog      = 0x10,
        kResetReasonSW            = 0x20,
    };
    """)


wakeup_source = parse_cpp_enum_to_dict("""
    enum {
        kWakeupSourceSensorMCU = (0x1 << 0),
        kWakeupSourceButton    = (0x1 << 1),
        kWakeupSourceRTC       = (0x1 << 2),
        kWakeupSourceWiFi      = (0x1 << 3),
        kWakeupSourceLoWPAN    = (0x1 << 4),
        kWakeupSourceLpTimer   = (0x1 << 5),
        kWakeupSourceExitTrap  = (0x1 << 6),
        kWakeupSourceUSB       = (0x1 << 7),
    };
    """)


wave_detection_state = parse_cpp_enum_to_dict("""
    enum nlState_t
    {
        nlState_Disabled,
        nlState_Calibrating,
        nlState_CalibratingForced,
        nlState_LookingForOccupancy,
        nlState_LookingForNearPerson,
        nlState_LookingForWave,
        nlState_WaveDetected
    };
    """)


alarm_state = parse_cpp_enum_to_dict("""
    enum alarm_state {
        nlAll_Clear = 0,
        nlMonitor = 1,
        // removed nlHU2,
        nlAlarm = 3,
        nlHushed = 4
    };
    """)


alarm = parse_cpp_enum_to_dict("""
    typedef enum Alarm_t {
        kInvalidAlarm = 0x0,
        kSmokeAlarm=0x1,
        kHeatAlarm=0x2,
        kCOAlarm=0x4,
        kTroubleAlarm=0x8,
        kAlarmAll=0xf
    }Alarm_t;
    """)


alarm_event = parse_cpp_enum_to_dict("""
    typedef enum AlarmEvent_t {
        kAlarmIdle,
        kAlarmPresent,
        kAlarmUnhushable,
        kAlarmMonitor,
        kAlarmHushed,
        kAlarmInvalid
    }AlarmEvent_t;
    """)


horn_event = parse_cpp_enum_to_dict("""
    typedef enum HornEvent_t {
        kHornIdle,
        kHornBeep,
        kHornTalk,
        kHornInvalid
    }HornEvent_t;
    """)

alarm_type = parse_cpp_enum_to_dict("""
    enum nlAlarmType_t
    {
        nlAlarmType_Invalid = -1,
        nlAlarmType_Smoke,
        nlAlarmType_Smoke_Remote,
        nlAlarmType_CO,
        nlAlarmType_CO_Remote,
        nlAlarmType_Heat,
        nlAlarmType_Heat_Remote,

        nlAlarmType_First = nlAlarmType_Smoke,
        nlAlarmType_Last = nlAlarmType_Heat_Remote,
    };
    """)


stay_awake_reason = parse_cpp_enum_to_dict("""
    enum
    {
        nlStayAwakeReason_AppTask_NotReady = 1000,
        nlStayAwakeReason_AppTask_UserActivity,
        nlStayAwakeReason_AppTask_CntlrsNotReady,
        nlStayAwakeReason_AppTask_AudioPlaying,
        nlStayAwakeReason_ControlTask_NotReady,
        nlStayAwakeReason_ControlTask_Alarming,
        nlStayAwakeReason_ControlTask_WaveDetector_NotReady,
        nlStayAwakeReason_Sensors_Downloading,
        nlStayAwakeReason_Network_NotReady
    };
    """)


sensor_type = parse_cpp_enum_to_dict("""
    enum nlSensorType_t
    {
        nlSensorType_First,

        nlSensorType_BPSensorFirst = nlSensorType_First,
        nlSensorType_FIFOSensorFirst = nlSensorType_BPSensorFirst,
        nlSensorType_Smoke = nlSensorType_FIFOSensorFirst,
        nlSensorType_CO,
        nlSensorType_Temp,
        nlSensorType_Heat,
        nlSensorType_Humidity,
        nlSensorType_PIR,
        nlSensorType_ALS,
        nlSensorType_FIFOSensorLast = nlSensorType_ALS,

        nlSensorType_CO_Bucket_First,
        nlSensorType_CO_Bucket_Low = nlSensorType_CO_Bucket_First,
        nlSensorType_CO_Bucket_Mid,
        nlSensorType_CO_Bucket_High,
        nlSensorType_CO_Bucket_VeryHigh,
        nlSensorType_CO_Bucket_Last = nlSensorType_CO_Bucket_VeryHigh,
        nlSensorType_VBAT1,
        nlSensorType_VBAT2,
        nlSensorType_VBAT1_Inst,
        nlSensorType_VBAT2_Inst,
        nlSensorType_BPSensorLast = nlSensorType_VBAT2_Inst,

        nlSensorType_Ultrasound,
        nlSensorType_InstantaneousPIR,

        nlSensorType_Last = nlSensorType_InstantaneousPIR
    };
    """)


night_time_promise_state = parse_cpp_enum_to_dict("""
    enum night_time_promise_state {
        nlNightTimePromiseOff = 0,
        nlNightTimePromisePresented = 1, // Deprecated
        nlNightTimePromiseDelivered = 2,
        nlNightTimePromiseYellowAnimation = 3,
        nlNightTimePromiseGreenAnimation = 4,
        nlNightTimePromiseAnimationSkipped = 5,
    };
    """)


night_light_state = parse_cpp_enum_to_dict("""
    enum nlState_t
    {
        nlState_Disabled,
        nlState_LookingForDark,
        nlState_LookingForPerson,
        nlState_Active
    };
    """)


night_light_display_state = parse_cpp_enum_to_dict("""
    enum night_light_display_state {
        nlNightLightDisplayOff = 0,
        nlNightLightDisplayOn = 1
    };
    """)


lights_out_detector_state = parse_cpp_enum_to_dict("""
    enum nlLightsOutDetectorState_t
    {
        nlLightsOutDetectorStateLookingForLight = 0,    // High upper and high lower thresholds set
        nlLightsOutDetectorStateLookingBothWays,        // High upper and low lower thresholds set
        nlLightsOutDetectorStateLookingForDrop          // Low upper threshold set
    };
    """)


software_update_state = parse_cpp_enum_to_dict("""
    enum nlState_t
    {
        nlState_Idle,
        nlState_Querying,
        nlState_Preparing,          // Open the file
        nlState_Downloading,
        nlState_Installing
    };
    """)


smoke_alarm_threshold_level = parse_cpp_enum_to_dict("""
    enum nlSmokeAlarmThreshLevel_t
    {
        nlSmokeAlarmThreshLevel_Invalid = 0xff,        // We set this up high so we can use a MIN operation
        nlSmokeAlarmThreshLevel_Base = 0,
        nlSmokeAlarmThreshLevel_Low,
        nlSmokeAlarmThreshLevel_Mid,
        nlSmokeAlarmThreshLevel_High
    };
    """)


service_provisioning_event = parse_cpp_enum_to_dict("""
    enum ServiceProvisioningEventArguments
    {
        kServiceProvisioningRegisterService = 0,
        kServiceProvisioningUnregisterService,
        kServiceProvisioningPairingSuccessful,
        kServiceProvisioningPairingError,
    };
    """)


provisioning_event = parse_cpp_enum_to_dict("""
    enum ProvisioningEvent
    {
        kEventUnknown = 0,
        kEventRequestScanNetworks,
        kEventRequestAddNetwork,
        kEventRequestRemoveNetwork,
        kEventRequestUpdateNetwork,
        kEventRequestEnableNetwork,
        kEventRequestDisableNetwork,
        kEventRequestTestConnectivity,
        kEventRequestTestConnectivityEnableNetwork,
        kEventDidScan,
        kEventDidNotScan,
        kEventDidAddNetwork,
        kEventDidNotAddNetwork,
        kEventDidRemoveNetwork,
        kEventDidUpdateNetwork,
        kEventDidEnableNetwork,
        kEventDidNotEnableNetwork,
        kEventEnableRetriesExhausted,
        kEventDidDisableNetwork,
        kEventConnectivityTestPassed,
        kEventConnectivityTestFailed,
        kEventStartConnectingThreadScan,
        kEventThreadDidScan,
        kEventThreadDidNotScan,
        kEventStartConnectingThreadConnect,
        kEventThreadDidConnect,
        kEventThreadDidNotConnect,
        kEventThreadRetriesExhausted,
        kEventReadyToRetryThreadScan,
        kEventGetNetworks,
    };
    """)


provisioning_type = parse_cpp_enum_to_dict("""
    enum
    {
        nlHuntingEvent = 0,
        nlProvisioningEvent,
        nlFabricProvisioningEvent,
        nlServiceProvisioningEvent,
        nlSWUQueryEvent,
        nlSWUDownloadEvent,
        nlSWUInstallEvent,
        nlFailsafeEvent,
        nlProvisioningCompleteEvent
    };
    """)


activate_reason = parse_cpp_enum_to_dict("""
    enum
    {
        nlActivateReason_Pushed,
        nlActivateReason_Revealed,
        nlActivateReason_PoppingThrough
    };
    """)


deactivate_reason = parse_cpp_enum_to_dict("""
    enum
    {
        nlDeactivateReason_Popped,
        nlDeactivateReason_Hidden,
        nlDeactivateReason_PoppingThrough
    };
    """)


weave_feature = parse_cpp_enum_to_dict("""
    enum
    {
        nl_hist_weave_feature_SettingsSync = 0,
        nl_hist_weave_feature_SensorDataUpload,
        nl_hist_weave_feature_SoftwareUpdate,
        nl_hist_weave_feature_RemoteWake,
        nl_hist_weave_feature_RemoteWakeListener,
        nl_hist_weave_feature_RemoteAlarm,
        nl_hist_weave_feature_Provisioning,
        nl_hist_weave_feature_ServiceProvisioning,
        nl_hist_weave_feature_FabricProvisioning,
        nl_hist_weave_feature_DeviceControl,
        nl_hist_weave_feature_DeviceDescription,
        nl_hist_weave_feature_DownloadFeature,
        nl_hist_weave_feature_NetworkProvisioning,
        nl_hist_weave_feature_SWUQueryFeature,
        nl_hist_weave_feature_SettingsSubscribe,

        // the following values will be ORe with an additional error_type_t: ERROR_TYPE_APP, ERROR_TYPE_NM, ERROR_TYPE_WEAVE, etc.
        nl_hist_weave_feature_6LoWPANEnable_APP     = 0x100,
        nl_hist_weave_feature_6LoWPANEnable_NM,
        nl_hist_weave_feature_6LoWPANEnable_WEAVE,
        nl_hist_weave_feature_6LoWPANEnable_INET,
        nl_hist_weave_feature_6LoWPANEnable_SERVICE,
        nl_hist_weave_feature_6LoWPANEnable_BOARD,
        nl_hist_weave_feature_6LoWPANEnable_TIMEOUT,
        nl_hist_weave_feature_6LoWPANService_APP     = 0x200,
        nl_hist_weave_feature_6LoWPANService_NM,
        nl_hist_weave_feature_6LoWPANService_WEAVE,
        nl_hist_weave_feature_6LoWPANService_INET,
        nl_hist_weave_feature_6LoWPANService_SERVICE,
        nl_hist_weave_feature_6LoWPANService_BOARD,
        nl_hist_weave_feature_6LoWPANService_TIMEOUT,
        nl_hist_weave_feature_APConn_APP             = 0x300,
        nl_hist_weave_feature_APConn_NM,
        nl_hist_weave_feature_APConn_WEAVE,
        nl_hist_weave_feature_APConn_INET,
        nl_hist_weave_feature_APConn_SERVICE,
        nl_hist_weave_feature_APConn_BOARD,
        nl_hist_weave_feature_APConn_TIMEOUT,
        nl_hist_weave_feature_DeviceCtrl_APP         = 0x400,
        nl_hist_weave_feature_DeviceCtrl_NM,
        nl_hist_weave_feature_DeviceCtrl_WEAVE,
        nl_hist_weave_feature_DeviceCtrl_INET,
        nl_hist_weave_feature_DeviceCtrl_SERVICE,
        nl_hist_weave_feature_DeviceCtrl_BOARD,
        nl_hist_weave_feature_DeviceCtrl_TIMEOUT,
        nl_hist_weave_feature_DeviceDesc_APP         = 0x500,
        nl_hist_weave_feature_DeviceDesc_NM,
        nl_hist_weave_feature_DeviceDesc_WEAVE,
        nl_hist_weave_feature_DeviceDesc_INET,
        nl_hist_weave_feature_DeviceDesc_SERVICE,
        nl_hist_weave_feature_DeviceDesc_BOARD,
        nl_hist_weave_feature_DeviceDesc_TIMEOUT,
        nl_hist_weave_feature_FabricProv_APP         = 0x600,
        nl_hist_weave_feature_FabricProv_NM,
        nl_hist_weave_feature_FabricProv_WEAVE,
        nl_hist_weave_feature_FabricProv_INET,
        nl_hist_weave_feature_FabricProv_SERVICE,
        nl_hist_weave_feature_FabricProv_BOARD,
        nl_hist_weave_feature_FabricProv_TIMEOUT,
        nl_hist_weave_feature_NetworkProv_APP        = 0x700,
        nl_hist_weave_feature_NetworkProv_NM,
        nl_hist_weave_feature_NetworkProv_WEAVE,
        nl_hist_weave_feature_NetworkProv_INET,
        nl_hist_weave_feature_NetworkProv_SERVICE,
        nl_hist_weave_feature_NetworkProv_BOARD,
        nl_hist_weave_feature_NetworkProv_TIMEOUT,
        nl_hist_weave_feature_ServiceProv_APP        = 0x800,
        nl_hist_weave_feature_ServiceProv_NM,
        nl_hist_weave_feature_ServiceProv_WEAVE,
        nl_hist_weave_feature_ServiceProv_INET,
        nl_hist_weave_feature_ServiceProv_SERVICE,
        nl_hist_weave_feature_ServiceProv_BOARD,
        nl_hist_weave_feature_ServiceProv_TIMEOUT,
        nl_hist_weave_feature_StationConn_APP        = 0x900,
        nl_hist_weave_feature_StationConn_NM,
        nl_hist_weave_feature_StationConn_WEAVE,
        nl_hist_weave_feature_StationConn_INET,
        nl_hist_weave_feature_StationConn_SERVICE,
        nl_hist_weave_feature_StationConn_BOARD,
        nl_hist_weave_feature_StationConn_TIMEOUT,
        nl_hist_weave_feature_WifiEnable_APP         = 0xa00,
        nl_hist_weave_feature_WifiEnable_NM,
        nl_hist_weave_feature_WifiEnable_WEAVE,
        nl_hist_weave_feature_WifiEnable_INET,
        nl_hist_weave_feature_WifiEnable_SERVICE,
        nl_hist_weave_feature_WifiEnable_BOARD,
        nl_hist_weave_feature_WifiEnable_TIMEOUT,
    } nl_hist_weave_feature_t
    """)

topaz_sentences = parse_cpp_enum_to_dict("""
    enum
    {
        nlTopazSentence_Alarming_alarm_is_over = 0,
        nlTopazSentence_Alarming_all_clear = 1,
        nlTopazSentence_Alarming_co_alarm_1 = 2,
        nlTopazSentence_Alarming_co_alarm_2 = 3,
        nlTopazSentence_Alarming_co_alarm_is_over = 4,
        nlTopazSentence_Alarming_co_prealarm_1 = 5,
        nlTopazSentence_Alarming_co_prealarm_2 = 6,
        nlTopazSentence_Alarming_co_prealarm_silenced = 7,
        nlTopazSentence_Alarming_co_silenced = 8,
        nlTopazSentence_Alarming_silenced = 9,
        nlTopazSentence_Alarming_silenced_in_this_room = 10,
        nlTopazSentence_Alarming_smoke_alarm_1 = 11,
        nlTopazSentence_Alarming_smoke_alarm_2 = 12,
        nlTopazSentence_Alarming_smoke_alarm_3 = 13,
        nlTopazSentence_Alarming_smoke_alarm_4 = 14,
        nlTopazSentence_Alarming_smoke_alarm_5 = 15,
        nlTopazSentence_Alarming_smoke_alarm_6 = 16,
        nlTopazSentence_Alarming_smoke_alarm_7 = 17,
        nlTopazSentence_Alarming_smoke_alarm_is_over = 18,
        nlTopazSentence_Alarming_smoke_co_silenced = 19,
        nlTopazSentence_Alarming_smoke_prealarm_1 = 20,
        nlTopazSentence_Alarming_smoke_prealarm_silenced = 21,
        nlTopazSentence_Alarming_smoke_silenced = 22,
        nlTopazSentence_Alarming_smoke_silenced_disallowed_1 = 23,
        nlTopazSentence_Alarming_smoke_silenced_disallowed_2 = 24,
        nlTopazSentence_Arguments_volume_alarm = 25,
        nlTopazSentence_Arguments_volume_emergency_volume = 26,
        nlTopazSentence_Arguments_volume_interaction = 27,
        nlTopazSentence_Arguments_volume_notification = 28,
        nlTopazSentence_Chime_hi_nest = 29,
        nlTopazSentence_Chirp = 30,
        nlTopazSentence_Factoryreset_cancelled = 31,
        nlTopazSentence_Factoryreset_countdown = 32,
        nlTopazSentence_Factoryreset_started = 33,
        nlTopazSentence_Factoryreset_version = 34,
        nlTopazSentence_Hello = 35,
        nlTopazSentence_Hi_nest = 36,
        nlTopazSentence_Language_selection = 37,
        nlTopazSentence_Pairing = 38,
        nlTopazSentence_Please_try_again_later = 39,
        nlTopazSentence_Ready = 40,
        nlTopazSentence_Selftest_cancelled = 41,
        nlTopazSentence_Selftest_countdown_press_to_cancel = 42,
        nlTopazSentence_Selftest_finishing_up = 43,
        nlTopazSentence_Selftest_just_a_moment = 44,
        nlTopazSentence_Selftest_measure_room = 45,
        nlTopazSentence_Selftest_nest_protect_was_unable_to_complete_the_test = 46,
        nlTopazSentence_Selftest_passed = 47,
        nlTopazSentence_Selftest_passed_with_warnings = 48,
        nlTopazSentence_Selftest_processing_countdown = 49,
        nlTopazSentence_Selftest_starting_co_test = 50,
        nlTopazSentence_Selftest_starting_smoke_test = 51,
        nlTopazSentence_Walldetect_changed = 52,
        nlTopazSentence_Warnings_battery_low = 53,
        nlTopazSentence_Warnings_battery_very_low = 54,
        nlTopazSentence_Warnings_cant_sound_the_alarm = 55,
        nlTopazSentence_Warnings_everything_ok = 56,
        nlTopazSentence_Warnings_internet_disconnected = 57,
        nlTopazSentence_Warnings_power_is_out = 58,
        nlTopazSentence_Warnings_problem = 59,
        nlTopazSentence_Warnings_sensors_expired = 60,
        nlTopazSentence_Warnings_sensors_failed = 61,
        nlTopazSentence_Warnings_tone = 62,
        nlTopazSentence_Warnings_voice_not_working = 63,
        nlTopazSentence_Warnings_will_expire = 64,
        nlTopazSentence_Word_1_volume_050 = 65,
        nlTopazSentence_Word_1_volume_092 = 66,
        nlTopazSentence_Word_1_volume_100 = 67,
        nlTopazSentence_Zzz_boop = 68,
        nlTopazSentence_Zzz_debug_volume_v_050 = 69,
        nlTopazSentence_Zzz_debug_volume_v_060 = 70,
        nlTopazSentence_Zzz_debug_volume_v_070 = 71,
        nlTopazSentence_Zzz_debug_volume_v_080 = 72,
        nlTopazSentence_Zzz_debug_volume_v_090 = 73,
        nlTopazSentence_Zzz_debug_volume_v_100 = 74,
        nlTopazSentence_Max,
        nlTopazSentence_Unknown,
    } nlTopazSentences;
    """)

topaz_daily_reasons = parse_cpp_enum_to_dict("""
    enum
    {
        k_daily_connected = 1,      // There appears to have been a conection
        k_daily_trying_sleep,       // No conections, trying sleep to clear
        k_daily_trying_reboot,      // No conections, trying reboot to clear
    }
    """)

sleep_request_urgency = parse_cpp_enum_to_dict("""
    enum nlSleepRequestUrgency_t
    {
        nlSleepRequestUrgency_Low,
        nlSleepRequestUrgency_Mid,
        nlSleepRequestUrgency_High
    };
    """)

failsafe_provisioning_event = parse_cpp_enum_to_dict("""
    enum FailsafeProvisioningEvent
    {
        kFailsafeDisarmed = 0,
        kFailsafeArmed = 1,
    };
    """)

fabric_provisioning_event = parse_cpp_enum_to_dict("""
    enum FabricProvisioningEvent
    {
        kEventStartStoreFabricIdAndKey = 0,
        kEventDidStoreFabricIdAndKey,
        kEventDidNotStoreFabricIdAndKey,
        kEvent6LoWPANTechReady,
        kEvent6LoWPANTechNotReady,
        kEventStartCreate6LoWPANService,
        kEventDidCreate6LoWPANService,
        kEventDidNotCreate6LoWPANService,
        kEventDidCreate6LoWPANProvision,
        kEventDidNotCreate6LoWPANProvision,
        kEvent6LoWPANServiceReady,
        kEvent6LoWPANServiceNotReady,
        kEventWiFiStationReady,
        kEventWiFiStationNotReady,
        kEventDidAssignWiFiStationULA,
        kEventDidNotAssignWiFiStationULA,
        kEventDidCreateFabric,
    };
    """)


def get_reset_reasons(reset_reg):
    parsed_reasons = []
    for k, v in reset_reason.iteritems():
        if type(k) == int:
            if reset_reg & k:
                parsed_reasons.append(v)
    return '%s' % parsed_reasons


def get_wakeup_source(wakeup_reg):
    parsed_wakeups = []
    for k, v in wakeup_source.iteritems():
        if type(k) == int:
            if wakeup_reg & k:
                parsed_wakeups.append(v)
    return '%s' % parsed_wakeups


def provisioning_type_specific_status_decoding(row):
    """
    The section below outdated:

    if row['typeCode'] == 'nlProvisioningEvent':
        row['provisioningStatus'] = provisioning_event.get(row['provisioningStatus_raw'], np.nan)
    elif row['typeCode'] == 'nlServiceProvisioningEvent':
        row['provisioningStatus'] = service_provisioning_event.get(row['provisioningStatus_raw'], np.nan)
    else:
        row['provisioningStatus'] = 'Unknown: %d' % row['provisioningStatus_raw']
        logger.warn("Unable to parse provisioning status with typeCode=%s" % (row['typeCode']))
    """

    row['provisioningStatus'] = '%d, ' % row['typeCode_raw']
    row['provisioningStatus'] += '%d ' % row['provisioningStatus_raw']
    row['provisioningStatus'] += ' '
    if row['typeCode_raw'] == 1:
        row['provisioningStatus'] += provisioning_event.get(row['provisioningStatus_raw'], np.nan)
    elif row['typeCode_raw'] == 2:
        row['provisioningStatus'] += fabric_provisioning_event.get(row['provisioningStatus_raw'], np.nan)
    elif row['typeCode_raw'] == 3:
        row['provisioningStatus'] += service_provisioning_event.get(row['provisioningStatus_raw'], np.nan)
    elif row['typeCode_raw'] == 7:
        row['provisioningStatus'] += failsafe_provisioning_event.get(row['provisioningStatus_raw'], np.nan)
    return row


def provisioning_status_decoding(df):
    df['provisioningStatus_raw'] = df['provisioningStatus']
    return df.apply(provisioning_type_specific_status_decoding, axis=1)


nlWFM_Error = parse_cpp_enum_to_dict("""
    enum
    {
        SUCCESS =                                     0x00000000,
        EPERM =                                       0x00000001,
        ENOENT =                                      0x00000002,
        EIO =                                         0x00000005,
        ETIMEOUT =                                    0x00000006,
        EBADF =                                       0x00000009,
        EFAULT =                                      0x0000000e,
        EBUSY =                                       0x00000010,
        ENODEV =                                      0x00000013,
        EINVAL =                                      0x00000016, // {"errorcode": 22, "component": 0, "subcomponent": 0}
        ENOSPC =                                      0x0000001c,
        ETIME =                                       0x0000003e,
        EINPROGRESS =                                 0x00000077,
        EALREADY =                                    0x00000078,
        ESTALE =                                      0x00000074,
        EISCONN =                                     0x0000007f,
        NLER_ERROR_TIMEOUT =                          0x000007d8, // {"errorcode": 2008, "component": 0, "subcomponent": 0}
        HC_ERR_UNSUPPORTED_STATUS_CODE =              0x00001f4b,
        nlFAILURE =                                   0x30010001, // {"errorcode": 1, "component": 3, "subcomponent": 1}
        NM_kErrorBadState =                           0x30020001, // {"errorcode": 1, "component": 3, "subcomponent": 2}
        NM_kErrorAssociationFailed =                  0x3002000a, // {"errorcode": 10, "component": 3, "subcomponent": 2}
        LWIP_ERR_MEM =                                0x50000001, // {"errorcode": 1, "component": 5, "subcomponent": 0}
        LWIP_ERR_RTE =                                0x50000004, // {"errorcode": 4, "component": 5, "subcomponent": 0}
        LWIP_ERR_ABRT =                               0x5000000a, // {"errorcode": 10, "component": 5, "subcomponent": 0}
        LWIP_ERR_RST =                                0x5000000b, // {"errorcode": 11, "component": 5, "subcomponent": 0}
        INET_ERROR_CONNECTION_ABORTED =               0x50640001, // {"errorcode": 1, "component": 5, "subcomponent": 100}
        INET_ERROR_INCORRECT_STATE =                  0x50640003, // {"errorcode": 3, "component": 5, "subcomponent": 100}
        INET_ERROR_HOST_NOT_FOUND =                   0x50640009, // {"errorcode": 9, "component": 5, "subcomponent": 100}
        INET_ERROR_NO_ENDPOINTS =                     0x50640014, // {"errorcode": 20, "component": 5, "subcomponent": 100}
        WEAVE_ERROR_INCORRECT_STATE =                 0x50c80003, // {"errorcode": 3, "component": 5, "subcomponent": 200}
        WEAVE_ERROR_NO_MEMORY =                       0x50c8000b, // {"errorcode": 11, "component": 5, "subcomponent": 200}
        WEAVE_ERROR_STATUS_REPORT_RECEIVED =          0x50c8002c, // {"errorcode": 44, "component": 5, "subcomponent": 200}
        WEAVE_ERROR_TIMEOUT =                         0x50c80032, // {"errorcode": 50, "component": 5, "subcomponent": 200}
        WEAVE_ERROR_SECURITY_MANAGER_BUSY =           0x50c80037,
        WEAVE_ERROR_CONNECTION_CLOSED_UNEXPECTDLY =   0x50c8003c,  // {"errorcode": 60, "component": 5, "subcomponent": 200}
        WEAVE_ERROR_INVALID_SERVICE_EP =              0x50c80043, // {"errorcode": 67, "component": 5, "subcomponent": 200}
        WEAVE_ERROR_NOT_CONNECTED =                   0x50c80048, // {"errorcode": 72, "component": 5, "subcomponent": 200}
        WEAVE_ERROR_NO_UPDATE_AVAILABLE =             0x50c80049, // {"errorcode": 73, "component": 5, "subcomponent": 200}
        WEAVE_ERROR_UNDEFINED_BAD_REQUEST =           0x50c80071, // {"errorcode": 113, "component": 5, "subcomponent": 200}
    };
    """)

def get_error(err):
    data_width = 32
    if (err & (1 << (data_width - 1))):
        #take two's complement - required for pumice
        #if error is already negated (on dolo) then parse normally
        err = abs(err - (1 << data_width))
    errorcode_bits = 16
    subcomponent_bits = 12
    component_bits = 3

    subcomponent_shift = (errorcode_bits)
    component_shift = (errorcode_bits + subcomponent_bits)

    errorcode = err & ( (1 << errorcode_bits) - 1)
    subcomponent = err >> subcomponent_shift & ( (1 << subcomponent_bits) - 1)
    component = err >> component_shift & ( (1 << component_bits) - 1)
    label = nlWFM_Error.get(err, np.nan)

    return {'label':label, 'errorcode': errorcode, 'subcomponent':subcomponent,'component':component}

def serial_number(sn):
    if (type(sn) == str or type(sn) == unicode) and len(sn) == 16:
        sn_parsed = {
            'ProductNumber': sn[0:3],
            'HWRevision': sn[3],
            'HWVersion': sn[4:6],
            'ManufacturingLocation': sn[6:8],
            'WeekOfManufacture': sn[8:10],
            'YearOfManufacture': sn[10:12],
            'SerializedNumber': sn[12:],
            'Color': 'White' if sn[3] == 'A' else 'Black',
            'Power': 'Battery' if sn[0:3] == '05A' else 'Line'
        }
    else:
        sn_parsed = {
            'ProductNumber': np.nan,
            'HWRevision': np.nan,
            'HWVersion': np.nan,
            'ManufacturingLocation': np.nan,
            'WeekOfManufacture': np.nan,
            'YearOfManufacture': np.nan,
            'SerializedNumber': np.nan,
            'Color': 'Unknown',
            'Power': 'Unknown'
        }
    return pd.Series(sn_parsed)


# Parsing Sentences. Logs show a sentence id linked to a particular
# version (hash) of the topazaudio.h file.
audio_definitions = {}
def update_audio_definitions():
    audio_definition_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'topaz_definitions', 'audio')
    audio_definition_files = [f for f in os.listdir(audio_definition_path) if 'nltopazaudio.h_' in f]
    for f in audio_definition_files:
        # hash written to log is only 16 bits
        audio_definitions[int(f[f.index('_')+1:]) & 0xFFFF] = \
            parse_cpp_enums_to_dict_of_dicts(os.path.join(audio_definition_path, f))
update_audio_definitions()


def fetch_missing_audio_definition(hashes_requested):
    # eventually, we would like to fetch missing resources from S3
    # then we would call update_audio_definitions()
    raise NotImplementedError("Cannot yet fetch missing audio definitions")


def lookup_sentences_grouped_hash(group):
    audioHash = group.audioHash.unique()
    if len(audioHash) != 1:
        raise ValueError('Lookup may only be applied for a group of logs with the same hash')
    parser = audio_definitions[audioHash[0]]['nlTopazSentences']
    group['sentence'] = [parser[x] if x in parser else np.nan for x in group.sentenceID]
    return group


def parse_sentence_with_hash(df):
    requiredHashes = df.audioHash.unique()
    missingHashes = [requiredHash for requiredHash in requiredHashes if requiredHash not in audio_definitions]
    if len(missingHashes) > 0:
        # TODO - once we have hosted audio definitions
        # fetch_missing_audio_definition(missingHashes)
        logger.info('Unable to parse sentences because missingHashes = %s' % (str(missingHashes)))
        return df
    return df.groupby('audioHash').apply(lookup_sentences_grouped_hash)


def parse_topaz_metadata(metadata):
    for column in metadata:
        # check if this column name is defined in this module
        if hasattr(sys.modules[__name__], column):
            parser = getattr(sys.modules[__name__], column)

            if type(parser) == dict: # if it is a lookup table
                metadata[column] = [parser[x] if x in parser else np.nan for x in metadata[column]]

            elif hasattr(parser, '__call__'): # if it is a function
                metadata = metadata.join(metadata[column].apply(parser))

    metadata = metadata.rename(columns=name_conversion)
    return metadata


ULTRASONIC_BIN_SIZE = 64 #mm (0.2 ft)
def bucketized_to_distances(bucketized):
    """
    Converts a bucketized ultrasonic measurement to discrete distances.

    :param bucketized:
        the buckets in which distances were detected.
    :type bucketized:
        unsigned integer

    :return:
        an array of distances.
    :rtype:
        np.array
    """

    # Convert int to a bitfield
    # Based on http://stackoverflow.com/a/10322018
    bitfield = [1 if digit == '1' else 0 for digit in bin(int(bucketized))[2:]]

    # Get the indices of full bins
    filled_bucket_indices = np.nonzero(bitfield[::-1])[0]
    distances = filled_bucket_indices * ULTRASONIC_BIN_SIZE

    return distances


def resolve_ultrasonic(dataframe):
    """
    Takes a dataframe of binned ultrasonic distances, and returns a dataframe
    with individual distances.
    """

    times = []
    rtc_times = []
    values = []

    for time in dataframe.index.unique():
        current_rtc = dataframe.rtc_time[dataframe.index == time].values
        current_values = dataframe.Value0[dataframe.index == time].values

        if len(current_values) == 1:
            # New-style distances: 64-bit values
            distances = bucketized_to_distances(current_values[0])
        elif len(current_values) % 4 == 0:
            # Old-style distances: 16-bit values, which when appended together
            # represent the smallest bucket (0ft) to the largest (13.2ft). We
            # will iterate through each set of four, de-bucketizing each set
            # of distances.
            for index, value in enumerate(current_values):
                distances = bucketized_to_distances(value)
                distances += (index % 4) * ULTRASONIC_BIN_SIZE * 16
        else:
            raise ValueError("Number of values not appropriate: %d" % len(values))

        if len(distances) > 0:
            times.extend([time] * len(distances))
            rtc_times.extend([current_rtc[0]] * len(distances))
            values.extend(distances)

    if times:
        updated_dataframe = pd.DataFrame(values, columns = ["Value0"], index = times)
        updated_dataframe["rtc_time"] = rtc_times
    else:
        updated_dataframe = pd.DataFrame()

    return updated_dataframe


def calculate_life_expectancy(idle = 0.27,
                              ntp_events_per_day = 5,
                              ntp_seconds_per_event = 6.71,
                              ntp_power = 74.0,
                              pathlight_events_per_day = 24,
                              pathlight_seconds_per_event = 10.3,
                              pathlight_power = 78,
                              manualtest_events_per_year = 2,
                              manualtest_seconds_per_event = 54.9,
                              manualtest_power = 609.5,
                              wifiupdate_events_per_day = 1,
                              wifiupdate_seconds_per_event = 47,
                              wifiupdate_power = 246,
                              fifodump_events_per_day = 48,
                              fifodump_seconds_per_event = 3.7,
                              fifodump_power = 25.3,
                              alarm_events_per_year = 1,
                              alarm_seconds_per_event = 600,
                              alarm_power = 621.36,
                              prealarm_events_per_year = 1,
                              prealarm_seconds_per_event = 600,
                              prealarm_power = 522.7,
                              setup_events_per_lifetime = 1,
                              setup_seconds_per_event = 300,
                              setup_power = 1178.0,
                              swupdate_events_per_year = 2,
                              swupdate_seconds_per_event = 450,
                              swupdate_power = 775,
                              cell_capacity = 2280,
                              self_discharge_percentage = 0.6,
                              num_cells = 6,
                              voltage_per_cell = 1.6666666,
                              num_devices_bought = 1):


    # power per feature, all are in mW
    ntp_average_power = ntp_events_per_day * ntp_seconds_per_event * ntp_power / time_converters.SECONDS_PER_DAY
    pathlight_average_power = pathlight_events_per_day * pathlight_seconds_per_event * pathlight_power / time_converters.SECONDS_PER_DAY
    manualtest_average_power = (manualtest_events_per_year / time_converters.DAYS_PER_YEAR) * manualtest_seconds_per_event * manualtest_power / time_converters.SECONDS_PER_DAY
    wifiupdate_average_power = wifiupdate_events_per_day * wifiupdate_seconds_per_event * wifiupdate_power / time_converters.SECONDS_PER_DAY
    fifodump_average_power = fifodump_events_per_day * fifodump_seconds_per_event * fifodump_power / time_converters.SECONDS_PER_DAY
    alarm_average_power = (alarm_events_per_year / time_converters.DAYS_PER_YEAR) * alarm_seconds_per_event * alarm_power / time_converters.SECONDS_PER_DAY
    prealarm_average_power = (prealarm_events_per_year / time_converters.DAYS_PER_YEAR) * prealarm_seconds_per_event * prealarm_power / time_converters.SECONDS_PER_DAY
    swupdate_average_power = (swupdate_events_per_year / time_converters.DAYS_PER_YEAR) * swupdate_seconds_per_event * swupdate_power / time_converters.SECONDS_PER_DAY

    # setup is a one-time cost, so it should be measured in energy rather than power
    setup_energy = setup_events_per_lifetime * setup_seconds_per_event * setup_power * num_devices_bought / 3600.0 #mWh

    # calculate the energy held by all 6 cells
    total_capacity = cell_capacity * num_cells * voltage_per_cell #mAh * V = mWh
    post_setup_capacity = total_capacity - setup_energy

    recurring_power = idle + ntp_average_power + pathlight_average_power + \
                      manualtest_average_power + wifiupdate_average_power + \
                      fifodump_average_power + alarm_average_power + \
                      prealarm_average_power + swupdate_average_power

    # calculate the expected lifetime based on the capacity, expected power, and self-discharge
    k = post_setup_capacity / (recurring_power * time_converters.DAYS_PER_YEAR * time_converters.HOURS_PER_DAY)
    expected_lifetime = k / (1.0 + (self_discharge_percentage/100)*k)
    return expected_lifetime
