"""
Utilities for parsing schedule data from Diamond and Amber.
"""

from datetime import datetime, timedelta
import pandas as pd
import pytz
import re
import shlex

import diamond_utils

from .. import converters


TERMINATION_CAUSE = ["AnotherManualCommand", "ScheduleSetPoint", "Unknown"]
COMMAND_TYPE = ["Manual", "Addition", "Deletion"]


def to_utc(x):
    return pytz.utc.localize(datetime.utcfromtimestamp(x))


def to_setpoint_type(x):
    return diamond_utils.nlSetPointType[x]


SCHEDULE_SCHEMA = {
    "Day": lambda x: diamond_utils.nlDayOfWeek[x],
    "Default": bool,
    "Temp": converters.fixed2f,
    "TempMax": converters.fixed2f,
    "Time": lambda x: timedelta(seconds=x),
    "TouchedAt": to_utc,
    "TouchedBy": lambda x: diamond_utils.nlTouchedByWho[x],
    "TouchedTZO": int,
    "TouchedWhere": lambda x: diamond_utils.nlTouchedWhere[x],
    "Type": to_setpoint_type
}

COMMANDS_SCHEMA = {
    "Day": lambda x: diamond_utils.nlDayOfWeek[x],
    "Time": to_utc,
    "Sec": to_utc,
    "NewType": lambda x: diamond_utils.nlSetPointType[x],
    "NewTemp": converters.fixed2f,
    "NewTempHigh": converters.fixed2f,
    "Room": converters.fixed2f,
    "Old": converters.fixed2f,
    "OldHigh": converters.fixed2f,
    "OldType": lambda x: diamond_utils.nlSetPointType[x],
    "Hum": converters.fixed2c,
    "Len": lambda x: timedelta(seconds=x),
    "Term": lambda x: TERMINATION_CAUSE[x],
    "CmdType": lambda x: COMMAND_TYPE[x],
    "TouchedAt": to_utc,
    "TouchedBy": lambda x: diamond_utils.nlTouchedByWho[x],
    "TouchedTZO": int,
    "TouchedWhere": lambda x: diamond_utils.nlTouchedWhere[x]
}


def parse(line, schema, default_element={}, element_depth=3):
    """
    A generic parser for the weird JSON-like format used by Nest.
    Unlike schedule tools, this only parses event log lines, and returns a pandas DataFrame.

    Example line: 2014-04-12T07:24:14 WeeklySchedule "Ranged_Schedule:\"\" { DaySchedule:\"Mon\" { Total:1, SetPoint:\"\" { Total:9, Day:0, Time:0, Type:2, Temp:1310720, TempMax:1572864, Default:1, TouchedBy:1, TouchedAt:946713632, TouchedTZO:-28800 } }, DaySchedule:\"Tue\" { Total:1, SetPoint:\"\" { Total:9, Day:1, Time:0, Type:2, Temp:1310720, TempMax:1572864, Default:1, TouchedBy:1, TouchedAt:946713632, TouchedTZO:-28800 } }, DaySchedule:\"Wed\" { Total:1, SetPoint:\"\" { Total:9, Day:2, Time:0, Type:2, Temp:1310720, TempMax:1572864, Default:1, TouchedBy:1, TouchedAt:946713632, TouchedTZO:-28800 } }, DaySchedule:\"Thu\" { Total:1, SetPoint:\"\" { Total:9, Day:3, Time:0, Type:2, Temp:1310720, TempMax:1572864, Default:1, TouchedBy:1, TouchedAt:946713632, TouchedTZO:-28800 } }, DaySchedule:\"Fri\" { Total:1, SetPoint:\"\" { Total:9, Day:4, Time:0, Type:2, Temp:1310720, TempMax:1572864, Default:1, TouchedBy:1, TouchedAt:946713632, TouchedTZO:-28800 } }, DaySchedule:\"Sat\" { Total:1, SetPoint:\"\" { Total:9, Day:5, Time:0, Type:2, Temp:1310720, TempMax:1572864, Default:1, TouchedBy:1, TouchedAt:946713632, TouchedTZO:-28800 } }, DaySchedule:\"Sun\" { Total:1, SetPoint:\"\" { Total:9, Day:6, Time:0, Type:2, Temp:1310720, TempMax:1572864, Default:1, TouchedBy:1, TouchedAt:946713632, TouchedTZO:-28800 } } }"

    :param line:
        data string from an event log or recovery file
    :type line:
        string

    :param schema:
        the schema to use for decoding the line
    :type schema:
        dict

    :param default_element:
        a default element containing entries that must be present in every
        element
    :type default_element:
        dict

    :param element_depth:
        the depth at which individual elements are stored.
    :type element_depth:
        int

    :returns:
        a DataFrame with the parsed data for the line
    """

    data = shlex.split(line, posix=False)

    parsed_data = []

    element = default_element.copy()
    current_depth = 0

    for token in data[1:]:
        token = token.replace(',', '')

        if token == '{':
            current_depth += 1
            continue
        elif token == '}':
            if current_depth == element_depth:
                parsed_data.append(element)
                element = default_element.copy()
            current_depth -= 1
            continue

        m = re.match('(.*):(.*)', token)
        if m and current_depth == element_depth:
            key = m.group(1)
            val = m.group(2)

            if key in schema:
                element[key] = schema[key](int(val))
            else:
                element[key] = val

    return pd.DataFrame(data=parsed_data)


def parse_weekly_schedule(schedule_line):
    """
    Parses a weekly schedule into a DataFrame of setpoints.

    :param schedule_line:
        the schedule string, either from event logs or a recovery file.
    :type schedule_line:
        string

    :returns:
        the schedule as a DataFrame.
    """

    default_setpoint = {
        "Default": False
    }

    setpoints = parse(schedule_line, SCHEDULE_SCHEMA, default_setpoint)

    times_of_week = []
    for index, row in setpoints.iterrows():
        time_of_week = None
        if "Day" in row and "Time" in row:
            num_days = diamond_utils.nlDayOfWeek[row["Day"]]
            num_seconds = row["Time"] / 1e9  # convert from nanoseconds
            time_of_week = timedelta(days=num_days, seconds=num_seconds)

        times_of_week.append(time_of_week)

    setpoints["TimeInWeek"] = times_of_week

    return setpoints


def parse_daily_commands(commands_line):
    """
    Parses daily commands.

    :param commands_line:
        the commands string, either from event logs or a recovery file.
    :type commands_line:
        string

    :returns:
        the commands as a DataFrame.
    """

    default_command = {}
    return parse(commands_line, COMMANDS_SCHEMA, default_command, element_depth=2)
