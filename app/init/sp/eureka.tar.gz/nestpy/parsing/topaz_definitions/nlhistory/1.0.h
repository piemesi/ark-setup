    enum event_type
    {
        // nlSmokeAlarm =                      0x0000, // not used
        // nlCOAlarm =                         0x0001, // not used
        nlNightLightState =                 0x0002,
        nlNightTimePromise =                0x0003,
        nlWaveDetection =                   0x0004,

        nlAutoSelfTestPassSmoke =           0x0010,
        nlAutoSelfTestPassCO =              0x0011,
        nlAutoSelfTestPassTemperature =     0x0012,
        nlAutoSelfTestPassHumidity =        0x0013,
        nlAutoSelfTestPassPIR =             0x0014,
        nlAutoSelfTestPassALS =             0x0015,
        nlAutoSelfTestPassUltrasonic =      0x0016,
        nlAutoSelfTestPassWifi =            0x0017,

        nlManualSelfTestPassSmoke =         0x0020,
        nlManualSelfTestPassCO =            0x0021,
        nlManualSelfTestPassTemperature =   0x0022,
        nlManualSelfTestPassHumidity =      0x0023,
        nlManualSelfTestPassPIR =           0x0024,
        nlManualSelfTestPassALS =           0x0025,
        nlManualSelfTestPassUltrasonic =    0x0026,
        nlManualSelfTestPassWifi =          0x0027,


        // debug events (probably removed later)

        nlStandby_State_Smoke =               1000,
        nlMonitor_State_Smoke =               1001,
        nlPreAlarm1_Smoke =                   1002,
        nlPreAlarm2_Smoke =                   1003,
        nlPreAlarm_Hushed_Smoke =             1004,
        nlAlarm_Smoke =                       1005,
        nlAlarm_Hushed_Smoke =                1006,
        nlHolding_State_Smoke =               1007,
        nlAll_Clear_State_Smoke =             1008,
        nlRemote_Alarm_Smoke =                1009,
        nlRemote_Alarm_Hushed_Smoke =         1010,

        nlStandby_State_CO =                  1100,
        nlMonitor_State_CO =                  1101,
        nlPreAlarm1_CO =                      1102,
        nlPreAlarm2_CO =                      1103,
        nlPreAlarm_Hushed_CO =                1104,
        nlAlarm_CO =                          1105,
        nlAlarm_Hushed_CO =                   1106,
        nlHolding_State_CO =                  1107,
        nlAll_Clear_State_CO =                1108,
        nlRemote_Alarm_CO =                   1109,
        nlRemote_Alarm_Hushed_CO =            1110,

        nlButton_Hush_Triggered =             1200,
        nlGesture_Hush_Triggered =            1201,
        nlGesture_Hush_Train =                1202,

        nlApp_Boot =                          1300,
        nlReady_Triggered =                   1301,
        nlApp_Wakeup =                        1302,
        nlApp_Sleep =                         1303,
        nlApp_Stay_Awake =                    1304,
        nlApp_IdleCntlr_Activated =           1305,
        nlApp_IdleCntlr_Deactivated =         1306,
        nlApp_SleepRequestUrgency_Changed =   1307,

        nlManual_SelfTest_Started =           1400,
        nlAutomatic_SelfTest_Started =        1401,
        nlManual_SelfTest_Finished =          1402,
        nlAutomatic_SelfTest_Finished =       1403,
        nlManual_SelfTest_Cancelled =         1404,
        nlAutomatic_SelfTest_Cancelled =      1405,

        nlSelfTest_Safety_Failed =            1500, // include which sensor
        nlSelfTest_NonSafety_Failed =         1501, // include which sensor

        nlTrouble_Smoke =                     1600, // deprecated
        nlTrouble_Smoke_Expiration =          1601,
        nlTrouble_CO =                        1602, // deprecated
        nlTrouble_CO_Expiration =             1603,
        nlTrouble_Temp =                      1604,
        nlTrouble_Heat =                      1605,
        nlTrouble_Humidity =                  1606,
        nlTrouble_PIR =                       1607, // deprecated
        nlTrouble_ALS =                       1608,
        nlTrouble_LEDs =                      1609,
        nlTrouble_Ultrasonic =                1610,
        nlTrouble_vbat1 =                     1611,
        nlTrouble_vbat2 =                     1612,
        nlTrouble_Smoke_Dark =                1613,
        nlTrouble_Smoke_Light =               1614,
        nlTrouble_Smoke_CAO =                 1615,
        nlTrouble_CO_TH1 =                    1616,
        nlTrouble_CO_TH2 =                    1617,
        nlTrouble_CO_Comp_Temp =              1618,
        nlTrouble_Smoke_PWM_Read =            1619,
        nlTrouble_Smoke_PWM_Dark =            1620,
        nlTrouble_Smoke_PWM_Light =           1621,
        nlTrouble_PIR_ACD_Analog =            1622,
        nlTrouble_PIR_ACD_Peak =              1623,

        nlHistoryUpload_Started =             1700,
        nlHistoryUpload_Finished =            1701,
        nlHistoryUpload_Cancelled =           1702,
        nlHistoryBuffer_Data_Lost =           1703,
        nlHistoryContinuity_Marker =          1704,
        nlHistoryBad_Samples =                1705,

        nlSoftwareUpdate_Started =            1800,
        nlSoftwareUpdate_Finished =           1801,
        nlSoftwareUpdate_Cancelled =          1802,
        nlSoftwareUpdate_Download_Complete  = 1803,
        nlSoftwareUpdate_Failed =             1804,

        nlOOB_Started =                       1900,
        nlOOB_Finished =                      1901,
        nlLanguage_Selected =                 1902,
        nlProvisioning =                      1903,

        nlBattery_Low_6mon =                  2003,
        nlBattery_Low_3mon =                  2004,
        nlBattery_Near_Critical =             2005,
        nlBattery_Critical =                  2006,
        nlBattery_StatSamples =               2007,
        nlBattery_StatAverage =               2008,
        nlBattery_StatMinimum =               2009,
        nlBattery_StatMaximum =               2010,

        // nlNightLight_Started =                2100, // not used
        // nlNightLight_Finished =               2101, // not used
        // nlNightLight_Triggered =              2102, // not used

        nlNTP_Triggered =                     2200,
        nlNTP_Train =                         2201,
        // nlNTP_Debug_Entered_While =           2210, // deprecated (existed for DOLO-1219 investigation only)
        // nlNTP_Debug_Called_Delegate =         2211, // deprecated (existed for DOLO-1219 investigation only)
        // nlNTP_Debug_Entered_Trigger =         2212, // deprecated (existed for DOLO-1219 investigation only)
        // nlNTP_Debug_Published_Event =         2213, // deprecated (existed for DOLO-1219 investigation only)
        // nlNTP_Debug_Idle_Handle_Activate =    2220, // deprecated (existed for DOLO-1219 investigation only)
        // nlNTP_Debug_Idle_Subscribed =         2221, // deprecated (existed for DOLO-1219 investigation only)
        // nlNTP_Debug_Idle_Handle_Deactivate =  2222, // deprecated (existed for DOLO-1219 investigation only)
        // nlNTP_Debug_Idle_Unsubscribed =       2223, // deprecated (existed for DOLO-1219 investigation only)
        // nlNTP_Debug_Will_Sleep =              2230, // deprecated (existed for DOLO-1219 investigation only)

        nlLine_Power_Attached =               2300,
        nlLine_Power_Detached =               2301,

        nlWall_Detect_Attached =              2400,
        nlWall_Detect_Detached =              2401,

        nlFactory_Reset_Triggered =           2500,

        nlDaily_Timer_Set =                   2600, // for DOLO-1512 investigation only

        // nlWarning_Spoken =                    2700, // deprecated
        nlSentence_Played =                   2701,

        nlAuto_Away_Change =                  2800,

        nlSettings_Sync_Complete =            2900,
        nlSettings_Committed =                2901,

        nlHorn_State =                        3000,

        nlSmoke_Threshold =                   3100,

        nlWFM_Error_Feature =                 3200,
        nlWFM_Error =                         3201,

        nlLast_Gasp_Begin =                   3300,

        nlStorage_Assert =                    30000,

        // old stuff

//        nlHistoryUploadDriver_Init = 32768,         // not used
        nlHistory_UploadBegin = 32769,
        nlHistory_UploadEnd = 32770,
//        nlSelfTest_Started,                         // not used
//        nlSelfTest_Finished,                        // not used
//        nlSelfTest_Cancelled,                       // not used
//        nlSelfTestCountdownCntlr_CountDown_Started, // not used
//        nlSelfTest_manual,                          // not used
//        nlSelfTest_auto,                            // not used
//        nlPrealarm_smoke,                           // not used
//        nlPrealarm_CO,                              // not used
//        nlAlarm_smoke,                              // not used
//        nlAlarm_CO,                                 // not used
//        nlAlarm_Heat,                               // not used
        nlAlarmingCntlrButtonUp = 32782,
        nlIdleCntlrButtonUp = 32783,
//        nlOOBFinishedCntlrButtonUp,                 // not used
//        nlOOBWelcomeCntlrButtonUp,                  // not used
        nlReadySeqCntlrButtonUp = 32786,
        nlSelfTestSequenceCntlrButtonUp = 32787,
        nlSpeakDemoSentencesCntlrButtonUp = 32788,
        nlSpeakWarningsCntlrButtonUp = 32789,
//        nlBatteryLevelEvent,                        // not used
//        nlGeneralAlarm = 32791,                     // not used
        nlSelfTestMgr_BPSensorDriverTrouble = 32792,
        nlNTPTrain = 32793,
        nlNTPTrigger = 32794,
        nlNightLightDisplay = 32795,

        nlHushState = 32796,
        nlWaveDetection_Calibration_Started = 32797,
        nlWaveDetection_Calibration_Succeeded,
        nlWaveDetection_Calibration_Cancelled,
        nlWaveDetection_Calibration_TimedOut,
        nlWaveDetection_Sensor1CalibrationLow,
        nlWaveDetection_Sensor1CalibrationHigh,
        nlWaveDetection_Sensor2CalibrationLow,
        nlWaveDetection_Sensor2CalibrationHigh,
        nlWaveDetection_Started,
        nlWaveDetection_Finished,
        nlNightTimePromiseState = 32807,
    };
