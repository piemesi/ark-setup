import numpy as np
import logging


logger = logging.getLogger(__name__)


def bitfield_getslice(data, startbit, endbit):
    mask = 2L**(endbit - startbit) -1
    return (data >> startbit) & mask


def parse_event_fields(dh, event_field_definition, utils):
    unique_events = dh.event.name.unique()
    # add each event as a top-level member of the device history
    for index, event_name in enumerate(unique_events):
        event_data = dh.event[dh.event.name == event_name]

        # check if this event type has further definition for its fields
        if event_name in event_field_definition:
            if ("endian" in event_field_definition[event_name] and
                event_field_definition[event_name]["endian"] == "little"):
                raw_field_data = (event_data.Value2.astype(np.uint32).values << 16 |
                                  event_data.Value1.astype(np.uint32).values)
            else:
                raw_field_data = (event_data.Value1.astype(np.uint32).values << 16 |
                                  event_data.Value2.astype(np.uint32).values)

            start_bit = 0
            if 'fields' in event_field_definition[event_name]:
                for event_field in event_field_definition[event_name]['fields']:
                    field_name = event_field['description']
                    bit_length = event_field['length']
                    type_string = event_field['type']
                    if type_string == 'enum':
                        # round up to nearest 8 bits
                        cast_type = 'int%d' % (bit_length - (((bit_length-1) % 8) + 1) + 8)
                        event_data[field_name + '_raw'] = bitfield_getslice(raw_field_data,
                                                                            32-start_bit-bit_length,
                                                                            32-start_bit).astype(cast_type)
                        enum_name = event_field['enum_name']
                        parser = getattr(utils, enum_name)
                        if type(parser) == dict: # if it is a lookup table
                            event_data[field_name] = [parser[row] if row in parser else np.nan
                                                      for row in event_data[field_name + '_raw']]
                        else:
                            logger.warn("Unable to find lookup table '%s' when parsing %s::%s",
                                        enum_name, event_name, field_name)
                    elif type_string == 'parseable':
                        event_data[field_name + '_raw'] = bitfield_getslice(raw_field_data,
                                                                            32-start_bit-bit_length,
                                                                            32-start_bit).astype(int)
                        parser_name = event_field['parser_name']
                        parser = getattr(utils, parser_name)
                        if hasattr(parser, '__call__'): # if it is a function
                            event_data[field_name] = event_data[field_name + '_raw'].apply(parser)
                        else:
                            logger.warn("Unable to find parser function '%s' when parsing %s::%s",
                                        parser_name, event_name, field_name)
                    else:
                        event_data[field_name] = bitfield_getslice(raw_field_data,
                                                                   32-start_bit-bit_length,
                                                                   32-start_bit).astype(type_string)
                    start_bit += bit_length
            if 'operations' in event_field_definition[event_name]:
                for operation in event_field_definition[event_name]['operations']:
                    operator = getattr(utils, operation)
                    if hasattr(operator, '__call__'): # if it is a function
                        event_data = operator(event_data)
                    else:
                        logger.warn("Unable to find operation '%s' when operating on %s", operator, event_name)
        elif any(event_data.Value1 != 0) or any(event_data.Value2 != 0):
            logger.warn("No parsing instructions found for event %s in %s", event_name, dh.unique_device_id)

        dh.add_event_data(event_name, event_data, native=False)
