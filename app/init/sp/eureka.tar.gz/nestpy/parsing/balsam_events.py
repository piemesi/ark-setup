import json
import os

from .event_field_parser import parse_event_fields
from . import balsam_utils


# load in the event field definition file
with open(os.path.join(os.path.dirname(os.path.realpath(__file__)),
          'balsam_definitions', 'balsam_events_fields.json')) as data_file:
    event_field_definition = json.load(data_file)


def parse_balsam_events(dh):
    if 'event' in dh:
        # parse the event id into event name
        dh.event["name"] = dh.event.Value0.apply(lambda value: balsam_utils.event_type_enum.get(value))

        parse_event_fields(dh, event_field_definition, balsam_utils)
