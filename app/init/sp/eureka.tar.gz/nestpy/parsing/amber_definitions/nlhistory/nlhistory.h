typedef enum
{
    nlBoilerInfoReceived =                 0x0006,
    nlHistoryDataDropped =                 42,

    nlSoftwareVersion =                    300,
    // debug events (probably removed later)
    //
    // OT count events
    nlOpenTherm_RecoveryResetCount =       400,
    nlOpenTherm_CommsSendAttemptCount,
    nlOpenTherm_CommsReplyCount,
    nlOpenTherm_CommsSuccessCount,
    nlOpenTherm_DataRxErrorCount,
    nlOpenTherm_TimingRxErrorCount,
    nlOpenTherm_2MinNoCommsCount,
    nlOpenTherm_CommsRecoveryCount,
    nlOpenTherm_NoReplyErrorCount,
    nlOpenTherm_DecodeErrorCount,
    nlOpenTherm_TxCmdQueueFullCount,
    nlOpenTherm_MainEventQueueFullCount,

    // OT events
    nlOpenTherm_DataRxError =              450,
    nlOpenTherm_TimingRxError,
    nlOpenTherm_2MinNoComms,
    nlOpenTherm_CommsRecovery,
    nlOpenTherm_NoReplyError,
    nlOpenTherm_DecodeError,
    nlOpenTherm_TxCmdQueueFull,
    nlOpenTherm_MainEventQueueFull,

    // Wpan events
    nlWpanStats_CCAFailureCount =         500,
    nlWpanStats_RxTxPacketCount,
    nlWpanStats_RipEntry,
    nlWpanStats_ScanResults,
    nlWpanStats_SuccessRetryCount,
    nlWpanStats_AckExtFailCount,
    nlWpanStats_IPRxTxCount,

    // Weave Platform events
    nlWeavePlatform_6LoWPANServiceState = 700,
    nlWeavePlatform_6LoWPANServiceErrorState,
    nlWeavePlatform_6LoWPANServiceError,
    nlWeavePlatform_6LoWPANConnState,
    nlWeavePlatform_6LoWPANConnErrorState,
    nlWeavePlatform_6LoWPANConnError,
    nlWeavePlatform_HuntingState,
    nlWeavePlatform_HuntingErrorState,
    nlWeavePlatform_HuntingError,
    nlWeavePlatform_HuntingServiceState,
    nlWeavePlatform_HuntingServiceErrorState,

    // App events
    nlApp_Boot =                          1300,
    nlReady_Triggered =                   1301,
    // nlApp_Wakeup =                     1302,
    nlApp_Sleep =                         1303,
    nlApp_Stay_Awake =                    1304,
    // nlApp_IdleCntlr_Activated =        1305,
    nlApp_IdleCntlr_Deactivated =         1306,
    nlApp_SleepRequestUrgency_Changed =   1307,

    // App heat/hotwater control
    nlApp_ManualModeOffWithDuration =     1350,
    nlApp_WireCHRequestReceived,
    nlApp_WireDHWRequestReceived,
    nlApp_WeaveCHRequestReceived,
    nlApp_WeaveDHWRequestReceived,
    nlApp_CHAutoOffTimeout,
    nlApp_DHWAutoOffTimeout,

    // App connectivity
    nlApp_ResetWpan =                     1397,
    nlApp_WeaveConnected =                1398,
    nlApp_WeaveDisconnected =             1399,
    // end of nlApp events

    nlHistoryUTCOffset =                  1706,
    nlHistory_MemoryStomp =               1707,
    nlHistory_CurrentRTC,

    nlSoftwareUpdate_Started =            1800,
    // nlSoftwareUpdate_Finished =        1801,
    nlSoftwareUpdate_Cancelled =          1802,
    nlSoftwareUpdate_Download_Complete  = 1803,
    nlSoftwareUpdate_Failed =             1804,

    nlFactory_Reset_Triggered =           2500,

    nlWFM_Error_Feature =                 3200,
    nlWFM_Error =                         3201,

    // nlHistoryUploadDriver_Init = 32768,         // not used
    nlHistory_UploadBegin =               32769,
    nlHistory_UploadEnd   =               32770,
} nl_history_event_type;

