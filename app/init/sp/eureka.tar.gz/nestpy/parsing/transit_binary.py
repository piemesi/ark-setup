# pylint: disable=maybe-no-member
"""
Parsing methods for Transit logs.
"""

from datetime import datetime
import logging
from os import remove, stat
from os.path import basename
from struct import pack, unpack

import pytz

logger = logging.getLogger(__name__)


FIX_DICT = {0x0001  : 'NO_FIX',
            0x0002  : 'SPS',
            0x0004  : 'DGPS',
            0x0008  : 'PPS',
            0x0010  : 'RTK',
            0x0020  : 'FRTK',
            0x0040  : 'Est',
            0x0080  : 'Man',
            0x0100  : 'Sim'}

RCR_DICT = {0x01  : 'Time',
            0x02  : 'Speed',
            0x04  : 'Distance',
            0x08  : 'Interest'}

# position and number of bits for each data type that can be logged (index is position)
#                     index : (data_name, num_bits, log_name)
LOG_DATA_SIZE_DICT = {0     : ('UTC',           32, 'time'),
                      1     : ('VALID',         16, 'fixType'),
                      2     : ('LATITUDE',      64, 'latitude'),
                      3     : ('LONGITUDE',     64, 'longitude'),
                      4     : ('HEIGHT',        32, 'height'),
                      5     : ('SPEED',         32, 'speed'),
                      6     : ('HEADING',       32),
                      7     : ('DSTA',          16),
                      8     : ('DAGE',          32),
                      9     : ('PDOP',          16),
                      10    : ('HDOP',          16),
                      11    : ('VDOP',          16),
                      12    : ('NSAT',          16),
                      13    : ('SID_DATA',      8),
                      14    : ('SIDINUSE',      8),
                      15    : ('NBRSATS',       16),
                      16    : ('ELEVATION',     16),
                      17    : ('AZIMUTH',       16),
                      18    : ('SNR',           16),
                      19    : ('RCR',           16, 'recordReason'),
                      20    : ('MILLISECOND',   16),
                      21    : ('DISTANCE',      64)}


def get_log_version(filename):
    return float((basename(filename).split('v')[-1]).split('-')[0])


def get_log_id(filename):
    return ((basename(filename).split('v')[-1]).split('-')[1]).lstrip('id')


## functions for converting data to useful formats


def little_to_big_endian(data, error_log=None):
    try:
        output = (data.decode('hex')[::-1]).encode('hex')
    except Exception:
        logger.debug('Error converting to big endian: 0x%s' % (data))
        if error_log is not None:
            error_log.write('Error converting to big endian: 0x%s' % (data))
        return False
    return output


def hex_to_double(data, error_log=None):
    try:
        output = unpack("d", pack("Q", int(data, 16)))[0]
    except Exception:
        logger.debug('Error converting to double: 0x%s' % (data))
        if error_log is not None:
            error_log.write('Error converting from hex to double: 0x%s' % (data))
        return False
    return output


def little_endian_hex_to_double(data, error_log=None):
    big_endian_data = little_to_big_endian(data)
    if big_endian_data is not False:
        return hex_to_double(big_endian_data)
    else:
        logger.debug('Error converting to double: 0x%s' % (data))
        if error_log is not None:
            error_log.write('Error converting from little endian to double: 0x%s' % (data))
        return False


def little_endian_hex_to_float(data, error_log=None):
    try:
        output = unpack('<f', data.decode('hex'))[0]
    except Exception:
        logger.debug('Error converting to float: 0x%s' % (data))
        if error_log is not None:
            error_log.write('Error converting from little endina to float: 0x%s' % (data))
        return False
    return output


def utc(raw, error_log=None):
    try:
        output = datetime.utcfromtimestamp(int(little_to_big_endian(raw), 16)).replace(tzinfo=pytz.utc)
    except Exception:
        logger.debug('Error converting timestamp: 0x%s' % (raw))
        if error_log is not None:
            error_log.write('Error converting timestamp to utc: 0x%s' % (raw))
        return False
    return output


def valid(raw, error_log=None):
    try:
        output = FIX_DICT[int(little_to_big_endian(raw), 16)]
    except KeyError:
        logger.debug('Could not find 0x%s in FIX_DICT' % (little_to_big_endian(raw)))
        if error_log is not None:
            error_log.write('Could not find 0x%s in FIX_DICT' % (little_to_big_endian(raw)))
        return False
    return output


def latitude(raw, error_log=None):
    lati = little_endian_hex_to_double(raw)
    if lati is False:
        logger.debug('Could not convert latitude from raw to double: 0x%s' % (raw))
        if error_log is not None:
            error_log.write('Could not convert latitude from raw to double: 0x%s' % (raw))
    return lati


def longitude(raw, error_log=None):
    longi = little_endian_hex_to_double(raw)
    if longi is False:
        logger.debug('Could not convert longitude from raw to double: 0x%s' % (raw))
        if error_log is not None:
            error_log.write('Could not convert longitude from raw to double: 0x%s' % (raw))
    return longi


def height(raw, error_log=None):
    hght = little_endian_hex_to_float(raw)
    if hght is False:
        logger.debug('Could not convert height from raw to float: 0x%s' % (raw))
        if error_log is not None:
            error_log.write('Could not convert height from raw to float: 0x%s' % (raw))
    return hght


def speed(raw, error_log=None):
    spd = little_endian_hex_to_float(raw)
    if spd is False:
        logger.debug('Could not convert speed from raw to float: 0x%s' % (raw))
        if error_log is not None:
            error_log.write('Could not convert speed from raw to float: 0x%s' % (raw))
    return spd


def rcr(raw, error_log=None):
    try:
        output = RCR_DICT[int(little_to_big_endian(raw), 16)]
    except KeyError:
        logger.debug('Could not find 0x%s in RCR_DICT' % (little_to_big_endian(raw)))
        if error_log is not None:
            error_log.write('Could not find 0x%s in RCR_DICT' % (little_to_big_endian(raw)))
        return False
    return output


def gen_convert_data_func(error_log=None):
    pass


def parse_raw(raw_data, data_types_logged=None, error_log_fn=None):
    if data_types_logged is None:
        # default data that is logged
        data_types_logged = ['UTC', 'LATITUDE', 'LONGITUDE', 'VALID', 'RCR', 'SPEED']
    # there is an unknown two-byte data type being logged in each record (possibly milliseconds), initialize chunk size
    # to account for this
    chunk_size = 16
    # list to hold information about the data in each record to be used for parsing
    logged_data_list = []
    # figure out which things are being logged and compute size of each chunk in bits
    for index in LOG_DATA_SIZE_DICT:
        if LOG_DATA_SIZE_DICT[index][0] in data_types_logged:
            chunk_size += LOG_DATA_SIZE_DICT[index][1]
            logged_data_list.append((LOG_DATA_SIZE_DICT[index][0].lower(),
                                    (LOG_DATA_SIZE_DICT[index][1]/4),
                                    LOG_DATA_SIZE_DICT[index][2]))

    # convert from bits to nibbles
    chunk_size /= 4
    # create empty list to store parsed records
    output = []
    # pointer to keep track of which character has been explored in the raw_data
    ptr = 0
    error_log = None
    # if error log file name was provided
    if error_log_fn is not None:
        # open error log file
        try:
            error_log = open(error_log_fn, 'w')
        except IOError:
            logger.warn('Could not open error log for writing.')
    # parse until we've reached the end of the raw_data
    while ptr < len(raw_data):
        # print ptr
        # bool to possibly not add a chunk to the output
        add = True
        # try reading a chunk of 32 characters (128 bits) to look for a sep_record
        chunk = raw_data[ptr:ptr+32]
        # print chunk
        # look for start of sep_record (14 0xA)
        if chunk.find('AAAAAAAA') != -1:
            # found start of sep_record, find the end of it
            bb_loc = chunk.find('BBBBBBBB')
            # if the end exists in this chunk
            if bb_loc != -1:
                # move pointer after location of BB block since we found a sep_record
                ptr += bb_loc + 8
            else:
                # output the chunk we tried to read if the BB block can't be found
                print chunk
        # try reading a chunk of chunk_size characters (equal to chunk_size*4 bits) to look for a record entry
        chunk = raw_data[ptr:ptr+chunk_size]
        # check to see if the chunk is empty
        if len(chunk) == 0:
            break
        # proceed if no sep_record (no other indicator everything is ok)
        if chunk.find('AAAAAAAA') == -1:
            # no AA block found in sep_record, so assume this is a record entry
            # create empty dictonary to store the parsed data from this record
            record_dict = {}
            # character pointer for within in this chunk
            chunk_ptr = 0
            # loop over data types as specified in data_types_logged parameter
            for logged_data in logged_data_list:
                # convert data to the approriate type using the appropriate function
                converted_data = globals()[logged_data[0]](chunk[chunk_ptr:chunk_ptr+logged_data[1]], error_log)
                # if nothing failed
                if converted_data is not False:
                    # add converted data to record dictionary using the appropriate key
                    record_dict[logged_data[2]] = converted_data
                    # move pointer along?
                    chunk_ptr += logged_data[1]
                else:
                    # if one of the data conversion failed, assume this chunk is corrupted and skip it
                    add = False
                    break
            # if all data was good, add records from this chunk to output list
            if add is True:
                output.append(record_dict)
            else:
                logger.debug('There were errors converting some of the data in this chunk, skipping.')
                if error_log is not None:
                    error_log.write('Raw chunk: 0x%s\n' % (chunk))
            ptr += chunk_size
        else:
            pass
    if error_log_fn is not None and error_log is not None:
        # close log file
        error_log.close()
        # check size of log file
        if stat(error_log_fn).st_size == 0:
            # delete the file since its empty
            remove(error_log_fn)
    return {'GPSFix':output}


def parse_file(filename, log_errors=False):
    records_list = []
    if log_errors is not False:
        error_log_fn = filename.rstrip('.log') + '_error.log'
    else:
        error_log_fn = None
    log_version = get_log_version(filename)
    with open(filename, 'r') as file_to_parse:
        effective_log_version = log_version
        # for version 2 and above of the log, the first line has a list of the data types included in the log so we
        # know how to parse it
        if log_version < 2:
            # read number of lines to catch some files that were pushed to aws with incorrect version number and with
            # garbage on first 3 lines
            num_lines = sum(1 for line in open(filename))
            if num_lines > 2:
                # eat first 3 lines
                file_to_parse.readline()
                file_to_parse.readline()
                file_to_parse.readline()
                effective_log_version = 2
            else:
                log_id = get_log_id(filename)
            # only logs from S3 have actual IDs, so anything with an ID that is not all zeros and a log version of
            # 1 is likely an actual log version 2
                if log_id != '000000':
                    effective_log_version = 2
        if effective_log_version >= 2:
            data_types_logged = file_to_parse.readline()
        else:
            data_types_logged = None
        records_list = parse_raw(file_to_parse.readline(), data_types_logged, error_log_fn)
    return records_list
