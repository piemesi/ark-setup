"""
This module provides a Python interface to parse Topaz TVD files. It wraps
tvdreader which parses the binary files into Python structures.
"""
# pylint: disable=no-member

import copy
from datetime import datetime, timedelta
import gzip
import logging
import os

import pandas as pd
import pytz

from .. import converters
from .. import scriptutils
from . import tvdreader


logger = logging.getLogger(__name__)


DEFAULT_LOG_TYPE = "topazevent"
UPLOAD_PARSE_BUFFER = timedelta(hours=28)
TIMESYNC_EVENT_ID = 'timesync event'
NANOSECONDS_IN_A_MILLISECOND = 1000.
SECONDS_IN_A_DAY = 24*60*60

def parse_file(filename, timestamp=None, include_raw_values=False,
               default_synchronization=tvdreader.TVDReader.Synchronization.Unknown):
    """
    Parses the provided file and return the data as a dictionary mapping
    sensor names to a Pandas dataframe with their data

    Data is represented as an array of sensor readings.  Sensor readings are
    represented as tuples, with the first element of the tuple being the
    timestamp of the reading and the remaining value(s) being the value of the
    reading. Each sensor's array will be sorted in ascending order by
    timestamp.

    :param filename:
        Name of the log file to parse
    :param timestamp:
        datetime to use for interpreting the relative timestamps (usually the
        upload time)
    :param include_raw_values:
        whether to add on extra columns with un-parsed columns to each event dataframe
    :param default_synchronization:
        if file synchronization is unknown, override by setting this
    """
    file_metadata = {}
    file_metadata['size'] = os.path.getsize(filename)
    if file_metadata['size'] > 1000000L:
        raise ValueError('File %s size [%d] above max of 1M' % (filename, os.path.getsize(filename)))

    # Open the provided file and load its data into a byte array
    if filename[-3:] == '.gz':
        f = gzip.open(filename, "rb")
        file_data = f.read()
        f.close()
    else:
        file_data = open(filename, "rb").read()

    # Create a Java Date object from the provided timestamp
    if type(timestamp) == datetime:
        # This function expects a timestamp, but if we're given a datetime instead, just convert it to a timestamp
        timestamp = converters.datetime_to_epoch_time(timestamp)
    elif not timestamp:
        # If we weren't given a timestamp, check to see if there's one encoded in the filename
        d = extract_upload_time_from_filename(filename)
        if d:
            # If the filename has a date/time encoded in it, use that
            timestamp = converters.datetime_to_epoch_time(d)
        else:
            # Otherwise, use the file's last-modification time.
            timestamp = os.path.getmtime(filename)

    tvd = parse_data(file_data, timestamp, default_synchronization=default_synchronization)

    output = {}
    for stream in tvd.records:
        if stream.decoded:
            # Look up the description for this sensor
            description = stream.descriptor.description.replace(' ','')

            # Add to the output
            if description not in output:
                output[description] = {'times': [], 'values': [], 'rtc_times': []}
                if include_raw_values:
                    output[description].update({'raw_values': []})


            if len(stream.timestamps):
                output[description]['times'] += convert_timestamps_to_utc(stream.timestamps)
                output[description]['values'] += stream.data
                output[description]['rtc_times'] += stream.raw_timestamps
                if include_raw_values:
                    output[description]['raw_values'] += stream.raw_data

    file_metadata['parser'] = 'Python'
    file_metadata['description'] = tvd.description
    file_metadata['latest_rtc_time'] = tvd.latest_rtc_time

    return (output, file_metadata)


def convert_timestamps_to_utc(timestamps):
    return [pytz.utc.localize(datetime.utcfromtimestamp(t)) for t in timestamps]


def parse_data(file_data, upload_timestamp, default_synchronization=tvdreader.TVDReader.Synchronization.Unknown):
    """
    Top level parser function.  Reindexes using the time-sync event, if it exists, e.g. for Balsam devices.
    Falls back to the legacy service upload time reindexing if the time-sync event doesn't exist.
    :param file_data: file stream
    :param upload_timestamp: service upload time
    :param default_synchronization: value for synchronization if not specified (set to 1 for Synchronized)
    :return: tvd reader
    """

    # Parse the provided data
    tvd = tvdreader.TVDReader.read(file_data)

    # Calculate offset to apply for unsynchronized streams
    latest_timestamp = find_latest_rtc_timestamp(tvd)
    tvd.latest_rtc_time = latest_timestamp
    # See if the timesync event exists
    timesync_event = None
    for stream in tvd.records:
        if stream.decoded:
            # either synchronize based on time sync events or by service upload time
            if (stream.descriptor.description == TIMESYNC_EVENT_ID) and len(stream.data):
                timesync_event = stream
                break
    # if timesync exists, use it. Else used the upload timestamp
    if timesync_event is None:
        dt = upload_timestamp - latest_timestamp
    else:
        # Compute the time offset as the difference between the NTP timesync timestamp and the rtc timestamp
        timesync_timestamp = timesync_event.data[0]/NANOSECONDS_IN_A_MILLISECOND
        rtc_timestamp = timesync_event.timestamps[0]
        dt = timesync_timestamp - rtc_timestamp

    # AMB-466 - event data is occasionally left shifted, should be dropped
    # this means timestamp will be much larger than upload time
    if 'Amber' in file_data:
        tvd.records = [s for s in tvd.records if not [t for t in s.timestamps if t >= upload_timestamp + SECONDS_IN_A_DAY]]

    # Depending on the synchronization of each stream, set timestamps to be a best-effort UTC time
    # - if synchronized, don't adjust the times at all
    # - else, adjust RTC times to UTC using offset from above
    for stream in tvd.records:
        if stream.decoded:
            stream.raw_timestamps = copy.copy(stream.timestamps)
            if stream.synchronization == tvdreader.TVDReader.Synchronization.Synchronized or \
                    (stream.synchronization == tvdreader.TVDReader.Synchronization.Unknown and
                     default_synchronization == tvdreader.TVDReader.Synchronization.Synchronized):
                # do nothing
                pass
            else:
                # apply offset from above
                for i in range(len(stream.timestamps)):
                    stream.timestamps[i] += dt
    return tvd


def find_latest_rtc_timestamp(tvd):
    """
    Finds the latest RTC timestamp in the TVD reader.
    :param tvd: tvdreader
    :return: timestamp
    """
    # Find the lastest timestamp
    latest_timestamp = float('-inf')
    for stream in tvd.records:
        if stream.decoded:
            latest_timestamp = max(latest_timestamp, max(stream.timestamps))
    return latest_timestamp

def extract_upload_time_from_filename(filename):
    """
    Extract the upload time from the S3 filename, for example:
        topazevent_18b43000001e84ee-2013-07-17T04-53-14.149Z-v1-id32e689.log

    :param filename:
      Name of the Topaz logfile S3
    """
    timestamp_format = "%Y-%m-%dT%H-%M-%S.%f"
    try:
        f = os.path.split(filename)[1]
        upload_time = datetime.strptime(f[f.find('-20')+1:f.find('Z')], timestamp_format)
        d = pytz.utc.localize(upload_time)
    except ValueError:
        logger.warn('Could not extract upload time from filename: %s', filename)
        d = None
    return d


def append_to_dict(current, new):
    """
    Adds new data to an existing  dict. May be new data for existing
    fields or an entirely new field.

    :param current:
        existing dict of event dicts
    :param new:
        new dict of event dicts

    :rtype:
        dict of event dicts
    """
    for event in new:
        if event in current:
            for key in new[event]:
                if key in current[event]:
                    current[event][key] += new[event][key]
                else:
                    current[event][key] = new[event][key]
        else:
            current[event] = new[event]

    return current


def create_dataframes_from_dict(events):
    # Finally create dataframes:
    output_dataframes = {}
    for event in events:
        output_dataframes[event] = pd.DataFrame(data=events[event]['values'], index=events[event]['times'])

        # Fix column names
        output_dataframes[event].columns = ['Value{}'.format(x) for x in output_dataframes[event].columns]

        # Add rtc_time as a column:
        output_dataframes[event]['rtc_time'] = pd.Series(events[event]['rtc_times'],
                                                         index=output_dataframes[event].index)

        # possibly add raw values
        if 'raw_values' in events[event]:
            raw_values_df = pd.DataFrame(data=events[event]['raw_values'], index=events[event]['times'])
            raw_values_df.columns = ['_RawValue{}'.format(x) for x in raw_values_df.columns]
            output_dataframes[event] = output_dataframes[event].join(raw_values_df)

    return output_dataframes


def get_files_to_parse_in_tvd_directory(directory_name, start_date=None, end_date=None):
    """
    Returns a list TVD logfiles that should be parsed from the specified directory

    :param directory_name:
        path to a directory containing TVD logfiles
    :param start_date:
        as an optimization, reject logs uploaded some time before the target start date
    :param end_date:
        as an optimization, reject logs uploaded some time after the target end date

    :rtype:
        dict of Pandas dataframes
    """
    if start_date:
        start_date = converters.get_tz_aware_datetime(start_date)

    if end_date:
        end_date = converters.get_tz_aware_datetime(end_date)

    filenames = sorted(os.listdir(directory_name))
    files = [os.path.join(directory_name, filepath) for filepath in filenames]
    files_to_parse = []
    for filename in files:
        if filename.find(DEFAULT_LOG_TYPE) == -1: #skip files like .DS_Store, or possibly directoried logs
            continue
        filetime = extract_upload_time_from_filename(filename)
        if  start_date is not None and filetime < start_date - UPLOAD_PARSE_BUFFER or \
            end_date is not None and filetime > end_date + UPLOAD_PARSE_BUFFER:
            continue
        files_to_parse.append(filename)

    return files_to_parse

def parse_filepath_wrapper(kwargs):
    return parse_filepath(**kwargs)

def parse_filepath(filepath, include_raw_values=False, default_synchronization=tvdreader.TVDReader.Synchronization.Unknown):
    filename = os.path.basename(filepath)
    filetime = extract_upload_time_from_filename(filename)
    source_file_metadata = {}
    success = False
    output = None
    try:
        (output, parser_metadata) = parse_file(filepath,
                                               filetime,
                                               include_raw_values=include_raw_values,
                                               default_synchronization=default_synchronization)
        source_file_metadata.update(parser_metadata)
        success = True
    except (tvdreader.DownloadException, Exception):
        logger.exception('Error parsing file %s' % (filename))

    source_file_metadata.update({
        'parsed' : success,
        'filetime' : str(filetime),
        'parsed_at' : str(datetime.now())
    })
    return filename, source_file_metadata, output


def get_tvd_description_from_file(filepath):
    filename = os.path.basename(filepath)
    filetime = extract_upload_time_from_filename(filename)
    source_file_metadata = {}
    try:
        (output, parser_metadata) = parse_file(filepath, filetime)
        source_file_metadata.update(parser_metadata)
    except (tvdreader.DownloadException, Exception):
        logger.exception('Error parsing file %s' % (filename))

    return source_file_metadata.get('description','Unknown')


def parse_tvd_files(filepaths, threads=1, include_raw_values=False,
                    default_synchronization=tvdreader.TVDReader.Synchronization.Unknown):
    """
    Parses a list of TVD logfiles into a dict of Pandas dataframes.

    :param filenames:
        list of paths of TVD logfiles

    :rtype:
        dict of Pandas dataframes
    """
    def update_outputs(filename, source_file_metadata, new_output):
        if new_output is not None:
            if update_outputs.output is None:
                update_outputs.output = new_output
            else:
                update_outputs.output = append_to_dict(update_outputs.output, new_output)

        update_outputs.source_files_metadata[filename] = source_file_metadata

    update_outputs.output = None
    update_outputs.source_files_metadata = {}

    parameter_list = scriptutils.expand_device_arguments(filepaths, key='filepath',
                                                         include_raw_values=include_raw_values,
                                                         default_synchronization=default_synchronization)
    if threads > 1:
        results = scriptutils.parallelize(parameter_list=parameter_list, threads=threads, function_to_run=parse_filepath_wrapper)
        for (_query_parameters, (filename, source_file_metadata, new_output)) in results:
            update_outputs(filename, source_file_metadata, new_output)
    else:
        for filepath in filepaths:
            (filename, source_file_metadata, new_output) = parse_filepath(filepath,
                                                                          include_raw_values=include_raw_values,
                                                                          default_synchronization=default_synchronization)
            update_outputs(filename, source_file_metadata, new_output)

    output_dataframes = None
    if update_outputs.output is not None:
        output_dataframes = create_dataframes_from_dict(update_outputs.output)

    return (output_dataframes, update_outputs.source_files_metadata)
