# pylint: disable=invalid-name,no-member
import json
import logging
import os
import sys

import numpy as np
import pandas as pd

from ..converters import time_converters
from .cpp_enums import parse_cpp_enum_to_dict, parse_cpp_enums_to_dict_of_dicts
from .tvd_utils import remove_raw_values


logger = logging.getLogger(__name__)


# many options for event-specific parsing:
#  1. use a dictionary to lookup values given keys
#    a. dictionary loaded from a c++ enum
#    b. dictionary loaded from a json resource file
#    c. dictionary hardcoded in this file
#  2. define a function is run on a specific column in an event dataframe
#  3. define a operation that is run on the whole event dataframe

lowpan_conn_state = parse_cpp_enum_to_dict("""
    enum SixLoWPANConnectionState {
        kState6LoWPANConnectionStopped = 0,
        kState6LoWPANConnectionEnablingTechnology,
        kState6LoWPANConnectionEnablingExtension,
        kState6LoWPANConnectionTechnologyEnabled,
        kState6LoWPANConnectionExtensionEnabled,
        kState6LoWPANConnectionStopping,
    };
    """)

lowpan_conn_event = parse_cpp_enum_to_dict("""
    typedef enum
    {
        kEvent6LoWPANConnectionEnableTechnology = 0,
        kEvent6LoWPANConnectionDidEnableTechnology,
        kEvent6LoWPANConnectionDidNotEnableTechnology,
        kEvent6LoWPANConnectionEnableExtension,
        kEvent6LoWPANConnectionDidEnableExtension,
        kEvent6LoWPANConnectionDidNotEnableExtension,
        kEvent6LoWPANConnectionStop,
        kEvent6LoWPANConnectionStopComplete,
        kEvent6LoWPANConnectionError,
    } SixLoWPANConnectionEvent;
    """)

lowpan_service_state = parse_cpp_enum_to_dict("""
    typedef enum
    {
        kState6LoWPANServiceConnectionWaitingForConnection = 0,
        kState6LoWPANServiceConnectionConnected,
    } SixLoWPANServiceConnectionState;
    """)

lowpan_service_event = parse_cpp_enum_to_dict("""
    typedef enum
    {
        kEvent6LoWPANServiceConnectionDidConnect = 0,
        kEvent6LoWPANServiceConnectionDidNotConnect,
        kEvent6LoWPANServiceConnectionError,
        kEvent6LoWPANServiceConnectionRestart,
        kEvent6LoWPANServiceConnectionTimedOut,
    } SixLoWPANServiceConnectionEvent;
    """)

hunting_event = parse_cpp_enum_to_dict("""
    enum PREvent
    {
        kPREventStartScan = 0,
        kPREventHaveSomeScanResults,
        kPREventHaveNoScanResults,
        kPREventDidNotScan,
        kPREventConnectToPAN,
        kPREventDidConnectToPAN,
        kPREventDidNotConnectToPAN,
        kPREventReadyToTestCurrentScanResult,
        kPREventFinishedTestingScanResults,
        kPREventDidConnect,
        kPREventDidNotConnect,
        kPREventDidEstablishWeaveConnection,
        kPREventDidNotEstablishWeaveConnection,
        kPREventDidPASEAuthenticate,
        kPREventDidNotPASEAuthenticate,
        kPREventPairingComplete,
        kPREventDisconnectionComplete_ProvisionPresent,
        kPREventDisconnectionComplete_ProvisionNotPresent,
        kPREventPairingNotComplete
    };
    """)

hunting_state = parse_cpp_enum_to_dict("""
    enum PRState
    {
        kPRStateIdle = 0,
        kPRStateScanning,
        kPRStateConnectingToPAN,
        kPRStateAdvancingToNextScanResult,
        kPRStateConnectingProvisionally,
        kPRStateEstablishingWeaveConnection,
        kPRStateAttemptingPASEAuthentication,
        kPRStateRendezvoused,
        kPRStateConnectedToPAN,
        kPRStateDisconnecting
    };
    """)

service_state = parse_cpp_enum_to_dict("""
    enum State {
        kStateFirst = 0,

        kStateUnknown        = kStateFirst,
        kStateIdle,
        kStateAssociation,
        kStateInput,
        kStateConfiguration,
        kStateReady,
        kStateOnline,
        kStateDisconnect,
        kStateOffer,
        kStateAvailable,
        kStateWithdraw,
        kStateSleeping,
        kStateWaking,
        kStateFailure,
        kStateProxyAssociation,

        kStateLast           = kStateFailure
    };
    """)

software_update_state = parse_cpp_enum_to_dict("""
    enum nlState_t
    {
        nlState_Idle,
        nlState_Querying,
        nlState_Preparing,          // Open the file
        nlState_Downloading,
        nlState_Installing
    };
    """)


reset_reason = parse_cpp_enum_to_dict("""
    enum{
        kResetReasonPOR           = 0x01,
        kResetReasonLVD           = 0x02,
        kResetReasonResetAsserted = 0x04,
        kResetReasonWakup         = 0x08,
        kResetReasonWatchdog      = 0x10,
        kResetReasonSW            = 0x20,
    };
    """)


wakeup_source = parse_cpp_enum_to_dict("""
    enum {
        kWakeupSourceSensorMCU = (0x1 << 0),
        kWakeupSourceButton    = (0x1 << 1),
        kWakeupSourceRTC       = (0x1 << 2),
        kWakeupSourceWiFi      = (0x1 << 3),
        kWakeupSourceLoWPAN    = (0x1 << 4),
        kWakeupSourceLpTimer   = (0x1 << 5),
        kWakeupSourceExitTrap  = (0x1 << 6),
        kWakeupSourceUSB       = (0x1 << 7),
    };
    """)
decode_error_enum = parse_cpp_enum_to_dict("""
    enum {
       ot_decode_err_low_bit         = (1 << 0),
       ot_decode_err_high_bit        = (1 << 1),
       ot_decode_err_parity_bit      = (1 << 2),
       ot_decode_err_first_bit_zero  = (1 << 3),
       };
       """)

def get_wpan_pan_id(pan_id):
    return '%x' % pan_id

def get_wpan_scan_results(scan_flags):
    rssi = signed_16bit_int(((scan_flags & 0xFF00)  >> 8) | 0xFF00)
    channel = (scan_flags & 0x00F8) >> 3
    allow_join = (scan_flags & 0x4) >> 2
    router_cap = (scan_flags & 0x2) >> 1
    child_cap = (scan_flags & 0x1) >> 0
    return {'RSSI': rssi, 'channel': channel, 'allowing join': allow_join,
            'router capacity': router_cap, 'child capacity': child_cap}

def signed_int(data, width):
    if (data & (1 << (width - 1))):
        data = data - (1 << width)
    return data

def signed_8bit_int(data):
    return signed_int(data, 8)

def signed_16bit_int(data):
    return signed_int(data, 16)

def provisioning_type_specific_status_decoding(row):
    if row['typeCode'] == 'nlProvisioningEvent':
        row['provisioningStatus'] = provisioning_event.get(row['provisioningStatus_raw'], np.nan)
    elif row['typeCode'] == 'nlServiceProvisioningEvent':
        row['provisioningStatus'] = service_provisioning_event.get(row['provisioningStatus_raw'], np.nan)
    else:
        row['provisioningStatus'] = 'Unknown: %d' % row['provisioningStatus_raw']
        logger.warn("Unable to parse provisioning status with typeCode=%s" % (row['typeCode']))
    return row


def provisioning_status_decoding(df):
    df['provisioningStatus_raw'] = df['provisioningStatus']
    return df.apply(provisioning_type_specific_status_decoding, axis=1)


def get_reset_reasons(reset_reg):
    parsed_reasons = []
    for k, v in reset_reason.iteritems():
        if type(k) == int:
            if reset_reg & k:
                parsed_reasons.append(v)
    return '%s' % parsed_reasons

def get_wakeup_source(wakeup_reg):
    parsed_wakeups = []
    for k, v in wakeup_source.iteritems():
        if type(k) == int:
            if wakeup_reg & k:
                parsed_wakeups.append(v)
    return '%s' % parsed_wakeups

def get_error(err):
    data_width = 32
    if (err & (1 << (data_width - 1))):
        #take two's complement - required for pumice
        #if error is already negated (on dolo) then parse normally
        err = abs(err - (1 << data_width))
    errorcode_bits = 16
    subcomponent_bits = 12
    component_bits = 3

    subcomponent_shift = (errorcode_bits)
    component_shift = (errorcode_bits + subcomponent_bits)

    errorcode = err & ( (1 << errorcode_bits) - 1)
    subcomponent = err >> subcomponent_shift & ( (1 << subcomponent_bits) - 1)
    component = err >> component_shift & ( (1 << component_bits) - 1)

    return {'errorcode': errorcode, 'subcomponent':subcomponent,'component':component}

def ch_dhw_flags(flags):
    manual_mode = flags & (1 << 0)
    ot_connected = flags & (1 << 1)
    weave_connected = flags & (1 << 2)
    wire_connected = flags & (1 << 3)
    relay_on = flags & (1 << 4)

    return {'manual mode': bool(manual_mode),
            'OT boiler connected': bool(ot_connected),
            'weave connected': bool(weave_connected),
            'wire connected': bool(wire_connected),
            'relay on': bool(relay_on),
            }

def serial_number(sn):
    if (type(sn) == str or type(sn) == unicode) and len(sn) == 16:
        sn_parsed = {
            'ProductNumber': sn[0:3],
            'HWRevision': sn[3],
            'HWVersion': sn[4:6],
            'ManufacturingLocation': sn[6:8],
            'WeekOfManufacture': sn[8:10],
            'YearOfManufacture': sn[10:12],
            'SerializedNumber': sn[12:],
            'Color': 'White' if sn[3] == 'A' else 'Black',
            'Power': 'Battery' if sn[0:3] == '05A' else 'Line'
        }
    else:
        sn_parsed = {
            'ProductNumber': np.nan,
            'HWRevision': np.nan,
            'HWVersion': np.nan,
            'ManufacturingLocation': np.nan,
            'WeekOfManufacture': np.nan,
            'YearOfManufacture': np.nan,
            'SerializedNumber': np.nan,
            'Color': 'Unknown',
            'Power': 'Unknown'
        }
    return pd.Series(sn_parsed)


def parse_amber_metadata(metadata):
    for column in metadata:
        # check if this column name is defined in this module
        if hasattr(sys.modules[__name__], column):
            parser = getattr(sys.modules[__name__], column)

            if type(parser) == dict: # if it is a lookup table
                metadata[column] = [parser[x] if x in parser else np.nan for x in metadata[column]]

            elif hasattr(parser, '__call__'): # if it is a function
                metadata = metadata.join(metadata[column].apply(parser))

    metadata = metadata.rename(columns=name_conversion)
    return metadata


