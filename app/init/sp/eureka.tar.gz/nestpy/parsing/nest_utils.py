""" Common utility functions for Nest

    This module defines common utility functions/interfaces across *all* Nest products.
"""

where_id_mapping = {
    "00000000-0000-0000-0000-000100000000": 0,
    "00000000-0000-0000-0000-000100000001": 1,
    "00000000-0000-0000-0000-000100000002": 2,
    "00000000-0000-0000-0000-000100000003": 3,
    "00000000-0000-0000-0000-000100000004": 4,
    "00000000-0000-0000-0000-000100000005": 5,
    "00000000-0000-0000-0000-000100000006": 6,
    "00000000-0000-0000-0000-000100000007": 7,
    "00000000-0000-0000-0000-000100000008": 8,
    "00000000-0000-0000-0000-000100000009": 9,
    "00000000-0000-0000-0000-00010000000A": 10,
    "00000000-0000-0000-0000-00010000000B": 11,
    "00000000-0000-0000-0000-00010000000C": 12,
    "00000000-0000-0000-0000-00010000000D": 13,
    "00000000-0000-0000-0000-00010000000E": 14,
    "00000000-0000-0000-0000-00010000000F": 15,
    "00000000-0000-0000-0000-000100000010": 16
}

what_id_mapping = {
    "00000000-0000-0000-0000-000100000000": 0,
    "00000000-0000-0000-0000-000100000001": 1,
    "00000000-0000-0000-0000-000100000002": 2,
    "00000000-0000-0000-0000-000100000003": 3,
    "00000000-0000-0000-0000-000100000004": 4,
    "00000000-0000-0000-0000-000100000005": 5
}

where_lookup = {
    0: "Entry",
    1: "Basement",
    2: "Hallway",
    3: "Den",
    4: "Attic",
    5: "Master Bedroom",
    6: "Downstairs",
    7: "Garage",
    8: "Kids Room",
    9: "Bathroom",
    10: "Kitchen",
    11: "Family Room",
    12: "Living Room",
    13: "Bedroom",
    14: "Office",
    15: "Upstairs",
    16: "Dining Room"
}

what_lookup = {
    0: "None",
    1: "Outside/Exterior Door",
    2: "Inside Door",
    3: "Window",
    4: "Room/Wall",
    5: "Object"
}

subwhat_lookup = {
    1: "Hinged Door",
    2: "French Door",
    3: "Sliding Door",
    4: "Garage Door",
    32: "Single Hung Vertical Window",
    33: "Single Hung Horizontal Window",
    34: "Double Hung Vertical Window",
    35: "Double Hung Horizontal Window",
    36: "Hinged Casement Window",
    37: "Horizontal Hinged Window",
    38: "Tilt Turn Window",
    39: "Multi Segment Tilt Window",
    40: "Single Segment Tilt Window"
}

def get_deviceconfig(subwhat=None, what=None, where=None):
    """
    If input is of type(str), then it will compare against Hiddenite values
    else, it will compare against Pinna values (uint8_t)

    If nothing is found, '?' is returned.
    """
    description = {'what':'?', 'subwhat':'?', 'where':'?'}
    key = None

    if subwhat is not None:
        if type(subwhat) is str:
            key = None
        else:
            key = int(subwhat)
        if key in subwhat_lookup:
            description['subwhat'] = subwhat_lookup[key]

    if what is not None:
        if type(what) is str:
            key = what_id_mapping.get(what, None)
        else:
            key = int(what)
        if key in what_lookup:
            description['what'] = what_lookup[key]

    if where is not None:
        if type(where) is str:
            key = where_id_mapping.get(where, None)
        else:
            key = int(where)
        if key in where_lookup:
            description['where'] = where_lookup[key]

    return description

