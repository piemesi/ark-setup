import os
import re

def parse_cpp_enums_to_dict_of_dicts(enum_string):
    if os.path.isfile(enum_string):
        with open (enum_string, "r") as myfile:
            enum_string = myfile.read()

    def remove_words_from_string(text, remove_list):
        for i in remove_list:
            text = text.replace(i,'')
        return text

    # remove lines that are totally commented out
    file_data = '\n'.join([line for line in enum_string.split('\n') if not line.strip().startswith('//')])

    # remove text after comment on a single line
    file_data = ' '.join(line.split('//')[0].split('#')[0] for line in file_data.splitlines())

    # remove commented out blocks
    file_data = ' '.join(re.split(r'\/\*.*\*\/', file_data))

    # Look for enums: In the first { } block after the keyword "enum"
    # Name these enums by the text around the enum definition
    remove_list = [' ', '\n', '\t', ';', 'enum', 'typedef']
    enum_name_str = [(remove_words_from_string(text.split('{')[0] + text.split('}')[1], remove_list), \
                      text.split('{')[1].split('}')[0]) \
                        for text in re.split(r'\benum\b', file_data)[1:]]

    enum_library = {}
    for (enum_name, enum_str) in enum_name_str:
        lookup = {}
        last_value = -1
        for key in enum_str.split(','):
            if '=' in key:
                key, value = key.split('=')
                key = key.strip()
                value = value.strip()
                if value in lookup: # to handle self-referenced enum definitions
                    value = lookup[value]
                else:
                    try:
                        value = int(value, 0)
                    except ValueError:
                        value = eval(value)
            else:
                value = last_value + 1
            last_value = value
            key = key.strip()
            if len(key) > 0:
                lookup[key] = value
                lookup[value] = key
        if not hasattr(enum_library, enum_name):
            enum_library[enum_name] = lookup
        else:
            raise AttributeError("Enum with name %s already exists in library" % enum_name)

    return enum_library


def parse_cpp_enum_to_dict(enum_string):
    if os.path.isfile(enum_string):
        with open (enum_string, "r") as myfile:
            enum_string = myfile.read()

    def remove_words_from_string(text, remove_list):
        for i in remove_list:
            text = text.replace(i,'')
        return text

    # remove lines that are totally commented out
    file_data = '\n'.join([line for line in enum_string.split('\n') if not line.strip().startswith('//')])

    # remove text after comment on a single line
    file_data = ' '.join(line.split('//')[0].split('#')[0] for line in file_data.splitlines())

    # remove commented out blocks
    file_data = ' '.join(re.split(r'\/\*.*\*\/', file_data))

    # Look for enums: In the first { } block after the keyword "enum"
    # Name these enums by the text around the enum definition
    remove_list = [' ','\n','\t',';','enum','typedef']
    enum_name_str = [(remove_words_from_string(text.split('{')[0] + text.split('}')[1], remove_list), \
                      text.split('{')[1].split('}')[0]) \
                        for text in re.split(r'\benum\b', file_data)[1:]]

    if len(enum_name_str) > 1:
        raise ValueError("more than one enum found in text: %s" % enum_string)

    (enum_name, enum_str) = enum_name_str[0]
    lookup = {}
    last_value = -1
    for key in enum_str.split(','):
        if '=' in key:
            key, value = key.split('=')
            key = key.strip()
            value = value.strip()
            if value in lookup: # to handle self-referenced enum definitions
                value = lookup[value]
            else:
                try:
                    value = int(value, 0)
                except ValueError:
                    value = eval(value)
        else:
            value = last_value + 1
        last_value = value
        key = key.strip()
        if len(key) > 0:
            lookup[key] = value
            lookup[value] = key

    return lookup
