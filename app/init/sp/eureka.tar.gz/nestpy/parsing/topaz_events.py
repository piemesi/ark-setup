# pylint: disable=no-member
import json
import logging
import os

from .cpp_enums import parse_cpp_enum_to_dict
from . import topaz_utils
from .event_field_parser import parse_event_fields

logger = logging.getLogger(__name__)

# Load in the event_type enum from nlhistory
# This code allows the event_types enum from the dolomite tree to be copied in to the nlhistory directory, and
# automatically used. Note: This code does not actually check the software version number for the log files, and
# will not work if backwards compatibility is violated for event_types.
history_location = os.path.join(os.path.dirname(os.path.realpath(__file__)),
                                'topaz_definitions', 'nlhistory')
event_type_enum = {}
for file in os.listdir(history_location):
    if '.h' in file:
        event_type_enum[file.replace('.h', '')] = parse_cpp_enum_to_dict(os.path.join(history_location, file))

# load in the event field definition file
with open(os.path.join(os.path.dirname(os.path.realpath(__file__)),
          'topaz_definitions', 'topaz_events_fields.json')) as data_file:
    event_field_definition = json.load(data_file)


def parse_topaz_event_fields(dh):
    if 'event' in dh.events:
        # parse the event id into event name
        names = []
        for index, event in dh.event.Value0.iteritems():
            for version in reversed(sorted(event_type_enum)):
                if event in event_type_enum[version]:
                    names.append(event_type_enum[version][event])
                    break
            else:
                names.append("Unknown")
        dh.event["name"] = names

        if len(dh.event) > 0:
            for missing_event_enum in dh.event.Value0[dh.event.name == "Unknown"].unique():
                logger.warn('Missing event enum: %d', missing_event_enum)

        parse_event_fields(dh, event_field_definition, topaz_utils)
