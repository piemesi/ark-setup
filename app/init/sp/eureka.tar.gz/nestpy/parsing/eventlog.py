"""
Parsing methods for Sapphire event logs.
"""
# pylint: disable=maybe-no-member
from datetime import datetime, timedelta
import gzip
import json
import logging
import os
import re

import pandas as pd
import pytz

from ..converters.time_converters import get_tz_aware_datetime

UNIQUENESS_TIME_SHIFT = timedelta(microseconds=1000)
logger = logging.getLogger(__name__)


def set_error_logging(log_file):
    if not log_file:
        logger.warn("Unable to set error logging as no valid log file found ...")
        return

    if log_file and len(log_file.split('.')) > 1:
        error_file = log_file.split('.')[1].split('/')[-1]
        path = os.environ.get('EUREKA_CACHE')
        if path:
            error_log = os.path.join(path, error_file+'_error.log')
            logging.basicConfig(filename=error_log, filemode='w', level=logging.ERROR)


def parse_raw_event_log(log_file,
                        event_types=None,
                        start_date=None,
                        end_date=None):
    """
    Parses an event log into a dictionary containing event data. The returned
    dictionary has the following structure:

      event_name_1
        times: a list of datetimes
        values: a list of values that correspond to the datetimes
      event_type_2...
            Loads the specified event log into the device history.

    :param log_file: the log file to parse.
    :param event_types: a list of event types to include. If not provided,
      all event types will be loaded.

    :param start_date:
        the earliest date to include. If not specified, data from the very
        beginning of the event log will be included.
    :type start_date:
        timezone-aware datetime

    :param end_date:
        the latest date to include. If not specified, data to the very end of
        the event log will be included.
    :type end_date:
        timezone-aware datetime

    :rtype: the dictionary from event types to event data.
    """
    event_data = {}

    logger.debug("Reading event log data from log file: %s", log_file)

    set_error_logging(log_file)

    converters = {
        "timestamp": get_tz_aware_datetime,
        "integer": int,
        "decimal": float,
        "float": float,
        "boolean": lambda x: "true" in x,
        "string": lambda x: x.strip('"')
    }

    # Parse the event log
    event_headers = {}
    previous_event_times = {}

    if log_file.endswith("gz"):
        file_reader = gzip.open(log_file, 'r')
    else:
        file_reader = open(log_file, 'r')

    for line_count, line in enumerate(file_reader):
        # Split on spaces, preserving quotes
        fields = re.findall(r'(?:[^\s "]|"(?:\\.|[^"])*")+', line)

        if len(fields) < 2:
            message = "Error reading log line [%s] in file %s. Not enough fields." % (line, log_file)
            raise RuntimeError(message)
            continue
        elif len(fields) < 3:
            # This may happen if the data field contains only empty strings.
            continue

        try:
            # If this is a header line and throws an exception, all event data pertaining to this event, will be skipped.
            timestamp = get_tz_aware_datetime(fields[0])
        except ValueError as ve:
            logger.error(" | ".join(["LINE: {}".format(line_count), fields[0], str(ve), str(line)]))
            continue

        event_type = fields[1]
        data = fields[2:]

        if event_type.startswith("%"):
            # This is a header line
            event_type = event_type[1:]

            if event_types and event_type not in event_types:
                # We don't want this event type - skip it.
                continue

            try:
                header_info = json.loads(" ".join(data))
                event_headers[event_type] = header_info["fields"]
            except Exception as e:
                ## log error as : line number in file, event_type, error type, exception details, header/schema
                logger.error(" | ".join(["LINE: {}".format(line_count), event_type, str(type(e)), str(e), str(data)]))

        elif event_type in event_headers:

            # Check the time range. We do this only for event data because the
            # header may be printed before the start time.


            if start_date and timestamp < start_date:
                continue

            if end_date and timestamp > end_date:
                continue

            event_header = event_headers[event_type]


            if (event_type in previous_event_times and
               timestamp == previous_event_times[event_type]['timestamp']):
                    # Update time offset to preserve row ordering
                    previous_event_times[event_type]['offset'] = (previous_event_times[event_type]['offset'] +
                                                                  UNIQUENESS_TIME_SHIFT)
                    # Advance the timestamp to guarantee uniqueness
                    timestamp += previous_event_times[event_type]['offset']
            else:
                # Only update timestamp when there is no match, and reset offset to zero
                previous_event_times[event_type] = {'timestamp': timestamp,
                                                    'offset': timedelta(seconds=0)}

            if event_type not in event_data:
                event_data[event_type] = {"times": [], "values": []}

            line_data = {}

            if len(event_header) != len(data):
                logger.debug("Skipping line. Schema indicates %d fields, but data has %d entries. " %
                             (len(event_header), len(data)))
            else:
                for index, data_info in enumerate(event_header):
                    data_types = data_info["type"]
                    raw_value = data[index]

                    if raw_value in ["", "-"] and "null" in data_types:
                        # Value is null/missing, and that's okay!
                        logger.debug("Skipping 'null' value.")
                        continue

                    if raw_value in ["-", '"(null)"', '(null)']:
                        logger.debug("Skipping '(null)' value.")
                        continue

                    if not isinstance(data_types, list):
                        data_types = [data_types]

                    try:
                        for data_type in data_types:
                            if data_type == "null":
                                continue
                            value = converters[data_type](raw_value)
                    except ValueError as ve:
                        print(" | ".join(["Value error at: {}".format(line_count), event_type, str(type(ve)), str(ve), str(data)]))
                        break

                    line_data[data_info["name"]] = value
                else:
                    event_data[event_type]["times"].append(timestamp)
                    event_data[event_type]["values"].append(line_data)

    file_reader.close()
    logger.debug("Found %s events as %s " % (str(len(event_headers)),
                                             str(event_headers), ))


    return event_data


def parse_directoried_event_log(filename,
                                start_date=None,
                                end_date=None,
                                sort_by_time=False):
    """
    Parses the specified directoried event log file.

    :param filename: the name of the parsed event file to load.
    :param start_date: the earliest date to include.
    :param end_date: the latest date to include.
    :param sort_by_time: whether to sort the events by time.
    :rtype: a Pandas DataFrame containing the event data.
    """

    (base, ext) = os.path.splitext(os.path.basename(filename))

    # Determine file type
    if not ext:
        compression = None
        with open(filename, 'r') as file_reader:
            header_line = file_reader.readline()
    elif ext in [".gz", ".gzip"]:
        compression = "gzip"
        with gzip.open(filename, 'r') as file_reader:
            header_line = file_reader.readline()
    else:
        raise RuntimeError("%s: file extension '%s' not supported." % (filename, ext))

    # Assemble column names using the first line of the event log table.
    if "," in header_line:
        columns = header_line.strip("\n,").split(",")
    else:
        columns = header_line.strip("\n\t").split("\t")
    column_names = []
    converters = {}
    
    def timestamp_converter(x):
        converted_time = pytz.utc.localize(datetime(1900, 1, 1))
        try:
            converted_time = pytz.utc.localize(datetime.utcfromtimestamp(float(x)))
        except ValueError as ve:
            logger.warning("Error parsing column for file %s , error:  %s" %(str(filename), str(ve)))

        return converted_time
    
    string_converter = str

    for column in columns:
        items = column.split(":")
        column_name = items[0]
        column_type = items[1]

        column_names.append(column_name)

        # For timestamp columns, we'll want to use the timestamp converter
        if "timestamp" in column_type:
            converters[column_name] = timestamp_converter
        if "string" in column_type:
            converters[column_name] = string_converter

    # Parse the event log table into a DataFrame.
    # Although the first column (time) will be used as an index, we can't
    # do that immediately because we need to apply the datetime converter
    # to it first.
    dataframe = pd.read_table(filename,
                              converters=converters,
                              skiprows=1,
                              index_col=False,
                              header=None,
                              compression=compression,
                              names=column_names)
    dataframe = dataframe.set_index(column_names[0])
    # Handling case of '(null)' present in dh.CurrentState.ZipCode for certain devices
    if 'ZipCode' in dataframe.columns:
        dataframe.ZipCode = dataframe.ZipCode.replace('NaN', float('NaN'))
    # Restrict times to the user's specified range.
    if start_date:
        dataframe = dataframe[dataframe.index >= start_date]

    if end_date:
        dataframe = dataframe[dataframe.index <= end_date]

    if sort_by_time:
        dataframe = dataframe.sort()

    return dataframe
