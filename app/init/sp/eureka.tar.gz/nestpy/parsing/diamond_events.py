"""
Provides functionality for parsing Diamond events and fields into useful forms
"""
# pylint: disable=no-member
import ast
import json
import logging
import os
import numpy as np
import pandas as pd
import datetime

from . import diamond_utils
from .. import converters
from ..scriptutils import set_unique_index, series_diff, drop_consecutive_duplicates

logger = logging.getLogger(__name__)


# load in the event field definition file
with open(os.path.join(os.path.dirname(os.path.realpath(__file__)), 'diamond_definitions', 'diamond_event_fields.json')) as data_file:
    event_field_definition = json.load(data_file)

def parse_diamond_events(dh):
    """
    Parses events and fields in Diamond into more useful forms.

    :param dh:
        raw Diamond object loaded from logs
    :type dh:
        nestpy.Diamond

    :return:
        Diamond object with added events and fields
    :rtype:
        nestpy.Diamond
    """

    for event in dh.events:
        if event in event_field_definition:
            for field in dh[event].columns:
                if field in event_field_definition[event]:
                    if event_field_definition[event][field]['type'] == "enum":
                        enum_name = event_field_definition[event][field]['enum_name']
                        parser = getattr(diamond_utils, enum_name)
                        if type(parser) == dict: # if it is a lookup table
                            dh[event][field + '_string'] = [parser[row] if row in parser else np.nan for row in dh[event][field]]
                        else:
                            logger.warn("Unable to find lookup table '%s' when parsing %s::%s", enum_name, event, field)

    # Nonnative event: AwayMode with a boolean column IsAway
    if ('CurrentState' in dh
        and 'AwayMode' in dh.CurrentState):
        is_away = pd.Series(dh.CurrentState.AwayMode > 0, name="IsAway")
        away_mode = pd.DataFrame(is_away)
        dh.add_event_data("AwayMode", drop_consecutive_duplicates(away_mode), native=False)

    # Nonnative event: HVACState containing aggregated HVAC states
    if 'UpdateStateResults' in dh:
        hvac_heating_states = [state for state in dh.UpdateStateResults.columns if 'Heat' in state]
        hvac_heating = pd.Series(dh.UpdateStateResults[hvac_heating_states].sum(1) > 0, name="Heating")
        hvac_cooling_states = [state for state in dh.UpdateStateResults.columns if ('Cool' in state and not 'FanCooling' in state)]
        hvac_cooling = pd.Series(dh.UpdateStateResults[hvac_cooling_states].sum(1) > 0, name="Cooling")
        hvac_heating_or_cooling = pd.Series(hvac_heating | hvac_cooling, name='HeatingOrCooling')
        hvac_state = pd.concat([hvac_heating, hvac_cooling, hvac_heating_or_cooling], axis=1)
        dh.add_event_data("HVACState", drop_consecutive_duplicates(hvac_state), native=False)

    # Nonnative event: SetPoints containing categorized, range mode aware and clustered set points
    if ('NewSetPoint' in dh
        and 'Temperature' in dh.NewSetPoint
        and 'TouchedBy' in dh.NewSetPoint
        and 'TouchedWhere' in dh.NewSetPoint):
        set_points = pd.DataFrame(columns=['Heating','Cooling','Category'],index=dh.NewSetPoint.index)
        set_points.loc[(dh.NewSetPoint.TouchedWhere == 1), ['Category']] = "Schedule"
        set_points.loc[(dh.NewSetPoint.TouchedBy == 2) & (dh.NewSetPoint.TouchedWhere == 2), ['Category']] = "Dial"
        set_points.loc[(dh.NewSetPoint.TouchedBy >= 3) & (dh.NewSetPoint.TouchedBy <= 7) & (dh.NewSetPoint.TouchedWhere == 2), ['Category']] = "Thermozilla"
        set_points.loc[(dh.NewSetPoint.TouchedBy == 8), ['Category']] = "SeasonalSavings"
        set_points.loc[(dh.NewSetPoint.TouchedBy == 9), ['Category']] = "RushHourRewards"
        set_points.loc[(dh.NewSetPoint.TouchedBy == 10), ['Category']] = "TimeOfUse"
        set_points.loc[(dh.NewSetPoint.TouchedBy == 11), ['Category']] = "Topaz"
        set_points.loc[(dh.NewSetPoint.TouchedBy == 12), ['Category']] = "Programmer"
        if 'ScheduleMode' in dh.NewSetPoint:
            set_points['ScheduleMode'] = dh.NewSetPoint.ScheduleMode_string
            heating_mode_index = (dh.NewSetPoint.ScheduleMode == 0)
            cooling_mode_index = (dh.NewSetPoint.ScheduleMode == 1)
            range_mode_index = (dh.NewSetPoint.ScheduleMode == 2)
            set_points.loc[heating_mode_index | range_mode_index, ['Heating']] = dh.NewSetPoint.Temperature[heating_mode_index | range_mode_index]
            set_points.loc[cooling_mode_index, ['Cooling']] = dh.NewSetPoint.Temperature[cooling_mode_index]
            # When in range mode, add RangeTemperatureMax setpoints
            if range_mode_index.sum() > 0:
                set_points.loc[range_mode_index, ['Cooling']] = dh.NewSetPoint.RangeTemperatureMax[range_mode_index]
        # Debounces dial and thermozilla touches because a single touch shows up multiple times
        cluster_interval = 60
        for set_point_category in ["Dial","Thermozilla"]:
            cluster_set_points = set_points[set_points.Category == set_point_category]
            if len(cluster_set_points) > 1:
                # Appending cluster_interval to time_held to ensure that the last entry is kept
                time_held = np.append(np.diff(cluster_set_points.index.asi8)/1e9,cluster_interval)
                set_points_to_keep = cluster_set_points[time_held >= cluster_interval]
                set_points = set_points[set_points.Category != set_point_category] \
                    .append(set_points_to_keep).sort_index()
        set_points.loc[:,['Heating','Cooling']] = set_points.loc[:,['Heating','Cooling']].astype(float)
        dh.add_event_data("SetPoints", set_points, native=False)

    # Nonnative event: TargetTemperature containing range mode aware heating and cooling target temperatures
    if ('CurrentState' in dh and 'Temperature' in dh.CurrentState):
        target_temperature = pd.DataFrame(columns=['Heating','Cooling'],index=dh.CurrentState.index)
        if 'ScheduleMode' in dh.CurrentState:
            target_temperature['ScheduleMode'] = dh.CurrentState.ScheduleMode_string
            heating_mode_index = (dh.CurrentState.ScheduleMode == 0)
            cooling_mode_index = (dh.CurrentState.ScheduleMode == 1)
            range_mode_index = (dh.CurrentState.ScheduleMode == 2)
            target_temperature.loc[heating_mode_index | range_mode_index, ['Heating']] = dh.CurrentState.Temperature[heating_mode_index | range_mode_index]
            target_temperature.loc[cooling_mode_index, ['Cooling']] = dh.CurrentState.Temperature[cooling_mode_index]
            # When in range mode, add RangeTemperatureMax to cooling target temperature
            if 'RangeTemperatureMax' in dh.CurrentState:
                if range_mode_index.sum() > 0:
                    target_temperature.loc[range_mode_index, ['Cooling']] = dh.CurrentState.RangeTemperatureMax[range_mode_index]
            # When in away mode, add away temperatures to target temperatures
            if 'AwayMode' in dh.CurrentState and 'AwayTemperatureHigh' in dh.CurrentState and 'AwayTemperatureLow' in dh.CurrentState:
                away_mode_index = (dh.CurrentState.AwayMode > 0)
                if away_mode_index.sum() > 0:
                    # Define limits for when away_temperature is not set (in Centigrade).
                    # Set to NaN to plot effectively.
                    away_temperature_unset_low = -1000
                    away_temperature_unset_high = 1000

                    away_temperature_low = dh.CurrentState.AwayTemperatureLow
                    away_temperature_low[away_temperature_low == away_temperature_unset_low] = np.nan

                    away_temperature_high = dh.CurrentState.AwayTemperatureHigh
                    away_temperature_high[away_temperature_high == away_temperature_unset_high] = np.nan

                    target_temperature.loc[(heating_mode_index | range_mode_index) & away_mode_index, ['Heating']] = away_temperature_low[(heating_mode_index | range_mode_index) & away_mode_index]
                    target_temperature.loc[(cooling_mode_index | range_mode_index) & away_mode_index, ['Cooling']] = away_temperature_high[(cooling_mode_index | range_mode_index) & away_mode_index]
        # When system mode is off, set corresponding target temperatures to NaN
        if 'SystemMode' in dh.CurrentState:
            target_temperature['SystemMode'] = dh.CurrentState.SystemMode
            target_temperature.loc[[not x for x in target_temperature['SystemMode']], ['Heating','Cooling']] = np.nan
            if 'ScheduleMode' in target_temperature:
                 target_temperature.loc[[not x for x in target_temperature['SystemMode']], ['ScheduleMode']] = np.nan
        target_temperature.loc[:,['Heating','Cooling']] = target_temperature.loc[:,['Heating','Cooling']].astype(float)
        dh.add_event_data("TargetTemperature", drop_consecutive_duplicates(target_temperature), native=False)

    # Nonnative event: FixedWeather containing fixed weather data
    if ('Weather' in dh
        and 'Temperature' in dh.Weather
        and 'RelativeHumidity' in dh.Weather):
        # Future work could be to fill missing data using WU
        temperature_limits = [-140,140]
        if dh.temperature_unit == 'C':
            temperature_limits = [converters.f2c(temperature_limit) for temperature_limit in temperature_limits]
        fixed_weather = dh.Weather[['Temperature','RelativeHumidity']]

        bad_locs = (fixed_weather.RelativeHumidity < 0) | (fixed_weather.RelativeHumidity > 100) | \
            (fixed_weather.Temperature < temperature_limits[0]) | (fixed_weather.Temperature > temperature_limits[1])

        if bad_locs.sum() > 0:
            # Some weather data was bad set the entire row to nan.
            fixed_weather.loc[(bad_locs),['Temperature','RelativeHumidity']] = np.nan

        dh.add_event_data("FixedWeather", fixed_weather, native=False)

    # Nonnative event: FarPirActivity containing far PIR activity (max > threshold)
    if ('BufferedPassiveInfrared' in dh
        and 'max' in dh.BufferedPassiveInfrared
        and 'threshold' in dh.BufferedPassiveInfrared):
        far_pir_activity = pd.DataFrame(columns=['Activity'],index=dh.BufferedPassiveInfrared.index)
        far_pir_activity.Activity = (dh.BufferedPassiveInfrared['max'] > dh.BufferedPassiveInfrared.threshold)
        dh.add_event_data("FarPirActivity",drop_consecutive_duplicates(far_pir_activity), native=False)

    # Nonnative event: NearPirActivity containing near PIR activity (max > threshold)
    if ('BufferedNearPir' in dh
        and 'max' in dh.BufferedNearPir
        and 'threshold' in dh.BufferedNearPir):
        near_pir_activity = pd.DataFrame(columns=['Activity'],index=dh.BufferedNearPir.index)
        near_pir_activity.Activity = (dh.BufferedNearPir['max'] > dh.BufferedNearPir.threshold)
        dh.add_event_data("NearPirActivity", drop_consecutive_duplicates(near_pir_activity), native=False)

    # Nonnative event: DROptimizerBaselineModel containing parsed SetpointRampTrajectory data
    if ('SetpointRampTrajectory' in dh
        and not dh.SetpointRampTrajectory.empty):
        def old_parsing_method(setpoint_ramp_trajectory,trajectory_name,time_zone):
            optimizer_model = pd.DataFrame(columns=["Heating","Cooling","HeatingOrCooling","LowerTargetTemperature","UpperTargetTemperature","PredictedTemperature","EventID"],index=setpoint_ramp_trajectory.index)
            if len(optimizer_model) > 0:
                optimization_step_seconds = 60
                current_time_zone = setpoint_ramp_trajectory.index.tz
                effective_time = [reference_time + datetime.timedelta(0,int(step*optimization_step_seconds)) \
                    for reference_time,step in zip(setpoint_ramp_trajectory.referenceTime.values,setpoint_ramp_trajectory.step.values)]
                effective_time = pd.DatetimeIndex(effective_time)
                effective_time.tz = None
                effective_time = effective_time.tz_localize(time_zone)
                if time_zone != current_time_zone:
                    effective_time = effective_time.tz_convert(current_time_zone)
                optimizer_model["Heating"] = pd.Series(setpoint_ramp_trajectory.heating).astype(bool)
                optimizer_model["Cooling"] = pd.Series(setpoint_ramp_trajectory.cooling).astype(bool)
                optimizer_model["HeatingOrCooling"] = pd.Series(optimizer_model["Heating"] | optimizer_model["Cooling"])
                optimizer_model["LowerTargetTemperature"] = setpoint_ramp_trajectory.TargetTemperature
                optimizer_model["UpperTargetTemperature"] = setpoint_ramp_trajectory.TargetTemperature
                optimizer_model["PredictedTemperature"] = setpoint_ramp_trajectory.PredictedTemperature
                optimizer_model["EventID"] = setpoint_ramp_trajectory.referenceTime
                first_model_index =  (optimizer_model.index == optimizer_model[(setpoint_ramp_trajectory.trajectoryName == trajectory_name)].index.min())
                optimizer_model = optimizer_model[first_model_index].set_index(effective_time[first_model_index]).sort_index()
            return optimizer_model

        def new_parsing_method(setpoint_ramp_trajectory,trajectory_name,temperature_unit):
            optimizer_model = pd.DataFrame(columns=["Heating","Cooling","HeatingOrCooling","LowerTargetTemperature","UpperTargetTemperature","PredictedTemperature","EventID"])
            for event_id in setpoint_ramp_trajectory.eventID.unique():
                index = ((setpoint_ramp_trajectory.eventID == event_id) & (setpoint_ramp_trajectory.trajectoryName == trajectory_name))
                if index.sum() > 0:
                    hvac_states = json.loads(setpoint_ramp_trajectory.hvacStates[index][0])
                    enum_parser = getattr(diamond_utils, "nlHVACOperationState")
                    hvac_states_str = [enum_parser[row] if row in enum_parser else np.nan for row in hvac_states]
                    effective_time = [setpoint_ramp_trajectory.referenceTime[index][0] + \
                        datetime.timedelta(0,int(step*setpoint_ramp_trajectory.timestep[index][0])) \
                        for step in range(0,int(setpoint_ramp_trajectory.numsteps[index][0]))]
                    new_optimizer_model = pd.DataFrame(index=effective_time)
                    new_optimizer_model['HvacState'] = hvac_states_str
                    new_optimizer_model["Heating"] = ["Heat" in hvac_state_str for hvac_state_str in hvac_states_str]
                    new_optimizer_model["Cooling"] = ["Cool" in hvac_state_str for hvac_state_str in hvac_states_str]
                    new_optimizer_model["HeatingOrCooling"] = pd.Series(new_optimizer_model["Heating"] | new_optimizer_model["Cooling"])
                    new_optimizer_model["LowerTargetTemperature"] = json.loads(setpoint_ramp_trajectory.targetTemperatures[index][0])
                    new_optimizer_model["UpperTargetTemperature"] = json.loads(setpoint_ramp_trajectory.targetTemperatures[index][0])
                    new_optimizer_model["PredictedTemperature"] = json.loads(setpoint_ramp_trajectory.predictedTemperatures[index][0])
                    new_optimizer_model["EventID"] = event_id
                    if temperature_unit == "F":
                        for field in ["LowerTargetTemperature","UpperTargetTemperature","PredictedTemperature"]:
                            new_optimizer_model[field] = new_optimizer_model[field].apply(converters.c2f)
                    optimizer_model = optimizer_model.append(new_optimizer_model)
            return optimizer_model

        optimizer_model = {}
        for trajectory_name in ["baseline","optimal"]:
            if 'eventID' in dh.SetpointRampTrajectory:
                new_data_check = dh.SetpointRampTrajectory.timestep.notnull()
                optimizer_model[trajectory_name] = pd.concat([old_parsing_method(dh.SetpointRampTrajectory[~new_data_check],trajectory_name=trajectory_name,time_zone=dh.get_timezone()), \
                    new_parsing_method(dh.SetpointRampTrajectory[new_data_check],trajectory_name=trajectory_name,temperature_unit=dh.temperature_unit)]).sort_index()
            else:
                optimizer_model[trajectory_name] = old_parsing_method(dh.SetpointRampTrajectory,trajectory_name=trajectory_name,time_zone=dh.get_timezone())
            for float_field in ["LowerTargetTemperature","UpperTargetTemperature","PredictedTemperature"]:
                optimizer_model[trajectory_name][float_field] = optimizer_model[trajectory_name][float_field].astype(float)
            for boolean_field in ["Heating","Cooling","HeatingOrCooling"]:
                optimizer_model[trajectory_name][boolean_field] = optimizer_model[trajectory_name][boolean_field].astype(bool)
        dh.add_event_data("DROptimizerBaselineModel", set_unique_index(optimizer_model["baseline"]), native=False)
        dh.add_event_data("DROptimizerOptimalModel", set_unique_index(optimizer_model["optimal"]), native=False)

    # Nonnative event: UCTTrajectory
    if ('UCTTrajectory' in dh
        and not dh.UCTTrajectory.empty):
        combined_optimizer_model = {}
        for trajectory_name in ["baseline","optimal"]:
            trajectory_optimizer_model = pd.DataFrame(columns=["Heating","Cooling","HeatingOrCooling","LowerTargetTemperature","UpperTargetTemperature","PredictedTemperature","EventID"])
            for event_id in dh.UCTTrajectory.eventID.unique():
                index = ((dh.UCTTrajectory.eventID == event_id) & (dh.UCTTrajectory.trajectoryName == trajectory_name))
                if index.sum() > 0:
                    # Use ast.literal_eval instead of json.loads because of SAPPHIRE-11535
                    hvac_states = ast.literal_eval(dh.UCTTrajectory.hvacStates[index][0])
                    enum_parser = getattr(diamond_utils, "nlHVACOperationState")
                    hvac_states_str = [enum_parser[row] if row in enum_parser else np.nan for row in hvac_states]
                    effective_time = [dh.UCTTrajectory.referenceTime[index][0] + \
                        datetime.timedelta(0,int(step*dh.UCTTrajectory.timestep[index][0])) \
                        for step in range(0,len(hvac_states_str))]
                    new_optimizer_model = pd.DataFrame(index=effective_time)
                    new_optimizer_model['HvacState'] = hvac_states_str
                    new_optimizer_model["Heating"] = ["Heat" in hvac_state_str for hvac_state_str in hvac_states_str]
                    new_optimizer_model["Cooling"] = ["Cool" in hvac_state_str for hvac_state_str in hvac_states_str]
                    new_optimizer_model["HeatingOrCooling"] = pd.Series(new_optimizer_model["Heating"] | new_optimizer_model["Cooling"])
                    new_optimizer_model["LowerTargetTemperature"] = ast.literal_eval(dh.UCTTrajectory.lowerTargetTemperatures[index][0])
                    new_optimizer_model["UpperTargetTemperature"] = ast.literal_eval(dh.UCTTrajectory.upperTargetTemperatures[index][0])
                    new_optimizer_model["PredictedTemperature"] = ast.literal_eval(dh.UCTTrajectory.predictedTemperatures[index][0])
                    new_optimizer_model["EventID"] = event_id
                    if dh.temperature_unit == "F":
                        for field in ["LowerTargetTemperature","UpperTargetTemperature","PredictedTemperature"]:
                            new_optimizer_model[field] = new_optimizer_model[field].apply(converters.c2f)
                    trajectory_optimizer_model = trajectory_optimizer_model.append(new_optimizer_model)

            for float_field in ["LowerTargetTemperature","UpperTargetTemperature","PredictedTemperature"]:
                trajectory_optimizer_model[float_field] = trajectory_optimizer_model[float_field].astype(float)
            for boolean_field in ["Heating","Cooling","HeatingOrCooling"]:
                trajectory_optimizer_model[boolean_field] = trajectory_optimizer_model[boolean_field].astype(bool)

            combined_optimizer_model[trajectory_name] = trajectory_optimizer_model

        dh.add_event_data("DROptimizerBaselineModel", set_unique_index(combined_optimizer_model["baseline"]), native=False)
        dh.add_event_data("DROptimizerOptimalModel", set_unique_index(combined_optimizer_model["optimal"]), native=False)

    # Nonnative events: DRTemperatureDeviationActual and DRTemperatureDeviationVisible containing
    # temperature deviations w.r.t. the baseline model target temperature
    if ('DROptimizerBaselineModel' in dh
        and 'TargetTemperature' in dh.DROptimizerBaselineModel
        and 'EventID' in dh.DROptimizerBaselineModel
        and 'BufferedTemperature' in dh
        and 'temperature' in dh.BufferedTemperature
        and 'TargetTemperature' in dh
        and 'Heating' in dh.TargetTemperature
        and 'Cooling' in dh.TargetTemperature
        and 'DRAlgorithmResults' in dh
        and 'ScheduleMode' in dh.DRAlgorithmResults
        and 'ID' in dh.DRAlgorithmResults):

        actual_temperature = set_unique_index(dh.BufferedTemperature
                                              .set_index(dh.BufferedTemperature.bucketTime)
                                              .sort_index().temperature)
        baseline_model_target_temperature = drop_consecutive_duplicates(pd.Series(dh.DROptimizerBaselineModel
                                                                                  .TargetTemperature,
                                                                                  name="BaselineTargetTemperature"))

        actual_temperature_deviations = []
        visible_temperature_deviations = []

        for event_id in dh.DROptimizerBaselineModel.EventID.unique():

            start_time = dh.DROptimizerBaselineModel.index[dh.DROptimizerBaselineModel.EventID == event_id].min()
            end_time = dh.DROptimizerBaselineModel.index[dh.DROptimizerBaselineModel.EventID == event_id].max()

            schedule_mode = dh.DRAlgorithmResults.ScheduleMode[dh.DRAlgorithmResults.ID == event_id]

            if not schedule_mode.empty:
                schedule_mode = schedule_mode[0]
            else:
                continue

            if schedule_mode == 'HEAT':
                actual_target_temperature = set_unique_index(dh.TargetTemperature.Heating)
            elif schedule_mode == 'COOL':
                actual_target_temperature = set_unique_index(dh.TargetTemperature.Cooling)
            else:
                continue

            actual_temperature_deviation = pd.DataFrame(series_diff([baseline_model_target_temperature,
                                                                     actual_temperature],
                                                                    interpolation_methods=["zero", "time"],
                                                                    start_time=start_time,
                                                                    end_time=end_time,
                                                                    name="TemperatureDeviation"))
            visible_temperature_deviation = pd.DataFrame(series_diff([baseline_model_target_temperature,
                                                                      actual_target_temperature],
                                                                     interpolation_methods=["zero", "zero"],
                                                                     start_time=start_time,
                                                                     end_time=end_time,
                                                                     name="TemperatureDeviation"))

            actual_temperature_deviation['EventID'] = event_id
            actual_temperature_deviations += [actual_temperature_deviation]

            visible_temperature_deviation['EventID'] = event_id
            visible_temperature_deviations += [visible_temperature_deviation]

        if actual_temperature_deviations:
            dh.add_event_data('DRTemperatureDeviationActual',
                              pd.concat(actual_temperature_deviations).sort_index(),
                              native=False)

        if visible_temperature_deviations:
            dh.add_event_data('DRTemperatureDeviationVisible',
                              pd.concat(visible_temperature_deviations).sort_index(),
                              native=False)

    return dh
