from .cpp_enums import parse_cpp_enum_to_dict
from .tvd_utils import remove_raw_values


event_type_enum = parse_cpp_enum_to_dict("""
    enum nlTVDEventType
    {
        kTVDStartEventNumber = 1000,
        kTVDHiddeniteStartEventNumber = 2000,
        kTVDControlStartEventNumber = 3000,

        kTVDEventReboot = kTVDStartEventNumber,
        kTVDEventUploadStart,
        kTVDEventUploadEnd,
        kTVDEventWhat,
        kTVDEventWhere,

        kTVDEventHiddeniteOpen = kTVDHiddeniteStartEventNumber,
        kTVDEventHiddeniteClose,
        kTVDEventHiddeniteOccupancy,
        kTVDEventHiddeniteMotion,
        kTVDEventHiddeniteOccupancyStart,
        kTVDEventHiddeniteOccupancyEnd,
        kTVDEventHiddeniteBadAccelerometer,
        kTVDEventHiddeniteAppMode,
        kTVDEventHiddeniteInstallMode,
        kTVDEventHiddeniteOpenClosedCalibrationModeStarted,
        kTVDEventHiddeniteOpenClosedCalibrationModeFinished,
        kTVDEventHiddenitePathLightOn,
        kTVDEventHiddenitePathLightOff,

        kTVDEventControlAppMode = kTVDControlStartEventNumber,
        kTVDEventControlInstallMode,
        kTVDEventControlOpenClosedCalibrationMode,
        kTVDEventControlPIRTestMode,
        kTVDEventControlOpenDetectorEventOpenVerbose,
        kTVDEventControlOpenDetectorEventClosedVerbose
    };
    """)


open_close_interrupt_status = parse_cpp_enum_to_dict("""
    enum InterruptStatus
    {
        kInterruptStatusInit = 0,
        kInterruptStatusNone,
        kInterruptStatusAccelerometer,
        kInterruptStatusTMR
    };
    """)


inside_outside_detector = parse_cpp_enum_to_dict("""
    enum class nlInsideOutsideState
    {
        kUnknown = 0,
        kInside,
        kOutside
    };
    """)

reset_reason = parse_cpp_enum_to_dict("""
    enum nlResetReason
    {
        kGeneralReset = 0, //First Power-Up Reset
        kBackUpReset = 1, //Return from backup mode
        kWatchdogReset = 2, //Watchdog fault occurred
        kSoftwareReset = 3, //Processor reset required by software
        kUserReset = 4, //NRST pin detected low
    };
    """)
