"""
Generic TVD untility functions should be placed here. For device specific functions, place them in the relevant
utils file for that device.
"""

def remove_raw_values(df):
    return df.drop(['Value0', 'Value1', 'Value2'], 1)

