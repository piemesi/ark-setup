from .cpp_enums import parse_cpp_enum_to_dict

# enums from the Sapphire tree to convert enums back to strings
nlAwayMode = parse_cpp_enum_to_dict("""
    typedef enum
    {
        nlAwayModeHome = 0,
        nlAwayModeManual,
        nlAwayModeAuto,
        nlAwayModeUnknown = -1
    } nlAwayMode;
    """)

nlAutoAwayMode = parse_cpp_enum_to_dict("""
    typedef enum
    {
        nlAutoAwayModeHome = 0,
        nlAutoAwayModeIntraDay,
        nlAutoAwayModeInterDay,
        nlAutoAwayModeExpectedArrival,
        nlAutoAwayModeDisabled = -1
    } nlAutoAwayMode;
    """)

nlHVACControllerPriority = parse_cpp_enum_to_dict("""
    typedef enum
    {
        nlHVACControllerPriorityMin = 0,
        nlHVACControllerPrioritySafety = nlHVACControllerPriorityMin,
        nlHVACControllerPriorityRadiant,
        nlHVACControllerPriorityUCT,
        nlHVACControllerPriorityMaintenance,
        nlHVACControllerPriorityMax
    } nlHVACControllerPriority;
    """)

nlUCTControllerDisableReason = parse_cpp_enum_to_dict("""
    typedef enum
    {
        nlUCTControllerDisableReasonNone = 0,
        nlUCTControllerDisableReasonWeather,
        nlUCTControllerDisableReasonMissingModel,
        nlUCTControllerDisableReasonModelError,
        nlUCTControllerDisableReasonStageStrengths,
        nlUCTControllerDisableReasonRealTime,
        nlUCTControllerDisableReasonManualTouch,
        nlUCTControllerDisableReasonDREvent,
        nlUCTControllerDisableReasonEmergencyMode,
        nlUCTControllerDisableReasonMultistageSystem,
        nlUCTControllerDisableReasonMax,
        nlUCTControllerDisableReasonUnknown = -1
    } nlUCTControllerDisableReason;
    """)

nlAutoAwayRethinkCause = parse_cpp_enum_to_dict("""
    typedef enum
    {
        nlAutoAwayRethinkCauseAnotherDeviceStateChange = 0,
        nlAutoAwayRethinkCauseTimerRanOut,
        nlAutoAwayRethinkCauseWakeOnPir,
        nlAutoAwayRethinkCauseUserChangedTargetTemp,
        nlAutoAwayRethinkCauseAboutToSleep, //Calling to say to auto away, that next time wait for buffers to flush.
        nlAutoAwayRethinkCauseJustWokeUp, //Calling auto away because buffers have just flushed.
        nlAutoAwayRethinkCauseNewScheduledSetPoint,
        nlAutoAwayRethinkCausePreconditioningStarted,
        nlAutoAwayRethinkCauseManualArrival,
        nlAutoAwayRethinkCauseAutoAwayEnabled,
        nlAutoAwayRethinkCauseAutoAwayDisabled,
        nlAutoAwayRethinkCauseTopazAutoArrival
    } nlAutoAwayRethinkCause;
    """)

nlAutoAwayLearningPhase = parse_cpp_enum_to_dict("""
    typedef enum
    {
        nlAutoAwayLearningPhaseTraining = 0,
        nlAutoAwayLearningPhaseReady,
        nlAutoAwayLearningPhaseOff,
        nlAutoAwayLearningPhaseUnknown = -1
    } nlAutoAwayLearningPhase;
    """)

nlAutoDehumState = parse_cpp_enum_to_dict("""
    typedef enum
    {
        nlAutoDehumStateDisabled = 0,
        nlAutoDehumStateLookingForHumidity,
        nlAutoDehumStateDehumidificationWithAC,
        nlAutoDehumStateShortBackoff,
        nlAutoDehumStateLongBackoff
    } nlAutoDehumState;
    """)

nlAutoDehumAwayState = parse_cpp_enum_to_dict("""
    typedef enum
    {
        nlAutoDehumAwayStateHome = 0,
        nlAutoDehumAwayStateAway
    } nlAutoDehumAwayState;
    """)

nlHVACOperationState = parse_cpp_enum_to_dict("""
    typedef enum
    {
        nlHVACOperationStateNone = 0,
        nlHVACOperationStateStage1Heat,
        nlHVACOperationStateStage1Cool,
        nlHVACOperationStateStage2Heat,
        nlHVACOperationStateStage2Cool,
        nlHVACOperationStateStage1HeatAux,
        nlHVACOperationStateStage2HeatAux,
        nlHVACOperationStateAuxOnly,
        nlHVACOperationStateEmergency,
        nlHVACOperationStateStage3Heat,
        nlHVACOperationStateStage1AltHeat,
        nlHVACOperationStateStage2AltHeat,
        nlHVACOperationStateMax,
        nlHVACOperationStateUnknown = -1
    } nlHVACOperationState;
    """)

nlScheduleMode = parse_cpp_enum_to_dict("""
    typedef enum
    {
        nlScheduleModeHeat = 0,
        nlScheduleModeCool,
        nlScheduleModeRange,
        nlScheduleModeMixed,
        nlScheduleModeEmergency,
        nlScheduleModeUnknown = -1
    } nlScheduleMode;
    """)

nlSetPointType = parse_cpp_enum_to_dict("""
    typedef enum
    {
        nlSetPointTypeHeat = 0,
        nlSetPointTypeCool,
        nlSetPointTypeRange,
        nlSetPointTypeAway,     // future
        nlSetPointTypeFan,      // future
        nlSetPointTypeMaxPossibleValue = 7,   // nlHistory currently packs a nlSetPointType into a 4-bit signed value. '7' is currently the largest value which will fit
        nlSetPointTypeUnknown = -1
    } nlSetPointType;
    """)

nlSunlightCorrectionRethinkCause = parse_cpp_enum_to_dict("""
    typedef enum
    {
        nlSunlightCorrectionRethinkCauseTimerRanOut = 0,
        nlSunlightCorrectionRethinkCauseWakeOnAls,
        nlSunlightCorrectionRethinkCauseWakeOnVergence,
        // Calling to say to sunlight correction, that next time wait for buffers to flush.
        nlSunlightCorrectionRethinkCauseAboutToSleep,
        // Calling sunlight correction because buffers have just flushed.
        nlSunlightCorrectionRethinkCauseJustWokeUp,
        nlSunlightCorrectionRethinkCauseSunlightCorrectionEnabled,
        nlSunlightCorrectionRethinkCauseSunlightCorrectionDisabled,
        nlSunlightCorrectionRethinkCauseBackplateReset,
    } nlSunlightCorrectionRethinkCause;
    """)

nlSunlightCorrectionStateTxCause = parse_cpp_enum_to_dict("""
    typedef enum
    {
        nlSunlightCorrectionStateTxCauseNone = 0,
        nlSunlightCorrectionStateTxCauseDisabled,
        nlSunlightCorrectionStateTxCauseEnabled,
        nlSunlightCorrectionStateTxCauseStartLooking,
        nlSunlightCorrectionStateTxCauseStopLooking,
        nlSunlightCorrectionStateTxCauseLowProbability,
        nlSunlightCorrectionStateTxCauseHighProbability,
        nlSunlightCorrectionStateTxCauseAlsHigh,
        nlSunlightCorrectionStateTxCauseAlsLow,
        nlSunlightCorrectionStateTxCauseMaxTimeInState,
        nlSunlightCorrectionStateTxCauseDivergence,
        nlSunlightCorrectionStateTxCauseConvergence,
        nlSunlightCorrectionStateTxCauseMaxTimeSinceAlsSpikeEnd,
        nlSunlightCorrectionStateTxCauseBackplateReset,
        nlSunlightCorrectionStateTxCauseAlsConfirmed,
        nlSunlightCorrectionStateTxCauseUnknown = -1,
    } nlSunlightCorrectionStateTxCause;
    """)

nlSunlightCorrectionState = parse_cpp_enum_to_dict("""
    typedef enum
    {
        nlSunlightCorrectionStateDisabled = 0,
        nlSunlightCorrectionStateNotLooking,
        nlSunlightCorrectionStateLookingForAlsLowProbability,
        nlSunlightCorrectionStateLookingForAlsHighProbability,
        nlSunlightCorrectionStateLookingForTemperature,
        nlSunlightCorrectionStateSunlightCorrection,
        nlSunlightCorrectionStateTimeout,
        nlSunlightCorrectionStateConfirmAlsSpike,
        nlSunlightCorrectionStateUnknown = -1
    } nlSunlightCorrectionState;
    """)

nlTouchedByWho = parse_cpp_enum_to_dict("""
    typedef enum
    {
        nlTouchedByNobody = 0,
        nlTouchedByLearning,
        nlTouchedByLocal,
        nlTouchedByRemote,
        nlTouchedByWeb,
        nlTouchedByAndroid,
        nlTouchedByiOS,
        nlTouchedByWinMobile,
        nlTouchedByTuneUp,
        nlTouchedByDR,
        nlTouchedByToU,
        nlTouchedByTopaz,
        nlTouchedByProgrammer
        /// more after the fact, to future proof
    } nlTouchedByWho;
    """)

nlTouchedWhere = parse_cpp_enum_to_dict("""
    typedef enum
    {
        nlTouchedWhereUnknown = 0,
        nlTouchedWhereSchedule,
        nlTouchedWhereAdHoc
    } nlTouchedWhere;
    """)

nlFanMode = parse_cpp_enum_to_dict("""
    typedef enum
    {
        nlFanModeAutomatic = 0,
        nlFanModeOn,
        nlFanModeDutyCycle
    } nlFanMode;
    """)

nlRethinkStateCause = parse_cpp_enum_to_dict("""
    typedef enum
    {
        nlRethinkStateCauseSimulate = 0,
        nlRethinkStateCauseComfortTimeout,                      // obsolete
        nlRethinkStateCauseScheduleExecution,                   // obsolete
        nlRethinkStateCauseSetTemperature,                      // manual cause
        nlRethinkStateCauseRefreshBeforeSleep,
        nlRethinkStateCauseScheduleModeChanged,                 // manual cause
        nlRethinkStateCauseManualSwitchoverTemperatureChanged,  // obsolete
        nlRethinkStateCauseCompressorLockoutToggle,             // obsolete
        nlRethinkStateCauseSetHumidity,                         // obsolete
        nlRethinkStateCauseHumidifierToggle,                    // obsolete
        nlRethinkStateCauseDehumidifierToggle,                  // 10 obsolete
        nlRethinkStateCauseOBOrientationToggle,                 // obsolete
        nlRethinkStateCauseFanControlWithHeatToggle,            // obsolete
        nlRethinkStateCauseFanModeToggle,                       // obsolete
        nlRethinkStateCauseInstallationTestControlOver,         // obsolete
        nlRethinkStateCauseAwayToggle,
        nlRethinkStateCauseMinimumCycleTimeTimeoutExpired,
        nlRethinkStateCauseCycleCheckTimeoutExpired,            // obsolete
        nlRethinkStateCauseTargetTimeTimeoutExpired,            // obsolete
        nlRethinkStateCausePreconditioningStageChanged,         // obsolete
        nlRethinkStateCauseAwayTemperatureChanged,              // 20
        nlRethinkStateCauseNewTemperatureSample,
        nlRethinkStateCauseBackplateConnectionsChanged,
        nlRethinkStateCauseHVACControlLockedOutChanged,
        nlRethinkStateCauseSafetyTemperatureChanged,
        nlRethinkStateCauseHeatPumpLockoutTemperatureChanged,
        nlRethinkStateCauseAuxiliaryLockoutTemperatureChanged,
        nlRethinkStateCauseTimeShifted,
        nlRethinkStateCauseNewWeather,
        nlRethinkStateCauseInstallationTestTracker,             // obsolete
        nlRethinkStateCauseCompressorToggleTimeoutExpired,      // 30
        nlRethinkStateCauseGotGoodNewScheduleFromPoints,
        nlRethinkStateCauseGotBadNewScheduleFromPoints,
        nlRethinkStateCauseGotGoodNewScheduleFromLearner,
        nlRethinkStateCauseGotBadNewScheduleFromLearner,
        nlRethinkStateCauseUserInteractionTimedOut,
        nlRethinkStateCauseScheduledSetPointChange,
        nlRethinkStateCauseSetInitialInterviewBasedSchedule,
        nlRethinkStateCauseLearningModeChanged,
        nlRethinkStateCauseSetLowerLearningBaseTemperature,     // obsolete
        nlRethinkStateCauseSetUpperLearningBaseTemperature,     // 40 obsolete
        nlRethinkStateCauseScheduleManagerInitialization,
        nlRethinkStateCausePreconditioningEnabledToggle,        // obsolete
        nlRethinkStateCauseSystemModeToggle,
        nlRethinkStateCauseRangeModeToggle,                     // obsolete
        nlRethinkStateCauseSeasonChanged,                       // obsolete
        nlRethinkStateCauseJustWokeUp,
        nlRethinkStateCauseFanCoolingTimeoutExpired,
        nlRethinkStateCauseHVACStateChanged,
        nlRethinkStateCauseTargetHumidityChanged,
        nlRethinkStateCauseHumidifierTypeChanged,               // 50
        nlRethinkStateCauseDehumidifierTypeChanged,
        nlRethinkStateCausePreconditioningStarted,
        nlRethinkStateCausePreconditioningEnded,
        nlRethinkStateCauseFanCoolingEnabledChanged,
        nlRethinkStateCauseHeatPumpUserSettingsChanged,
        nlRethinkStateCauseRadiantControlTimeoutExpired,
        nlRethinkStateCauseDeliveryTypeChanged,
        nlRethinkStateCauseFuelSourceChanged,
        nlRethinkStateCauseDehumidifierFanTypeChanged,
        nlRethinkStateCauseMultistageControlTimeoutExpired,     // 60
        nlRethinkStateCauseHumidifierFanTypeChanged,
        nlRethinkStateCauseDualFuelOverrideChanged,
        nlRethinkStateCauseDualFuelBreakpointChanged,
        nlRethinkStateCauseFanControlChanged,
        nlRethinkStateCauseFanSchedulerTimeoutExpired,
        nlRethinkStateCauseStarTypeChanged,
        nlRethinkStateCauseDuelFuelSelected,
        nlRethinkStateCauseAutoDehumEnabledChanged,
        nlRethinkStateCauseNewDRSetPoint,
        nlRethinkStateCauseDRCruiseControlExited,               // 70
        nlRethinkStateCauseHumidistatTimeoutExpired,
        nlRethinkStateCauseHumidifierLockoutChanged,
        nlRethinkStateCauseUnknown = -1
    } nlRethinkStateCause;
    """)

nlRadiantControlAlgorithmType = parse_cpp_enum_to_dict("""
    typedef enum
    {
        nlRadiantControlAlgorithmTypeBangBang = 0,
        nlRadiantControlAlgorithmTypePredictive,
        nlRadiantControlAlgorithmTypeUnknown = -1,
    } nlRadiantControlAlgorithmType;
    """)

nlHVACStatus = parse_cpp_enum_to_dict("""
    typedef enum
    {
        nlHVACStatusDrifting = 0,
        nlHVACStatusHeating,
        nlHVACStatusCooling,
        nlHVACStatusMax,
        nlHVACStatusUnknown = -1
    } nlHVACStatus;
    """)

nlDayOfWeek = parse_cpp_enum_to_dict("""
    typedef enum
    {
        nlDayOfWeekMon = 0,
        nlDayOfWeekTue,
        nlDayOfWeekWed,
        nlDayOfWeekThu,
        nlDayOfWeekFri,
        nlDayOfWeekSat,
        nlDayOfWeekSun,
        nlDayOfWeekMax,
        nlDayOfWeekUnknown = -1
    } nlDayOfWeek;
    """)

nlLearningMode = parse_cpp_enum_to_dict("""
    typedef enum
    {
        nlLearningModeInitial = 0,
        nlLearningModeSteadyState,
        nlLearningModeSlowState,
        nlLearningModeUnknown = -1
    } nlLearningMode;
    """)

nlFanScheduleState = parse_cpp_enum_to_dict("""
    typedef enum
    {
        nlFanScheduleStateOutsideBounds = 0, // We are not currently in the fan control period
        nlFanScheduleStateDutyCycling,       // We are in the fan control period and the fan is runnning
        nlFanScheduleStateInBounds,          // We are in the fan control period but the fan isn't running
        nlFanScheduleStateTimer,
        nlFanScheduleStateOff,
        nlFanScheduleStateOn
    } nlFanScheduleState;
    """)

nlDRLearnerState = parse_cpp_enum_to_dict("""
    typedef enum
    {
        nlDRLearnerStateInitial = 0,    // has not run
        nlDRLearnerStateBaseline,       // tracking the original schedule
        nlDRLearnerStateOptimal,        // tracking an optimized schedule
        nlDRLearnerStateDefault,        // tracking the CZ-specified default schedule
        nlDRLearnerStateNotAdjusting,   // not adjusting the schedule because thermostat is OFF, AWAY with OFF, or too close to end
        nlDRLearnerStateFailure,        // did not touch the setpoint, expecting to exit CRUISE_CONTROL
        nlDRLearnerStateUct             // UCT is controlling the learner
    } nlDRLearnerState;
    """)
