# -*- coding: utf8 -*-
"""
Util functions for schedule processing.
"""

import calendar
import datetime
import json
import pandas as pd
import numpy as np
import re
import shlex
import string
import time

from datetime import timedelta
from pandas import DataFrame

# Static (private) dictionary containing log line schemas.
_SCHEMAS = {}


def any_schedule_to_schedule_dict(input_schedule):
    """
    A general purpose parser that can process schedules of various types, and return a dict version.

    Input formats accepted:
      json format (i.e. no-op, except maybe to minify it).
      nlclient logs (is in "regular json", may include the time/date stamp, may include other keys, and has
          $merge_payload":false at the end).
      nlevent logs.
      splunkified nlevent logs (keys are added to the raw string).
      recovery files. (almost but not quite nlevent format).
      "directoried" event logs, where spaces are changed to _, etc.
    """
    if input_schedule.lstrip()[0:1] == r'{': 
        # Simple heuristic: if it starts with '{' assume it is valid json.
        schedule_dict = json.loads(input_schedule)
    elif (r',"$merge_payload":false' in input_schedule) and ('"schedule":{' in input_schedule):
        # Looks like an nlclient log line.
        schedule_string = input_schedule.split('{"ver":2', 1)[1].split(',"$merge_payload":false')[0]
        schedule_string = '{"ver":2' + schedule_string + '}'
        schedule_dict = json.loads(schedule_string)
    elif 'czsubscribe: cloud result data: ' in input_schedule:
        schedule_string = input_schedule.split('czsubscribe: cloud result data: ')[1].split(" for 'schedule' bucket")[0]
        schedule_dict = json.loads(schedule_string)
    elif (r',""$merge_payload"":false' in input_schedule) and ('""schedule"":{' in input_schedule):
        # Looks like an nlclient log line, saved in .csv by splunk.
        input_schedule = input_schedule.replace('""', '"')
        schedule_string = input_schedule.split('{"ver":2', 1)[1].split(',"$merge_payload":false')[0]
        schedule_string = '{"ver":2' + schedule_string + '}'
        schedule_dict = json.loads(schedule_string)
    elif 'WeeklySchedule' in input_schedule:
        # Assume is in "raw" event log format (or a splunkified event log line).
        schedule_dict, timestamp = event_log_to_schedule_dict(unsplunkify_schedule(input_schedule.strip()))
    elif ('golden_sch' in input_schedule) and ('] = [[' in input_schedule):
        schedule_string = input_schedule.split('] = [[', 1)[1].rsplit(']]', 1)[0]
        schedule_dict = json.loads(schedule_string)
    elif '_DaySchedule' in input_schedule: 
        # Assume is a version 01 "directoried" event log, where spaces are replaced with _, etc.
        # Make this look like a "normal" event log line.
        schedule_string = input_schedule\
            .replace('_DaySchedule', ' DaySchedule')\
            .replace('_{', ' {')\
            .replace('{_', '{ ')\
            .replace('_}', ' }')\
            .replace(',_', ', ')\
            .replace('DaySchedule:Mon', 'DaySchedule:"Mon')\
            .replace('Cooling_Schedule:"', 'Cooling_Schedule:""')\
            .replace('"', r'\"')
        # Replace the final }\" with just }"
        schedule_string = schedule_string.replace(r'}\"', r'}"')
        schedule_string = '2013-01-01T00:00:00 WeeklySchedule "' + schedule_string
        schedule_dict, timestamp = event_log_to_schedule_dict(schedule_string)
    elif ' DaySchedule' in input_schedule:
        # 130726 These are the "new style" directoried schedules.  Some small tweaking is still needed to it.
        # Slice off the utc timestamp at the start of the line, i.e. '1369163176.0	"Cooling_Schedule'
        schedule_string = input_schedule.split('"', 1)[1]
        schedule_string = schedule_string.replace(r'""', r'"')
        schedule_string = '2013-01-01T00:00:00 WeeklySchedule "' + schedule_string
        (schedule_dict, timestamp) = event_log_to_schedule_dict(schedule_string)
    else:
        raise ValueError('Unrecognized schedule format in:' + input_schedule)
    return schedule_dict


def df_schedule_to_schedule_dict(series_input):
    """
    Takes one row of DataFrame from WeeklySchedule as input.  For example if you have Diamond History object dh, this
    takes in dh.WeeklySchedule.ix[n] as the input parameter, e.g df_schedule_to_json(dh.WeeklySchedule.ix[0])
    The input object is actually a named Pandas series object.  Returns a dict-format schedule.
    author: Sourav Dey
    """
    sch_str = str(series_input.name) + '\"' + series_input['Data'] + '\"'
    return any_schedule_to_schedule_dict(sch_str)


def schedule_dict_to_schedule_df(schedule_dict):
    """
    Converts nested dict version of schedule to DataFrame containing time_of_week column.
    """
    days = []
    data_frames = []

    for day, data in schedule_dict['days'].iteritems():
        days.append(int(day))
        new_data_frame = pd.DataFrame.from_dict(data, orient='index')
        new_data_frame.index = new_data_frame.index.astype('int')
        data_frames.append(new_data_frame)

    result = pd.concat(data_frames, keys=days)

    time_of_week = result.index.get_level_values(0).values * 24 * 3600 + result.time.values

    result['time_of_week'] = time_of_week

    schedule_df = result.sort('time_of_week')

    return schedule_df


def get_temperature_column(schedule_df, set_point_type="COOL"):
    """
    Returns the temperature column from the schedule data frame.
    """
    if 'temp' in schedule_df:
        return schedule_df['temp']
    else:
        if set_point_type == "COOL":
            return schedule_df['temp-max']
        elif set_point_type == "HEAT":
            return schedule_df['temp-min']


def mean_schedule_temp(schedule_df, set_point_type="COOL"):
    """
    Returns the time weighted mean temperature of a schedule data frame.
    """
    temp = get_temperature_column(schedule_df, set_point_type=set_point_type)

    time_of_week = schedule_df.time_of_week
    time_of_week = np.append(time_of_week, 7*24*3600)

    return np.average(temp, weights=np.diff(time_of_week))


def min_schedule_temp(schedule_df, set_point_type="COOL"):
    """
    Returns the min temperature of a schedule data frame.
    """
    temp = get_temperature_column(schedule_df, set_point_type=set_point_type)

    return temp.min()


def max_schedule_temp(schedule_df, set_point_type="COOL"):
    """
    Returns the max temperature of a schedule data frame.
    """
    temp = get_temperature_column(schedule_df, set_point_type=set_point_type)

    return temp.max()


def delta_min_max_schedule_temp(schedule_df, set_point_type="COOL"):
    """
    Returns the delta min max temperature of a schedule data frame.
    """
    return (max_schedule_temp(schedule_df, set_point_type=set_point_type) -
            min_schedule_temp(schedule_df, set_point_type=set_point_type))


def schedule_df_per_day(schedule_df, days=range(0, 7), set_point_type="COOL"):
    """
    Converts a schedule data frame to a data frame that has columns for each day of the week.
    """
    new_schedule_df = schedule_df.reset_index()

    day_schedules = []

    for day in days:
        day_schedule = new_schedule_df[new_schedule_df.level_0 == day]
        day_schedules += [get_temperature_column(day_schedule.set_index(day_schedule.time),
                                                 set_point_type=set_point_type)]

    day_schedules_df = pd.concat(day_schedules, axis=1)
    day_schedules_df.loc[24*3600] = np.nan
    day_schedules_df = day_schedules_df.fillna(method="pad")
    day_schedules_df.columns = days

    return day_schedules_df


def df_schedule_to_samples(series_input):
    """
    Convert one row of DataFrame into a DataFrame of 5-min sampled schedule temperatures.  The output DataFrame is
    indexed by timestamps for the week that this schedule was extracted (the date comes from the name of the Series).
    There are only two columns for now, one for max temp and one for min temp.
    """
    # Parse into a flattened JSON.
    sch_dict = df_schedule_to_schedule_dict(series_input)
    flat_json = flatten_schedule(sch_dict)

    # We want to index with a timestamp for this week.
    # This code creates the index (which is essentially a UNIX epoch timestamp offset)
    week_start_date = series_input.name.date() - timedelta(days=series_input.name.date().weekday())
    week_start_datetime = datetime.datetime(week_start_date.year, week_start_date.month, week_start_date.day)
    epoch_offset = (week_start_datetime - datetime.datetime(1970, 1, 1)).total_seconds()

    # Loop through setpoints and make a dictionary with epoch timestamp as key.
    sch_df_dict = {}
    for setpoint in flat_json:
        sch_df_dict[setpoint['secInWeek'] + epoch_offset] = {
            'max_temp': setpoint['temp-max'], 'min_temp': setpoint['temp-min']}

    # Convert the dictionary into a DataFrame an resample to 5-mins.
    df = DataFrame(sch_df_dict).transpose()
    df.index = pd.to_datetime(df.index, unit='s')
    # Note that this dataframe only goes up until last setpoint, not to end of week.
    df = df.resample('5Min', fill_method='ffill')

    # Make DataFrame for entire week (beyond that last setpoint)
    time_index = pd.date_range(week_start_datetime, periods=7*288, freq='5min')
    week_df = DataFrame(index=time_index)
    week_df['max_temp'] = df.max_temp
    week_df['min_temp'] = df.min_temp

    # Fill the last setpoint ahead to midnight sunday
    week_df = week_df.fillna(method='ffill')

    return week_df


def event_log_to_schedule_dict(schedule_event_log_line):
    """
    Convert from the event log fields to the standard json fields
      (see https://wiki.nestlabs.com/display/NEST/Schedule+Schema+for+Version+1.0+to+2.0)
    The possible fields for the event log are shown in function from the sapphire source code:
        char * nlSetPoint :: AppendToBuffer(char *aBuf) const
    Note: Might need FanOn in the future?

    Example event log fields:
    {'Day': '5',
        'Default': '1',
        'Temp': '1078865',
        'TempMax': '2097152',
        'Time': '0',
        'Total': '9',
        'TouchedAt': '1327323600',
        'TouchedBy': '1',
        'TouchedTZO': '-28800',
        'Type': '0'},
    """
    sch_schema = '''2012-01-04T13:00:00 %WeeklySchedule { "fields": [{"name":"Data","type":"string"}]}'''

    # Load up the schema.  This is used when parsing a schedule later on.
    _parse_event_line(sch_schema)
    parsed_schedule_event_log_line = _parse_event_line(schedule_event_log_line)
    event_log_sch_array = _parse_weekly_schedule(parsed_schedule_event_log_line['data']['Data'])
    sched_epoch_time = parsed_schedule_event_log_line['date']

    # Now convert to a dict, rename keys as needed, and convert to float/int as needed.
    setpt_type_lookup = {'0': 'HEAT', '1': 'COOL', '2': 'RANGE'}
    setpt_entry_type_lookup = {'0': 'setpoint', '1': 'continuation'}

    schedule_dict = {'name': event_log_sch_array['scheduleName'],
                     'schedule_mode': setpt_type_lookup[event_log_sch_array['schedule'][0][0]['Type']],
                     'ver': 2}

    # TODO: Probably need to update this if we allow completely blank schedules (no setpoints in a particular day).
    newsched = {}
    for dayNum, day in enumerate(event_log_sch_array['schedule']):
        newsched[str(dayNum)] = {}
        for setptNum, setpoint in enumerate(day):
            sp = {'type': setpt_type_lookup[setpoint['Type']],
                  'time': int(setpoint['Time'])}

            # Variable keys (which are different for range mode)
            if setpoint['Type'] in ['0', '1']:  # Heat and Cool
                sp['temp'] = float(setpoint['Temp']) / 65536  # Convert from fixed point (16.16) to floating point C.
            elif setpoint['Type'] == '2':  # Range
                sp['temp-min'] = float(setpoint['Temp']) / 65536
                sp['temp-max'] = float(setpoint['TempMax']) / 65536

            # Optional keys (default and touched* fields)
            if 'Default' in setpoint:
                sp['entry_type'] = setpt_entry_type_lookup[setpoint['Default']]

            if 'TouchedBy' in setpoint:
                sp['touched_by'] = int(setpoint['TouchedBy'])
            if 'TouchedAt' in setpoint:
                sp['touched_at'] = int(setpoint['TouchedAt'])
            if 'TouchedTZO' in setpoint:
                sp['touched_tzo'] = int(setpoint['TouchedTZO'])
            if 'TouchedSource' in setpoint:
                sp['touched_source'] = setpoint['TouchedSource']
            if 'TouchedID' in setpoint:
                sp['touched_id'] = setpoint['TouchedID']

            newsched[str(dayNum)][str(setptNum)] = sp
    schedule_dict['days'] = newsched
    return schedule_dict, sched_epoch_time


def flatten_schedule(schedule_dict, skip_continuation=False):
    """  Ported from flatten_schedule in common_lib.lua
    Create a "flat" list of setpoints, with a numerical index (not a string index, for easier sorting).
    This adds a
    indexInDay
    dayOfWeek
    secInWeek
    field to each setpoint, and renames "time" to "secInDay" (to keep track of the day information).
    Returns 0 on failure (if it found unexpected elements in the schedule).  Returns table of setpoints on success.

    TODO: Perhaps make this into a ring buffer, to move special code needed for the end of week wrap-around into this library?
    """
    if len(schedule_dict) == 0:
        return []
    set_pt_list = []
    for day_key in sorted(schedule_dict['days'].keys()):
        # Sort the setpoint index numerically, not alphanum (so '10' is after '9').
        for set_pt_key in sorted(schedule_dict['days'][day_key].keys(), key=lambda int_str: int(int_str)):
            sp = schedule_dict['days'][day_key][set_pt_key].copy()

            sp["indexInDay"] = int(set_pt_key)
            sp["dayOfWeek"] = int(day_key)
            sp["secInWeek"] = sp["dayOfWeek"] * 86400 + sp["time"]
            sp["secInDay"] = sp["time"]
            del(sp["time"])

            # Standardize on the keys, don't want to process range/heat/cool separately.
            # 130910  From a discussion with M3, Todd:
            #   For a heating schedule:
            #      assign the temperatures to temp-min (temp_heat).  temp-max = None (which converts to a json 'null')
            #   For a cooling schedule:
            #      assign the temperatures to temp-max (temp_cool).  temp-min = None (which converts to a json 'null')
            # A python None converts to a json null bidirectionally (if we export to other tools in the future).
            # A numpy NaN does output as a 'NaN' in json.dumps, but this is "non-standard" json.
            #   (see http://stackoverflow.com/questions/6601812/sending-nan-in-json)
            if sp['type'] == 'HEAT':
                sp["temp-min"] = sp['temp']
                sp["temp-max"] = None
                del(sp["temp"])
            elif sp['type'] == 'COOL':
                sp["temp-min"] = None
                sp["temp-max"] = sp['temp']
                del(sp["temp"])
            elif sp['type'] == 'RANGE':
                pass
            else:
                raise ValueError('type field does not contain one of HEAT/COOL/RANGE ')

            if skip_continuation and (sp['entry_type'] == 'continuation'):
                pass
            else:
                set_pt_list.append(sp)
    return set_pt_list


def unsplunkify_schedule(schedule_from_splunk):
    """
    Make a function to convert a "WeeklySchedule" event log line from the "splunk modified" back to the "raw" format.
    This is hopefully smart enough to detect if the string came from splunk or not, and pass it out unmodified if not.

    #Example log from splunk (the _raw field).
    #schedule_from_splunk = r'''[2013-02-15 06:41:06,000] serialNumber="02AA01AB48120FDC",macAddress="18b430030f3f",timestamp="2013-02-15T06:41:06.000Z",schema_name="WeeklySchedule",type="WeeklySchedule",deviceId="18b430030f3f",Data="TuneUpPostRun_Schedule:\"\" { DaySchedule:\"Mon\" { Total:3, SetPoint:\"\" { Total:9, Day:0, Time:0, Type:0, Temp:1019478, TempMax:2097152, Default:1, TouchedBy:1, TouchedAt:1360890686, TouchedTZO:-21600 }, SetPoint:\"\" { Total:8, Day:0, Time:60300, Type:0, Temp:1200422, TempMax:2097152, TouchedBy:1, TouchedAt:1359010352, TouchedTZO:-21600 }, SetPoint:\"\" { Total:9, Day:0, Time:72000, Type:0, Temp:1014431, TempMax:2097152, TouchedBy:8, TouchedAt:1360651266, TouchedTZO:-21600, TouchedSource:\"TuneUp\" } }, DaySchedule:\"Tue\" { Total:3, SetPoint:\"\" { Total:9, Day:1, Time:0, Type:0, Temp:1014431, TempMax:2097152, Default:1, TouchedBy:1, TouchedAt:1360890686, TouchedTZO:-21600 }, SetPoint:\"\" { Total:8, Day:1, Time:60300, Type:0, Temp:1122369, TempMax:2097152, TouchedBy:4, TouchedAt:1358959254, TouchedTZO:-21600 }, SetPoint:\"\" { Total:9, Day:1, Time:72000, Type:0, Temp:1014431, TempMax:2097152, TouchedBy:8, TouchedAt:1360651266, TouchedTZO:-21600, TouchedSource:\"TuneUp\" } }, DaySchedule:\"Wed\" { Total:3, SetPoint:\"\" { Total:9, Day:2, Time:0, Type:0, Temp:1014431, TempMax:2097152, Default:1, TouchedBy:1, TouchedAt:1360890686, TouchedTZO:-21600 }, SetPoint:\"\" { Total:8, Day:2, Time:60300, Type:0, Temp:1200422, TempMax:2097152, TouchedBy:1, TouchedAt:1359010352, TouchedTZO:-21600 }, SetPoint:\"\" { Total:9, Day:2, Time:72000, Type:0, Temp:1014431, TempMax:2097152, TouchedBy:8, TouchedAt:1360651266, TouchedTZO:-21600, TouchedSource:\"TuneUp\" } }, DaySchedule:\"Thu\" { Total:3, SetPoint:\"\" { Total:9, Day:3, Time:0, Type:0, Temp:1014431, TempMax:2097152, Default:1, TouchedBy:1, TouchedAt:1360890686, TouchedTZO:-21600 }, SetPoint:\"\" { Total:8, Day:3, Time:60300, Type:0, Temp:1200422, TempMax:2097152, TouchedBy:1, TouchedAt:1359010352, TouchedTZO:-21600 }, SetPoint:\"\" { Total:9, Day:3, Time:72000, Type:0, Temp:1014431, TempMax:2097152, TouchedBy:8, TouchedAt:1360651266, TouchedTZO:-21600, TouchedSource:\"TuneUp\" } }, DaySchedule:\"Fri\" { Total:3, SetPoint:\"\" { Total:9, Day:4, Time:0, Type:0, Temp:1014431, TempMax:2097152, Default:1, TouchedBy:1, TouchedAt:1360890686, TouchedTZO:-21600 }, SetPoint:\"\" { Total:8, Day:4, Time:60300, Type:0, Temp:1200422, TempMax:2097152, TouchedBy:1, TouchedAt:1359010352, TouchedTZO:-21600 }, SetPoint:\"\" { Total:9, Day:4, Time:72000, Type:0, Temp:1014431, TempMax:2097152, TouchedBy:8, TouchedAt:1360651266, TouchedTZO:-21600, TouchedSource:\"TuneUp\" } }, DaySchedule:\"Sat\" { Total:2, SetPoint:\"\" { Total:9, Day:5, Time:0, Type:0, Temp:1014431, TempMax:2097152, Default:1, TouchedBy:1, TouchedAt:1360890686, TouchedTZO:-21600 }, SetPoint:\"\" { Total:8, Day:5, Time:72000, Type:0, Temp:1019478, TempMax:2097152, TouchedBy:4, TouchedAt:1358784777, TouchedTZO:-21600 } }, DaySchedule:\"Sun\" { Total:2, SetPoint:\"\" { Total:9, Day:6, Time:0, Type:0, Temp:1019478, TempMax:2097152, Default:1, TouchedBy:1, TouchedAt:1360890686, TouchedTZO:-21600 }, SetPoint:\"\" { Total:8, Day:6, Time:72000, Type:0, Temp:1019478, TempMax:2097152, TouchedBy:4, TouchedAt:1358784778, TouchedTZO:-21600 } } }"'''

    #Example of a event log weekly schedule (not the same one, just for formatting info).
    #schedule_event_log_line  = '''2012-01-25T13:00:00 WeeklySchedule "TuneUpPostRun_Schedule:\"\" { DaySchedule:\"Mon\" { Total:4, SetPoint:\"\" { Total:9, Day:0, Time:0, Type:0, Temp:1151683, TempMax:2097152, Default:1, TouchedBy:1, TouchedAt:1327323600, TouchedTZO:-28800 }, SetPoint:\"\" { Total:9, Day:0, Time:21600, Type:0, Temp:1221149, TempMax:2097152, TouchedBy:1, TouchedAt:1327323600, TouchedTZO:-28800, TouchedSource:\"Learning\" }, SetPoint:\"\" { Total:9, Day:0, Time:28800, Type:0, Temp:1306804, TempMax:2097152, TouchedBy:1, TouchedAt:1327323600, TouchedTZO:-28800, TouchedSource:\"Learning\" }, SetPoint:\"\" { Total:9, Day:0, Time:75600, Type:0, Temp:1078865, TempMax:2097152, TouchedBy:1, TouchedAt:1327323600, TouchedTZO:-28800, TouchedSource:\"Learning\" } }, DaySchedule:\"Tue\" { Total:4, SetPoint:\"\" { Total:9, Day:1, Time:0, Type:0, Temp:1078865, TempMax:2097152, Default:1, TouchedBy:1, TouchedAt:1327323600, TouchedTZO:-28800 }, SetPoint:\"\" { Total:9, Day:1, Time:21600, Type:0, Temp:1148307, TempMax:2097152, TouchedBy:1, TouchedAt:1327323600, TouchedTZO:-28800, TouchedSource:\"Learning\" }, SetPoint:\"\" { Total:9, Day:1, Time:27900, Type:0, Temp:1344160, TempMax:2097152, TouchedBy:1, TouchedAt:1327323600, TouchedTZO:-28800, TouchedSource:\"Learning\" }, SetPoint:\"\" { Total:9, Day:1, Time:75600, Type:0, Temp:1078865, TempMax:2097152, TouchedBy:1, TouchedAt:1327323600, TouchedTZO:-28800, TouchedSource:\"Learning\" } }, DaySchedule:\"Wed\" { Total:4, SetPoint:\"\" { Total:9, Day:2, Time:0, Type:0, Temp:1078865, TempMax:2097152, Default:1, TouchedBy:1, TouchedAt:1327323600, TouchedTZO:-28800 }, SetPoint:\"\" { Total:9, Day:2, Time:21600, Type:0, Temp:1148307, TempMax:2097152, TouchedBy:1, TouchedAt:1327323600, TouchedTZO:-28800, TouchedSource:\"Learning\" }, SetPoint:\"\" { Total:9, Day:2, Time:28800, Type:0, Temp:1306804, TempMax:2097152, TouchedBy:1, TouchedAt:1327323600, TouchedTZO:-28800, TouchedSource:\"Learning\" }, SetPoint:\"\" { Total:9, Day:2, Time:75600, Type:0, Temp:1078865, TempMax:2097152, TouchedBy:1, TouchedAt:1327323600, TouchedTZO:-28800, TouchedSource:\"Learning\" } }, DaySchedule:\"Thu\" { Total:4, SetPoint:\"\" { Total:9, Day:3, Time:0, Type:0, Temp:1078865, TempMax:2097152, Default:1, TouchedBy:1, TouchedAt:1327323600, TouchedTZO:-28800 }, SetPoint:\"\" { Total:9, Day:3, Time:21600, Type:0, Temp:1148307, TempMax:2097152, TouchedBy:1, TouchedAt:1327323600, TouchedTZO:-28800, TouchedSource:\"Learning\" }, SetPoint:\"\" { Total:9, Day:3, Time:28800, Type:0, Temp:1306804, TempMax:2097152, TouchedBy:1, TouchedAt:1327323600, TouchedTZO:-28800, TouchedSource:\"Learning\" }, SetPoint:\"\" { Total:9, Day:3, Time:75600, Type:0, Temp:1078865, TempMax:2097152, TouchedBy:1, TouchedAt:1327323600, TouchedTZO:-28800, TouchedSource:\"Learning\" } }, DaySchedule:\"Fri\" { Total:4, SetPoint:\"\" { Total:9, Day:4, Time:0, Type:0, Temp:1078865, TempMax:2097152, Default:1, TouchedBy:1, TouchedAt:1327323600, TouchedTZO:-28800 }, SetPoint:\"\" { Total:9, Day:4, Time:21600, Type:0, Temp:1148307, TempMax:2097152, TouchedBy:1, TouchedAt:1327323600, TouchedTZO:-28800, TouchedSource:\"Learning\" }, SetPoint:\"\" { Total:9, Day:4, Time:28800, Type:0, Temp:1306804, TempMax:2097152, TouchedBy:1, TouchedAt:1327323600, TouchedTZO:-28800, TouchedSource:\"Learning\" }, SetPoint:\"\" { Total:9, Day:4, Time:75600, Type:0, Temp:1078865, TempMax:2097152, TouchedBy:1, TouchedAt:1327323600, TouchedTZO:-28800, TouchedSource:\"Learning\" } }, DaySchedule:\"Sat\" { Total:5, SetPoint:\"\" { Total:9, Day:5, Time:0, Type:0, Temp:1078865, TempMax:2097152, Default:1, TouchedBy:1, TouchedAt:1327323600, TouchedTZO:-28800 }, SetPoint:\"\" { Total:9, Day:5, Time:22500, Type:0, Temp:1151683, TempMax:2097152, TouchedBy:1, TouchedAt:1327323600, TouchedTZO:-28800, TouchedSource:\"Learning\" }, SetPoint:\"\" { Total:9, Day:5, Time:26100, Type:0, Temp:1350058, TempMax:2097152, TouchedBy:1, TouchedAt:1327323600, TouchedTZO:-28800, TouchedSource:\"Learning\" }, SetPoint:\"\" { Total:9, Day:5, Time:70200, Type:0, Temp:1256014, TempMax:2097152, TouchedBy:1, TouchedAt:1327323600, TouchedTZO:-28800, TouchedSource:\"Learning\" }, SetPoint:\"\" { Total:9, Day:5, Time:82800, Type:0, Temp:1151683, TempMax:2097152, TouchedBy:1, TouchedAt:1327323600, TouchedTZO:-28800, TouchedSource:\"Learning\" } }, DaySchedule:\"Sun\" { Total:5, SetPoint:\"\" { Total:9, Day:6, Time:0, Type:0, Temp:1151683, TempMax:2097152, Default:1, TouchedBy:1, TouchedAt:1327323600, TouchedTZO:-28800 }, SetPoint:\"\" { Total:9, Day:6, Time:22500, Type:0, Temp:1151683, TempMax:2097152, TouchedBy:1, TouchedAt:1327323600, TouchedTZO:-28800, TouchedSource:\"Learning\" }, SetPoint:\"\" { Total:9, Day:6, Time:26100, Type:0, Temp:1350058, TempMax:2097152, TouchedBy:1, TouchedAt:1327323600, TouchedTZO:-28800, TouchedSource:\"Learning\" }, SetPoint:\"\" { Total:9, Day:6, Time:70200, Type:0, Temp:1256014, TempMax:2097152, TouchedBy:1, TouchedAt:1327323600, TouchedTZO:-28800, TouchedSource:\"Learning\" }, SetPoint:\"\" { Total:9, Day:6, Time:82800, Type:0, Temp:1151683, TempMax:2097152, TouchedBy:1, TouchedAt:1327323600, TouchedTZO:-28800, TouchedSource:\"Learning\" } } }"'''
    """
    if schedule_from_splunk[0] == "[":
        # Extract timestamp field.  Remove millisec.
        date = schedule_from_splunk.split('timestamp="')[1].split('.')[0]
        schema_name = schedule_from_splunk.split('schema_name="')[1].split('"')[0]
        # Assumes the data field is the LAST element in the splunk raw string.
        data = schedule_from_splunk.split('Data=')[1]
        # Note: don't remove the double quotes around the Data section!
        event_log_line = date + ' ' + schema_name + ' ' + data
        return event_log_line
    else:
        return schedule_from_splunk


def _record_schema(schema_name, schema_def):
    _SCHEMAS[schema_name] = json.loads(schema_def)['fields']


def _parse_event_based_on_schema(schema_name, raw_event_data):
    if schema_name not in _SCHEMAS:
        return None

    schema_def = _SCHEMAS[schema_name]
    raw_event_data = shlex.split(raw_event_data)
    data = {}
    for i in range(0, len(raw_event_data)):
        key = schema_def[i]['name']
        typ = schema_def[i]['type']
        val = raw_event_data[i]
        if typ == 'integer':
            val = long(val)
        elif typ == 'decimal':
            val = float(val)
        elif typ == 'boolean':
            val = {'true': True, 'false': False}[val]
        elif typ == 'timestamp':
            val = calendar.timegm(time.strptime(val, '%Y-%m-%dT%H:%M:%S'))
        data[key] = val
    return data


def _parse_event_line(line):
    m = re.match('(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}) (\w*) (.*)', line)
    if m:
        date = calendar.timegm(time.strptime(m.group(1), '%Y-%m-%dT%H:%M:%S'))
        schema_name = m.group(2)
        raw_event_data = m.group(3)
        data = _parse_event_based_on_schema(schema_name, raw_event_data)
        return {'date': date, 'schema_name': schema_name, 'data': data}
    m = re.match('\d\d\d\d-\d\d-\d\dT\d\d:\d\d:\d\d %(\w*) ({.*})', line)
    if m:
        _record_schema(m.group(1), m.group(2))


def _parse_weekly_schedule(data):
    data = shlex.split(data)
    schedule_name = data[0]
    schedule = [[], [], [], [], [], [], []]
    depth = 0
    day = 0
    for token in data[1:]:
        token = string.replace(token, ',', '')
        if token == '{':
            depth += 1
            setpoint = {}
            continue
        elif token == '}':
            if depth == 3:
                schedule[day].append(setpoint)
            depth -= 1
            continue
        m = re.match('(.*):(.*)', token)
        if m and depth == 3:
            key = m.group(1)
            val = m.group(2)
            setpoint[key] = val
            if key == 'Day':
                day = int(val)
    return {'scheduleName': schedule_name, 'schedule': schedule}
