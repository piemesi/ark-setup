"""
This module provides a Python interface to parse Lithium files.

Author: Jeff Herman

"""
# pylint: disable=no-member
import datetime
import logging
import os
import struct
import time

import dateutil.tz
import pandas
import pytz

from .. import scriptutils

logger = logging.getLogger(__name__)


SAMPLE_INTERVAL_US              = 10
US_PER_SECOND                   = 1000
NUM_INTEGRATIONS_PER_CHUNK      = 1000

INTEGRATION_INTERVAL            = float(SAMPLE_INTERVAL_US) / float(US_PER_SECOND)
INTEGRATIONS_PER_SECOND         = int(US_PER_SECOND / SAMPLE_INTERVAL_US)

MILLIAMPS_PER_AMP               = 1000

K_LO_M                          = 6.27737942878e-11 * 2
K_HI_M                          = 2.24111194698e-08 * 2

DARK_CURRENT                    = 3.446280803707675e-06

tzutc   = dateutil.tz.tzutc()
tzlocal = dateutil.tz.tzlocal()

def epoch_to_datetime(epoch):
    return datetime.datetime.fromtimestamp(float(epoch), tz=tzlocal).astimezone(tzlocal)

def epoch_to_date_string(epoch):
    t = time.gmtime(epoch)
    return '%04d/%02d/%02d' % (t.tm_year, t.tm_mon, t.tm_mday)

def parse_file(filename, timestamp=None):
    """
    Parses current measuring data from Lithium

    :param filename:
        Name of the log file to parse
    :param timestamp:
        upload time of the file
    """
    times = []
    amperages = []
    output = {}

    # Open the provided file and load its data into a byte array
    data = open(filename, 'rb').read()

    # Lithium stores a new 'integration' every 10ms and stores the epoch end time in the last
    # 4 bytes of each file so this interpoolates between the start and end times.
    samples     = data[0:-4]
    num_samples = len(samples) / 8
    num_seconds = num_samples / INTEGRATIONS_PER_SECOND
    end_time    = struct.unpack('<L', data[-4:])[0]
    start_time  = end_time - num_seconds

    for i in xrange(num_samples):
        base_ptr = i * 8
        accum_lo = struct.unpack('<L', samples[base_ptr + 0:base_ptr + 4])[0]
        accum_hi = struct.unpack('<L', samples[base_ptr + 4:base_ptr + 8])[0]
        amperages.append((K_LO_M * accum_lo + K_HI_M * accum_hi - DARK_CURRENT) * MILLIAMPS_PER_AMP)
        times.append(epoch_to_datetime(start_time + i * INTEGRATION_INTERVAL))

    data = {}
    data['current'] = pandas.Series(amperages, index=times)
    data_frame = pandas.DataFrame(data)
    output['current'] = data_frame

    file_metadata = {}
    file_metadata['size'] = os.path.getsize(filename)
    file_metadata['parser'] = 'Python'
    file_metadata['description'] = 'lithiumlog'
    file_metadata['latest_rtc_time'] = end_time

    return (output, file_metadata)

def extract_upload_time_from_filename(filename):
    """
    Extract the upload time from the S3 filename, for example:
        topazevent_18b43000001e84ee-2013-07-17T04-53-14.149Z-v1-id32e689.log

    :param filename:
      Name of the Topaz logfile S3
    """
    try:
        f = os.path.split(filename)[1]
        d = datetime.datetime.strptime(f[f.find('-')+1:f.find('Z')], "%Y-%m-%dT%H-%M-%S.%f").replace(tzinfo = pytz.utc)
    except ValueError:
        logger.warn('Could not extract upload time from filename: %s', filename)
        d = None
    return d

def append_to_dataframe_dict(current, new):
    """
    Adds new data to an existing dataframe dict. May be new data for existing
    fields or an entirely new field.

    :param current:
        existing dict of dataframes
    :param new:
        new dict of dataframes

    :rtype:
        dict of Pandas dataframes
    """
    appended = {}
    for key in list(set([key for key in current] + [key for key in new])):
        if (key in current) and (key in new):
            appended[key] = current[key].append(new[key])
        elif key in current:
            appended[key] = current[key]
        elif key in new:
            appended[key] = new[key]
    return appended

def parse_filepath(filepath):
    filename = os.path.basename(filepath)
    filetime = extract_upload_time_from_filename(filename)
    source_file_metadata = {}
    success = False
    output = None
    try:
        (output, parser_metadata) = parse_file(filepath, filetime)
        source_file_metadata.update(parser_metadata)
        success = True
    except:
        logger.exception('Error parsing file %s' % (filename))

    source_file_metadata.update({
        'parsed' : success,
        'filetime' : str(filetime),
        'parsed_at' : str(datetime.datetime.now())
    })
    return filename, source_file_metadata, output

def parse_lithium_files(filepaths, threads=1):
    """
    Parses a list of Lithium logfiles into a dict of Pandas dataframes.

    :param filenames:
        list of paths of Lithium logfiles

    :rtype:
        dict of Pandas dataframes
    """
    output = None
    source_files_metadata = {}

    if threads > 1:
        results = scriptutils.parallelize(parameter_list=filepaths, threads=threads, function_to_run=parse_filepath)
        for (_query_parameters, (filename, source_file_metadata, new_output)) in results:
            if new_output is not None:
                if output is None:
                    output = new_output
                else:
                    output = append_to_dataframe_dict(output, new_output)

            source_files_metadata[filename] = source_file_metadata
    else:
        for filepath in filepaths:
            (filename, source_file_metadata, new_output) = parse_filepath(filepath)
            if new_output is not None:
                if output is None:
                    output = new_output
                else:
                    output = append_to_dataframe_dict(output, new_output)

            source_files_metadata[filename] = source_file_metadata
    return (output, source_files_metadata)
