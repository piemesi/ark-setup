"""
This module reads in TLV - TVD data according to the spec at:
    https://docs.google.com/a/nestlabs.com/document/d/1IXJszV8ikWFQ_XyCszydt00KKQ1PM-Mgj0X7TbW9XdE

In nestpy, this is used as a fallback parser when the Service's Scala-based
parser fails. This parser is less strict and may be more on the bleeding-edge as
the log format evolves.

Author: Michael Dixon
"""
import binascii
import collections
import datetime
import gzip
import logging
from multiprocessing import Lock
import os
import struct
import sys

from ..aws.s3_data_downloader import S3Downloader
from .. import fileutils

logger = logging.getLogger(__name__)


S3_PREFIX = 's3://tvd.nestlabs.com'
TVD_BUCKET = 'tvd.nestlabs.com'

class DownloadException(Exception):
    pass

def bytes2int(raw_bytes, signed=False):
    """
    Convert a string of bytes to an integer (assumes little-endian byte order)
    """
    if len(raw_bytes) == 0:
        return None
    fmt = {1:'B', 2:'H', 4:'I', 8:'Q'}[len(raw_bytes)]
    if signed:
        fmt = fmt.lower()
    return struct.unpack('<'+fmt, raw_bytes)[0]

class TLVReader(object):
    # The TLV tag-control values (contained in the most significant 3 bits of the control byte)
    # (name, tag-size)
    tag_control_lookup = [
        ('Anonymous', 0),
        ('Context-specific', 1),
        ('Core Profile', 2),
        ('Core Profile', 4),
        ('Implicit Profile', 2),
        ('Implicit Profile', 4),
        ('Fully-qualified', 6),
        ('Fully-qualified', 8)
    ]

    # The TLV element-type values (contained in the least-significant 5 bits of the control byte)
    # (name, length-size, value-size)
    element_type_lookup = [
        ('Signed Integer', 0, 1),
        ('Signed Integer', 0, 2),
        ('Signed Integer', 0, 4),
        ('Signed Integer', 0, 8),
        ('Unsigned Integer', 0, 1),
        ('Unsigned Integer', 0, 2),
        ('Unsigned Integer', 0, 4),
        ('Unsigned Integer', 0, 8),
        ('Boolean False', 0, 0),
        ('Boolean True', 0, 0),
        ('Floating Point Number', 0, 4),
        ('Floating Point Number', 0, 8),
        ('UTF-8 String', 1, 0),
        ('UTF-8 String', 2, 0),
        ('UTF-8 String', 4, 0),
        ('UTF-8 String', 8, 0),
        ('Byte String', 1, 0),
        ('Byte String', 2, 0),
        ('Byte String', 4, 0),
        ('Byte String', 8, 0),
        ('Null', 0, 0),
        ('Structure', 0, 0),
        ('Array', 0, 0),
        ('Path', 0, 0),
        ('End of Container', 0, 0)
    ]

    class EndOfContainer(object):
        """ A special class to represent the end-of-container element """
        def __init__(self):
            pass

    def lookup_tag_control(self, control_byte):
        """
        Decode the tag-control potion of the control byte
        """
        return self.tag_control_lookup[(control_byte & 0b11100000) >> 5]

    def lookup_element_type(self, control_byte):
        """
        Decode the element-type portion of the control byte
        """
        return self.element_type_lookup[control_byte & 0b00011111]

    def parse_tag(self, tlv, tag_control, tag_size):
        """
        Parse the tag value from the raw TLV bytes given the tag-control code and tag size
        """
        if tag_size == 0:
            tag = None
        elif tag_size == 1:
            tag = bytes2int(tlv[0:1])
        elif tag_size == 6:
            tag = (bytes2int(tlv[0:2]), bytes2int(tlv[2:4]), bytes2int(tlv[4:6]))
        elif tag_size == 8:
            tag = (bytes2int(tlv[0:2]), bytes2int(tlv[2:4]), bytes2int(tlv[4:8]))
        else:
            logger.warn('Unrecognized tag: %s (%d)', tag_control, tag_size)
        return tag

    def parse_integer(self, tlv, value_size, signed):
        """
        Parse a TLV integer element from the raw TLV bytes
        """
        value = bytes2int(tlv[0:value_size], signed)
        return value, value_size

    def parse_utf8(self, tlv, length_size):
        """
        Parse a TLV UTF-8 string element from the raw TLV bytes
        """
        length = bytes2int(tlv[0:length_size])
        value = ''.join(['%c'%b for b in tlv[length_size:length_size+length]])
        return value, length_size+length

    def parse_byte_string(self, tlv, length_size):
        """
        Parse a TLV byte-string element from the raw TLV bytes
        """
        length = bytes2int(tlv[0:length_size])
        value = tlv[length_size:length_size+length]
        return value, length_size+length

    def parse_structure(self, tlv):
        """
        Parse a TLV structure element (and recursively parse its contents) from the raw bytes
        """
        element = {}
        i = 0
        while True:
            tag, subelement, subelement_size = self.parse_element(tlv[i:])
            i += subelement_size
            if isinstance(subelement, self.EndOfContainer):
                break
            else:
                assert(tag != None)
                element[tag] = subelement
        return element, i

    def parse_array(self, tlv):
        """
        Parse a TLV array element (and recursively parse its contents) from the raw bytes
        """
        element = []
        i = 0
        while True:
            tag, subelement, subelement_size = self.parse_element(tlv[i:])
            i += subelement_size
            if isinstance(subelement, self.EndOfContainer):
                break
            else:
                assert(tag == None)
                element.append(subelement)
        return element, i

    def parse_path(self, tlv):
        """
        Parse a TLV path element (and recursively parse its contents) from the raw bytes
        """
        element = collections.OrderedDict()
        i = 0
        while True:
            tag, subelement, subelement_size = self.parse_element(tlv[i:])
            i += subelement_size
            if isinstance(subelement, self.EndOfContainer):
                break
            else:
                element[tag] = subelement
        return element, i

    def parse_element(self, tlv):
        """
        Parse an arbitrary TLV element from the raw bytes
        """
        i = 0

        # Parse the control byte
        control_byte = bytes2int(tlv[i:i+1])
        tag_control, tag_size = self.lookup_tag_control(control_byte)
        element_type, length_size, value_size = self.lookup_element_type(control_byte)
        i += 1

        # Parse the tag
        tag = self.parse_tag(tlv[i:], tag_control, tag_size)
        i += tag_size

        # Parse the rest of the element
        if element_type == 'Signed Integer':
            element, element_size = self.parse_integer(tlv[i:], value_size, signed=True)

        elif element_type == 'Unsigned Integer':
            element, element_size = self.parse_integer(tlv[i:], value_size, signed=False)

        elif element_type == 'Boolean False':
            element, element_size = False, 0

        elif element_type == 'Boolean True':
            element, element_size = True, 0

        elif element_type == 'UTF-8 String':
            element, element_size = self.parse_utf8(tlv[i:], length_size)

        elif element_type == 'Byte String':
            element, element_size = self.parse_byte_string(tlv[i:], length_size)

        elif element_type == 'Null':
            element, element_size = None, 0

        elif element_type == 'Structure':
            element, element_size = self.parse_structure(tlv[i:])

        elif element_type == 'Array':
            element, element_size = self.parse_array(tlv[i:])

        elif element_type == 'Path':
            element, element_size = self.parse_path(tlv[i:])

        elif element_type == 'End of Container':
            element, element_size = self.EndOfContainer(), 0

        else:
            logger.warn('Unrecognized element type: %s', element_type)

        return tag, element, (1+tag_size+element_size)


class TVDReader(object):
    # TVD Synchronization, per https://docs.google.com/a/nestlabs.com/document/d/1IXJszV8ikWFQ_XyCszydt00KKQ1PM-Mgj0X7TbW9XdE/edit#heading=h.1cdtiocly985
    class Synchronization(object):
        Unknown = 0
        Synchronized = 1
        Unsynchronized = 2

    class TVD(object):

        tvd_file_lock = Lock()

        def __init__(self, root_tag, tlv):
            # Parse the Version and Description
            self.version = tlv.get(0x02)
            self.description = tlv.get(0x09)

            # Load the external Descriptors
            self.resources = [uri for uri in tlv.get(0x23, [])]
            self.descriptors = []
            for uri in self.resources:
                resource = self.load_external_resource(uri)
                is_valid = (resource is not None
                            and isinstance(resource, list)
                            and all([isinstance(d, self.Descriptor) for d in resource]))
                if is_valid:
                    self.descriptors += resource
                else:
                    logger.warn('Invalid resource: %s', uri)

            # Parse the internal Descriptors
            self.descriptors += [self.Descriptor(descriptor_tlv) for descriptor_tlv in tlv.get(0x03, [])]

            # Convert the Descriptors from a list to a dictionary keyed on identifier
            self.descriptors = {descriptor.identifier: descriptor for descriptor in self.descriptors}

            # Parse the Records (a.k.a. Streams)
            self.records = [self.Stream(stream_tlv, self.descriptors) for stream_tlv in tlv.get(0x1c, [])]

        def load_external_resource(self, uri):
            # Find and load the resource data
            tvd_definitions_path = os.path.join(fileutils.EUREKA_ROOT, 'build', 'tvd_definitions')
            fileutils.mkdir_p(tvd_definitions_path)

            filename = uri.split('/')[-1]
            local_filename = os.path.join(tvd_definitions_path, filename)

            if os.path.isfile(local_filename) and os.path.getsize(local_filename) == 0:
                logger.warn('Refetching zero byte resource file %s' % local_filename)
                os.remove(local_filename)

            if not os.path.isfile(local_filename):
                with TVDReader.TVD.tvd_file_lock:
                    if not os.path.isfile(local_filename):
                        # Get the path the file is located at. We remove the HTTP header and bucket, since those aren't
                        # honored yet, and just extract the path.
                        s3_uri = os.path.dirname(uri.split('.com/')[-1])

                        # We first try the path given in the file, and fall back to "balsam" and "topaz" for supporting
                        # old tvd files with invalid URIs

                        downloader = S3Downloader(bucket_name=TVD_BUCKET, destination=tvd_definitions_path)

                        for path_to_try in [s3_uri, 'topaz', 'balsam', 'flintstone']:

                            logger.info("Loading external resource from: %s to %s",
                                        TVD_BUCKET,
                                        local_filename)

                            params = {'tvd_directory' : path_to_try,
                                      'uri_filename' : filename }

                            downloader.set_download_strategy_from_bucket(**params)
                            results = downloader.get_log_files(parallel=True)

                            if results:
                                temp_filename = results[0]

                                if os.path.isfile(temp_filename):
                                    if os.path.getsize(temp_filename) > 0:
                                        os.rename(temp_filename, local_filename)
                                        break
                                    else:
                                        # Remove temp file if it is zero bytes
                                        os.remove(temp_filename)
                        else:
                            raise DownloadException('Unable to download TVD resources file.')
            try:
                with open(local_filename, 'rb') as f:
                    data = f.read()

                # Parse and return the TVD data
                if data:
                    element = TVDReader.read(data)
                    return element

            except IOError:
                logger.warn('Could not find TVD resource file %s', filename)
            return None

        class Descriptor(object):
            class Field(object):
                def __init__(self, tlv):
                    self.valid = tlv[0x0e]
                    self.relative = tlv[0x0f]
                    self.signed = tlv[0x10]
                    self.size = tlv[0x11]
                    self.count = tlv[0x12]
                    self.exponent = tlv.get(0x17, 0)
                    self.logical_minimum = tlv.get(0x18, 0)
                    self.logical_maximum = tlv.get(0x19, 2**(self.size-1) if self.signed else 2**self.size)
                    self.physical_minimum = tlv.get(0x1a, self.logical_minimum)
                    self.physical_maximum = tlv.get(0x1b, self.logical_maximum)
            class TimeBase(object):
                def __init__(self, tlv):
                    self.exponent = tlv.get(0x17, 0)
                    self.reference = tlv.get(0x20, 0)
                    self.synchronization = tlv.get(0x21, 0)
            class TimePeriod(object):
                def __init__(self, tlv):
                    self.exponent = tlv.get(0x17, 0)

            def __init__(self, tlv):
                self.identifier = tlv[0x05]
                self.description = tlv.get(0x09, 'Stream %d' % self.identifier)
                self.stream_periodicity = tlv.get(0x0a, False)
                self.time_base = self.TimeBase(tlv.get(0x1f, {}))
                if self.stream_periodicity:
                    self.time_period = self.TimePeriod(tlv.get(0x0b, {}))
                else:
                    self.time_period = None
                self.fields = [self.Field(field) for field in tlv[0x0c]]

        class Stream(object):
            def logical2physical(self, logical_value, field):
                if logical_value is not None:
                    rescale_factor = 1.0 * (field.physical_maximum - field.physical_minimum) / (field.logical_maximum - field.logical_minimum)
                    return (field.physical_minimum + rescale_factor*(logical_value - field.logical_minimum)) * 10.0**field.exponent

            def __init__(self, tlv, descriptors):
                self.identifier = tlv[0x05]

                # Look-up the corresponding Descriptor for this stream
                if self.identifier in descriptors:
                    self.descriptor = descriptors[self.identifier]
                    self.decoded = True
                else:
                    self.decoded = False
                    logger.warn('No corresponding Descriptor found for Stream identifier %d', self.identifier)
                    logger.warn('tlv: %s', tlv)
                    return

                # Parse the time base and time period
                self.time_base = tlv[0x1f] * 10.0**self.descriptor.time_base.exponent
                if self.descriptor.stream_periodicity:
                    self.time_period = tlv[0x0b] * 10.0**self.descriptor.time_period.exponent
                else:
                    self.time_period = 0
                self.synchronization = self.descriptor.time_base.synchronization

                # Parse the data
                self.raw_data = []
                self.data = []
                i = 0
                raw_bytes = tlv[0x1e]

                while i < len(raw_bytes):
                    raw_sample = []
                    sample = []
                    for field in self.descriptor.fields:
                        assert(field.size % 8 == 0) # TODO: We need to be able to handle sizes that aren't multiples of 8
                        field_size = field.size / 8

                        for j in range(field.count):
                            try:
                                logical_value = bytes2int(raw_bytes[i:i+field_size], field.signed)
                                physical_value = self.logical2physical(logical_value, field)
                                raw_sample.append(logical_value)
                                sample.append(physical_value)
                            except KeyError: # happens if the number of bytes does not map to a standard numeric type
                                raw_sample.append(raw_bytes[i:i+field_size])
                                try:
                                    # see if it can be encoded as UTF-8, but leave it in raw bytes
                                    # TODO: determine the right encoding to use
                                    utf_string = raw_bytes[i:i+field_size].decode("utf-8")
                                    sample.append(raw_bytes[i:i+field_size])
                                except UnicodeDecodeError: # happens if the string is not ASCII. For now, we'll hexlify
                                    hex_string = binascii.hexlify(raw_bytes[i:i+field_size])
                                    sample.append(hex_string)
                            i += field_size

                    if len(sample) == 1:
                        self.raw_data.append(raw_sample[0])
                        self.data.append(sample[0])
                    else:
                        self.raw_data.append(tuple(raw_sample))
                        self.data.append(tuple(sample))

                # Compute the timestamps for each sample
                time_base = self.time_base
                try:
                    datetime.datetime.utcfromtimestamp(time_base)
                except ValueError as exc:
                    # This most likely indicates the time_base is in milliseconds,
                    # so convert to seconds and see if the conversion works.
                    if str(exc) == 'year is out of range':
                        time_base /= 1000.0
                        # Try converting to UTC again to make sure it wasn't
                        # just an accident...
                        datetime.datetime.utcfromtimestamp(time_base)
                    else:
                        raise
                self.timestamps = [time_base + i * self.time_period for i in range(len(self.data))]

    @staticmethod
    def load(filename):
        """
        Load and parse the given file of TVD formatted data
        """
        if filename[-3:] == '.gz':
            f = gzip.open(filename, "rb")
            file_data = f.read()
            f.close()
        else:
            file_data = open(filename, "rb").read()
        return TVDReader.read(file_data)

    @staticmethod
    def read(tlv):
        """
        Parse the provided bytes as TVD formatted data
        """
        tlvreader = TLVReader()
        tag, root_element, element_size = tlvreader.parse_element(tlv)

        if tag == (0x235a, 0x04, 0x01):
            return TVDReader.TVD(tag, root_element)
        elif tag == (0x235a, 0x04, 0x03):
            return [TVDReader.TVD.Descriptor(d) for d in root_element]


if __name__ == '__main__':
    tvd = TVDReader.load(sys.argv[1])

    print tvd.description
    print 'Version:'
    print '  %d' % tvd.version
    print 'Descriptors:'
    for id in tvd.descriptors:
        print '  %d: %s' % (id, tvd.descriptors[id].description)
    print 'Records:'
    for stream in tvd.records:
        if stream.decoded:
            print '  %s (%d): t0 = %0.3f; dt = %0.3f;' % (stream.descriptor.description, stream.identifier, stream.time_base, stream.time_period),
            print '%d samples from %0.3f - %0.3f; ' % (len(stream.data), stream.timestamps[0], stream.timestamps[-1]),
            print 'first value = ', stream.data[0]
