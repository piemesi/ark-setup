# Fix for pylint not recognizing dynamically generated methods.
# pylint: disable=maybe-no-member

import datetime
import matplotlib

from ..converters import time_converters


class DailyPlotter(object):
    """
    A specific matplotlib axes which is used to plot time-series data over a
    day.
    """

    def __init__(self, axes, plot_date):
        """
        :param axes:
            the axes to be used for the daily plot

        :param plot_date:
            a datetime that falls in the first day of the plot
        """

        self.axes = axes

        day_begin = plot_date.replace(hour=0, minute=0, second=0)
        self.start_date = time_converters.get_tz_aware_datetime(day_begin)
        self.end_date = self.start_date + datetime.timedelta(days=1)

    def format(self, print_absolute=True, use_offset=True, hour_locator_interval=3):
        """
        Formats axes in a standard way with dateticks and title.

        :param print_absolute:
            whether to print the month, day, and year. Should be disabled for
            weekly setpoints.
        :type print_absolute:
            boolean

        :param use_offset:
            whether to allow offsets on the y axis.
        :type:
            boolean
        """
        self.axes.get_xaxis().set_major_locator(matplotlib.dates.HourLocator(interval=hour_locator_interval))

        date_formatter = matplotlib.dates.DateFormatter('%H:%M', tz=self.start_date.tzinfo)
        self.axes.get_xaxis().set_major_formatter(date_formatter)

        y_formatter = matplotlib.ticker.ScalarFormatter(useOffset=use_offset)
        self.axes.get_yaxis().set_major_formatter(y_formatter)

        self.axes.set_xlim(self.start_date, self.end_date)

        # Place the day of week and date title to the left of the plot.
        time_format = "%a, %b %d" if print_absolute else "%a"
        self.axes.set_title(self.start_date.strftime(time_format), x=-0.1, y=0.3)

    def plot_xy(self,
                x,
                y,
                func_name='plot',
                y2=False,
                y2_position=1.0,
                yscale=None,
                **kwargs):
        """
        :param x:
            time series data to be plotting on x-axis
        :type x:
            list-like

        :param y:
            data to be plotted on the y-axis
        :type y:
            list-like

        :param func_name:
            function name to be called on the axes. These can be any plotting
            function runnable using matplotlib.pyplot. Common examples include:
                plot, step, scatter, arrow
        :type func_name:
            string

        :param y2:
            whether to plot on a secondary y axis
        :type y2:
            boolean

        :param y2_position:
            what position to use for the secondary y axis
        :type y2_position:
            numeric

        :returns:
            a handle to the newly created trace
        """
        axes = self.axes

        if y2:
            axes = axes.twinx()
            axes.spines["right"].set_position(("axes", y2_position))

        if yscale is not None:
            axes.set_yscale(yscale)

        return getattr(axes, func_name)(x, y, **kwargs)

    def get_axes(self):
        return self.axes

    def get_start_date(self):
        return self.start_date

    def get_end_date(self):
        return self.end_date
