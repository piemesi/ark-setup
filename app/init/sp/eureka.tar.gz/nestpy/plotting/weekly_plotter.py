from .multiday_plotter import MultiDayPlotter

DAYS_PER_WEEK = 7


class WeeklyPlotter(MultiDayPlotter):
    """
    A specific matplotlib figure which is used to plot time-series data over a
    week.
    """

    def __init__(self,
                 start_date,
                 device_id=None,
                 description=None):
        """
        :param start_date:
            the date of the first plot in the data

        :param device_id:
            the ID for the device being plotted

        :param description:
            the description for the type of plot. i.e. "Auto-Away"
        """
        super(WeeklyPlotter, self).__init__(start_date=start_date,
                                              device_id=device_id,
                                              description=description,
                                              num_days=DAYS_PER_WEEK)

