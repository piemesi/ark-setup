"""
Common functionality for Diamond plots.
"""
# pylint: disable=no-member,maybe-no-member

import os
from datetime import timedelta
import collections

import matplotlib.pyplot as plt
import matplotlib
import pandas as pd
import numpy as np
import brewer2mpl

from ..converters import time_converters, list_to_intervals

import logging
logger = logging.getLogger(__name__)

# TODO: Make these temperatures dynamic. Snap them to nearest 5 degrees.
TEMPERATURE_LIM_F = (45, 90)
TEMPERATURE_LIM_C = (10, 30)

PIR_MIN = 0
PIR_MAX = 100
PIR_LIM = (PIR_MIN, PIR_MAX)
PIR_INTERVALS = 60 * 24 / 5.0  # Five-minute intervals
PIR_WIDTH = 1.0 / PIR_INTERVALS


class DiamondPlotter(object):
    """A plot generator for Diamond devices.

    Provides the ability to plot commonly used variables through a combination of automatic detection and configuration
    of plot types.

    Manual selection of plotting variables is done in the constructor.

    >>> DiamondPlotter(device_history).plot()  # Generate a plot.
    >>> DiamondPlotter(device_history).plot_to_file(".")  # Generate a plot and save it to the current directory.

    TODO: Add support for annotations on the state subplots. Include both event and range support.
    """

    def __init__(self,
                 device_history,
                 description="Diamond",
                 annotations=None,
                 setpoints=True,
                 temperature=True,
                 light=True,
                 occupancy=True,
                 update_state=True,
                 away=True,
                 log_light_scale=False,
                 independent_light_scales=False,
                 occupancy_noise_quantile=0.5):
        """Create a new DiamondPlotter.

        This constructor calculates global parameters for plotting (e.g. setpoint categories, limits, number of days),
        and sets up a figure on which to plot all of the independent axes.

        Each of the options has a corresponding test for the existence of the relevant variables. For example, setpoint
        plotting will be gracefully omitted if setpoints are not available.

        :param device_history: Diamond device history.
        :type device_history DeviceHistory
        :param description: text to add to the plot title.
        :type description: str
        :param annotations: list of annotations to add to the state subplots.
        :type annotations: list
        :param setpoints: whether to plot setpoints. (defaults to True)
        :type setpoints: boolean
        :param temperature: whether to plot temperatures: target and ambient. (defaults to True)
        :type temperature: boolean
        :param light: whether to plot light, including min, max, and a band between the two. (defaults to True)
        :type light: boolean
        :param occupancy: whether to plot occupancy. (defaults to True)
        :type occupancy: boolean
        :param update_state: whether to plot HVAC state updates (i.e. heat and cool). (defaults to True)
        :type update_state: boolean
        :param away: whether to plot auto and manual away state. (defaults to True)
        :type away: boolean
        :param log_light_scale: use log scale for the light variables. (defaults to False)
        :type log_light_scale: boolean
        :param independent_light_scales: use independent scales for light on each day. (defaults to False)
        :type independent_light_scales: boolean
        :param occupancy_noise_quantile: quantile under which occupancy is considered to be noise, and should not be
                plotted
        :type occupancy_noise_quantile: float
        :return: DiamondPlotter instance.
        """
        logger.debug("Diamond plotter initializing device [%s]", device_history.unique_device_id)

        self.device_history = device_history
        self.location = self.device_history.get_location()
        self.device_id = "%s (%s)" % (self.device_history.unique_device_id, self.location)
        self.description = description
        self.annotations = annotations

        self.show_setpoints = setpoints and self._has_frame("SetPoints")
        self.show_temperature = temperature and self._has_frame("BufferedTemperature") and self._has_frame(
            "RethinkStateResults")
        self.show_light = light and self._has_frame("BufferedAmbientLightSensor")
        self.show_occupancy = occupancy and (self._has_frame("BufferedPassiveInfrared") or self._has_frame(
            "BufferedNearPir"))
        self.show_update_state = update_state and self._has_frame("UpdateStateResults")
        self.show_away = away and (
            self._has_frame("CurrentState")
            or
            self._has_frame("AutoAway")
        )
        self.show_annotations = self.annotations is not None
        self.show_state = self.show_away or self.show_update_state or self.show_annotations

        self.log_light_scale = log_light_scale
        self.independent_light_scales = independent_light_scales

        earliest_date = self.device_history.earliest_date
        latest_date = self.device_history.latest_date

        if earliest_date is None or latest_date is None:
            logger.error("Cannot plot device: %s", self.device_history.unique_device_id)
            return

        self.start_date = earliest_date - timedelta(hours=earliest_date.hour,
                                                    minutes=earliest_date.minute,
                                                    seconds=earliest_date.second)

        self.days = (self.device_history.latest_date - self.device_history.earliest_date).days
        # Convert to local device time and get beginning of day
        self.start_date = time_converters.get_tz_aware_datetime(self.start_date.replace(hour=0, minute=0, second=0))
        self.end_date = self.start_date + timedelta(days=self.days)

        self.figure = plt.figure(figsize=[15, self.days])
        self.axes = []

        num_subplots = self.days * 2 if self.show_state else self.days
        height_ratios = [1, 0.2] * self.days if self.show_state else [1] * self.days
        self.grid_spec = matplotlib.gridspec.GridSpec(num_subplots, 1, height_ratios=height_ratios)

        if self.show_occupancy:
            self.far_pir_noise = 0.0
            self.near_pir_noise = 0.0
            if 'BufferedPassiveInfrared' in self.device_history:
                self.far_pir_noise = self.device_history.BufferedPassiveInfrared['max'].quantile(occupancy_noise_quantile)
                logger.debug("Far PIR noise level: %s" % self.far_pir_noise)
            if 'BufferedNearPir' in self.device_history:
                self.near_pir_noise = self.device_history.BufferedNearPir['max'].quantile(occupancy_noise_quantile)
                logger.debug("Near PIR noise level: %s" % self.near_pir_noise)

        if self.show_away:
            if self._has_frame("CurrentState"):
                self.auto_away_mode = DiamondPlotter._resample_to_5m(self.device_history.CurrentState.AwayMode,
                                                                     2)  # 2 == Auto Away
                self.manual_away_mode = DiamondPlotter._resample_to_5m(self.device_history.CurrentState.AwayMode,
                                                                       1)  # 1 == Manual Away
            elif self._has_frame("AutoAway"):
                self.auto_away_mode = DiamondPlotter._resample_to_5m(self.device_history.AutoAway > 0, True)

        if self.show_update_state:
            self.update_state_heat = DiamondPlotter._resample_to_5m(
                self.device_history.UpdateStateResults.Stage1HeatState, 1)
            self.update_state_cool = DiamondPlotter._resample_to_5m(
                self.device_history.UpdateStateResults.Stage1CoolState, 1)

        if self.show_setpoints:
            setpoints = self.device_history.SetPoints
            setpoints = setpoints[~setpoints.Category.isnull()]  # Only plot attributable setpoints.
            categories = setpoints.Category.unique()
            colors = DiamondPlotter.get_hex_colors(categories)
            self.setpoint_category_colors = {category: colors[i] for i, category in enumerate(categories)}

        if self.show_light:
            self.ambient_light_limits, self.ambient_light_log_limits = DiamondPlotter._calculate_ambient_light_limits(
                self.device_history.BufferedAmbientLightSensor)

    def plot(self):
        """Plots diamond event data on a per-day basis.

        Generates two subplots for each day: one for sensors (e.g. far infrared) and another for state (e.g. away). Uses
        the plotting options (see constructor) to determine which variables are meant to be plotted, and creates axes
        for each set of variable types (e.g. one set of axes for all temperature variables).
        """
        for day_index in range(self.days):

            y_offset = 1

            start_date = self.start_date + timedelta(days=day_index)
            end_date = start_date + timedelta(days=1)
            xlim = (start_date, end_date)

            def slice_day(data_frame):
                return DiamondPlotter._slice_dates(data_frame, start_date, end_date)

            background_color = '#f5f5f5' if start_date.weekday() > 4 else 'white'

            # Create a sensor subplot, which will have several twin x axes - one for each unit of measurement
            # (e.g. temperature, light).
            sensor_subplot_index = day_index * 2 if self.show_state else day_index
            sensors_ax1 = self.figure.add_subplot(self.grid_spec[sensor_subplot_index], axisbg=background_color)
            self.axes.append(sensors_ax1)

            if self.show_light:
                df_ambient_light = slice_day(self.device_history.BufferedAmbientLightSensor)
                self._plot_light(sensors_ax1, df_ambient_light, xlim)

            if self.show_occupancy:
                sensors_ax2 = sensors_ax1.twinx()
                y_offset += 0.05  # Increase y-offset for future twin y axes.
                self.axes.append(sensors_ax2)
                df_far_pir = slice_day(self.device_history.BufferedPassiveInfrared) if 'BufferedPassiveInfrared' in self.device_history else None
                df_near_pir = slice_day(self.device_history.BufferedNearPir) if 'BufferedNearPir' in self.device_history else None
                self._plot_occupancy(sensors_ax2, df_far_pir, df_near_pir, xlim)

            if self.show_temperature or self.show_setpoints:
                sensors_ax3 = sensors_ax1.twinx()
                self.axes.append(sensors_ax3)
                sensors_ax3.spines["right"].set_position(("axes", y_offset))

                if self.show_setpoints:
                    df_setpoints = slice_day(self.device_history.SetPoints)
                    df_setpoints = df_setpoints[~df_setpoints.Category.isnull()]  # Only plot attributable setpoints.
                    self._plot_setpoints(sensors_ax3, df_setpoints)

                if self.show_temperature:
                    df_temperature = slice_day(self.device_history.BufferedTemperature)
                    df_target_temperature = slice_day(self.device_history.RethinkStateResults)
                    self._plot_temperature(sensors_ax3, df_temperature, df_target_temperature)

                temperature_lim = TEMPERATURE_LIM_C if self.device_history.temperature_unit == 'C' else TEMPERATURE_LIM_F
                sensors_ax3.axis(xlim + temperature_lim)

            # Remove x axis labels and ticks for the sensor plot. Note that we'll leave it in for the state plot, later
            # on.
            sensors_ax1.get_xaxis().set_visible(False)
            sensors_ax1.set_title(start_date.strftime("%a, %b %d"), x=-0.1, y=0.3)

            if self.show_state:
                # Subplot for state: Manual and Auto Away, Heat, Cool
                state_ax1 = self.figure.add_subplot(self.grid_spec[day_index * 2 + 1])
                self.axes.append(state_ax1)

                # Remove the Y axis for the state subplot, since it just shows a meaningless 0-1 range.
                state_ax1.get_yaxis().set_visible(False)

                # Remove x axis labels and ticks for all but the last day.
                if day_index < self.days - 1:
                    DiamondPlotter._hide_xtick_labels(state_ax1)

                state_ax1.axis(xlim + (0, 1))
                date_formatter = matplotlib.dates.DateFormatter('%H', tz=start_date.tzinfo)
                state_ax1.get_xaxis().set_major_formatter(date_formatter)

                if self.show_away:
                    self._plot_state(axes=state_ax1, state=self.auto_away_mode, xlim=xlim, color='g', alpha=0.5,
                                     label='Away Auto')
                    self._plot_state(axes=state_ax1, state=self.manual_away_mode, xlim=xlim, color='g', alpha=0.9,
                                     label='Away Manual')

                if self.show_update_state:
                    self._plot_state(axes=state_ax1, state=self.update_state_heat, xlim=xlim, color='r', alpha=1,
                                     label='State Heating')
                    self._plot_state(axes=state_ax1, state=self.update_state_cool, xlim=xlim, color='b', alpha=1,
                                     label='State Cooling')

                if self.show_annotations:
                    self._plot_annotations(axes=state_ax1)

        self._plot_title()
        self._plot_legend()
        self.figure.subplots_adjust(right=0.9)  # Leave a larger right margin to account for extra y-axis labels.
        self.figure.subplots_adjust(hspace=0)  # Drop all whitespace between daily plots.

    def plot_to_file(self, path, overwrite=True, filename_prefix="diamond"):
        """Plots Diamond behavior on a per-week basis, storing plots in the specified path.

        :param path: the path in which to store the diamond plot.
        :param overwrite: whether to overwrite an existing diamond plot.
        :param filename_prefix: the prefix of the filename for the stored plot.
        :return path to the new file

        """

        filename = "{}_{}.png".format(filename_prefix, self.device_history.unique_device_id)
        file_path = os.path.join(path, filename)
        exists = os.path.exists(file_path)
        if not exists or (exists and overwrite):
            try:
                logger.info("Plotting diamond to: %s", file_path)
                self.plot()
                plt.savefig(file_path)
                plt.close()
            except Exception, e:
                logger.error("Couldn't plot diamond device to file: %s", e)
                plt.close()
                raise e
        else:
            logger.info("Plot already exists or plot overwrite is set to False.")
            return None

        return file_path

    def _has_frame(self, key):
        return key in self.device_history

    def _plot_light(self, axes, ambient_light, xlim):
        x = ambient_light.index
        ymax = ambient_light['max']
        axes.plot(x, ymax, color='black', label='Max Light')

        ymin = ambient_light['min']
        axes.plot(x, ymin, color='black', label='Min Light')

        axes.fill_between(x,
                          ymax,
                          ymin,
                          facecolor='grey',
                          alpha=0.5,
                          label="light")

        if self.log_light_scale:
            axes.set_yscale('log')
            light_ylim = self.ambient_light_log_limits
        else:
            light_ylim = self.ambient_light_limits

        if not self.independent_light_scales:
            axes.axis(xlim + light_ylim)

    def _plot_occupancy(self, axes, far_pir, near_pir, xlim):
        far_pir_above_threshold = far_pir[far_pir['max'] > self.far_pir_noise]
        x_far = far_pir_above_threshold.index
        y_far = far_pir_above_threshold['max']
        axes.bar(x_far, y_far, width=PIR_WIDTH, color='grey', alpha=0.2, label='PIR Far')

        if near_pir is not None:
            near_pir_above_threshold = near_pir[near_pir['max'] > self.near_pir_noise]
            x_near = near_pir_above_threshold.index
            y_near = near_pir_above_threshold['max']
            axes.bar(x_near, y_near, width=PIR_WIDTH, color='black', alpha=0.4, label="PIR Near")

        axes.axis(xlim + (0, 100))

    def _plot_setpoints(self, axes, setpoints):
        if self.show_setpoints:
            for category in self.setpoint_category_colors.keys():
                category_setpoints = setpoints[setpoints.Category == category]
                x_sp = category_setpoints.index.values
                for setpoint_type in ['Heating', 'Cooling']:
                    marker = "o" if setpoint_type == 'Heating' else "*"
                    # Note that, for scatter plots, we're using the index _values_. Not sure why, but there's a
                    # failure when we use the index directly.
                    values = category_setpoints[setpoint_type]
                    if not all(values.isnull()):
                        axes.scatter(x_sp,
                                     values,
                                     color=self.setpoint_category_colors[category],
                                     edgecolors='grey',
                                     marker=marker,
                                     label="Setpoint %s %s" % (setpoint_type, category),
                                     zorder=10,  # Set high zorder so that setpoints appear above everything else.
                                     s=50)

    def _plot_temperature(self, axes, temperature, target_temperature):
        axes.plot(temperature.index,
                  temperature.temperature,
                  color='red',
                  label="Temperature Ambient")

        axes.plot(target_temperature.index,
                  target_temperature.TargetTemperature,
                  color='purple',
                  label="Temperature Target")

    def _plot_state(self, axes, state, xlim, color, alpha, label):
        start_date, end_date = xlim
        if state is not None:
            for index, data in state.iterrows():
                start = max(data.start, start_date)
                end = min(data.end, end_date)
                if start >= start_date and end <= end_date:
                    axes.axvspan(start, end, color=color, alpha=alpha, label=label)

    def _plot_annotations(self, axes):
        for annotation in self.annotations:
            # TODO: This currently plots each annotation on all day plots. We should instead plot each annotation only
            # TODO: on the day on which it falls.
            axes.axvspan(annotation["start_date"],
                         annotation["end_date"],
                         color=annotation["color"],
                         alpha=0.2,
                         label=annotation["label"])

    def _plot_title(self):
        start = self.start_date.strftime("%a, %b %d %Y")
        end = (self.end_date - timedelta(days=1)).strftime("%a, %b %d %Y")
        time_range = "%s to %s" % (start, end)
        self.figure.suptitle("%s\n%s\n%s" % (self.device_id, self.description, time_range))

    def _plot_legend(self):
        # Collect a superset of all axis handles and labels for use in the legend.
        traces = {}
        for ax in self.axes:
            handles, labels = ax.get_legend_handles_labels()
            for idx, label in enumerate(labels):
                traces[label] = handles[idx]

        ordered_traces = collections.OrderedDict(sorted(traces.items()))
        self.figure.legend(ordered_traces.values(),
                           ordered_traces.keys(),
                           loc='lower center',
                           frameon=False,
                           ncol=5,
                           prop={'size': 10})

    @staticmethod
    def _calculate_ambient_light_limits(ambient_light):
        max_values = ambient_light['max']
        min_values = ambient_light['min']

        ambient_light_min = min(max_values.min(), min_values.min())
        ambient_light_max = max(max_values.max(), min_values.max())

        ambient_light_limits = (ambient_light_min, ambient_light_max)
        ambient_light_log_limits = (0, 10**np.ceil(np.log10(ambient_light_max)))

        logger.debug("Ambient light limits for plotting. Base: %s Log: %s",
                     ambient_light_limits, ambient_light_log_limits)

        return ambient_light_limits, ambient_light_log_limits

    @staticmethod
    def _slice_dates(data_frame, start_date, end_date):
        """
        :param data_frame:
            the data frame to plot, with index set to time-series data

        :param start_date:
            the beginning of the time-span to slice

        :param end_date:
            the end of the time-span to slice
        """

        last_prior = data_frame[(data_frame.index < start_date)].tail(1)
        current = data_frame[(data_frame.index >= start_date) & (data_frame.index <= end_date)]
        first_after = data_frame[(data_frame.index > end_date)].head(1)
        return pd.concat([last_prior, current, first_after])

    @staticmethod
    def _resample_to_5m(timeseries, value):
        resampled_timeseries = timeseries.resample('5min', fill_method='ffill', how='max')
        intervals = list_to_intervals(resampled_timeseries == value)
        interval_dicts = [{"start": resampled_timeseries.index[start], "end": resampled_timeseries.index[end]}
                          for (start, end) in intervals]
        if not intervals:
            return
        return pd.DataFrame(interval_dicts)

    @staticmethod
    def _hide_xtick_labels(axes):
        for xlabel_i in axes.get_xticklabels():
            xlabel_i.set_visible(False)
            xlabel_i.set_fontsize(0.0)

    @staticmethod
    def get_hex_colors(categories):
        # Work around an issue getting fewer than 3 colors using colorbrewer: https://github.com/yhat/ggplot/issues/303
        num_colors = max(3, len(categories))
        colors = brewer2mpl.get_map('Set2', 'Qualitative', num_colors)
        return colors.hex_colors[0:len(categories)]


