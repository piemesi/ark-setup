# Fix for pylint not recognizing dynamically generated methods.
# pylint: disable=maybe-no-member

import datetime
import collections
import matplotlib
import matplotlib.pyplot as plt
import pandas

from .. converters import time_converters
from .daily_plotter import DailyPlotter
from .plotter import figure


class MultiDayPlotter(object):
    """
    A specific matplotlib figure which is used to plot time-series data over a
    week. It is a container for DailyPlotter objects.
    """

    def __init__(self,
                 start_date,
                 device_id=None,
                 description=None,
                 num_days=7
                 ):
        """
        :param start_date:
            the date of the first plot in the data

        :param device_id:
            the ID for the device being plotted

        :param description:
            the description for the type of plot. i.e. "Auto-Away"
        """

        self.figure = figure(figsize=[15, num_days])
        self.start_date = time_converters.get_tz_aware_datetime(start_date.replace(hour=0, minute=0, second=0))
        self.end_date = self.start_date + datetime.timedelta(days=num_days)
        self.device_id = device_id
        self.description = description
        self.daily_plots = []
        self.traces = {}
        self.num_days = num_days

        self.grid_spec = matplotlib.gridspec.GridSpec(self.num_days, 1, height_ratios=[1] * self.num_days)

        ax = None
        for idx in range(num_days):

            # Set background to grey for weekends and white for weekdays.
            idx_date = start_date + datetime.timedelta(days=idx)
            background_color = '#f5f5f5' if idx_date.weekday() > 4 else 'white'
            ax = self.figure.add_subplot(self.grid_spec[idx], sharey=ax, axisbg=background_color)

            ax.xaxis.grid(True)

            # Remove x axis labels and ticks, except for the bottom plot.
            if idx < num_days - 1:
                for xlabel_i in ax.get_xticklabels():
                    xlabel_i.set_visible(False)
                    xlabel_i.set_fontsize(0.0)

            daily_plotter = DailyPlotter(ax, self.start_date + datetime.timedelta(days=idx))
            self.daily_plots.append(daily_plotter)

    def __str__(self):
        return "%s from %s to %s for device %s" % (self.description,
                                                   self.start_date,
                                                   self.end_date,
                                                   self.device_id)

    @staticmethod
    def slice_data_for_time_span(data_frame, date_start, date_end):
        """
        :param data_frame:
            the data frame to plot, with index set to time-series data

        :param date_start:
            the beginning of the time-span to slice

        :param date_end:
            the end of the time-span to slice
        """

        last_prior = data_frame[(data_frame.index < date_start)].tail(1)
        current = data_frame[(data_frame.index >= date_start) & (data_frame.index <= date_end)]
        first_after = data_frame[(data_frame.index > date_end)].head(1)
        return pandas.concat([last_prior, current, first_after])

    def format(self,
               print_absolute=True,
               use_offset=False,
               create_legend=False):
        """
        Formats the weekly plot. This command should be executed after all
        plots have been ordered, and before the figure is shown.

        :param print_absolute:
            whether to print absolute times (including month, day, and year),
            or as times in a standard week.
        :param print_absolute:
            boolean

        :param use_offset:
            whether to allow offsets on the y axis.
        :type:
            boolean

        :param create_legend:
            whether to create a legend to the right of the plot.
        :type create_legend:
            boolean
        """

        self.figure.subplots_adjust(hspace=0)

        time_range = ""
        if print_absolute:
            start = self.start_date.strftime("%a, %b %d %Y")
            end = (self.end_date - datetime.timedelta(days=1)).strftime("%a, %b %d %Y")
            time_range = "%s to %s" % (start, end)

        self.figure.suptitle("%s %s\n%s" % (self.device_id, self.description, time_range))

        for daily_plot in self.daily_plots:
            daily_plot.format(print_absolute=print_absolute,
                              use_offset=use_offset)

        if create_legend:
            ordered_traces = collections.OrderedDict(sorted(self.traces.items()))
            ncol = min(7, len(ordered_traces))
            plt.figlegend(handles=ordered_traces.values(),
                          labels=ordered_traces.keys(),
                          loc='lower center',
                          ncol=ncol,
                          prop={'size': 10},
                          frameon=False)

    def plot_xy(self,
                data_frame,
                data_field,
                func_name,
                label=None,
                ylim=None,
                yscale=None,
                **kwargs):
        """
        :param data_frame:
            the data frame to plot, with index set to time-series data
        :type data_frame:
            pandas.DataFrame

        :param data_field:
            the field or list of fields to plot over time
        :type data_field:
            string

        :param func_name:
            the plotting function name to plot the data (plot, scatter, step)
        :type func_name:
            string

        :param label:
            the label to use for the trace
        :type label:
            string

        :param y2:
            whether to plot on a secondary y axis
        :type y2:
            boolean

        :param ylim:
            the limits for the y axis. For example: (0, 200)
        :type ylim:
            tuple of integer or float

        :param yscale:
            the type of y scale
        :type yscale
            string representing the matplotlib yscale type. e.g. 'log'
        """

        for daily_plot in self.daily_plots:
            data_slice = MultiDayPlotter.slice_data_for_time_span(data_frame,
                                                                  daily_plot.get_start_date(),
                                                                  daily_plot.get_end_date())

            x = data_slice.index if func_name != 'scatter' else data_slice.index.values
            p = daily_plot.plot_xy(x=x,
                                   y=data_slice[data_field],
                                   func_name=func_name,
                                   yscale=yscale,
                                   **kwargs)

            if ylim is not None:
                plt.ylim(ylim)

            if isinstance(p, list):
                # If the plotting function used returns a tuple of results (for
                # example, the plot() function), take only the first one since
                # it's the handle
                p = p[0]

            if label is not None and p is not None:
                self.traces[label] = p

    def plot_arrows(self,
                    data_frame,
                    start_field,
                    end_field,
                    label=None,
                    **kwargs):
        """
        Plots arrows between the specified start and end points.

        :param data_frame:
            the data frame to plot, with index set to time-series data
        :type data_frame:
            pandas.DataFrame

        :param start_field:
            the field to use for the start of the arrows
        :type start_field:
            string

        :param end_field:
            the field to use for the end of the arrows
        :type end_field:
            string

        :param label:
            the label to use for the trace
        :type label:
            string

        :param y2:
            whether to plot on a secondary y axis
        :type y2:
            boolean
        """

        for daily_plot in self.daily_plots:
            data_slice = MultiDayPlotter.slice_data_for_time_span(data_frame,
                                                                  daily_plot.get_start_date(),
                                                                  daily_plot.get_end_date())

            p = None
            for index, data in data_slice.iterrows():
                dy = data[end_field] - data[start_field]

                if dy == 0:
                    continue

                p = daily_plot.plot_xy(index,
                                       data[start_field],
                                       dx=0,
                                       dy=dy,
                                       func_name="arrow",
                                       **kwargs)

            if isinstance(p, list):
                # If the plotting function used returns a tuple of results (for
                # example, the plot() function), take only the first one since
                # it's the handle
                p = p[0]

            if label is not None and p is not None:
                self.traces[label] = p

    def axvspan(self,
                data_frame,
                start_field,
                end_field,
                label=None,
                **kwargs):
        """
        Plots vertical spans between the specified start and end points.

        :param data_frame:
            the data frame to plot, with index set to time-series data
        :type data_frame:
            pandas.DataFrame

        :param start_field:
            the field to use for the starts of the vertical spans
        :type start_field:
            string

        :param end_field:
            the field to use for the ends of the vertical spans
        :type end_field:
            string

        :param label:
            the label to use for the trace
        :type label:
            string
        """

        for daily_plot in self.daily_plots:

            p = None
            for index, data in data_frame.iterrows():
                p = daily_plot.plot_xy(data[start_field],
                                       data[end_field],
                                       func_name="axvspan",
                                       y2=True,
                                       **kwargs)

            if isinstance(p, list):
                # If the plotting function used returns a tuple of results (for
                # example, the plot() function), take only the first one since
                # it's the handle
                p = p[0]

            if label is not None and p is not None:
                self.traces[label] = p
