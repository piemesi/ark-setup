# pylint: disable=invalid-name

import matplotlib.pyplot as plt


def figure(**kwargs):
    """
    Creates a matplotlib plotting figure with nice properties.

    :param kwargs: parameters that will be passed to ``matplotlib.pyplot.figure``
    :rtype: matplotlib figure handle

    The created figure has the following properties:

    * Has a reasonable font size.
    * Allows zooming in and out using the mouse scroll wheel.
    * Closes when 'q' is pressed.
    """

    fig = plt.figure(**kwargs)

    # Set up mousewheel zoom
    # based on http://stackoverflow.com/questions/11551049/matplotlib-plot-zooming-with-scroll-wheel
    base_scale = 2.

    def zoom_fun(event):

        def update_axes(scale_factor):
            # get the current x and y limits
            ax = event.inaxes

            if ax is None:
                # Don't attempt zooming if the mouse is not over a plot
                return

            cur_xlim = ax.get_xlim()
            cur_ylim = ax.get_ylim()
            cur_xrange = (cur_xlim[1] - cur_xlim[0])*.5
            cur_yrange = (cur_ylim[1] - cur_ylim[0])*.5

            xdata = event.xdata # get event x location
            ydata = event.ydata # get event y location
            # set new limits
            ax.set_xlim([xdata - cur_xrange*scale_factor,
                        xdata + cur_xrange*scale_factor])
            ax.set_ylim([ydata - cur_yrange*scale_factor,
                        ydata + cur_yrange*scale_factor])

            plt.draw() # force re-draw

        if event.button == 'up':
            # deal with zoom in
            update_axes(1/base_scale)
        elif event.button == 'down':
            # deal with zoom out
            update_axes(base_scale)

    fig.canvas.mpl_connect('scroll_event', zoom_fun)

    # Set up keyboard close
    def quit_figure(event):
        """Allows a matplotlib figure to be closed when the 'q' key is
        pressed."""

        if event.key == 'q':
            plt.close(event.canvas.figure)

    fig.canvas.mpl_connect('key_press_event', quit_figure)

    return fig
