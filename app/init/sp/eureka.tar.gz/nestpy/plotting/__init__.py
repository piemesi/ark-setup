"""
General utilities for plotting.

Also sets up 'Nest-y' plotting:

* The default color scheme is the Nest palette.
* The legend is shadowed and fancy.
* The background is white.
"""

from cycler import cycler
import matplotlib

from .plotter import *
from .diamond_plotter import *
from .groupplotter import GroupPlotter
from .daily_plotter import DailyPlotter
from .weekly_plotter import WeeklyPlotter
from .multiday_plotter import MultiDayPlotter


cool = [0, .2549, .8863]
heat = [.9059, .2667, 0]
leaf = [.0863, 1.0, .0078]
gray = [.5686, .5843, .6]
blue = [.2431, .7333, .7882]
yellow = [1.0, .7216, 0]

matplotlib.rcParams.update({
    'font.size': 8,
    'figure.facecolor': 'white',
    'figure.edgecolor': 'black',
    'figure.subplot.hspace': 0.7,
    'figure.subplot.left': 0.05,
    'figure.subplot.right': 0.95,
    'figure.subplot.top': 0.9,
    'axes.grid': True,
    'axes.edgecolor': 'black',
    'axes.titlesize': 'large',
    'axes.prop_cycle': cycler('color', [cool, heat, leaf, gray, blue, yellow]),
    'lines.linewidth': 1,
    'lines.linestyle': '-',
    'legend.fancybox': True,
    'legend.fontsize': 'x-small',
    'legend.loc': 'right',
    'legend.shadow': True
    })
