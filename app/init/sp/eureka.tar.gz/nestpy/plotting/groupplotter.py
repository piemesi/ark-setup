import logging
import os

from matplotlib.backends.backend_pdf import PdfPages

from .. import fileutils

logger = logging.getLogger(__name__)


class GroupPlotter(object):
    """
    Allows a group of plots to be created in a single location.
    Handles plotting different formats, and allows each plot to be uniquely
    named. PDF's are grouped into a single file; other formats are grouped into
    a single folder.
    """

    def __init__(self,
                 format,
                 name='Figure',
                 directory=os.getcwd(),
                 force_unique=False):
        """
        :param format:
            the format to save the plots with. (pdf, jpg, png)

        :param name:
            The name of the file or folder the images are saved in.

        :param directory:
            the directory to save the logs in.

        :param force_unique:
            create a unique filename or directory to store images
        :type boolean:
        """

        self.plot_num = 0
        self.unique_id = 0
        self.saved_plots = []
        self.format = '.'+format
        self.location = os.path.join(directory, name)
        self.pdfplot = None

        if self.format == '.pdf':
            if force_unique and os.path.exists(self.location+self.format):
                unique_num = 1
                while os.path.exists(self.location+'_'+str(unique_num)+self.format):
                    unique_num += 1

                self.location = self.location+'_'+str(unique_num)+self.format

            else:
                self.location = self.location+self.format

            self.pdfplot = PdfPages(self.location)

        else:
            if force_unique and os.path.exists(self.location):
                unique_num = 1
                while os.path.exists(self.location+'_'+str(unique_num)):
                    unique_num += 1

                self.location = self.location+'_'+str(unique_num)

            self.location = os.path.join(self.location, '')
            fileutils.mkdir_p(self.location)

    def savefig(self,
                fig,
                name=''):
        """
        :param fig:
            the figure object to save to file

        :param name:
            optional name of the image file for non-pdf formats
        """

        if self.format == '.pdf':
            self.pdfplot.savefig(fig)

        else:
            if name and name not in self.saved_plots:
                #The name is unique:
                figname = name

            # We need to create a unique name for the plot:
            else:
                if name:
                    name += '_'

                while name+str(self.unique_id) in self.saved_plots:
                    self.unique_id += 1

                figname = name+str(self.unique_id)
                self.unique_id += 1

            # Save the plot with our computed name
            fig.savefig(self.location+figname+self.format)
            self.saved_plots.append(figname)

        self.plot_num += 1

    def close(self):

        if self.format == '.pdf':
            self.pdfplot.close()

        logger.info('%i figures have been saved at %s', self.plot_num, self.location)
