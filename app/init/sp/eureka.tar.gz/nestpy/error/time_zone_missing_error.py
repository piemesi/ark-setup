class TimeZoneMissingError(ValueError):
    pass