import logging
import Queue
import thread
import time

import pandas as pd
import pymysql

from .. import credentials
from . import ssh_tunnel

logger = logging.getLogger(__name__)

CONNECTION_TIMEOUT = 15  # seconds
DEFAULT_PORT = 0         # specifying port 0 will make the interpreter choose next free port.
PORT_QUEUE_TIMEOUT = 15


class SQLDatabase(object):
    """
    A generic class to manage SQL database connections.
    """
    def __init__(self,
                 tunnel_host='shelldb01.bastion.nest.com',
                 tunnel_username=None,
                 db_host=None,
                 db_port=3306,
                 db_name=None,
                 db_user='nestlabs',
                 db_passwd='nestlabs'):

        if tunnel_username is None:
            tunnel_username = credentials.get_nestlabs_username()

        self.tunnel_thread = None
        self.db_connection = None
        self.db_cursor = None

        self.local_port = None
        self.tunnel_host = tunnel_host
        self.tunnel_username = tunnel_username
        self.db_host = db_host
        self.db_port = db_port
        self.db_name = db_name
        self.db_user = db_user
        self.db_passwd = db_passwd
        self.ssh_forward_server = None

    def __del__(self):
        # self.tunnel_thread # thread runs as daemon and destructs automatically
        try:
            if self.db_cursor is not None:
                self.db_cursor.close()

            if self.db_connection is not None:
                self.db_connection.close()

            # After every instance of SQL database is destroyed, stop the server.
            # This will make the calling thread return and eventually killed, else it will live forever!
            if self.ssh_forward_server:
                # shutdown() has a high possibility of hanging, so we use this.
                # Once a server closes its socket connection, it becomes eligible for garbage collection and kills
                # the connection. We can assume its being garbage collected since this is really being executed in __del__ method.
                # See example: http://bioportal.weizmann.ac.il/course/python/PyMOTW/PyMOTW/docs/SocketServer/index.html

                self.ssh_forward_server.shutdown()

        except pymysql.Error as e:
            logger.warn("Connection already closed. Warn: " + str(e))
            pass
        except Exception as ex:
            logger.error("Error releasing database resources: " + str(ex))

    def __str__(self):
        return "SQLDatabase connected to [%s] via [%s]" % (self.db_host, self.tunnel_host)

    def __repr__(self):
        return "<nestpy.SQLDatabase %s>" % str(self)

    def create_threaded_ssh_tunnel(self):
        # tunneled
        if self.tunnel_thread is None:
            forward_server_queue = Queue.Queue()

            # set up the tunnel
            self.tunnel_thread = thread.start_new_thread(ssh_tunnel.create_tunnel,
                                                         (DEFAULT_PORT,
                                                          self.tunnel_host,
                                                          self.db_host,
                                                          self.db_port,
                                                          self.tunnel_username,
                                                          forward_server_queue))

            # queue to get handle of ssh tunneling forward server

            timeout = time.time() + PORT_QUEUE_TIMEOUT

            while time.time() < timeout:
                if not forward_server_queue.empty():
                    self.ssh_forward_server = forward_server_queue.get()
                    self.local_port = self.ssh_forward_server.server_address[1]
                    forward_server_queue.task_done()
                    break
            else:
                # thread result timeout
                raise RuntimeError("Timeout setting local port for SSH tunnel: user {0} at host {1}: Db Host {2},"
                                   "Db Port {3}".format(self.tunnel_username, self.tunnel_host, self.db_host,
                                                        self.db_port))

    def query(self, query_string):
        logger.debug("Running db query [%s]", query_string)

        if self.tunnel_host is None and self.tunnel_username is None:
            # not tunneled
            self.db_connection = pymysql.connect(host=self.db_host,
                                                 port=self.db_port,
                                                 user=self.db_user,
                                                 passwd=self.db_passwd,
                                                 db=self.db_name)
        else:
            self.create_threaded_ssh_tunnel()
            # wait for a connection to the db

            timeout = time.time() + CONNECTION_TIMEOUT
            while time.time() < timeout:
                try:

                    self.db_connection = pymysql.connect(host='127.0.0.1',
                                                         port=self.local_port,
                                                         user=self.db_user,
                                                         passwd=self.db_passwd,
                                                         db=self.db_name)
                    # If the connection takes more than CONNECTION_TIMEOUT and still connects
                    # it shouldn't timeout
                    if self.db_connection:
                        break

                except pymysql.OperationalError as py_error:
                    # expecting an exception until the connection is established
                    logging.error("mysql connection failed. Retrying.. error: " + str(py_error))
                    pass
            else:
                # Connection failed
                raise RuntimeError("could not connect to %s:%d via %s@%s" %
                    (self.db_host, self.db_port, self.tunnel_username, self.tunnel_host))

        # execute the query
        if self.db_cursor is None:
            self.db_cursor = self.db_connection.cursor()
        self.db_cursor.execute(query_string)
        lrows = []
        for row in self.db_cursor.fetchall():
            lrows.append(list(row))
        df = pd.DataFrame()
        if len(lrows) > 0:
            colnames = tuple([desc[0] for desc in self.db_cursor.description])
            df = pd.DataFrame(lrows, columns=colnames, dtype=object)
        return df
