"""
Please see this for more help on forward tunnels:
https://github.com/paramiko/paramiko/blob/master/demos/forward.py
"""

# pylint: disable=no-member

import logging
import os
import select
import socket
import random
import SocketServer

import paramiko

logger = logging.getLogger(__name__)


SSH_DIR = os.path.expanduser("~/.ssh")
CONNECTION_TIMEOUT = 5 # seconds


class ForwardServer (SocketServer.ThreadingTCPServer):
    daemon_threads = True
    allow_reuse_address = True


class Handler (SocketServer.BaseRequestHandler):

    def handle(self):
        try:
            chan = self.ssh_transport.open_channel('direct-tcpip',
                                                   (self.chain_host, self.chain_port),
                                                   self.request.getpeername())
        except Exception, e:
            logger.warn('Incoming request to %s:%d failed: %s' % (self.chain_host,
                                                                  self.chain_port,
                                                                  repr(e)))
            return
        if chan is None:
            logger.warn('Incoming request to %s:%d was rejected by the SSH server.' %
                    (self.chain_host, self.chain_port))
            return

        logger.debug('Opened tunnel %r -> %r -> %r' % (self.request.getpeername(),
                                                      chan.getpeername(),
                                                      (self.chain_host, self.chain_port)))
        while True:
            r, w, x = select.select([self.request, chan], [], [])
            if self.request in r:
                data = self.request.recv(1024)
                if len(data) == 0:
                    break
                chan.send(data)
            if chan in r:
                data = chan.recv(1024)
                if len(data) == 0:
                    break
                self.request.send(data)

        chan.close()
        self.request.close()
        logger.debug('Tunnel to %s:%d was closed.' %
                    (self.chain_host, self.chain_port))


def forward_tunnel(local_port, remote_host, remote_port, transport, forward_server_queue):
    # this is a little convoluted, but lets me configure things for the Handler
    # object.  (SocketServer doesn't give Handlers any way to access the outer
    # server normally.)
    class SubHander(Handler):
        chain_host = remote_host
        chain_port = remote_port
        ssh_transport = transport
    forward_server = ForwardServer(('', local_port), SubHander)

    # returns a handle to the server
    forward_server_queue.put(forward_server)
    forward_server.serve_forever()

def create_tunnel(local_port,
                  middleman,
                  endpoint,
                  endpoint_port,
                  username,
                  port_address_msg_queue,
                  look_for_keys=True):
    """
    Creates an SSH tunnel. This tunnel can be kept alive in a separate process
    to allow access to databases and other secure resources.
    """

    # set up the tunnel
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

    # Unlike the Unix ssh command, Paramiko is too stupid to actually look for
    # the appropriate private key. So, we're going to help it out.
    if look_for_keys:
        for ssh_file in os.listdir(SSH_DIR):
            if ssh_file.endswith(".pub") or ssh_file in ["config", "authorized_keys", "known_hosts"]:
                continue

            try:
                private_key = paramiko.RSAKey.from_private_key_file(os.path.join(SSH_DIR, ssh_file))
                ssh.connect(middleman, username=username, pkey=private_key)
                break
            except (paramiko.AuthenticationException, paramiko.SSHException):
                pass
        else:
            # Tried all private keys; could not connect using any of them.
            raise paramiko.SSHException("could not find valid private key")
    else:
        ssh.connect(middleman, username=username)

    transport = ssh.get_transport()
    forward_tunnel(local_port, endpoint, endpoint_port, transport, port_address_msg_queue)


