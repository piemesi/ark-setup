"""
This module provides a Python interface to the SQL FT database.
It sets up a tunnel through the production bastion to connect
to the Production read replica.

In order to use this, you must have keys to access the bastion.

"""
from .sql_database import SQLDatabase
from ..credentials import get_production_db_password

class ProductionDatabase(SQLDatabase):
    """
    A SQLDatabase subclass specifically for the Production Database.
    """

    def __init__(self):
        super(ProductionDatabase, self).__init__(db_host='db-replica.devices.production.nest.com',
                                                 db_name='nestlabs_devices',
                                                 db_passwd=get_production_db_password())

    def __repr__(self):
        return "<nestpy.ProductionDatabase via %s>" % str(self)
