from .sql_database import SQLDatabase
from .balsam_device_tracking import BalsamDeviceTracking
from .ft_analytics_database import FTAnalyticsDatabase
from .ft_database import FTDatabase
from .ft_accounts_database import FTAccountsDatabase
from .ft_report_database import FTReportDatabase
from .production_analytics_database import ProductionAnalyticsDatabase
from .production_database import ProductionDatabase
from .production_accounts_database import ProductionAccountsDatabase
from .production_report_database import ProductionReportDatabase
from .validate_db_access import validate_db_access, validate_access

SQL_DATABASES = {
    'ft_analytics' : FTAnalyticsDatabase,
    'production_analytics' : ProductionAnalyticsDatabase,
    'ft_tier': FTDatabase,
    'production_tier': ProductionDatabase,
    'ft_accounts': FTAccountsDatabase,
    'production_accounts': ProductionAccountsDatabase,
    'ft_report': FTReportDatabase,
    'production_report': ProductionReportDatabase,
}
_tier_db_conn_map = {}
_tier_report_db_conn_map = {}
_tier_analytics_db_conn_map = {}


def get_db(tier, env):
    return SQL_DATABASES.get('_'.join([tier, env]), None)


# TODO:  Obsolete - phase out all below functions
def get_tier_database(tier):
    """
       Get a connection to the database for the specified tier.
        :param tier:
            name of the tier, 'ft' or 'production'
        :type tier:
            str

        :returns:
            the requested sql database object
        :rtype:
            nestpy.SQLDatabase
    """

    if tier == 'ft':
        return _tier_db_conn_map.setdefault(tier, FTDatabase())
    elif tier == 'production':
        return _tier_db_conn_map.setdefault(tier, ProductionDatabase())
    else:
        raise NotImplementedError('Parametric DBs supported for ft and production, not %s' % tier)


def get_tier_report_database(tier):
    """
       Get a connection to the report database for the specified tier.
        :param tier:
            name of the tier, 'ft' or 'production'
        :type tier:
            str

        :returns:
            the requested sql database object
        :rtype:
            nestpy.SQLDatabase
    """
    if tier == 'ft':
        return _tier_report_db_conn_map.setdefault(tier, FTReportDatabase())
    elif tier == 'production':
        return _tier_report_db_conn_map.setdefault(tier, ProductionReportDatabase())
    else:
        raise NotImplementedError('Parametric DBs supported for ft and production, not %s' % tier)


def get_tier_analytics_database(tier):
    """
       Get a connection to the analytics database for the specified tier.
        :param tier:
            name of the tier, 'ft' or 'production'
        :type tier:
            str

        :returns:
            the requested sql database object
        :rtype:
            nestpy.SQLDatabase
    """
    if tier == 'ft':
        return _tier_analytics_db_conn_map.setdefault(tier, FTAnalyticsDatabase())
    elif tier == 'production':
        return _tier_analytics_db_conn_map.setdefault(tier, ProductionAnalyticsDatabase())
    else:
        raise NotImplementedError('Parametric Report DBs supported for ft and production, not %s' % tier)


from .sql_lookup import (
    lookup_devices,
    lookup_device,
    lookup_devices_in_ss_event,
    lookup_ss_event,
    lookup_devices_in_rhr_event,
    lookup_rhr_event,
    lookup_devices_satisfying_criteria,
)
