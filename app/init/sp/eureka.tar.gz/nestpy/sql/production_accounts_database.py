from .sql_database import SQLDatabase
from ..credentials import get_ft_db_password


class ProductionAccountsDatabase(SQLDatabase):

    def __init__(self):
        super(ProductionAccountsDatabase, self).__init__(
            db_host='db-replica.accounts.production.nest.com',
            db_name='nestlabs_accounts',
            db_passwd=get_ft_db_password()
        )

    def __repr__(self):
        return "<nestpy.ProductionAccountsDatabase via %s>" % str(self)
