"""
This module provides a Python interface to the SQL production Analytics
database.
It sets up a tunnel through the production bastion to connect
to the Analytics read replica.

In order to use this, you must have keys to access the bastion.

"""
from .sql_database import SQLDatabase


class ProductionAnalyticsDatabase(SQLDatabase):
    """
    A SQLDatabase subclass specifically for the production Analytics Database.
    """

    def __init__(self):
        super(ProductionAnalyticsDatabase, self).__init__(db_host='analytics-replica.nestlabs.com',
                                                          db_name='analytics',
                                                          db_user='nestlabs_ro')

    def __repr__(self):
        return "<nestpy.ProductionAnalyticsDatabase via %s>" % str(self)
