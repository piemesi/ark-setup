"""
This module provides a Python interface to the SQL Production Report database.
It sets up a tunnel through the production bastion to connect
to the ProductionReport db.

In order to use this, you must have keys to access the bastion.

"""
from .sql_database import SQLDatabase
from ..credentials import get_production_db_password


class ProductionReportDatabase(SQLDatabase):
    """
    A SQLDatabase subclass specifically for the Production Database.
    """

    def __init__(self):
        super(ProductionReportDatabase, self).__init__(db_host='reportdb01.production.nest.com',
                                                       db_name='nestlabs_devices',
                                                       db_passwd=get_production_db_password())

    def __repr__(self):
        return "<nestpy.ProductionReportDatabase via %s>" % str(self)
