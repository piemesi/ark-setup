"""
This module provides a Python interface to the SQL FT Analytics database.
It sets up a tunnel through the production bastion to connect
to the Analytics read replica.

In order to use this, you must have keys to access the bastion.

"""
from .sql_database import SQLDatabase


class FTAnalyticsDatabase(SQLDatabase):
    """
    A SQLDatabase subclass specifically for the FT Analytics Database.
    """

    def __init__(self):
        super(FTAnalyticsDatabase, self).__init__(db_host='analytics-replica.nestlabs.com',
                                                  db_name='analytics_ft',
                                                  db_user='nestlabs_ro')

    def __repr__(self):
        return "<nestpy.FTAnalyticsDatabase via %s>" % str(self)
