"""
This module provides a Python interface to the SQL FT Report database.
It sets up a tunnel through the production bastion to connect
to the FTReport db.

In order to use this, you must have keys to access the bastion.

"""
from .sql_database import SQLDatabase
from ..credentials import get_ft_db_password


class FTReportDatabase(SQLDatabase):
    """
    A SQLDatabase subclass specifically for the FT Database.
    """

    def __init__(self):
        super(FTReportDatabase, self).__init__(db_host='reportdb01.ft.nest.com',
                                               db_name='nestlabs_devices',
                                               db_passwd=get_ft_db_password())

    def __repr__(self):
        return "<nestpy.FTReportDatabase via %s>" % str(self)
