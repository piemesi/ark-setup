import datetime
import json
import logging

import pytz
import pandas as pd

from ..aws import TIERS
from ..converters import get_tz_aware_datetime

from . import get_db

logger = logging.getLogger(__name__)

SUPPORTED_TIERS = TIERS.index.tolist()


def lookup_devices_in_tier_satisfying_criteria(tier,
                                               results,
                                               n_devices=None,
                                               start_date=None,
                                               end_date=None,
                                               device_type=None,
                                               zip_code=None,
                                               heating_type=None,
                                               heating_source=None,
                                               cooling_source=None,
                                               has_heat_pump=None,
                                               has_aux_heat=None,
                                               has_stage1_heat=None,
                                               has_stage2_heat=None,
                                               has_stage3_heat=None,
                                               has_stage1_cool=None,
                                               has_stage2_cool=None,
                                               learning_enabled=None,
                                               auto_away_enabled=None,
                                               random=False):
    """
    Get device details for a list of devices in specified tier that satisfy the specified criteria.

    :param tier:
        Name of the tier: 'production', 'ft', 'integration' or 'qa'.
    :type tier:
        str

    :param results:
        Pandas DataFrame containing device details.
    :type results:
        pandas.DataFrame

    :param n_devices:
        Number of devices limit
    :type n_devices:
        int

    :param start_date:
        Date before which the devices have to be activated
    :type start_date:
        Timezone-aware datetime or timezone-naive UTC datetime

    :param end_date:
        Date after which the devices have to have last connected to the service
    :type end_date:
        Timezone-aware datetime or timezone-naive UTC datetime

    :param device_type:
        Device type(s)
    :type device_type:
        str or list containing str

    :param zip_code:
        Zip code(s)
    :type zip_code:
        str or list containing str

    :param heating_type:
        Heating type(s) (e.g. forced-air, in-floor-radiant, radiator)
    :type heating_type:
        str or list containing str

    :param heating_source:
        Heating source(s) (e.g. gas, electric)
    :type heating_source:
        str or list containing str

    :param cooling_source:
        Cooling source(s) (e.g. gas, electric)
    :type cooling_source:
        str or list containing str

    :param has_heat_pump:
        Whether or not the devices should have a heat pump
    :type has_heat_pump:
        bool

    :param has_aux_heat:
        Whether or not the devices should have a auxiliary heating
    :type has_aux_heat:
        bool

    :param has_stage1_heat:
        Whether or not the devices should have stage 1 heating
    :type has_stage1_heat:
        bool

    :param has_stage2_heat:
        Whether or not the devices should have stage 2 heating
    :type has_stage2_heat:
        bool

    :param has_stage3_heat:
        Whether or not the devices should have stage 3 heating
    :type has_stage3_heat:
        bool

    :param has_stage1_cool:
        Whether or not the devices should have stage 1 cooling
    :type has_stage1_cool:
        bool

    :param has_stage2_cool:
        Whether or not the devices should have stage 2 cooling
    :type has_stage2_cool:
        bool

    :param learning_enabled:
        Whether or not the devices should have learning enabled
    :type learning_enabled:
        bool

    :param auto_away_enabled:
        Whether or not the devices should have Auto-Away enabled
    :type auto_away_enabled:
        bool

    :param random:
        Whether or not to look for a randomized group of devices that satisfy the requirements
    :type random:
        bool

    :returns:
        Pandas DataFrame containing device details.
    :rtype:
        pandas.DataFrame
    """

    def convert_arg_to_comma_separated_str(arg):
        if isinstance(arg, str):
            css = "'{}'".format(arg)
        else:
            css = ",".join(["'{}'".format(instance) for instance in arg])
        return css

    current_tier = TIERS[TIERS.index == tier].iloc[0]
    analytics = get_db(current_tier.analytics_database, 'analytics')
    db = analytics()

    query = ("select serial_number, mac_address, device_type, structure_id from etl_cz_devices")

    where_clause_list = ["service_environment = '{}'".format(current_tier.service_environment),
                         "mac_address is not null"]

    if start_date is not None:
        where_clause_list.append("activated_at < '{}'".format(get_tz_aware_datetime(start_date).strftime('%Y-%m-%d')))

    if end_date is not None:
        where_clause_list.append("connected_at > '{}'".format(get_tz_aware_datetime(end_date).strftime('%Y-%m-%d')))

    if device_type is not None:
        where_clause_list.append('device_type in ({})'.format(convert_arg_to_comma_separated_str(device_type)))

    if zip_code is not None:
        where_clause_list.append('postal_code in ({})'.format(convert_arg_to_comma_separated_str(zip_code)))

    if heating_type is not None:
        where_clause_list.append('heater_delivery in ({})'.format(convert_arg_to_comma_separated_str(heating_type)))

    if heating_source is not None:
        where_clause_list.append('heater_source in ({})'.format(convert_arg_to_comma_separated_str(heating_source)))

    if cooling_source is not None:
        where_clause_list.append('cooling_source in ({})'.format(convert_arg_to_comma_separated_str(cooling_source)))

    if has_heat_pump is not None:
        where_clause_list.append('has_heat_pump = {}'.format(json.dumps(has_heat_pump)))

    if has_aux_heat is not None:
        where_clause_list.append('has_aux_heat = {}'.format(json.dumps(has_aux_heat)))

    if has_stage1_heat is not None:
        where_clause_list.append('can_heat = {}'.format(json.dumps(has_stage1_heat)))

    if has_stage2_heat is not None:
        where_clause_list.append('has_x2_heat = {}'.format(json.dumps(has_stage2_heat)))

    if has_stage3_heat is not None:
        where_clause_list.append('has_x3_heat = {}'.format(json.dumps(has_stage3_heat)))

    if has_stage1_cool is not None:
        where_clause_list.append('can_cool = {}'.format(json.dumps(has_stage1_cool)))

    if has_stage2_cool is not None:
        where_clause_list.append('has_x2_cool = {}'.format(json.dumps(has_stage2_cool)))

    if learning_enabled is not None:
        where_clause_list.append('learning_mode = {}'.format(json.dumps(learning_enabled)))

    if auto_away_enabled is not None:
        where_clause_list.append('auto_away_enable = {}'.format(json.dumps(auto_away_enabled)))

    if len(where_clause_list) > 0:
        where_clause = " and ".join(where_clause_list)
        query = " where ".join([query, where_clause])

    if random:
        order_by_clause = 'order by rand()'
        query = " ".join([query, order_by_clause])

    if n_devices is not None:
        limit_clause = 'limit {}'.format(n_devices)
        query = " ".join([query, limit_clause])

    result = db.query(query)

    if result.empty:
        logger.debug("No corresponding devices found on '{}' tier".format(tier))
    else:
        result["tier"] = tier
        results = results.append(result)

    return results


def lookup_devices_in_tier(devices, tier, results):
    """
    Get device details for a list of devices in specified tier.

    :param devices:
        List of devices containing mac addresses and/or serial numbers.
    :type devices:
        iterable

    :param tier:
        Name of the tier: 'production', 'ft', 'integration' or 'qa'.
    :type tier:
        str

    :param results:
        Pandas DataFrame containing device details.
    :type results:
        pandas.DataFrame

    :returns:
        Pandas DataFrame containing device details.
    :rtype:
        pandas.DataFrame
    """

    devices_tuple = ",".join(["'{}'".format(device) for device in devices])

    current_tier = TIERS[TIERS.index == tier].iloc[0]

    analytics = get_db(current_tier.analytics_database, 'analytics')
    db = analytics()

    result = db.query("select serial_number, mac_address, device_type, structure_id "
                      "from etl_cz_devices where service_environment = '{0}' "
                      "and (serial_number in ({1}) or mac_address in ({1}))"
                      .format(current_tier.service_environment, devices_tuple))

    if result.empty:
        logger.debug("No corresponding devices found on '{}' tier".format(tier))
    else:
        result["tier"] = tier
        results = results.append(result)

    return results


def verify_lookup_devices_results(results):

    count_missing_mac_address = results.mac_address.isnull().sum()

    if count_missing_mac_address > 0:
        logger.warn("Discarding {} device(s) without a valid mac address".format(count_missing_mac_address))
        results = results[results.mac_address.notnull()]

    count_missing_data = results.isnull().any(1).sum()

    if count_missing_data > 0:
        logger.warn("Found missing data for {} device(s)".format(count_missing_data))

    if results.empty:
        raise ValueError("No corresponding devices found")
    else:
        logger.info("Found {} device(s) that satisfy the specified criteria".format(len(results)))

    if not results.index.is_unique:
        results.index = range(0, len(results))

    return results


def lookup_devices_satisfying_criteria(n_devices=None,
                                       tier=None,
                                       start_date=None,
                                       end_date=None,
                                       device_type=None,
                                       zip_code=None,
                                       heating_type=None,
                                       heating_source=None,
                                       cooling_source=None,
                                       has_heat_pump=None,
                                       has_aux_heat=None,
                                       has_stage1_heat=None,
                                       has_stage2_heat=None,
                                       has_stage3_heat=None,
                                       has_stage1_cool=None,
                                       has_stage2_cool=None,
                                       learning_enabled=None,
                                       auto_away_enabled=None,
                                       random=False):
    """
    Get device details for a random list of devices that satisfy the specified criteria.

    :param n_devices:
        Number of devices limit
    :type n_devices:
        int

    :param tier:
        Name of the tier: 'production', 'ft', 'integration' or 'qa'.
        If not specified, it will look for data in all of these tiers.
    :type tier:
        str

    :param start_date:
        Date before which the devices have to be activated
    :type start_date:
        Timezone-aware datetime or timezone-naive UTC datetime

    :param end_date:
        Date after which the devices have to have last connected to the service
    :type end_date:
        Timezone-aware datetime or timezone-naive UTC datetime

    :param device_type:
        Device type(s)
    :type device_type:
        str or list containing str

    :param zip_code:
        Zip code(s)
    :type zip_code:
        str or list containing str

    :param heating_type:
        Heating type(s) (e.g. forced-air, in-floor-radiant, radiator)
    :type heating_type:
        str or list containing str

    :param heating_source:
        Heating source(s) (e.g. gas, electric)
    :type heating_source:
        str or list containing str

    :param cooling_source:
        Cooling source(s) (e.g. gas, electric)
    :type cooling_source:
        str or list containing str

    :param has_heat_pump:
        Whether or not the devices should have a heat pump
    :type has_heat_pump:
        bool

    :param has_aux_heat:
        Whether or not the devices should have auxiliary heating
    :type has_aux_heat:
        bool

    :param has_stage1_heat:
        Whether or not the devices should have stage 1 heating
    :type has_stage1_heat:
        bool

    :param has_stage2_heat:
        Whether or not the devices should have stage 2 heating
    :type has_stage2_heat:
        bool

    :param has_stage3_heat:
        Whether or not the devices should have stage 3 heating
    :type has_stage3_heat:
        bool

    :param has_stage1_cool:
        Whether or not the devices should have stage 1 cooling
    :type has_stage1_cool:
        bool

    :param has_stage2_cool:
        Whether or not the devices should have stage 2 cooling
    :type has_stage2_cool:
        bool

    :param learning_enabled:
        Whether or not the devices should have learning enabled
    :type learning_enabled:
        bool

    :param auto_away_enabled:
        Whether or not the devices should have Auto-Away enabled
    :type auto_away_enabled:
        bool

    :param random:
        Whether or not to look for a randomized group of devices that satisfy the requirements
    :type random:
        bool

    :returns:
        Pandas DataFrame containing device details.
    :rtype:
        pandas.DataFrame
    """

    if tier is not None and tier not in SUPPORTED_TIERS:
        raise ValueError("'{}' tier is not supported".format(tier))

    results = pd.DataFrame(columns=["serial_number", "mac_address", "device_type", "structure_id", "tier"])

    if tier is None:
        lookup_tiers = SUPPORTED_TIERS
    else:
        lookup_tiers = [tier]

    for lookup_tier in lookup_tiers:

        results = lookup_devices_in_tier_satisfying_criteria(tier=lookup_tier,
                                                             results=results,
                                                             n_devices=n_devices,
                                                             start_date=start_date,
                                                             end_date=end_date,
                                                             device_type=device_type,
                                                             zip_code=zip_code,
                                                             heating_type=heating_type,
                                                             heating_source=heating_source,
                                                             cooling_source=cooling_source,
                                                             has_heat_pump=has_heat_pump,
                                                             has_aux_heat=has_aux_heat,
                                                             has_stage1_heat=has_stage1_heat,
                                                             has_stage2_heat=has_stage2_heat,
                                                             has_stage3_heat=has_stage3_heat,
                                                             has_stage1_cool=has_stage1_cool,
                                                             has_stage2_cool=has_stage2_cool,
                                                             learning_enabled=learning_enabled,
                                                             auto_away_enabled=auto_away_enabled,
                                                             random=random)

        if n_devices is not None and len(results) == n_devices:
            break

    results = verify_lookup_devices_results(results)

    return results


def lookup_devices(devices, tier=None):
    """
    Get device details for a list of devices.

    :param devices:
        List of devices containing mac addresses and/or serial numbers.
    :type devices:
        iterable

    :param tier:
        Name of the tier: 'production', 'ft', 'integration' or 'qa'.
        If not specified, it will look for data in all of these tiers.
    :type tier:
        str

    :returns:
        Pandas DataFrame containing device details.
    :rtype:
        pandas.DataFrame
    """

    if tier is not None and tier not in SUPPORTED_TIERS:
        raise ValueError("'{}' tier is not supported".format(tier))

    results = pd.DataFrame(columns=["serial_number", "mac_address", "device_type", "structure_id", "tier"])

    if tier is None:
        lookup_tiers = SUPPORTED_TIERS
    else:
        lookup_tiers = [tier]

    for lookup_tier in lookup_tiers:

        results = lookup_devices_in_tier(devices, tier=lookup_tier, results=results)

        if len(results) == len(devices):
            break

    results = verify_lookup_devices_results(results)

    macs_and_serials_found = results.mac_address.tolist() + results.serial_number.tolist()
    devices_not_found = [device for device in devices if device not in macs_and_serials_found]
    if devices_not_found:
        logger.warn("Devices not found: %s", devices_not_found)

    return results


def lookup_device(device_id, tier=None):
    """
    Get device details for a specified device.

    :param device_id:
        Mac address or serial number.
    :type device:
        str

    :param tier:
        Name of the tier: 'production', 'ft', 'integration' or 'qa'.
        If not specified, it will look for data in all of these tiers.
    :type tier:
        str

    :returns:
        Pandas DataFrame containing device details.
    :rtype:
        pandas.DataFrame
    """

    return lookup_devices([device_id], tier=tier).iloc[0]


def lookup_mac_addresses(serial_numbers, tier=None):
    """
    Get mac addresses for a list of serial numbers.

    :param serial_numbers:
        List of serial numbers.
    :type serial_numbers:
        iterable object

    :param tier:
        Name of the tier: 'production', 'ft', 'integration' or 'qa'.
        If not specified, it will look for data in all of these tiers
    :type tier:
        str

    :returns:
        List with corresponding serial numbers.
    :rtype:
        list
    """

    devices = lookup_devices(serial_numbers, tier=tier)

    return devices.mac_address.values.tolist()


def lookup_serial_numbers(mac_addresses, tier=None):
    """
    Get serial numbers for a list of mac addresses.

    :param mac_addresses:
        List of mac addresses.
    :type mac_addresses:
        iterable object

    :param tier:
        Name of the tier: 'production', 'ft', 'integration' or 'qa'.
        If not specified, it will look for data in all of these tiers
    :type tier:
        str

    :returns:
        List with corresponding mac addresses.
    :rtype:
        list
    """

    devices = lookup_devices(mac_addresses, tier=tier)

    return devices.serial_number.values.tolist()


def lookup_devices_in_ss_event(event_id, tier):
    """
    Get device details for devices in the specified Seasonal Savings event.

    :param event_id:
        Event id for Seasonal Savings event.
    :type event_id:
        str

    :param tier:
        Name of the tier: 'production' or 'ft'.
    :type tier:
        str

    :returns:
        Pandas DataFrame containing device details.
    :rtype:
        pandas.DataFrame
    """

    # db = get_tier_database(tier)
    tier_db = get_db(tier, 'tier')
    db = tier_db()

    result = db.query("select "
                      "sn as serial_number, "
                      "state, "
                      "stop_reason, "
                      "presenting_tuneup_time, "
                      "running_start_time, "
                      "stop_time "
                      "from tuneup_instances "
                      "where job_id = '{}'".format(event_id))

    if result.empty:
        raise ValueError("No instances found for event id: '{}'".format(event_id))

    for time_column in ['presenting_tuneup_time', 'running_start_time', 'stop_time']:
        result[time_column] = (result[time_column]
                               .apply(datetime.datetime.utcfromtimestamp)
                               .apply(get_tz_aware_datetime))

    devices = lookup_devices(result.serial_number.tolist(), tier=tier)

    return devices.merge(result, on='serial_number')


def lookup_ss_event(event_id, tier):
    """
    Get event details for specified Seasonal Savings event.
    :param event_id:
        Event id for Seasonal Savings event.
    :type event_id:
        str

    :param tier:
        Name of the tier: 'production' or 'ft'.
    :type tier:
        str

    :returns:
        Pandas Series containing event details.
    :rtype:
        pandas.Series
    """

    tier_db = get_db(tier, 'tier')
    db = tier_db()

    job_result = db.query("select "
                          "id as event_id, "
                          "debug_name, "
                          "qual_start_time_local, "
                          "qual_stop_time_local, "
                          "afterglow_length_seconds, "
                          "set_point_type, "
                          "paused_expiration_seconds "
                          "from tuneup_jobs "
                          "where id = '{}'".format(event_id))

    if job_result.empty:
        raise ValueError("No event found for event id: '{}'".format(event_id))

    event = job_result.iloc[0]
    for datetime_column in ['qual_start_time_local', 'qual_stop_time_local']:
        event[datetime_column] = get_tz_aware_datetime(event[datetime_column])

    stages_result = db.query("select stage, number_updates from tuneup_stages where job_id = '{}'".format(event_id))

    event['event_duration_days'] = stages_result.number_updates.sum()

    return event


def lookup_devices_in_rhr_event(event_id, tier):
    """
    Get device details for devices in the specified Rush Hour Rewards event.

    :param event_id:
        Event id for Rush Hour Rewards event.
    :type event_id:
        str

    :param tier:
        Name of the tier: 'production' or 'ft'.
    :type tier:
        str

    :returns:
        Pandas DataFrame containing device details.
    :rtype:
        pandas.DataFrame
    """

    tier_db = get_db(tier, 'tier')
    db = tier_db()

    result = db.query("select "
                      "id "
                      "from demand_response_event "
                      "where exid = '{}'".format(event_id))

    if result.empty:
        raise ValueError("No events found with event id: '{}'".format(event_id))

    result = db.query("select "
                      "serial_number, "
                      "state, "
                      "stop_reason "
                      "from demand_response_event_instance "
                      "where demand_response_event_id = '{}'".format(result.id[0]))

    if result.empty:
        raise ValueError("No instances found with event id: '{}'".format(event_id))

    devices = lookup_devices(result.serial_number.tolist(), tier=tier)

    return devices.merge(result, on='serial_number')


def lookup_rhr_event(event_id, tier):
    """
    Get event details for a specified Rush Hour Rewards event.

    :param event_id:
        Event id for the Rush Hour Rewards event
    :type event_id:
        str

    :param tier:
        Name of the tier: 'production' or 'ft'
    :type tier:
        str

    :returns:
        Pandas Series containing event details
    :rtype:
        pandas.Series
    """

    tier_db = get_db(tier, 'tier')
    db = tier_db()

    result = db.query("select "
                      "exid as event_id, "
                      "debug_name, "
                      "optimization_parameters, "
                      "qual_start_time_local, "
                      "qual_stop_time_local, "
                      "presentation_time_local, "
                      "start_time_local, "
                      "length_preparation_seconds, "
                      "length_event_seconds, "
                      "timezone_str "
                      "from demand_response_event "
                      "where exid = '{}'".format(event_id))

    if result.empty:
        raise ValueError("No event found for event id: '{}'".format(event_id))

    event = result.iloc[0]

    for datetime_column in ['qual_start_time_local',
                            'qual_stop_time_local',
                            'presentation_time_local',
                            'start_time_local']:

        event[datetime_column[:-6]] = get_tz_aware_datetime(event[datetime_column],
                                                            timezone=pytz.timezone(event.timezone_str))
        event = event.drop(datetime_column)

    event['preconditioning_end_time'] = (event['start_time'] +
                                         datetime.timedelta(0, event['length_preparation_seconds']))
    event['end_time'] = (event['start_time'] +
                         datetime.timedelta(0, event['length_event_seconds']))

    if event['length_preparation_seconds'] == 0:
        event['instant'] = True
    else:
        event['instant'] = False

    optimization_parameters = json.loads(event.optimization_parameters)

    for optimization_parameter in ['weight_temperature_deviation',
                                   'event_maximum_displayed_offset',
                                   'cycle_length_minimum']:

        event[optimization_parameter] = float(optimization_parameters[optimization_parameter])

    event['set_point_type'] = str(optimization_parameters['setpoint_type'])

    event = event.drop(['length_preparation_seconds',
                        'length_event_seconds',
                        'timezone_str',
                        'optimization_parameters'])

    return event


def lookup_structure(structure_id, tier):
    """
    :param structure_id:
        Structure id
    :type structure_id:
        int

    :param tier:
        Name of tier: 'production' or 'ft'
    :type tier:
        str

    :returns:
        Pandas series containing structure details
    :rtype:
        pandas.Series
    """

    tier_db = get_db(tier, 'analytics')
    db = tier_db()

    result = db.query("select id as structure_id, structure_uuid, user_id "
                      "from structures where id={}".format(structure_id))

    return result.iloc[0]


def lookup_structure_ids(n_structures, tier, random=False):
    """
    :param n_structures:
        Number of structures to lookup
    :type n_structures:
        int

    :param tier:
        Name of tier: 'production' or 'ft'
    :type tier:
        str

    :param random:
        Whether to populate output list at random
    :type random:
        bool

    :returns:
        List of structure ids
    :rtype:
        list
    """

    tier_db = get_db(tier, 'analytics')
    db = tier_db()

    if random:
        order_by = 'rand()'
    else:
        order_by = 'structure_id'

    result = db.query("select distinct structure_id "
                      "from etl_cz_devices "
                      "where (device_type is not null) and (structure_id is not null) "
                      "order by {} "
                      "limit {}".format(order_by, n_structures))

    return list(result['structure_id'])


def lookup_devices_in_structure(structure_id, tier):
    """
    Note that quartz devices are specified by device_uuid, not mac_address.

    :param structure_id:
        Structure id
    :type structure_id:
        int

    :param tier:
        Name of tier: 'production' or 'ft'
    :type tier:
        str

    :returns:
        Devices in structure
    :rtype:
        pandas.DataFrame
    """
    analytics = get_db(tier, "analytics")
    db = analytics()

    result = db.query(
        "select mac_address, device_uuid, serial_number, device_type "
        "from etl_cz_devices where structure_id={}".format(structure_id)
    )
    return result


def lookup_structure_devices(structure_ids, tier):
    """
    :param structure_ids:
        List of structure ids
    :type structure_ids:
        list

    :param tier:
        Name of tier: 'production' or 'ft'
    :type tier:
        str

    :returns:
        Devices breakdown of structures
    :rtype:
        pandas.DataFrame
    """

    structures_tuple = ",".join(["{}".format(structure) for structure in structure_ids])

    analytics = get_db(tier, 'analytics')
    db = analytics()

    result = db.query("select structure_id, device_type, count(*) as device_count "
                      "from etl_cz_devices "
                      "where structure_id in ({}) "
                      "group by structure_id, device_type".format(structures_tuple))

    result = result.pivot(index='structure_id', columns='device_type', values='device_count').fillna(0)

    return result


def lookup_user_ids(structure_id, tier):
    """
    :param structure_id:
        Structure id
    :type structure_id:
        list

    :param tier:
        Name of tier: 'production' or 'ft'
    :type tier:
        str

    :returns:
        List of user ids for structure
    :rtype:
        list
    """
    tier_db = get_db(tier, 'tier')
    db = tier_db()

    structure_result = db.query(
        "select user_id from structures where id = '{}'".format(structure_id)
    )
    structure_member_result = db.query(
        "select user_id from structure_members where structure_id = '{}'".format(structure_id)
    )
    result = structure_result.append(structure_member_result)
    if not result.empty:
        user_ids = result['user_id'].tolist()
    else:
        user_ids = []
    return user_ids


def lookup_mobile_device_ids(structure_id, tier):
    """
    :param structure_id:
        Structure id
    :type structure_id:
        list

    :param tier:
        Name of tier: 'production' or 'ft'
    :type tier:
        str

    :returns:
        List of mobile device ids for structure
    :rtype:
        list
    """
    user_ids = lookup_user_ids(structure_id, tier)

    if user_ids:
        accounts_db = get_db(tier, 'accounts')
        db = accounts_db()

        result = db.query(
            "select device_id from mobile_devices where user_id in ({})".format(", ".join(map(str, user_ids)))
        )
        if not result.empty:
            device_ids = result['device_id'].tolist()
        else:
            device_ids = []
    else:
        device_ids = []
    return device_ids
