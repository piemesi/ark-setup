"""
Methods for verifying access to the Nest Databases
"""
import logging

from .ft_analytics_database import FTAnalyticsDatabase
from .ft_database import FTDatabase
from .ft_report_database import FTReportDatabase
from .production_analytics_database import ProductionAnalyticsDatabase
from .production_database import ProductionDatabase
from .production_report_database import ProductionReportDatabase


logger = logging.getLogger(__name__)


def validate_db_access(clazz):
    logger.info("Testing connection using database class [%s]", clazz)
    db = clazz()
    try:
        db.query("select count(*) as count from devices")
    except:
        logger.error("Connection with database class [%s] failed." % clazz)
        raise


def validate_access():

    logger.info("Validating database access.")

    for clazz in [FTAnalyticsDatabase,
                  FTDatabase,
                  FTReportDatabase,
                  ProductionAnalyticsDatabase,
                  ProductionDatabase,
                  ProductionReportDatabase]:
        validate_db_access(clazz)

    logger.info("Database access validation complete.")
