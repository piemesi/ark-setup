from .sql_database import SQLDatabase
from ..credentials import get_ft_db_password


class FTAccountsDatabase(SQLDatabase):

    def __init__(self):
        super(FTAccountsDatabase, self).__init__(
            db_host='db-replica.accounts.ft.nest.com',
            db_name='nestlabs_accounts',
            db_passwd=get_ft_db_password()
        )

    def __repr__(self):
        return "<nestpy.FTAccountsDatabase via %s>" % str(self)
