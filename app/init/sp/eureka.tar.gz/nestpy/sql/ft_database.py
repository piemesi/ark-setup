"""
This module provides a Python interface to the SQL FT database.
It sets up a tunnel through the production bastion to connect
to the FT read replica.

In order to use this, you must have keys to access the bastion.

"""
from .sql_database import SQLDatabase
from ..credentials import get_ft_db_password


class FTDatabase(SQLDatabase):
    """
    A SQLDatabase subclass specifically for the FT Database.
    """

    def __init__(self):
        super(FTDatabase, self).__init__(db_host='db-replica.devices.ft.nest.com',
                                         db_name='nestlabs_devices',
                                         db_passwd=get_ft_db_password())

    def __repr__(self):
        return "<nestpy.FTDatabase via %s>" % str(self)

