"""
This module provides a Python interface to the SQL Balsam Tracking database.
Unlike our other SQL interfaces, this does not use a tunnel as the DB is open to the world.

"""
from . import SQLDatabase


class BalsamDeviceTracking(SQLDatabase):
    """
    A SQLDatabase subclass specifically for the FT Analytics Database.
    """

    def __init__(self):
        super(BalsamDeviceTracking, self).__init__(tunnel_host=None,
                                                   tunnel_username=None,
                                                   db_host='itrack.cpyi4jeqwfek.us-east-1.rds.amazonaws.com',
                                                   db_port=3306,
                                                   db_name='bdl',
                                                   db_user='iTrackAdmin',
                                                   db_passwd='e8fMyH9sKRyrVCtC')

    def __repr__(self):
        return "<nestpy.BalsamDeviceTracking via %s>" % str(self)
