import functools
import logging
import os
import pandas as pd

from ..cache import Cache
from ..groups import DeviceGroup
from ..groups.function_applicators import (serial_device_group_function_applicator,
                                           parallel_device_group_function_applicator)
from .. import env

logger = logging.getLogger(__name__)


class EventReporter(object):
    """
    Provides infrastructure to load and cache event stats for an arbitrary event for cross-platform devices.

    A custom event stats loader function can be specified by the user, which loads the relevant event stats (e.g. by
    loading and extracting from a device history). The output of this function should be a dictionary containing the
    event stats, which is then cached locally per device, and later aggregated into a single internal data frame.

    >>> import nestpy

    Example:

    >>> def event_stats_loader(device):
    >>>     return {'device_id': device.mac_address}

    >>> event_reporter = nestpy.reporting.EventReporter(['18b430047f40', '18b4302a28da', '18b43000002366e5'], 'TEST')

    >>> event_reporter.load_and_cache_event_stats(event_stats_loader)

    >>> event_reporter.event_stats
            mac_address         device_id
    0      18b430047f40      18b430047f40
    1      18b4302a28da      18b4302a28da
    2  18b43000002366e5  18b43000002366e5
    """

    EVENT_STATS = 'event_stats'

    def __init__(self, devices, event_id):

        self.dg = DeviceGroup(devices)
        self.event_id = event_id
        self.event_stats = None
        self.cache_destination = os.path.join(env.cache_destination(), self.event_id)
        self.cache = functools.partial(Cache, cache_destination=self.cache_destination)

        self._merge_event_stats()

    def __repr__(self):

        if not self.dg.devices.empty:
            output = "<nestpy.EventReporter for event '{}' with {} devices>".format(self.event_id,
                                                                                    len(self.dg.devices))
        else:
            output = "<nestpy.EventReporter for event '{}'>".format(self.event_id)

        return output

    def clear_cache(self):

        logger.debug("Clearing event stats cache...")

        cache_event = self.cache(cache_id=self.event_id)
        cache_event.clear()

        self.event_stats = None

    def load_and_cache_event_stats(self, event_stats_loader, threads=10):

        if self.event_stats is not None:
            raise ValueError("Already cached event stats for event '{}'. "
                             "Use 'clear_cache' method to clear cached event stats".format(self.event_id))

        logger.info("Loading and caching event stats to destination: {}".format(self.cache_destination))

        parallel_device_group_function_applicator(self.dg,
                                                  functools.partial(self._cache_event_stats,
                                                                    event_stats_loader=event_stats_loader),
                                                  threads=threads)
        self._collect_and_merge_event_stats()

    def _cache_event_stats(self, device, event_stats_loader):

        logger.debug("{}: Sending device metadata to event stats loader...".format(device.mac_address))

        event_stats = event_stats_loader(device)

        if isinstance(event_stats, dict):

            logger.debug("{}: Caching event stats...".format(device.mac_address))

            cache_device = self.cache(cache_id=device.mac_address)
            cache_device[self.EVENT_STATS] = pd.DataFrame.from_dict({device.mac_address: event_stats}, orient='index')

    def _collect_and_merge_event_stats(self):

        self._collect_event_stats()
        self._merge_event_stats()

    def _collect_event_stats(self):

        logger.debug("Collecting event stats...")

        serial_device_group_function_applicator(self.dg,
                                                self._append_event_stats)

    def _append_event_stats(self, device):

        cache_device = self.cache(cache_id=device.mac_address)
        cache_event = self.cache(cache_id=self.event_id)

        if cache_device[self.EVENT_STATS] is not None:

            logger.debug("{}: Appending event stats to event cache...".format(device.mac_address))

            cache_event.update(self.EVENT_STATS, cache_device[self.EVENT_STATS])
            cache_device.clear()

    def _merge_event_stats(self):

        cache_event = self.cache(cache_id=self.event_id)
        event_stats = cache_event[self.EVENT_STATS]

        if event_stats is not None:

            logger.debug("Merging event stats into internal data frame...")

            self.event_stats = pd.merge(self.dg.devices,
                                        event_stats,
                                        left_on=self.dg.MAC_ADDRESS,
                                        right_index=True,
                                        how='outer')