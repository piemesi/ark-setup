import datetime
import logging

import numpy as np

from ..event_reporter import EventReporter
from ...converters.time_converters import datetime_index_to_epoch_time_array, timestamp_series_to_epoch_time_array
from ...groups.function_applicators import device_history_loader
from ...scriptutils import drop_consecutive_duplicates, weighted_average, set_timeframe
from ...sql import lookup_devices_in_rhr_event, lookup_rhr_event
from ...structures import Diamond


logger = logging.getLogger(__name__)


class RushHourRewards(EventReporter):
    """
    Manages and extracts event stats for a group of devices in a specified Rush Hour Rewards event.

    Has to be called with a valid Rush Hour Rewards event id and the corresponding event tier. Once these are
    specified, a database lookup is done for the event and the underlying devices. The event details are stored
    as instance variables, whereas the device details are contained in a DeviceGroup.

    >>> import nestpy

    Example:

    >>> nestpy.RushHourRewards('44cc0c61-1b41-4bb8-a761-6bb9d7279d97', tier='production')
    <nestpy.RushHourRewards for event '44cc0c61-1b41-4bb8-a761-6bb9d7279d97' with 406 devices (341 j49, 65 diamond)>

    The class method 'get_event_stats' allows one to extract a list of relevant metrics from all devices in the
    specified event. In addition to this, the instance method 'get_event_stats' allows one to extract these
    metrics for a specified list of devices in the event.
    """

    EVENT_TYPES = ['DRAlgorithmResults',
                   'AdvanceDRState',
                   'DRSpeedBump',
                   'SetpointRampTrajectory',
                   'BufferedTemperature',
                   'CurrentState',
                   'UpdateStateResults',
                   'NewSetPoint',
                   'Weather']
    REQUIRED_METADATA = ['mac_address', 'device_type', 'tier']

    def __init__(self, event_id, tier):

        event = lookup_rhr_event(event_id, tier=tier)
        devices = lookup_devices_in_rhr_event(event_id, tier=tier)

        for metadata in self.REQUIRED_METADATA:
            if metadata not in devices.columns:
                raise ValueError("Device metadata is missing a required '{}' field".format(metadata))

        super(RushHourRewards, self).__init__(devices=devices[devices.device_type.isin(Diamond.DEVICE_TYPES)],
                                              event_id=event_id)

        self.event_id = event.event_id
        self.debug_name = event.debug_name
        self.qual_start_time = event.qual_start_time
        self.qual_stop_time = event.qual_stop_time
        self.start_time = event.start_time
        self.preconditioning_end_time = event.preconditioning_end_time
        self.end_time = event.end_time
        self.instant = event.instant
        self.weight_temperature_deviation = event.weight_temperature_deviation
        self.event_maximum_displayed_offset = event.event_maximum_displayed_offset
        self.cycle_length_minimum = event.cycle_length_minimum
        self.set_point_type = event.set_point_type

    def __repr__(self):

        if self.event_id:
            device_type_counts = self.dg.devices.device_type.value_counts()

            if not device_type_counts.empty:
                device_type_counts_str = ", ".join(["{} {}".format(device_type_counts[device_type], device_type)
                                                    for device_type in device_type_counts.index.values])
                output = "<nestpy.RushHourRewards for event '{}' with {} devices ({})>".format(self.event_id,
                                                                                               len(self.dg.devices),
                                                                                               device_type_counts_str)
            else:
                output = "<nestpy.RushHourRewards for event '{}'>".format(self.event_id)
        else:
            output = "<nestpy.RushHourRewards>"

        return output

    @classmethod
    def get_event_stats(cls,
                        event_id,
                        tier,
                        threads=10):
        """
        Look up and load the device histories for a specified Rush Hour Rewards event,
        extract relevant event statistics from them and store these in an internal data frame.

        :param event_id:
            Rush Hour Rewards event id
        :type devices:
            str

        :param tier:
            Name of the tier: 'production' or 'ft'.
        :type tier:
            str

        :returns:
            The RushHourRewards class with events stats stored as results
        :rtype:
            nestpy.RushHourRewards
        """

        rhr = cls(event_id, tier)

        super(RushHourRewards, rhr).load_and_cache_event_stats(rhr._event_stats_loader,
                                                               threads=threads)

        return rhr

    def _event_stats_loader(self, device):

        try:
            if device.device_type in Diamond.DEVICE_TYPES:

                logger.debug("{}: Loading device history...".format(device.mac_address))

                device_history = device_history_loader(device,
                                                       start_date=self.qual_start_time-datetime.timedelta(days=1),
                                                       end_date=self.end_time+datetime.timedelta(days=1),
                                                       event_types=self.EVENT_TYPES,
                                                       to_local_time=True)

                if device_history is not None:

                    logger.debug("{}: Loading event stats...".format(device.mac_address))

                    event_stats = {}

                    event_stats.update(self._get_states_and_stop_reasons(device_history))
                    event_stats.update(self._get_load_shift(device_history))
                    event_stats.update(self._get_temperature_deviation(device_history))
                    event_stats.update(self._get_speed_bump_stats(device_history))

                    return event_stats

        except Exception, e:
            logger.exception(e)

    def _get_states_and_stop_reasons(self, device_history):

        result = {}

        if 'AdvanceDRState' in device_history:

            advance_dr_state = (device_history.AdvanceDRState[device_history
                                .AdvanceDRState.ID == self.event_id])

            new_state_index = drop_consecutive_duplicates(advance_dr_state.NewState).index

            unique_advance_dr_state = advance_dr_state[advance_dr_state.index.isin(new_state_index)]
            new_state_seconds_held = np.diff(datetime_index_to_epoch_time_array(new_state_index))

            for index in range(len(unique_advance_dr_state)):

                new_key = '{} -> {}'.format(unique_advance_dr_state.OldState[index],
                                            unique_advance_dr_state.NewState[index])

                if new_key not in result:
                    result[new_key] = unique_advance_dr_state.StopReason[index]

                if index != len(unique_advance_dr_state)-1:
                    if unique_advance_dr_state.NewState[index] in result:
                        result[unique_advance_dr_state.NewState[index]] += new_state_seconds_held[index]
                    else:
                        result[unique_advance_dr_state.NewState[index]] = new_state_seconds_held[index]

        return result

    def _get_load_shift(self, device_history):

        result = {}

        if 'DROptimizerBaselineModel' in device_history and 'HVACState' in device_history:

            dr_optimizer_baseline_model = (device_history.DROptimizerBaselineModel[device_history
                                           .DROptimizerBaselineModel.EventID == self.event_id])

            schedule_mode = '{}ing'.format(self.set_point_type.capitalize())

            for series_title, series in [('hvac_runtime',
                                          device_history.HVACState[schedule_mode]),
                                         ('hvac_runtime_baseline_model',
                                          dr_optimizer_baseline_model[schedule_mode])]:

                for time_frame_title, start_time, end_time in [('preconditioning',
                                                                self.start_time + datetime.timedelta(0, 5),
                                                                self.preconditioning_end_time),
                                                               ('event',
                                                                self.preconditioning_end_time,
                                                                self.end_time)]:

                    if time_frame_title == 'preconditioning' and self.instant:
                        continue

                    result['{}_{}'.format(series_title,
                                          time_frame_title)] = weighted_average(series,
                                                                                interpolation_method='zero',
                                                                                start_time=start_time,
                                                                                end_time=end_time)

        return result

    def _get_temperature_deviation(self, device_history):

        result = {}

        if 'DRTemperatureDeviationActual' in device_history and 'DRTemperatureDeviationVisible' in device_history:

            dr_temperature_deviation_actual = (device_history.DRTemperatureDeviationActual[device_history
                                               .DRTemperatureDeviationActual.EventID == self.event_id])
            dr_temperature_deviation_visible = (device_history.DRTemperatureDeviationVisible[device_history
                                                .DRTemperatureDeviationVisible.EventID == self.event_id])

            for series_title, series, interpolation_method in [('temperature_deviation_actual',
                                                                dr_temperature_deviation_actual.TemperatureDeviation,
                                                                'time'),
                                                               ('temperature_deviation_visible',
                                                                dr_temperature_deviation_visible.TemperatureDeviation,
                                                                'zero')]:

                for time_frame_title, start_time, end_time in [('preconditioning',
                                                                self.start_time + datetime.timedelta(0, 5),
                                                                self.preconditioning_end_time),
                                                               ('event',
                                                                self.preconditioning_end_time,
                                                                self.end_time)]:

                    if time_frame_title == 'preconditioning' and self.instant:
                        continue

                    for statistic in ['avg', 'min', 'max']:

                        if statistic == 'avg':
                            statistic_function = weighted_average
                        else:
                            statistic_function = set_timeframe

                        temperature_deviation = statistic_function(series,
                                                                   interpolation_method=interpolation_method,
                                                                   start_time=start_time,
                                                                   end_time=end_time)

                        temperature_deviation_statistic = temperature_deviation

                        if statistic == 'min':
                            temperature_deviation_statistic = temperature_deviation_statistic.min()
                        elif statistic == 'max':
                            temperature_deviation_statistic = temperature_deviation_statistic.max()

                        result['{}_{}_{}'.format(series_title,
                                                 statistic,
                                                 time_frame_title)] = temperature_deviation_statistic

        return result

    def _get_speed_bump_stats(self, device_history):

        result = {}

        if 'DRSpeedBump' in device_history:

            dr_speed_bump = (device_history.DRSpeedBump[(device_history.DRSpeedBump.index >=
                                                         self.start_time) &
                                                        (device_history.DRSpeedBump.index <=
                                                         self.end_time)])

            if len(dr_speed_bump) > 0:

                dr_speed_bump_index_epoch = datetime_index_to_epoch_time_array(dr_speed_bump.index)
                dr_speed_bump_display_time_epoch = timestamp_series_to_epoch_time_array(dr_speed_bump.DisplayTime)

                result['speed_bump_avg_display_time'] = (dr_speed_bump_index_epoch -
                                                         dr_speed_bump_display_time_epoch).mean()
                result['speed_bump_count'] = len(dr_speed_bump)
                result['speed_bump_cancelled_dr'] = dr_speed_bump.CancelledDR.sum() > 0

                cancelled_dr = dr_speed_bump[dr_speed_bump.CancelledDR]

                if len(cancelled_dr) > 0:

                    cancelled_dr = cancelled_dr.iloc[0]

                    if 'SetPoints' in device_history:

                        cancelled_dr_set_point = device_history.SetPoints[(device_history.SetPoints.Category
                                                                           .isin(['Dial', 'Thermozilla'])) &
                                                                          (device_history.SetPoints.index >
                                                                           cancelled_dr.name) &
                                                                          (device_history.SetPoints.index <
                                                                           cancelled_dr.name +
                                                                           datetime.timedelta(0, 60))]

                        if len(cancelled_dr_set_point) > 0:

                            cancelled_dr_set_point = cancelled_dr_set_point.iloc[0]
                            cancelled_dr_prior_set_point = device_history.SetPoints[:cancelled_dr_set_point.name]

                            if len(cancelled_dr_prior_set_point) > 1:

                                cancelled_dr_prior_set_point = cancelled_dr_prior_set_point.iloc[-2]
                                schedule_mode = '{}ing'.format(self.set_point_type.capitalize())
                                result['speed_bump_temp_change'] = (cancelled_dr_set_point[schedule_mode] -
                                                                    cancelled_dr_prior_set_point[schedule_mode])

        return result