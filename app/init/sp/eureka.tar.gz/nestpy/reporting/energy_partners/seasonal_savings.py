import datetime
import logging
import numpy as np
import pandas as pd

from ..event_reporter import EventReporter
from ...groups.function_applicators import device_history_loader
from ...scriptutils import drop_consecutive_duplicates
from ...sql import lookup_devices_in_ss_event, lookup_ss_event
from ...structures import Diamond
from ...parsing.schedule_tools import (df_schedule_to_schedule_dict, schedule_dict_to_schedule_df,
                                       schedule_df_per_day, mean_schedule_temp, min_schedule_temp,
                                       max_schedule_temp, delta_min_max_schedule_temp)


logger = logging.getLogger(__name__)


class SeasonalSavings(EventReporter):
    """
    Manages and extracts event stats for a group of devices in a specified Seasonal Savings event.

    Has to be called with a valid Seasonal Savings event id and the corresponding event tier. Once these are
    specified, a database lookup is done for the event and the underlying devices. The event details are stored
    as instance variables, whereas the device details are contained in a DeviceGroup.

    >>> import nestpy

    Example:

    >>> nestpy.SeasonalSavings('6b7fcf30-f594-11e3-a073-1231392b7482', tier='production')
    <nestpy.SeasonalSavings for event '6b7fcf30-f594-11e3-a073-1231392b7482' with 1005 devices (992 j49, 13 diamond)>

    The class method 'get_event_stats' allows one to extract a list of relevant metrics from all devices in the
    specified event. In addition to this, the instance method 'get_event_stats' allows one to extract these
    metrics for a specified list of devices in the event.
    """

    EVENT_TYPES = ['AdvanceTuneUpState',
                   'TuneUpRunResults',
                   'WeeklySchedule',
                   'CurrentState',
                   'UsageEstimatorModelStatus',
                   'Weather']
    REQUIRED_METADATA = ['mac_address', 'device_type', 'tier']
    BUFFER_DAYS = 1
    PRESENTATION_DAYS = 7

    def __init__(self, event_id, tier):

        event = lookup_ss_event(event_id, tier=tier)
        devices = lookup_devices_in_ss_event(event_id, tier=tier)

        devices['start_date'] = event.qual_start_time_local
        devices['end_date'] = (devices['running_start_time']
                               .apply(lambda x: (max((x + datetime.timedelta(days=event.event_duration_days) +
                                                      datetime.timedelta(seconds=event.paused_expiration_seconds)),
                                                     (event.qual_stop_time_local +
                                                      datetime.timedelta(days=self.PRESENTATION_DAYS))) +
                                                 datetime.timedelta(days=self.BUFFER_DAYS))))

        for metadata in self.REQUIRED_METADATA:
            if metadata not in devices.columns:
                raise ValueError("Device metadata is missing a required '{}' field".format(metadata))

        super(SeasonalSavings, self).__init__(devices=devices[devices.device_type.isin(Diamond.DEVICE_TYPES)],
                                              event_id=event_id)

        self.event_id = event.event_id
        self.debug_name = event.debug_name
        self.qual_start_time_local = event.qual_start_time_local
        self.qual_stop_time_local = event.qual_stop_time_local
        self.afterglow_length_seconds = event.afterglow_length_seconds
        self.set_point_type = event.set_point_type
        self.paused_expiration_seconds = event.paused_expiration_seconds
        self.event_duration_days = event.event_duration_days

    def __repr__(self):

        if self.event_id:
            device_type_counts = self.dg.devices.device_type.value_counts()

            if not device_type_counts.empty:
                device_type_counts_str = ", ".join(["{} {}".format(device_type_counts[device_type], device_type)
                                                    for device_type in device_type_counts.index.values])
                output = "<nestpy.SeasonalSavings for event '{}' with {} devices ({})>".format(self.event_id,
                                                                                               len(self.dg.devices),
                                                                                               device_type_counts_str)
            else:
                output = "<nestpy.SeasonalSavings for event '{}'>".format(self.event_id)
        else:
            output = "<nestpy.SeasonalSavings>"

        return output

    @classmethod
    def get_event_stats(cls,
                        event_id,
                        tier,
                        threads=10):
        """
        Look up and load the device histories for a specified Seasonal Savings event,
        extract relevant event statistics from them and store these in an internal data frame.

        :param event_id:
            Seasonal Savings event id
        :type event_id:
            str

        :param tier:
            Name of the tier: 'production' or 'ft'.
        :type tier:
            str

        :returns:
            The SeasonalSavings class with events stats stored as results
        :rtype:
            nestpy.SeasonalSavings
        """

        ss = cls(event_id, tier)

        super(SeasonalSavings, ss).load_and_cache_event_stats(ss._event_stats_loader,
                                                              threads=threads)

        return ss

    def _event_stats_loader(self, device):

        try:
            if device.device_type in Diamond.DEVICE_TYPES:

                logger.debug("{}: Loading device history...".format(device.mac_address))

                device_history = device_history_loader(device,
                                                       start_date=device.start_date,
                                                       end_date=device.end_date,
                                                       event_types=self.EVENT_TYPES,
                                                       to_local_time=True)

                start_8_weeks_after = datetime.timedelta(days=7*7)
                end_8_weeks_after = datetime.timedelta(days=9*7)

                device_history_after_8_weeks = device_history_loader(device,
                                                                     start_date=device.end_date + start_8_weeks_after,
                                                                     end_date=device.end_date + end_8_weeks_after,
                                                                     event_types=self.EVENT_TYPES,
                                                                     to_local_time=True)

                if device_history is not None and device_history_after_8_weeks is not None:

                    logger.debug("{}: Loading event stats...".format(device.mac_address))

                    event_stats = {}

                    event_stats.update(self._get_states_and_stop_reasons(device_history))
                    event_stats.update(self._get_punishments(device_history))
                    event_stats.update(self._get_weekly_schedule_changes(device_history, device_history_after_8_weeks))
                    event_stats.update(self._get_savings(device_history, device_history_after_8_weeks))

                    return event_stats

        except Exception, e:
            logger.exception(e)

    def _get_states_and_stop_reasons(self, device_history):

        result = {}

        if 'AdvanceTuneUpState' in device_history:

            advance_tune_up_state = (device_history.AdvanceTuneUpState[device_history
                                     .AdvanceTuneUpState.ID.str.contains(self.event_id)])

            new_state_index = drop_consecutive_duplicates(advance_tune_up_state.NewState).index

            unique_advance_tune_up_state = advance_tune_up_state[advance_tune_up_state.index.isin(new_state_index)]
            new_state_seconds_held = np.diff(new_state_index.asi8).astype('float') / 10**9

            for index in range(0, len(unique_advance_tune_up_state)):

                new_key = '{} -> {}'.format(unique_advance_tune_up_state.OldState[index],
                                            unique_advance_tune_up_state.NewState[index])

                if unique_advance_tune_up_state.NewState[index] == 'PAUSED':
                    if 'paused_count' not in result:
                        result['paused_count'] = 1
                    else:
                        result['paused_count'] += 1

                if new_key not in result:
                    result[new_key] = unique_advance_tune_up_state.StopReason[index]

                if index != len(unique_advance_tune_up_state)-1:
                    if unique_advance_tune_up_state.NewState[index] in result:
                        result[unique_advance_tune_up_state.NewState[index]] += new_state_seconds_held[index]
                    else:
                        result[unique_advance_tune_up_state.NewState[index]] = new_state_seconds_held[index]

        return result

    def _get_punishments(self, device_history):

        def parse_punishments(stage_feature_punishments_line):

            punishment_sum = 0

            line_parts = stage_feature_punishments_line.replace('"', '').split(',')
            for punishment in line_parts:
                punishment_sum += float(punishment.split(':')[1].replace('}', ''))

            return punishment_sum

        result = {}

        if 'TuneUpRunResults' in device_history:

            tune_up_results = (device_history.TuneUpRunResults[device_history
                               .TuneUpRunResults.TuneUpID.str.contains(self.event_id)])

            if not tune_up_results.StageFeaturePunishments.empty:

                total_punishment = parse_punishments(tune_up_results.StageFeaturePunishments[-1])

                result.update({'total_punishment': total_punishment})

        return result

    def __get_weekly_schedules_tune_up(self, device_history, device_history_after_8_weeks):

        weekly_schedule_tune_up_undo = (device_history.WeeklySchedule[device_history
                                        .WeeklySchedule.Data.str.contains('TuneUpUndo')])
        weekly_schedule_tune_up_post_run = (device_history.WeeklySchedule[device_history
                                            .WeeklySchedule.Data.str.contains('TuneUpPostRun')])

        indices_info = []

        if len(weekly_schedule_tune_up_undo) > 0:
            indices_info += [['before', weekly_schedule_tune_up_undo.index[0]]]

        if len(weekly_schedule_tune_up_post_run) > 0:
            indices_info += [['after', weekly_schedule_tune_up_post_run.index[-1]]]

            schedule_mode = device_history.CurrentState.ScheduleMode[(device_history.CurrentState.index <=
                                                                      weekly_schedule_tune_up_post_run.index[-1])]
            if len(schedule_mode) > 0:

                if schedule_mode[-1] == 2:
                    schedule_name = 'Ranged_Schedule'
                else:
                    schedule_name = '{}ing_Schedule'.format(self.set_point_type.capitalize())

                weekly_schedule_mode_after_8_weeks = (device_history_after_8_weeks.WeeklySchedule[device_history_after_8_weeks
                                                      .WeeklySchedule.Data.str.contains(schedule_name)])

                after_8_weeks_index = weekly_schedule_tune_up_post_run.index[-1] + datetime.timedelta(8*7)
                weekly_schedule_mode_after_8_weeks = weekly_schedule_mode_after_8_weeks[after_8_weeks_index:]

                if len(weekly_schedule_mode_after_8_weeks) > 0:
                    indices_info += [['after_8_weeks', weekly_schedule_mode_after_8_weeks.index[0]]]

        weekly_schedule_dfs = {}

        for name, index in indices_info:

            if name is 'after_8_weeks':
                weekly_schedule = device_history_after_8_weeks.WeeklySchedule.loc[index]
            else:
                weekly_schedule = device_history.WeeklySchedule.loc[index]

            schedule_dict = df_schedule_to_schedule_dict(weekly_schedule)
            schedule_df = schedule_dict_to_schedule_df(schedule_dict)

            weekly_schedule_dfs[name] = schedule_df

        return weekly_schedule_dfs

    def _get_weekly_schedule_changes(self, device_history, device_history_after_8_weeks):

        def get_schedule_mean_temp_diff(schedule_df_old, schedule_df_new, days=range(0, 7)):

            schedule_avg = []

            for schedule_df in [schedule_df_old, schedule_df_new]:
                schedule_avg += [schedule_df_per_day(schedule_df, days=days).mean(1)]

            schedule_avg_df = pd.concat(schedule_avg, axis=1).fillna(method="pad")
            schedule_avg_df.columns = ['before', 'after']

            return schedule_avg_df.after - schedule_avg_df.before

        result = {}

        if 'WeeklySchedule' in device_history:

            weekly_schedule_dfs = self.__get_weekly_schedules_tune_up(device_history, device_history_after_8_weeks)

            for name in weekly_schedule_dfs:

                if not weekly_schedule_dfs[name].empty:

                    result.update({'schedule_mean_temp_{}'.format(name):
                                       mean_schedule_temp(weekly_schedule_dfs[name],
                                                          set_point_type=self.set_point_type),
                                   'schedule_min_temp_{}'.format(name):
                                       min_schedule_temp(weekly_schedule_dfs[name],
                                                         set_point_type=self.set_point_type),
                                   'schedule_max_temp_{}'.format(name):
                                       max_schedule_temp(weekly_schedule_dfs[name],
                                                         set_point_type=self.set_point_type),
                                   'schedule_delta_min_max_temp_{}'.format(name):
                                       delta_min_max_schedule_temp(weekly_schedule_dfs[name],
                                                                   set_point_type=self.set_point_type)})

            for day_info in [['weekdays', range(0, 5)],
                             ['weekend', range(5, 7)],
                             ['week', range(0, 7)]]:

                if 'before' in weekly_schedule_dfs and 'after' in weekly_schedule_dfs:
                    schedule_mean_temp_diff = get_schedule_mean_temp_diff(weekly_schedule_dfs['before'],
                                                                          weekly_schedule_dfs['after'],
                                                                          days=day_info[1])

                    result.update({'schedule_mean_temp_diff_dict_{}'.format(day_info[0]):
                                       schedule_mean_temp_diff.to_dict(),
                                   'schedule_min_temp_diff_time_{}'.format(day_info[0]):
                                       schedule_mean_temp_diff.idxmin(),
                                   'schedule_min_temp_diff_{}'.format(day_info[0]):
                                       schedule_mean_temp_diff.loc[schedule_mean_temp_diff.idxmin()],
                                   'schedule_max_temp_diff_time_{}'.format(day_info[0]):
                                       schedule_mean_temp_diff.idxmax(),
                                   'schedule_max_temp_diff_{}'.format(day_info[0]):
                                       schedule_mean_temp_diff.loc[schedule_mean_temp_diff.idxmax()]})

        return result

    def _get_savings(self, device_history, device_history_after_8_weeks):

        result = {}

        if ('UsageEstimatorModelStatus' in device_history and
            'WeeklySchedule' in device_history and
            'FixedWeather' in device_history):

            weekly_schedule_tune_up_undo = (device_history.WeeklySchedule[device_history
                                            .WeeklySchedule.Data.str.contains('TuneUpUndo')])

            if len(weekly_schedule_tune_up_undo) > 0:

                start_index = weekly_schedule_tune_up_undo.index[0]

                usage_estimator_model = (device_history.UsageEstimatorModelStatus[device_history.
                                         UsageEstimatorModelStatus['{}IsModelValid'
                                         .format(self.set_point_type.capitalize())]])

                weather = device_history.FixedWeather[device_history.FixedWeather.Temperature.notnull()]

                model_slope = (usage_estimator_model[usage_estimator_model.index > start_index]
                               ['{}Slope'.format(self.set_point_type.capitalize())])
                model_intercept = (usage_estimator_model[usage_estimator_model.index > start_index]
                                   ['{}Intercept'.format(self.set_point_type.capitalize())])

                outdoor_temp = weather.Temperature[(weather.index > start_index) &
                                                   (weather.index < start_index + datetime.timedelta(3*7))]

                if len(model_slope) > 0 and len(model_intercept) > 0 and len(outdoor_temp) > 0:

                    weekly_schedule_dfs = self.__get_weekly_schedules_tune_up(device_history, device_history_after_8_weeks)

                    for name in weekly_schedule_dfs:

                        if not weekly_schedule_dfs[name].empty:

                            temp_delta = outdoor_temp.mean() - mean_schedule_temp(weekly_schedule_dfs[name],
                                                                                  set_point_type=self.set_point_type)

                            result.update({'hvac_runtime_{}'.format(name): (model_slope[0] * temp_delta +
                                                                            model_intercept[0])})

        return result