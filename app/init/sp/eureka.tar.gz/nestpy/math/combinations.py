from itertools import chain, combinations


def power_set(iterable, subset_sizes=None):
    """Calculates the power set of an iterable.

    Shamelessly taken from the itertools recipe:
    https://docs.python.org/2/library/itertools.html#recipes
    :param iterable: on which to calculate subsets
    :param subset_sizes: optional limit on the allowable subset sizes
    :return: iterable: combinations of the iterable parameter adhering to the combination sizes passed in
    """
    s = list(iterable)

    if subset_sizes is None:
        subset_sizes = range(len(s) + 1)

    return chain.from_iterable(combinations(s, r) for r in range(len(s) + 1) if (r in subset_sizes))
