# pylint: disable=no-member,maybe-no-member
import copy
import datetime
import logging

import numpy as np
import pandas as pd

import action_pb2  # See scripts/Diamond/actions/README for how to compile and use this library.
from ...modeling.daily_consumption_models import consumption_model_utilities as cmu
from ...modeling.daily_consumption_models.dynamic_float_model import DynamicFloatModel
from ...converters import c2f

logger = logging.getLogger(__name__)

_MODEL_VALIDATION_MAX_APE = 0.8

# Go into away after 1 hour (with no other information, this is a reasonable estimate).
_SIMULATION_AWAY_TIME = datetime.timedelta(hours=1)
_AWAY_BLACKOUT_START_TIME = datetime.time(20, 0)
_AWAY_BLACKOUT_END_TIME = datetime.time(8, 0)
_NIGHT_START_TIME_SECONDS = 18 * 3600
_NIGHT_END_TIME_SECONDS = 8 * 3600
_EPSILON = 1e-6
_WEEKEND_DAY_THRESHOLD = 5
_MINUTES_IN_HOUR = 60.0
_SECONDS_IN_HOUR = 60.0 * _MINUTES_IN_HOUR
_MINIMUM_SCHED_TEMP_F = 50
_MAXIMUM_SCHED_TEMP_F = 90

# Assumed estimates for HPB savings. Eventually, we may want to have a look-up table by climate for these numbers,
# as we may be over-estimating for milder climates with the numbers below.
_AUX_KW = 15.0
_HEAT_1_KW = 3.0
_HEAT_1_AUX_EFFICIENCY_RATIO = 2.0
_AUX_HOURLY_SAVINGS_KWH = _AUX_KW / _HEAT_1_AUX_EFFICIENCY_RATIO


class ActionAnalyzer(object):
    """Class to build the Action Table for a single device."""
    # TODO: Look into emergency heat mode.
    HEATING = 0
    COOLING = 1
    RANGE = 2
    MODE_NAME = {HEATING: 'HEATING', COOLING: 'COOLING', RANGE: 'RANGE'}
    SAVINGS = 1
    COMFORT = -1
    HEAT_PUMP_SAVINGS = 0
    HEAT_PUMP_BALANCED = 1
    HEAT_PUMP_COMFORT = 2
    HEAT_PUMP_OFF = 3

    def __init__(self, device_history, date_of_analysis, action_step_menu, location=None):
        self.device_history = device_history
        self.schedule_mode = None
        self.affect_heat = None
        self.affect_cool = None
        self.date_of_analysis = date_of_analysis.date()
        self.location = location if location else 'N/A'
        self._action_step_menu = action_step_menu
        self._actual_daily_runtimes = cmu.extract_daily_hvac_runtimes(self.device_history)
        self._actual_daily_histories = cmu.extract_all_time_series(self.device_history)
        self.dates = list(self._actual_daily_runtimes.index)

        self._qualified_dh = self._qualify_device_history()
        if self._qualified_dh:
            self._model = self._train_and_validate_model(self._actual_daily_histories, self._actual_daily_runtimes)
        else:
            self._model = None
        self._qualified = None
        self._qualified_model_for_mode = None
        self._qualified_usage_for_mode = None

    def define_mode(self, mode):
        self.schedule_mode = mode
        self.affect_heat = mode in [self.HEATING, self.RANGE]
        self.affect_cool = mode in [self.COOLING, self.RANGE]
        self._qualified_model_for_mode = self._qualify_model()
        self._qualified_usage_for_mode = self.qualify_usage()
        self._qualified = self._qualified_dh and self._qualified_model_for_mode and self._qualified_usage_for_mode

    @staticmethod
    def events_to_load():
        """Return the list of events needed to analyze the actions for this device."""
        return ['Weather', 'BufferedTemperature', 'BufferedPassiveInfrared', 'AutoAway', 'CurrentState',
                'EnergySummary', 'SetPoints', 'UpdateStateResults', 'OccupancyCharacteristics', 'HeatPumpBalance']

    def _qualify_model(self):
        if self._model is None:
            return False
        if self.schedule_mode == self.HEATING:
            wMAPE = self._model.training_results['heating_wMAPE']
        elif self.schedule_mode == self.COOLING:
            wMAPE = self._model.training_results['cooling_wMAPE']
        elif self.schedule_mode == self.RANGE:
            wMAPE = min(self._model.training_results['heating_wMAPE'], self._model.training_results['cooling_wMAPE'])
        if wMAPE > _MODEL_VALIDATION_MAX_APE:
            logger.info('Cannot model device \'%s\': wMAPE=%f.' % (self.device_history.unique_device_id, wMAPE))
            return False
        return True

    def _qualify_device_history(self):
        """Raise an error if the device does not qualify for analysis."""
        if 'CurrentState' not in self.device_history:
            return False
        if ('WeatherUndergroundHourly' not in self.device_history or
                'Temperature' not in self.device_history.WeatherUndergroundHourly):
            return False
        return True

    def _train_and_validate_model(self, daily_histories, daily_runtimes):
        """
        Train a consumption model.

        Determine whether we *believe* the consumption model for this device.
        If so, return the model, else return None.
        """
        model = DynamicFloatModel.create_trained_model(daily_histories, daily_runtimes)
        predicted_runtimes = model.predict_consumption(daily_histories)
        if predicted_runtimes.dropna().empty:
            logger.info('Cannot model device \'%s\': runtimes = NaN' % self.device_history.unique_device_id)
            return None
        return model

    def get_actual_hvac_usage_minutes(self):
        """Return the actual historical HVAC usage in the analysis mode during the analysis period."""
        hvac = self.device_history.HVACState[['Heating', 'Cooling']]
        return hvac.resample('1Min', fill_method='ffill', how='min').sum()

    def get_actual_hvac_usage_minutes_for_mode(self):
        hvac = self.get_actual_hvac_usage_minutes()
        if self.schedule_mode == self.HEATING:
            return hvac['Heating']
        elif self.schedule_mode == self.COOLING:
            return hvac['Cooling']
        elif self.schedule_mode == self.RANGE:
            return hvac.sum()
        else:
            assert 'Unknown schedule mode.'

    def qualify_usage(self):
        """Return whether there was enough HVAC usage to offer an Action Table to the user."""
        usage_min_per_day = (self.get_actual_hvac_usage_minutes_for_mode() / len(self.dates))
        return bool(usage_min_per_day >= self._action_step_menu.acceptance_criteria.minimum_usage_min_per_day)

    def get_heat_pump_balance_mode(self):
        # TODO: decide how to handle explicit heat pump off mode
        if self.has_heat_pump_balance():
            latest_mode = self.device_history.HeatPumpBalance.HeatPumpSavings[-1]
            if latest_mode == self.HEAT_PUMP_SAVINGS:
                return action_pb2.SAVINGS
            elif latest_mode == self.HEAT_PUMP_BALANCED:
                return action_pb2.BALANCED
            elif latest_mode == self.HEAT_PUMP_COMFORT:
                return action_pb2.COMFORT
            elif latest_mode == self.HEAT_PUMP_OFF:
                return action_pb2.OFF
            else:
                raise ValueError('Error: unknown heat pump balance mode.')
        else:
            return action_pb2.OFF

    def get_baseline_config(self):
        """Return the actual configuration of the device, based on event logs, which may be imperfect."""
        config = action_pb2.Config()
        config.auto_away.enabled = bool(self.device_history.AutoAway.NewMode[-1] != -1)  # -1 = nlAutoAwayModeDisabled
        config.auto_away.away_temperature_high_f = self.device_history.CurrentState.AwayTemperatureHigh[-1]
        config.auto_away.away_temperature_low_f = self.device_history.CurrentState.AwayTemperatureLow[-1]
        config.autotune.mode = action_pb2.OFF
        config.heat_pump_balance.mode = self.get_heat_pump_balance_mode()
        config.hvac_control.mode = action_pb2.BALANCED
        return config

    def has_heat_pump_balance(self):
        """Returns whether this device can use heat pump balance."""
        return (self.device_history.CurrentState.HasAuxHeat[-1] and
                self.device_history.CurrentState.HasHeatPump[-1])

    def get_mode_params(self, parameters, mode):
        """Get the parameters from the action menu corresponding to the input mode."""
        for params in parameters:
            if params.mode == mode:
                return params
        return None

    def get_baseline_mean_target_temp_f(self):
        """Return the actual mean target temperature for the device in the analysis period."""
        target_temp = cmu.calculate_target_temp(self._actual_daily_histories)
        if self.schedule_mode in [self.HEATING, self.COOLING, self.RANGE]:
            return target_temp.mean()
        else:
            raise ValueError('Unknown schedule mode.')

    @staticmethod
    def _get_occupancy_row_for_date(date, day_occupancy_df):
        is_weekend = date.weekday() >= _WEEKEND_DAY_THRESHOLD
        label = 'WeekdayPIR' if is_weekend else 'WeekendPIR'
        occupancy_row = day_occupancy_df[day_occupancy_df.Identity == label].iloc[0]
        return occupancy_row

    def _apply_autotune(self, dh, config):
        """Apply an autotune to make schedule changes."""
        autotune_params = self.get_mode_params(self._action_step_menu.autotune, config.autotune.mode)
        simulated_dh = dh.copy()

        occupancy_df = pd.DataFrame(index=set(simulated_dh.OccupancyCharacteristics.index.date),
                                    columns=simulated_dh.OccupancyCharacteristics.columns)
        occupancy_df = occupancy_df.sort()

        grouped_occupancy =\
            simulated_dh.OccupancyCharacteristics.groupby(simulated_dh.OccupancyCharacteristics.index.date)
        for date, day_occupancy_df in grouped_occupancy:
            occupancy_row = self._get_occupancy_row_for_date(date, day_occupancy_df)
            occupancy_df.loc[date] = occupancy_row

        integer_time_columns = ['BedTime', 'EveningReturnTime', 'MorningLeaveTime', 'WakeupTime']
        occupancy_df[integer_time_columns] /= _SECONDS_IN_HOUR

        # Occupancy usually reported around midnight and can therefore be in one of two dates.
        # If missing occupancy for date, use the first row as the default for now.
        default_occupancy_row = occupancy_df.iloc[0]
        schedule = simulated_dh.SetPoints[simulated_dh.SetPoints.Category == 'Schedule']
        for timestamp, row in schedule.iterrows():
            date_in_occupancy_index = timestamp.date() in occupancy_df.index
            if date_in_occupancy_index:
                occupancy_char = occupancy_df.loc[timestamp.date()]
            else:
                occupancy_char = default_occupancy_row

            bedtime = occupancy_char.BedTime
            wakeup = occupancy_char.WakeupTime
            morning_leave = occupancy_char.MorningLeaveTime
            evening_return = occupancy_char.EveningReturnTime
            bed_before_midnight = bedtime >= wakeup
            assert(wakeup <= evening_return)
            assert(morning_leave <= evening_return)
            # TODO: evaluate hard-coded setpoint deltas
            if self.affect_heat and row.ScheduleMode in ['nlScheduleModeHeat', 'nlScheduleModeRange']:
                # Adjust nightime
                if ((not bed_before_midnight and bedtime <= timestamp.hour <= wakeup) or
                        (bed_before_midnight and (timestamp.hour >= bedtime or timestamp.hour <= wakeup))):
                    row['Heating'] += autotune_params.heating_setpoint_delta_f_nighttime
                # Adjust daytime
                if morning_leave <= timestamp.hour <= evening_return:
                    row['Heating'] += autotune_params.heating_setpoint_delta_f_day_and_night
                # Adjust all
                row['Heating'] += autotune_params.heating_setpoint_delta_f_all
                row['Heating'] = max(row['Heating'], _MINIMUM_SCHED_TEMP_F)

            if self.affect_cool and row.ScheduleMode in ['nlScheduleModeCool', 'nlScheduleModeRange']:
                # Adjust daytime
                if ((bed_before_midnight and wakeup <= timestamp.hour <= bedtime) or
                        (not bed_before_midnight and (timestamp.hour >= wakeup or timestamp.hour <= bedtime))):
                    row['Cooling'] += autotune_params.cooling_setpoint_delta_f_day_and_night
                # Adjust workday
                if wakeup <= timestamp.hour <= evening_return:
                    row['Cooling'] += autotune_params.cooling_setpoint_delta_f_day_and_night
                # Adjust all
                row['Cooling'] += autotune_params.cooling_setpoint_delta_f_all
                row['Cooling'] = min(row['Cooling'], _MAXIMUM_SCHED_TEMP_F)

            simulated_dh.SetPoints.loc[timestamp] = row

        return simulated_dh

    def _simulate_alternate_device_history(self, config, baseline_config):
        """
        Alter the past device history to respect config, assuming baseline_config
        as the original dh config.
        """
        simulated_dh = copy.deepcopy(self.device_history)

        # If turning AutoAway off, set all away modes to "home".
        if baseline_config.auto_away.enabled and not config.auto_away.enabled:
            simulated_dh.CurrentState.AwayMode = 0
        # If turning AutoAway on, find all long periods of non-occupancy and approximate away.
        if not baseline_config.auto_away.enabled and config.auto_away.enabled:
            pir_max = simulated_dh.BufferedPassiveInfrared['max']
            if pir_max.index[-1] < simulated_dh.latest_date:
                pir_max = pir_max.append(pd.Series(pir_max.iloc[-1], index=[simulated_dh.latest_date]))
            pir_max = pir_max.resample('1Min', fill_method='ffill')
            T = simulated_dh.BufferedPassiveInfrared.threshold[-1]
            pir_away = pir_max < T
            last_home_time = pir_away.index[0]
            simulated_away = dict()
            for bucket_time, away in pir_away.iteritems():
                if away:
                    time_since_home = bucket_time - last_home_time
                    simulated_away[bucket_time.replace(second=0)] = (
                        time_since_home.total_seconds() > _SIMULATION_AWAY_TIME.total_seconds() and
                        _AWAY_BLACKOUT_END_TIME <= bucket_time.time() <= _AWAY_BLACKOUT_START_TIME)
                else:
                    simulated_away[bucket_time.replace(second=0)] = False
                    last_home_time = bucket_time
            current_state_away_mode = list()
            for index, row in simulated_dh.CurrentState.iterrows():
                t = index
                t = t.replace(second=0, microsecond=0)
                current_state_away_mode.append(1 * int(simulated_away[t]))
            simulated_dh.CurrentState['AwayMode'] = current_state_away_mode

        # Adjusting AutoAway temps.
        # Adjust the away temperature in the CurrentState event.
        if config.auto_away.away_temperature_low_f != baseline_config.auto_away.away_temperature_low_f:
            simulated_dh.CurrentState.AwayTemperatureLow = config.auto_away.away_temperature_low_f
        if config.auto_away.away_temperature_high_f != baseline_config.auto_away.away_temperature_high_f:
            simulated_dh.CurrentState.AwayTemperatureHigh = config.auto_away.away_temperature_high_f

        # Running autotune.
        if config.autotune.mode != action_pb2.OFF:
            simulated_dh = self._apply_autotune(simulated_dh, config)

        return simulated_dh

    def analyze_device_history(self, device_history, additional_savings=0.0):
        """
        Return an ActionAnalysis containing the analysis of device_history
        with additional_savings added in.
        """
        analysis = action_pb2.ActionAnalysis()

        daily_histories = cmu.extract_all_time_series(device_history)
        predicted_runtimes = self._model.predict_consumption(daily_histories)
        h_hat_total = predicted_runtimes.sum()

        analysis.heating_usage_minutes = h_hat_total.heating + _EPSILON
        analysis.cooling_usage_minutes = h_hat_total.cooling + _EPSILON
        analysis.analysis_period_days = len(self.dates)
        analysis.mean_heating_target_f = daily_histories.heating_scheduled_temp.mean()
        analysis.mean_cooling_target_f = daily_histories.cooling_scheduled_temp.mean()
        if additional_savings:
            additional_heating_savings = 0.0
            additional_cooling_savings = 0.0
            if self.affect_heat:
                additional_heating_savings = additional_savings
            if self.affect_cool:
                additional_cooling_savings = additional_savings
            analysis.heating_usage_minutes *= (1.0 - additional_heating_savings)
            analysis.cooling_usage_minutes *= (1.0 - additional_cooling_savings)
        return analysis

    @staticmethod
    def score_action(action,
                     parent_savings,
                     heating_usage_minutes_baseline,
                     cooling_usage_minutes_baseline,
                     comfort_cost):
        """Populate additional fields of analysis based on the usage and baseline information."""
        action.analysis.heating_usage_minutes_baseline = heating_usage_minutes_baseline
        action.analysis.cooling_usage_minutes_baseline = cooling_usage_minutes_baseline
        action.analysis.comfort_cost = comfort_cost
        total_usage_minutes = action.analysis.heating_usage_minutes + action.analysis.cooling_usage_minutes
        total_usage_minutes_baseline =\
            action.analysis.heating_usage_minutes_baseline + action.analysis.cooling_usage_minutes_baseline
        action.analysis.usage_ratio = total_usage_minutes / total_usage_minutes_baseline
        action.analysis.savings = 1.0 - action.analysis.usage_ratio
        # Utility Score = Savings - Comfort.
        action.analysis.utility_score = action.analysis.savings - action.analysis.comfort_cost
        if action.step:
            action.step[-1].incremental_savings = action.analysis.savings - parent_savings

    def _get_mode_usage_minutes(self, usage_minutes):
        if self.schedule_mode == ActionAnalyzer.HEATING:
            return usage_minutes['Heating']
        elif self.schedule_mode == ActionAnalyzer.COOLING:
           return usage_minutes['Cooling']
        elif self.schedule_mode == ActionAnalyzer.RANGE:
            return usage_minutes.sum()

    def compute_canned_analysis(self, action=None):
        """
        Return an ActionAnalysis corresponding to canned savings for the given action.
        This is for use if we cannot simulate this device.
        """
        analysis = action_pb2.ActionAnalysis()
        analysis.analysis_period_days = len(self.dates)
        baseline_usage_minutes = self.get_actual_hvac_usage_minutes()
        if action is None:
            analysis.heating_usage_minutes = baseline_usage_minutes.Heating
            analysis.cooling_usage_minutes = baseline_usage_minutes.Cooling
            return analysis
        canned_savings = 0.0
        for step in action.step:
            canned_savings += step.canned_savings
        canned_heating_savings = 0
        canned_cooling_savings = 0
        if self.affect_heat:
            canned_heating_savings = canned_savings
        if self.affect_cool:
            canned_cooling_savings = canned_savings
        analysis.heating_usage_minutes = baseline_usage_minutes['Heating'] * (1 - canned_heating_savings)
        analysis.cooling_usage_minutes = baseline_usage_minutes['Cooling'] * (1 - canned_cooling_savings)
        return analysis

    def analyze_action(self, parent_action, action_step, action_config):
        """Analyze an action, returning an Action object with the analysis part filled."""
        assert action_step.HasField('comfort_cost')
        logger.debug('Analyzing action step: %s' % action_step.description)
        analyzed_action = action_pb2.Action()
        analyzed_action.is_baseline = False
        analyzed_action.baseline_config.CopyFrom(parent_action.baseline_config)
        analyzed_action.config.CopyFrom(action_config)
        analyzed_action.step.extend(parent_action.step)
        analyzed_action.step.add().CopyFrom(action_step)

        additional_savings = self.compute_additional_savings(analyzed_action, parent_action)
        if not self._qualified_model_for_mode:
            analyzed_action.analysis.CopyFrom(self.compute_canned_analysis(analyzed_action))
        else:
            simulated_dh = self._simulate_alternate_device_history(action_config, parent_action.baseline_config)
            analyzed_action.analysis.CopyFrom(self.analyze_device_history(simulated_dh,
                                                                          additional_savings=additional_savings))
        self.score_action(analyzed_action,
                          parent_action.analysis.savings,
                          parent_action.analysis.heating_usage_minutes_baseline,
                          parent_action.analysis.cooling_usage_minutes_baseline,
                          parent_action.analysis.comfort_cost + action_step.comfort_cost)
        return analyzed_action

    def compute_away_temp_comfort_cost(self, current_away_low_f, target_away_low_f):
        return self._action_step_menu.auto_away.comfort_cost_per_delta_f * (current_away_low_f - target_away_low_f)

    def compute_heat_pump_savings(self, action, parent_action):
        savings_percentage = 0
        if (action.config.heat_pump_balance.mode != action_pb2.OFF and
                parent_action.config.heat_pump_balance.mode != action_pb2.OFF):
            aux_heat = self.device_history.UpdateStateResults.AuxHeatState
            aux_heat_1min = cmu.fillforward_series_and_cover_extent(aux_heat,
                                                                    self.device_history.earliest_date,
                                                                    self.device_history.latest_date)
            aux_heat_1min = pd.DataFrame(aux_heat_1min, columns=['aux_heat'])

            lockout = self.device_history.HeatPumpBalance.HPAUXHeatStartTemperature
            lockout_1min = pd.DataFrame(cmu.fillforward_series_and_cover_extent(lockout,
                                                                                self.device_history.earliest_date,
                                                                                self.device_history.latest_date),
                                        columns=['lockout_temp'])
            lockout_1min['lockout_temp'] = [c2f(x) for x in lockout_1min['lockout_temp']]

            heat_pump_df = pd.concat([aux_heat_1min,
                                      lockout_1min,
                                      self._actual_daily_histories[['heating_hvac', 'outdoor_temp']],
                                      cmu.calculate_target_temp(self._actual_daily_histories)['heating_target_temp']],
                                     axis=1).dropna()

            params = self.get_mode_params(self._action_step_menu.heat_pump_balance,
                                          action.config.heat_pump_balance.mode)

            # Calculate delta aux between two heat pump settings: aux heat that ran while outdoor temp was between the
            # old and new lockout temp
            significant_aux_df = heat_pump_df[heat_pump_df.outdoor_temp <= heat_pump_df.lockout_temp]
            significant_aux_df = significant_aux_df[significant_aux_df.outdoor_temp >= params.default_lockout_temp_f]
            delta_aux_hours = significant_aux_df.aux_heat.sum() / _MINUTES_IN_HOUR

            # Calculate baseline kwh and saved_kwh, return percent savings
            baseline_aux_hours = heat_pump_df.aux_heat.sum() / _MINUTES_IN_HOUR
            baseline_heat1_hours = self._actual_daily_histories.heating_hvac.sum() / _MINUTES_IN_HOUR
            baseline_kwh = baseline_heat1_hours * _HEAT_1_KW + baseline_aux_hours * _AUX_KW
            if baseline_kwh != 0:
                kwh_savings = delta_aux_hours * _AUX_HOURLY_SAVINGS_KWH
                savings_percentage = kwh_savings / baseline_kwh
        return savings_percentage

    def compute_additional_savings(self, action, parent_action):
        return (sum([step.additional_savings for step in action.step]) +
                self.compute_heat_pump_savings(action, parent_action))

    def apply_action_step(self, current_config, action_step, direction):
        """Apply action_step to current_config, and return the resulting Config as well as the effective ActionStep."""
        # TODO(geremy): Clean up the repetition in all the if statements below.
        next_config = action_pb2.Config()
        next_config.CopyFrom(current_config)
        effective_action_step = action_pb2.ActionStep()
        effective_action_step.CopyFrom(action_step)
        is_savings_direction = direction == self.SAVINGS
        is_comfort_direction = direction == self.COMFORT
        success = False
        away_temp_delta = 0.3

        if action_step.component == action_pb2.ActionStep.ENABLE_AUTO_AWAY:
            if is_savings_direction and not current_config.auto_away.enabled:
                next_config.auto_away.enabled = True
                success = True
        else:
            parameter_float_value = action_step.parameter_value[0].float_value
            parameter_mode_value = action_step.parameter_value[0].mode_value
            if action_step.component == action_pb2.ActionStep.AWAY_TEMPERATURE_LOW and self.affect_heat:
                if ((is_savings_direction and (parameter_float_value < (current_config.auto_away.away_temperature_low_f - away_temp_delta))) or
                        (is_comfort_direction and (parameter_float_value > (current_config.auto_away.away_temperature_low_f + away_temp_delta)))):
                    next_config.auto_away.away_temperature_low_f = parameter_float_value
                    effective_action_step.comfort_cost = action_step.comfort_cost + self.compute_away_temp_comfort_cost(
                        current_config.auto_away.away_temperature_low_f, action_step.parameter_value[0].float_value)
                    success = True
            elif action_step.component == action_pb2.ActionStep.AWAY_TEMPERATURE_HIGH and self.affect_cool:
                if ((is_savings_direction and (parameter_float_value > (current_config.auto_away.away_temperature_high_f + away_temp_delta))) or
                        (is_comfort_direction and (parameter_float_value < (current_config.auto_away.away_temperature_high_f - away_temp_delta)))):
                    next_config.auto_away.away_temperature_high_f = parameter_float_value
                    effective_action_step.comfort_cost = action_step.comfort_cost + self.compute_away_temp_comfort_cost(
                        parameter_float_value, current_config.auto_away.away_temperature_high_f)
                    success = True
            elif action_step.component == action_pb2.ActionStep.AUTOTUNE_MODE:
                if ((is_savings_direction and (parameter_mode_value > current_config.autotune.mode)) or
                        (is_comfort_direction and (parameter_mode_value < current_config.autotune.mode))):
                    next_config.autotune.mode = parameter_mode_value
                    success = True
            elif action_step.component == action_pb2.ActionStep.HEAT_PUMP_BALANCE_MODE and self.has_heat_pump_balance():
                if ((is_savings_direction and (parameter_mode_value > current_config.heat_pump_balance.mode)) or
                        (is_comfort_direction and (parameter_mode_value < current_config.heat_pump_balance.mode))):
                    next_config.heat_pump_balance.mode = parameter_mode_value
                    success = True
            elif action_step.component == action_pb2.ActionStep.HVAC_CONTROL_MODE:
                if ((is_savings_direction and (parameter_mode_value > current_config.hvac_control.mode)) or
                        (is_comfort_direction and (parameter_mode_value < current_config.hvac_control.mode))):
                    next_config.hvac_control.mode = parameter_mode_value
                    success = True

        if success:
            return next_config, effective_action_step
        else:
            return None, None

    @staticmethod
    def step_is_blocked(action_step, used_step_names):
        """Return true if the given action_step cannot be used, given the already used_step_names."""
        for must_come_after in action_step.must_come_after:
            if must_come_after in used_step_names:
                return True
        return False

    def find_best_next_action(self, current_action, direction):
        """Find the best next action step to apply given the current action, return the resulting action."""
        best_next_action = None
        for action_step_family in self._action_step_menu.action_step_family:
            family = [step for step in action_step_family.action_step]
            if direction == self.COMFORT:
                family.reverse()
            # Find the next applicable action from this family.
            candidate_next_config = None
            for action_step in family:
                action_step.family_name = action_step_family.name
                (candidate_next_config, effective_action_step) = self.apply_action_step(current_action.config,
                                                                                        action_step,
                                                                                        direction)
                if candidate_next_config:
                    break
            if not candidate_next_config:
                continue

            # Analyze it.
            candidate_next_action = self.analyze_action(current_action, effective_action_step, candidate_next_config)
            if not candidate_next_action:
                continue
            if direction == self.SAVINGS and candidate_next_action.analysis.savings <= current_action.analysis.savings:
                continue
            if direction == self.COMFORT and candidate_next_action.analysis.savings >= current_action.analysis.savings:
                continue

            logger.debug('Predicted Incremental Savings: %0.3f' % candidate_next_action.step[-1].incremental_savings)
            if best_next_action is None:
                best_next_action = candidate_next_action
            elif ((direction == self.SAVINGS) and
                    (candidate_next_action.analysis.utility_score > best_next_action.analysis.utility_score)):
                best_next_action = candidate_next_action
            elif ((direction == self.COMFORT) and
                    (candidate_next_action.analysis.utility_score < best_next_action.analysis.utility_score)):
                best_next_action = candidate_next_action

        if best_next_action is None:
            return None
        elif (direction == self.SAVINGS) and (best_next_action.analysis.savings < current_action.analysis.savings):
            return None
        elif (direction == self.COMFORT) and (best_next_action.analysis.savings > current_action.analysis.savings):
            return None

        logger.debug('BEST ACTION THIS ROUND: {}'.format(str(best_next_action)))
        return best_next_action

    @staticmethod
    def polish_action(action, next_action=None):
        """Determine which action steps to display for this action."""
        families_used = set()
        for step in reversed(action.step):
            step.display = (step.family_name not in families_used)
            families_used.add(step.family_name)

        # Determine whether to display this action at all (or is it grouped with the next one?)
        action.display = bool((next_action is None) or
                              (next_action.analysis.savings - action.analysis.savings > 0.0075))

        return action

    def build_baseline_action(self):
        """Creates the baseline (no-op) action for the given device."""
        baseline_action = action_pb2.Action()
        baseline_action.is_baseline = True
        baseline_action.config.CopyFrom(self.get_baseline_config())
        if not self._qualified_model_for_mode:
            baseline_action.analysis.CopyFrom(self.compute_canned_analysis())
        else:
            baseline_action.analysis.CopyFrom(self.analyze_device_history(self.device_history))
        self.score_action(baseline_action,
                          parent_savings=0,
                          heating_usage_minutes_baseline=baseline_action.analysis.heating_usage_minutes,
                          cooling_usage_minutes_baseline=baseline_action.analysis.cooling_usage_minutes,
                          comfort_cost=0)
        baseline_action.baseline_config.CopyFrom(baseline_action.config)
        baseline_action.analysis.utility_score = np.nan
        return baseline_action

    def analyze_device_with_single_action_step(self, action_step):
        """
        Applies the given action step to the device, analyzes the results,
        returns an analyzed action.
        """
        baseline_action = self.build_baseline_action()
        candidate_next_config, effective_action_step = self.apply_action_step(baseline_action.config,
                                                                              action_step,
                                                                              self.SAVINGS)
        if not candidate_next_config:
            candidate_next_config, effective_action_step = self.apply_action_step(baseline_action.config,
                                                                                  action_step,
                                                                                  self.COMFORT)
        if not candidate_next_config:
            return None

        action = self.analyze_action(baseline_action,
                                     effective_action_step,
                                     candidate_next_config)
        return action

    def build_action_table(self):
        """Build the ActionTable for a given device."""
        baseline_action = self.build_baseline_action()

        # For now we use a greedy algorithm that picks the best next ActionStep at each point
        # and adds the resulting Action to the ActionTable.  At each time, it picks the step
        # that maximizes/minimizes the utility score.
        action_table = action_pb2.ActionTable()
        action_table.device_id = self.device_history.unique_device_id
        action_table.location = self.location
        action_table.date_of_analysis = str(self.date_of_analysis)
        action_table.schedule_mode = self.MODE_NAME[self.schedule_mode]
        action_table.available = self._qualified_dh and self._qualified_usage_for_mode
        if not action_table.available:
            return action_table
        action_table.personalized = self._qualified

        action_list = [baseline_action]
        # First in the savings direction. Maximize utility score.
        while True:
            best_next_action = self.find_best_next_action(action_list[-1], direction=self.SAVINGS)
            if not best_next_action:
                break
            action_list.append(best_next_action)
        # Then in the comfort direction. Minimize utility score.
        while True:
            best_next_action = self.find_best_next_action(action_list[0], direction=self.COMFORT)
            if not best_next_action:
                break
            action_list.insert(0, best_next_action)

        for (i, action) in enumerate(action_list):
            action_table.action.add().CopyFrom(
                self.polish_action(action, action_list[i+1] if i + 1 < len(action_list) else None))
        return action_table
