# pylint: disable=no-member,maybe-no-member
import copy
import logging
import os
import sys

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

from ...converters import c2f
from ...plotting import DiamondPlotter

logger = logging.getLogger(__name__)

eps = sys.float_info.epsilon


class ActionResults(object):

    def __init__(self, action_analyzer, directory=None, overwrite=True):
        self.action_analyzer = action_analyzer
        self.device_history = action_analyzer.device_history
        self.directory = directory
        self.overwrite = overwrite

    def plot_device(self):
        plt.close('all')
        DiamondPlotter(device_history=self.device_history, light=False).plot_to_file(self.directory,
                                                                                     filename_prefix='actions',
                                                                                     overwrite=self.overwrite)

    def plot_autoaway_info(self):
        baseline_config = self.action_analyzer.get_baseline_config()
        indoor = self.device_history.BufferedTemperature.resample('5Min', fill_method='ffill', how='mean')
        away = self.device_history.AwayMode.resample('5Min', fill_method='ffill')
        indoor_with_away = pd.concat([indoor, away], axis=1)
        temp_while_away = indoor_with_away[indoor_with_away.IsAway == 1].temperature
        if temp_while_away.empty:
            return
        weights = np.ones_like(temp_while_away) / (eps + len(indoor_with_away))
        plt.hist(temp_while_away, 10, weights=weights)
        plt.axvline(baseline_config.auto_away.away_temperature_low_f, 0.0, 1.0, color='k', linestyle='--', linewidth=3)
        plt.xlim(5, 30)
        plt.title('Away Indoor Temp (%.0f%% of time away)' %
                  (100.0 * len(temp_while_away) / (eps + len(indoor_with_away))), fontsize=10)

    def plot_schedule_info(self):
        heating = self.device_history.HVACState.Heating
        heating_series = heating.resample('5Min', fill_method='ffill')
        setpoint_touched_by = self.device_history.NewSetPoint.TouchedBy_string
        setpoint_touched_by_series = setpoint_touched_by.resample('5Min', fill_method='ffill', how='first')
        setpoint_touched_where = self.device_history.NewSetPoint.TouchedWhere_string
        setpoint_touched_where_series = setpoint_touched_where.resample('5Min', fill_method='ffill', how='first')
        away = copy.deepcopy(self.device_history.AwayMode.IsAway)
        away_series = away.resample('5Min', fill_method='ffill')
        x = pd.concat([heating_series, setpoint_touched_by_series, setpoint_touched_where_series, away_series],
                      axis=1,
                      keys=['Heating', 'TouchedBy_string', 'TouchedWhere_string', 'IsAway']).fillna(method='ffill').dropna()

        fraction_heating_on_schedule = sum(x.Heating * (x.TouchedWhere_string == 'nlTouchedWhereSchedule') * (x.IsAway == 0)) / (eps + sum(x.Heating))
        fraction_heating_on_learning = sum(x.Heating * (x.TouchedBy_string == 'nlTouchedByLearning') * (x.IsAway == 0)) / (eps + sum(x.Heating))
        fraction_heating_on_away = sum(x.Heating * x.IsAway) / (eps + sum(x.Heating))
        fraction_heating_on_other = 1.0 - fraction_heating_on_schedule - fraction_heating_on_away
        plt.bar([0.1], [fraction_heating_on_schedule], color=['b'])
        plt.bar([1.1], [fraction_heating_on_learning], color=['g'])
        plt.bar([2.1], [fraction_heating_on_away], color=['r'])
        plt.bar([3.1], [fraction_heating_on_other], color=['k'])
        plt.axis([0, 4, 0, 1])
        plt.legend(['Schedule Heating', 'Learned SP Heating', 'Away Heating', 'Other Heating'],
                   loc='upper right',
                   fontsize=8)
        plt.title('Scheduled Heating Ratios', fontsize=10)

    def plot_demand_info(self):
        indoor = self.device_history.BufferedTemperature.resample('5Min', fill_method='ffill', how='mean')
        outdoor = c2f(self.device_history.WeatherUndergroundHourly.temp_c).resample('5Min', how='mean').interpolate()
        demand = pd.concat([indoor.temperature, outdoor], axis=1, keys=['indoor', 'outdoor']).dropna()
        demand['demand'] = demand['indoor'] - demand['outdoor']
        plt.hist(demand['demand'], 20)
        plt.axvline(0.0, 0.0, 1.0, color='k', linestyle='--', linewidth=3)
        plt.xlim([-20, 50])
        plt.title('Heating Demand (%.0f%% positive)' % (100.0 * len(demand[demand.demand > 0]) / (eps + len(demand))))

    def plot_device_stats(self):
        plt.close('all')
        file_path = os.path.join(self.directory, 'diamond_{}.stats.png'.format(self.device_history.unique_device_id))
        if not self.overwrite and os.path.exists(file_path):
            return
        plt.subplot(2, 2, 1)
        self.plot_demand_info()
        plt.subplot(2, 2, 2)
        self.plot_schedule_info()
        plt.subplot(2, 2, 3)
        self.plot_autoaway_info()
        plt.savefig(file_path)

    def plot_and_write_all_results(self, action_table):
        self.plot_device()
        self.plot_device_stats()
        self.write_results_tsv(action_table)

    def get_device_profile(self):
        """Returns a list of profile/characteristics lines for the device."""
        lines = list()
        baseline_config = self.action_analyzer.get_baseline_config()
        lines.append('Mac Address\t%s' % self.device_history.unique_device_id)
        lines.append('Location\t%s' % self.action_analyzer.location)
        lines.append('Analysis Date\t%s' % self.action_analyzer.date_of_analysis)
        lines.append('Schedule Mode\t%s' % self.action_analyzer.MODE_NAME[self.action_analyzer.schedule_mode])
        lines.append('Actual Mean Heating Target Temp\t%0.1fF' % self.action_analyzer.get_baseline_mean_target_temp_f().heating_target_temp)
        lines.append('Actual Mean Cooling Target Temp\t%0.1fF' % self.action_analyzer.get_baseline_mean_target_temp_f().cooling_target_temp)
        lines.append('Actual Heating Usage (min/day)\t%0.1f' % (
            (self.action_analyzer.get_actual_hvac_usage_minutes() / len(self.action_analyzer.dates)).Heating))
        lines.append('Actual Cooling Usage (min/day)\t%0.1f' % (
            (self.action_analyzer.get_actual_hvac_usage_minutes() / len(self.action_analyzer.dates)).Cooling))
        lines.append('Days of Analysis\t%s' % len(self.action_analyzer.dates))
        lines.append('Acceptance\t%s' % self.action_analyzer.qualify_usage)
        lines.append('AutoAway\t%s' % ('ENABLED' if baseline_config.auto_away.enabled else 'DISABLED'))
        lines.append('AwayLowTemp\t%0.0fF' % baseline_config.auto_away.away_temperature_low_f)
        lines.append('AwayHighTemp\t%0.0fF' % baseline_config.auto_away.away_temperature_high_f)
        lines.append('Has Heat Pump Balance\t%s' % self.action_analyzer.has_heat_pump_balance())
        return lines

    @staticmethod
    def get_action_table_tsv(action_table, action_report=None):
        """Returns a human-readable action table as a TSV."""
        lines = ['ActionTable',
                 'Device          \t%s' % action_table.device_id,
                 'Location        \t%s' % action_table.location,
                 'Date Of Analysis\t%s' % action_table.date_of_analysis,
                 'Available       \t%s' % action_table.available,
                 'Personalized    \t%s' % action_table.personalized,
                 'ScheduleMode    \t%s' % action_table.schedule_mode,
                 '\t'.join(['%-40s' % '',
                            'Heating Usage (min/day)',
                            'Cooling Usage (min/day)',
                            'Savings        ',
                            'Inc. Savings   ',
                            'Comfort Cost   ',
                            'Inc. Cost      ',
                            'Utility        '])]
        if action_table:
            for action in action_table.action:
                description = '%-40s' % ('baseline' if action.is_baseline else action.step[-1].description)
                line = [description,
                        '%12.0f' % (action.analysis.heating_usage_minutes / action.analysis.analysis_period_days),
                        '%12.0f' % (action.analysis.cooling_usage_minutes / action.analysis.analysis_period_days),
                        '%12.1f%%' % (100.0 * action.analysis.savings),
                        '%12.1f%%' % (100.0 * action.step[-1].incremental_savings if action.step else 0.0),
                        '%12.1f%%' % (100.0 * action.analysis.comfort_cost),
                        '%12.1f%%' % (100.0 * action.step[-1].comfort_cost if action.step else 0.0),
                        '%12.1f%%' % (100.0 * action.analysis.utility_score)]
                lines.append('\t'.join(line))
        if action_report:
            lines.extend(
                ['',
                 'ActionReport',
                 'Action Date               \t%s' % action_report.action_date,
                 'Action Items              \t%s' % '\t'.join(action_report.action_line_item),
                 'PreAction Usage (min/day) \t%4.0f' % action_report.pre_action_usage_minutes_per_day,
                 'PostAction Usage (min/day)\t%4.0f' % action_report.post_action_usage_minutes_per_day,
                 'Projected Savings:              \t%4.1f%%' % (100.0 * action_report.predicted_savings)])
            for adjustment in action_report.adjustment:
                lines.append('  Adjustment:                   \t%4.1f%%\t%s' % (
                    100.0 * adjustment.delta_savings, adjustment.reason))
            lines.append('(Estimated) Actual Savings:     \t%4.1f%%' % (100.0 * action_report.estimated_actual_savings))
            if action_report.HasField('year_on_year_savings'):
                lines.append('Year-on-Year Savings:           \t%4.1f%%' % (100.0 * action_report.year_on_year_savings))
        lines.extend(['', '', ''])
        return lines

    def write_results_tsv(self, action_table):
        """Write the results for this device as human-readable TSV."""
        filename = "diamond_{}.tsv".format(self.device_history.unique_device_id)
        file_path = os.path.join(self.directory, filename)
        if not self.overwrite and os.path.exists(file_path):
            return
        lines = ['']
        lines.extend(self.get_device_profile())
        lines.extend(self.get_action_table_tsv(action_table))
        lines.extend(['', ''])
        f = open(file_path, 'w')
        f.write('\n'.join(lines))
        f.close()
