"""General utilities for dealing with files and file names."""

import errno
import os
import shutil

ILLEGAL_CHARS = ["/", "\\"]

NESTPY_ROOT = os.path.dirname(os.path.realpath(__file__))
EUREKA_ROOT = os.path.dirname(NESTPY_ROOT)


def resource_path(*path_args):
    """
    Retrieves the path to the given nestpy resource.
    :param path_args: additional path or file names to the requested resource
    :return: the path to the requested resource

    >>> path_to_configuration_file = nestpy.fileutils.resource_path('goose', 'config', 'macs_algo.lst')
    """
    return os.path.join(NESTPY_ROOT, '..', 'resources', *path_args)


def get_all_files(paths, extension=None):
    """
    Gets a list of all files in the given directory/list of directories.

    Works on directories and lists of directories.

    :param paths: a path or list of paths to recursively search.
    :param extension: the extension to use.
    :rtype: list of absolute file names.
    """

    def file_is_appropriate(filename):
        return not extension or filename.endswith(extension)

    if not isinstance(paths, list):
        paths = [paths]

    found_files = []
    for path in paths:
        if os.path.isdir(path):
            # Path is a folder; walk through it.
            # pylint: disable=unused-variable
            for root, _, files in os.walk(path):
                for filepath in files:
                    if file_is_appropriate(filepath):
                        found_files.append(os.path.join(root, filepath))
            # pylint: enable=unused-variable
        elif file_is_appropriate(path):
            found_files.append(os.path.abspath(path))

    return found_files


def get_path_components(filepath):
    """
    Gets the list of folders that constitute the provided filepath.

    >>> get_path_components("foo/bar/z")
    ["foo", "bar"]

    :param filepath: a path to break down into component folders.
    :return: the folders that make up the path.
    :rtype: list
    """

    path = filepath
    folders = []
    while 1:
        path, folder = os.path.split(path)

        if folder != "":
            folders.append(folder)
        else:
            if path != "":
                folders.append(path)

            break

    folders.reverse()
    return folders


def basename(filename):
    """
    Gets the file's base name, without the extension::

      >>> basename("~/data/analysis_results.csv")
      'analysis_results'

    :param filename: the name of the file to process.
    :rtype: string
    """
    return os.path.splitext(os.path.basename(filename))[0]


def mkdir_p(path):
    """
    Makes a directory only if the directory does not exist.

    :rtype: none
    """

    try:
        os.makedirs(path)
    except OSError as exc:
        if exc.errno == errno.EEXIST and os.path.isdir(path):
            pass
        else:
            raise


def rmdir(path):
    """
    Remove a directory only if the directory exists

    :rtype: none
    """
    try:
        shutil.rmtree(path)
    except OSError as exc:
        if exc.errno == errno.ENOENT:
            pass
        else:
            raise


def cleanup(string, replacement_char="_"):
    """
    Cleans up a string to make it usable in a filename.

    :param string: the string to clean up.
    :param replacement_char: the character to replace offending characters with.
    :rtype: string
    """

    for illegal_char in ILLEGAL_CHARS:
        string = string.replace(illegal_char, replacement_char)

    return string
