# pylint: disable=no-member, maybe-no-member

import logging

from json import dumps, load
from math import ceil
from os.path import isfile, join as path_join
from serial import Serial
from time import sleep, time

from ..fileutils import EUREKA_ROOT

logger = logging.getLogger(__name__)


class TransitSerial(Serial):

    LOG_VERSION = 2
    logger = None

    def __init__(self, port, baud=115200):
        try:
            super(TransitSerial, self).__init__(port, long(baud), timeout=3)
            sleep(0.5)

            def gen_toggle_feature_func(fmt_reg_bit_index, disable_enable):
                def generated_func(fmt_reg=None):
                    return self._toggle_x_logging(fmt_reg_bit_index, disable_enable, fmt_reg)
                return generated_func

            def gen_is_feature_func(fmt_reg_bit_index):
                def generated_func(fmt_reg=None):
                    return self._is_x_logged(fmt_reg_bit_index, fmt_reg)
                return generated_func

            # config variables are stored in an external json, open it and add them all as variables to the instance of
            # this class
            transit_config_filename = path_join(EUREKA_ROOT,
                                                'resources',
                                                'communication',
                                                'transit_serial_config.json')

            if isfile(transit_config_filename) is not True:
                raise IOError('Could not open config file.')
            transit_config_raw = open(transit_config_filename)
            transit_config = load(transit_config_raw)
            for config_variable, config_value in transit_config.iteritems():
                setattr(self.__class__, config_variable, config_value)

            # dynamically generate all of the enable / disable logging functions
            for reg_name, reg_index in self.FMT_REG_BIT_INDICES.iteritems():
                setattr(self.__class__, 'disable_%s_logging' % reg_name.lower(), gen_toggle_feature_func(reg_index, 0))
                setattr(self.__class__, 'enable_%s_logging' % reg_name.lower(), gen_toggle_feature_func(reg_index, 1))
                setattr(self.__class__, 'is_%s_logged' % reg_name.lower(), gen_is_feature_func(reg_index))

        except OSError:
            logger.exception('Could not connect to device.  ' +
                                  'Make sure it is turned on and not used by any other processes.')


    def _little_to_big_endian(self, data):
        try:
            output = (data.decode('hex')[::-1]).encode('hex')
        except:
            logger.exception('Error converting from little to big endian')
            return False
        return output


    def _construct_raw_cmd(self, api_cmd, cmd=None, arg1=None, arg2=None):
        raw_cmd_list = ['PMTK' + str(api_cmd)]
        if cmd != None:
            raw_cmd_list.append(str(cmd))
        if arg1 != None:
            raw_cmd_list.append(str(arg1))
        if arg2 != None:
            raw_cmd_list.append(str(arg2))
        raw_cmd = ','.join(raw_cmd_list)
        logger.debug('Raw command: %s' % (raw_cmd))
        return raw_cmd


    @staticmethod
    def _checksum_calc(nmea_str):
        chksum_val = 0
        nmea_str = nmea_str.replace('$', '')
        nmea_str = nmea_str.split('*')[0]
        for next_char in nmea_str:
            chksum_val ^= ord(next_char)

        return "%02X" % chksum_val


    def _generate_cmd(self, cmd_str):
        checksum = self._checksum_calc(cmd_str)
        cmd = ''.join(['$', cmd_str, '*', checksum, '\r\n'])
        logger.debug('Final command generated: %s' % (cmd))
        return cmd


    def _check_expected(self, expect, rcvd):
        # break apart line by commas
        rcvd_list = rcvd.split(',')
        # extract received checksum
        rcvd_checksum = (rcvd_list[-1]).split('*')[-1]
        # extract all but checksum and last element of rcvd line
        raw_rcvd = (rcvd_list[0:-1])
        # add back last element by removing * and checksum
        raw_rcvd.append((rcvd_list[-1]).split('*')[0])
        # save last argument
        last_arg = raw_rcvd[-1]
        # generate string that excludes final (unknown) argument
        expect_rcvd = (",".join(raw_rcvd[0:-1])).lstrip('$')
        # put list back together with commas and remove leading $
        no_checksum_rcvd = (",".join(raw_rcvd)).lstrip('$')
        # check if expected command matches received one
        if expect_rcvd != expect:
            logger.debug('Expected response does not match received response')
            return False
        # recompute checksum and see if it matches the one that was recevied
        computed_checksum = self._checksum_calc(no_checksum_rcvd)
        if computed_checksum != rcvd_checksum:
            logger.warn('Received (0x%s) and computed (0x%s) checksum do not match' % (computed_checksum,
                                                                                            rcvd_checksum))
            return False
        return last_arg


    def _check_ack(self, api_cmd, rcvd):
        # break apart line by commas
        rcvd_list = rcvd.split(',')
        # first element of ack packet should contain $PMTK001
        if rcvd_list[0].lstrip('$') != "PMTK001":
            logger.debug('Not an ACK packet')
            return False
        # second element of ack packet should have matching api command
        if int(rcvd_list[1]) != api_cmd:
            logger.debug('Command in ACK does not match api command of sent message')
            return False
        # last element before checksum should contain 3 (0-2 are bad)
        if int(rcvd_list[-1].split('*')[0]) != 3:
            logger.debug('Invalid / unsupported packet or action failed')
            return False
        return True


    def _send_cmd(self, api_cmd, cmd, expect=None, ack=True, timeout=5):
        self.write(cmd)
        if expect is not None:
            expect_rcvd = False
        if ack is True:
            ack_rcvd = False
        # get time of start to kill process if timed out
        start_time = time()
        while True:
            if (time() - start_time) > timeout:
                logger.warn('Timed out waiting for response')
                return False
            try:
                rcvd = (self.readline()).rstrip()
                logger.debug('Received line: %s' % (rcvd))
                if expect is not None and expect_rcvd is False:
                    expect_result = self._check_expected(expect, rcvd)
                    if expect_result is not False:
                        # print rcvd
                        expect_rcvd = True
                if (ack is True) and (ack_rcvd is False) and (self._check_ack(api_cmd, rcvd) is True):
                    ack_rcvd = True
            except:
                sleep(0.15)
            if ((expect is None or (expect is not None and expect_rcvd is True)) and
                (ack is not True or (ack is True and ack_rcvd is True))):
                break
            sleep(0.1)
        if expect is not None:
            return expect_result
        else:
            return True


    def _send_no_expect_cmd(self, api_cmd, cmd, arg1=None, arg2=None):
        raw_cmd = self._construct_raw_cmd(api_cmd, cmd, arg1, arg2)
        return self._send_cmd(api_cmd, self._generate_cmd(raw_cmd))


    def _send_expect_cmd(self,
                         api_cmd,
                         send_cmd,
                         return_cmd,
                         send_arg1=None,
                         send_arg2=None,
                         return_arg1=None,
                         return_arg2=None,
                         ack=True,
                         return_api_cmd=None):
        raw_cmd = self._construct_raw_cmd(api_cmd, send_cmd, send_arg1, send_arg2)
        if return_api_cmd is None:
            return_api_cmd = api_cmd
        raw_expect = self._construct_raw_cmd(return_api_cmd, return_cmd, return_arg1, return_arg2)
        logger.debug('Raw expect: %s' % (raw_expect))
        return self._send_cmd(api_cmd, self._generate_cmd(raw_cmd), raw_expect, ack)


    def _get_next_record_address(self):
        return self._send_expect_cmd(self.API_CMD_DICT['log'],
                                     self.LOG_CMD_DICT['query_log_status'],
                                     self.LOG_CMD_DICT['return_log_status'],
                                     self.QUERY_LOG_STATUS_DICT['rcd_addr'],
                                     None,
                                     self.RETRUN_LOG_STATUS_DICT['rcd_addr'],
                                     None)


    def _read_log(self, addr, read_len):
        # pad left of address with zeros to make it 8 bits
        addr = addr.zfill(8)
        return self._send_expect_cmd(self.API_CMD_DICT['log'],
                                     self.LOG_CMD_DICT['read_log'],
                                     self.LOG_CMD_DICT['log_data_output'],
                                     addr,
                                     read_len.zfill(8),
                                     addr)


    def _get_num_blocks(self):
        next_addr_hex = self._get_next_record_address()
        if next_addr_hex is False:
            logger.warn('Cannot get next record address to compute number of blocks')
            return False
        next_addr = int(next_addr_hex, 16)
        # number of blocks is integer representation of next address over number of addresses per block
        num_blocks = float(next_addr) / float(self.BLOCK_SIZE)
        return int(ceil(num_blocks))


    def _read_log_block(self, block_num):
        first_chunk_addr_pointer = self.BLOCK_SIZE * block_num
        # each block is 32 chunks long, each chunk is 2048 addresses, there are 65536 addresses per block
        first_chunk_addr = (hex(first_chunk_addr_pointer)[2:]).upper()
        # get first chunk of block
        first_chunk = self._read_log(first_chunk_addr, '800')
        if first_chunk is False:
            logger.error('Could not get first chunk of log')
            return False
        for header_chunk_sep in self.KNOWN_HEADER_CHUNK_SEP:
            # look for position of separator
            sep_index = first_chunk.find(header_chunk_sep)
            if sep_index != -1:
                break
        # fail if cannot find separator in first chunk of log
        if sep_index == -1:
            logger.error('Could not find header / chunk separator in first chunk')
            logger.info('Chunk: %s' % first_chunk)
            return False
        # first part of raw data is after spe index (header is bytes 0:sep_index of the first_chunk)
        raw_data = first_chunk[(sep_index+12):]
        i = 1
        while True:
            # blocks are 32 chunks large
            if i == 32:
                break
            # read log by 0x800 (2048 byte) chunks
            addr = (hex(first_chunk_addr_pointer + (i * 2048))[2:]).upper()
            # read 2048 address chunk from logger
            chunk = self._read_log(addr, '800')
            if chunk is False:
                logger.error('Encountered an error while reading chunk %i' % (i))
                return False
            # do this until we get a chunk that is full of FF
            if chunk.count("FFFF") != 1024:
                raw_data += chunk
                i += 1
            else:
                break

        logger.debug('Read %i bytes from log' % (0.5 * len(raw_data)))
        return raw_data.rstrip('FF')


    def _get_recorded_count(self):
        rcd_count_hex = self._send_expect_cmd(self.API_CMD_DICT['log'],
                                              self.LOG_CMD_DICT['query_log_status'],
                                              self.LOG_CMD_DICT['return_log_status'],
                                              self.QUERY_LOG_STATUS_DICT['rcd_rcnt'],
                                              None,
                                              self.RETRUN_LOG_STATUS_DICT['rcd_rcnt'])
        if rcd_count_hex is False:
            return False
        logger.debug('Recorded count: 0x%s' % int(rcd_count_hex, 16))
        return int(rcd_count_hex, 16)


    # generate a new format register in hex with a new value at bit index
    @staticmethod
    def _generate_format_register(in_fmt_reg, bit_index, new_value):
        list_reg = list(bin(int(in_fmt_reg, 16))[2:].zfill(32)[::-1])
        list_reg[bit_index] = str(new_value)
        return hex(int((''.join(list_reg))[::-1].lstrip('0'), 2))[2:].zfill(8).upper()


    def _set_format_register(self, fmt_reg):
        return self._send_no_expect_cmd(self.API_CMD_DICT['log'],
                                        self.LOG_CMD_DICT['setup_log_ctrl'],
                                        self.SETUP_LOG_CTL_DICT['rcd_field'],
                                        fmt_reg)


    def _toggle_x_logging(self, bit_index, new_value, fmt_reg=None):
        if fmt_reg is None:
            fmt_reg = self._get_format_register()
        return self._set_format_register(self._generate_format_register(fmt_reg, bit_index, new_value))


    def _get_format_register(self):
        fmt_reg_hex = self._send_expect_cmd(self.API_CMD_DICT['log'],
                                            self.LOG_CMD_DICT['query_log_status'],
                                            self.LOG_CMD_DICT['return_log_status'],
                                            self.QUERY_LOG_STATUS_DICT['fmt_reg'],
                                            None,
                                            self.RETRUN_LOG_STATUS_DICT['fmt_reg'])
        logger.debug('Format regsiter: 0x%s' % (fmt_reg_hex))
        return fmt_reg_hex


    def _is_x_logged(self, bit, fmt_reg_hex=None):
        if fmt_reg_hex is None:
            fmt_reg_hex = self._get_format_register()
        # convert from hex to int, convert from int to binary, chop off leading 0b then pad left with zeros to be 32
        # bits, flip order so that we can index directly
        fmt_reg_bin = bin(int(fmt_reg_hex, 16))[2:].zfill(32)[::-1]
        logger.debug('Format register: %s' % (bin(int(fmt_reg_hex, 16))))
        if int(fmt_reg_bin[bit]) == 1:
            return True
        return False


    def _get_rcd_method(self):
        rcd_method = self._send_expect_cmd(self.API_CMD_DICT['log'],
                                           self.LOG_CMD_DICT['query_log_status'],
                                           self.LOG_CMD_DICT['return_log_status'],
                                           self.QUERY_LOG_STATUS_DICT['rcd_method'],
                                           None,
                                           self.RETRUN_LOG_STATUS_DICT['rcd_method'])
        if int(rcd_method) == 1:
            return 'OVP'
        if int(rcd_method) == 2:
            return 'STP'
        logger.error('Error getting record method')
        return 'Error'


    def enable_verbose(self):
        logger.setLevel(10)


    def get_log_version(self):
        return self.LOG_VERSION


    def disable_all_logging(self):
        return self._set_format_register('0')


    # does not currently work because of the way things are expected
    def get_fix_interval(self):
        print self._send_expect_cmd(self.API_CMD_DICT['get_fix_interval'],
                                    None, None, None, None, None, None, False,
                                    self.API_CMD_DICT['set_log_interval'])


    def set_fix_interval(self, interval):
        # interval is in ms
        api_cmd = self.API_CMD_DICT['set_fix_interval']
        raw_cmd = self._construct_raw_cmd(api_cmd, str(interval))
        raw_cmd += ',0,0,0.0,0.0'
        return self._send_cmd(api_cmd, self._generate_cmd(raw_cmd))


    def set_log_interval(self, interval):
        # interval is in seconds, device expects it in tenths of seconds
        return self._send_no_expect_cmd(self.API_CMD_DICT['log'],
                                        self.LOG_CMD_DICT['setup_log_ctrl'],
                                        self.SETUP_LOG_CTL_DICT['by_sec'],
                                        str(interval*10))


    def get_log_interval(self):
        # returns log interval in seconds
        return float(self._send_expect_cmd(self.API_CMD_DICT['log'],
                                           self.LOG_CMD_DICT['query_log_status'],
                                           self.LOG_CMD_DICT['return_log_status'],
                                           self.QUERY_LOG_STATUS_DICT['sec'],
                                           return_arg1=self.RETRUN_LOG_STATUS_DICT['sec']))/10.


    def get_bt_mac_address(self):
        mac_address_rsp = self._send_expect_cmd(self.API_CMD_DICT['get_bt_mac_address'],
                                                None, None, None, None, None, None, False,
                                                self.API_CMD_DICT['return_bt_mac_address'])
        if mac_address_rsp == False:
            logger.error('There was an error getting the bluetooth MAC address')
            return False
        return self._little_to_big_endian(mac_address_rsp)


    def verify_log_settings(self):
        # get format register in hexadecimal
        fmt_reg_hex = self._get_format_register()
        # loop over all register bits in bit mask dictionary
        for reg_mask, reg_mask_index in self.FMT_REG_BIT_INDICES.iteritems():
            logged = self._is_x_logged(reg_mask_index, fmt_reg_hex)
            default_setting = self.FMT_REG_DEFAULTS[reg_mask]
            msg = 'OK: ' if logged == default_setting else 'FAIL: '
            msg += reg_mask + ' is'
            msg += '' if logged else 'n\'t'
            msg += ' logged and it should'
            msg += '' if default_setting else 'n\'t'
            msg += ' be.'
            if logged != default_setting:
                msg += ' Vefification failed'
                logger.error('%s' % msg)
                return False
            else:
                logger.debug('%s' % msg)
        if self._get_rcd_method() != 'STP':
            return False
        return True


    def stop_logging(self):
        return self._send_no_expect_cmd(self.API_CMD_DICT['log'], self.LOG_CMD_DICT['stop_log'])


    def start_logging(self):
        return self._send_no_expect_cmd(self.API_CMD_DICT['log'], self.LOG_CMD_DICT['start_log'])


    def format_log(self):
        num_blocks = self._get_num_blocks()
        # time in seconds to format a block (estimated to be ~15s longer than all samples seen during development)
        time_per_block = 60
        api_cmd = self.API_CMD_DICT['log']
        raw_cmd = self._construct_raw_cmd(api_cmd, self.LOG_CMD_DICT['format_log'], 1)
        logger.info('Formatting log')
        rsp = self._send_cmd(api_cmd, self._generate_cmd(raw_cmd), ack=True, timeout=(time_per_block * num_blocks))
        if rsp == False:
            logger.error('There was an error formatting the log.')
            return False
        logger.info('Log formatting completed')
        return True


    def generate_log_preamble(self):
        # get format register in hexadecimal
        fmt_reg_hex = self._get_format_register()
        # empty list to store data types that are logged
        data_types_logged = []
        # loop over all register bits in bit mask dictionary
        for reg_mask, reg_mask_index in self.FMT_REG_BIT_INDICES.iteritems():
            if self._is_x_logged(reg_mask_index, fmt_reg_hex):
                data_types_logged.append(reg_mask)
        # output json string of data types
        return dumps(data_types_logged)


    def read_entire_raw_log(self):
        # get number of blocks in log to know how many loops to do
        num_blocks = self._get_num_blocks()
        if num_blocks is False:
            logger.error('Could not get number of blocks in memory')
        # allocate variable to store raw log data
        raw_log = ""
        if num_blocks < 128:
            # stop logging before reading if not full
            self.stop_logging()
        for i in range(0, num_blocks):
            logger.info('Reading block %i of %i' % ((i+1), num_blocks))
            block = self._read_log_block(i)
            if block is not False:
                raw_log += block
            else:
                logger.error('Encountered an error while reading block %i' % (i))
                return False
        if num_blocks < 128:
            # restart logging
            self.start_logging()
        return raw_log
