import os
import shutil
import tempfile
import unittest
from pandas import DataFrame
from pandas.util.testing import assert_frame_equal

from nestpy.avrosupport.read import read_to_data_frame, Reader
from nestpy.avrosupport.write import Writer

from nestpy.test import utils


class TestReadWrite(unittest.TestCase):

    def setUp(self):
        self.tmp_dir = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmp_dir)

    def test_read_write(self):
        original_users = DataFrame({
            "name": ["Joe", "Jane"],
            "favorite_number": [42.0, 7.0],
            "favorite_color": ["blue", "green"]
        })

        path = os.path.join(self.tmp_dir, "users.avro")

        writer = Writer(utils.test_data_file_path('avro/users_1.avsc'))
        writer.write(original_users, path)

        self.assertTrue(os.path.exists(path))

        loaded_users = read_to_data_frame(path)

        assert_frame_equal(loaded_users, original_users)

    def test_read_write_missing_data(self):
        original_users = DataFrame({
            "name": ["Joe", "Jane"],
            "favorite_number": [None, 7],
            "favorite_color": ["blue", None]
        })

        path = os.path.join(self.tmp_dir, "users.avro")

        writer = Writer(utils.test_data_file_path('avro/users_1.avsc'))
        writer.write(original_users, path)

        self.assertTrue(os.path.exists(path))

        loaded_users = read_to_data_frame(path)

        assert_frame_equal(loaded_users, original_users)

    def test_read_multiple_using_readers_schema(self):

        readers_schema_path = utils.test_data_file_path('avro/users_1.avsc')

        users_1 = DataFrame({
            "name": ["Joe", "Jane"],
            "favorite_number": [42.0, 7.0],
            "favorite_color": ["blue", "green"]
        })
        users_2 = DataFrame({
            "name": ["Tinkerbell"],
            "favorite_number": [2.0],
            "favorite_color": ["maroon"],
            "age": [10000.0]
        })

        writer_1 = Writer(utils.test_data_file_path('avro/users_1.avsc'))
        writer_1.write(users_1, os.path.join(self.tmp_dir, "users_1.avro"))

        writer_2 = Writer(utils.test_data_file_path('avro/users_2.avsc'))
        writer_2.write(users_2, os.path.join(self.tmp_dir, "users_2.avro"))

        users = Reader(readers_schema_path).read_path(self.tmp_dir)

        self.assertIsNotNone(users)
        self.assertEqual(users.shape, (3, 3))

        expected = DataFrame({
            "name": ["Joe", "Jane", "Tinkerbell"],
            "favorite_number": [42.0, 7.0, 2.0],
            "favorite_color": ["blue", "green", "maroon"]
        })

        def sorted_by_color(df):
            return df.sort(columns=['favorite_color']).reset_index(drop=True)

        assert_frame_equal(sorted_by_color(expected), sorted_by_color(users))

if __name__ == '__main__':
    unittest.main()
