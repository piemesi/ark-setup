import unittest
from nestpy.avrosupport.read import read_to_data_frame, Reader

from nestpy.test import utils


class TestReadEnergySummaryAvro(unittest.TestCase):

    def test_read_energy_summary(self):

        energy_summary = read_to_data_frame(utils.test_data_file_path('avro/EnergySummary_1.avro'))
        self.assertIsNotNone(energy_summary)
        self.assertEqual(energy_summary.shape, (456, 56))

        for key in ['ActualCoolingTarget',
                    'ActualHeatingTarget',
                    'ActualTimeInCoolingMode',
                    'ActualTimeInHeatingMode',
                    'DSTOffset',
                    'DailySummaryLeaf',
                    'EnergyWinner',
                    'InsideHumidity',
                    'InsideTemperature',
                    'MissingSeconds',
                    'OutsideHumidity',
                    'OutsideTemperature',
                    'ScheduledCoolingTarget',
                    'ScheduledHeatingTarget',
                    'ScheduledRangeTargetMax',
                    'ScheduledRangeTargetMin',
                    'ScheduledTimeInCoolingMode',
                    'ScheduledTimeInHeatingMode',
                    'ScheduledTimeInRangeMode',
                    'SecondsAboveWeeklyAverage',
                    'SecondsAboveWeeklyAverageCool',
                    'SecondsAboveWeeklyAverageHeat',
                    'TimeZoneFile',
                    'Today',
                    'TotalAltHeat1',
                    'TotalAltHeat2',
                    'TotalAutoAway',
                    'TotalAutoDehum',
                    'TotalAux',
                    'TotalCool1',
                    'TotalCool2',
                    'TotalCoolOnTime',
                    'TotalDehum',
                    'TotalEmerHeat',
                    'TotalFan',
                    'TotalFanCool',
                    'TotalGoldLeaf',
                    'TotalHeat1',
                    'TotalHeat2',
                    'TotalHeat3',
                    'TotalHeatOnTime',
                    'TotalHum',
                    'TotalLeaf',
                    'TotalManualAway',
                    'TotalOffMode',
                    'UTCOffset',
                    'ValidSeconds',
                    'WeatherSeconds',
                    'eventLogLineNumber',
                    'eventLogTimestamp',
                    'logSequenceNumber',
                    'logTimestamp',
                    'macAddress',
                    's3Bucket',
                    's3Key',
                    'serialNumber']:
            self.assertTrue(key in energy_summary)

    def test_read_multiple(self):

        path = utils.test_data_file_path('avro')
        energy_summaries = Reader().read_path(path)

        self.assertIsNotNone(energy_summaries)
        self.assertEqual(energy_summaries.shape, (489, 56))


if __name__ == '__main__':
    unittest.main()
