"""
Tests to ensure that we can work with AWS resources.
"""
