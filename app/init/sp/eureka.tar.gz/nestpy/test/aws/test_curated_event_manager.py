import shutil
import tempfile
import unittest
import os
import datetime

from nestpy.aws.curated_event_manager import CuratedEventManager
from nestpy.test.utils import requires_s3


@unittest.skip("Need to configure S3 access for continuous integration job. See EUREKA-337.")
class TestCuratedDownload(unittest.TestCase):

    def setUp(self):
        self.tmp_dir = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmp_dir)

    @requires_s3()
    def test_download_event(self):

        start_date = datetime.date(2012, 1, 1)
        end_date = datetime.date(2012, 1, 2)

        directories = CuratedEventManager().download_event(event='EnergySummary',
                                                           start_date=start_date,
                                                           end_date=end_date,
                                                           destination=self.tmp_dir)
        expected = [os.path.join(self.tmp_dir, 'EnergySummary', date) for date in ['2012-01-01', '2012-01-02']]
        self.assertEquals(directories, expected)

        for path in expected:
            full_path = os.path.join(self.tmp_dir, path)
            self.assertTrue(os.path.exists(full_path), "Expected path [%s] to exist." % full_path)

    @requires_s3()
    def test_create_table_statement(self):
        manager = CuratedEventManager()
        actual = manager.create_table_statement("TopazEvent",
                                                "technology",
                                                "curated_topaz_event",
                                                file_system="hdfs")
        self.assertIsNotNone(actual)
        self.assertTrue("CREATE EXTERNAL TABLE curated_topaz_event" in actual,
                        "Query [%s] didn't include a create table statement." % actual)
        self.assertTrue("hdfs:///data/curated/TopazEvent" in actual,
                        "Query [%s] didn't include the correct location URL." % actual)

    @requires_s3()
    def test_alter_table_add_partition_statement(self):
        manager = CuratedEventManager()
        actual = manager.alter_table_add_partition_statement("foo", "2014-01-01")
        expected = "ALTER TABLE foo ADD PARTITION (day = '2014-01-01') location '2014-01-01';"
        self.assertEquals(actual, expected)

    @requires_s3()
    def test_alter_table_add_partition_statements(self):
        manager = CuratedEventManager()
        actual = manager.create_partition_statements("foo",
                                                              datetime.datetime(2014, 1, 1),
                                                              datetime.datetime(2014, 1, 3))
        expected = """ALTER TABLE foo ADD PARTITION (day = '2014-01-01') location '2014-01-01';
ALTER TABLE foo ADD PARTITION (day = '2014-01-02') location '2014-01-02';
ALTER TABLE foo ADD PARTITION (day = '2014-01-03') location '2014-01-03';"""
        self.assertEquals(actual, expected)

if __name__ == '__main__':
    unittest.main()
