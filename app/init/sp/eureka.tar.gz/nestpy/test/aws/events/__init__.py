"""
Tests that we can work with curated Avro Event data.
"""
