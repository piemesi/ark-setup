import shutil
import tempfile
import unittest
import datetime

from nestpy.avrosupport.events import load
from nestpy.test.utils import requires_s3


@unittest.skip("Need to configure S3 access for continuous integration job. See EUREKA-337.")
class TestCuratedDownload(unittest.TestCase):

    def setUp(self):
        self.tmp_dir = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmp_dir)

    @requires_s3()
    def test_load(self):

        start_date = datetime.date(2012, 1, 1)
        end_date = datetime.date(2012, 1, 2)

        energy_summaries = load(event='EnergySummary',
                                start_date=start_date,
                                end_date=end_date,
                                cache_destination=self.tmp_dir)

        self.assertIsNotNone(energy_summaries)
        self.assertFalse(energy_summaries.empty)

if __name__ == '__main__':
    unittest.main()
