import shutil
import tempfile
import unittest
import os

from nestpy.aws.adhoc_analysis_manager import AdHocAnalysisManager

from nestpy.test.utils import requires_s3


@unittest.skip("Need to configure S3 access for continuous integration job. See EUREKA-337.")
class TestCuratedDownload(unittest.TestCase):

    def setUp(self):
        self.tmp_dir = tempfile.mkdtemp()
        self.issue = 'dyna-222'
        self.downloader = AdHocAnalysisManager(issue=self.issue, cache_destination=self.tmp_dir)

    def tearDown(self):
        shutil.rmtree(self.tmp_dir)

    @requires_s3()
    def test_download_event(self):

        event = "EnergySummary"

        issues = AdHocAnalysisManager.issues()
        self.assertTrue(self.issue in issues, "Expected issue [%s] to be in [%s]" % (self.issue, issues))

        events = self.downloader.events()
        self.assertTrue(event in events)

        energy_summary = self.downloader.load(event=event, parallel=False)
        self.assertIsNotNone(energy_summary)
        self.assertFalse(energy_summary.empty)

        cache_path = os.path.join(self.tmp_dir, 'adhoc-analysis', self.issue)
        self.assertTrue(os.path.exists(cache_path), "Expected path [%s] to exist." % cache_path)

        # Single TSV:
        tsv_path = self.downloader.to_delimited(event=event, parallel=False, combine=True)[0]
        expected_tsv_path = os.path.join(self.tmp_dir, 'adhoc-analysis', self.issue, "%s.txt" % event)
        self.assertEquals(tsv_path, expected_tsv_path)
        self.assertTrue(os.path.exists(tsv_path))

        # Separate TSVs:
        tsv_paths = self.downloader.to_delimited(event=event, parallel=False, combine=False)
        for path in tsv_paths:
            self.assertTrue(os.path.exists(path))


if __name__ == '__main__':
    unittest.main()
