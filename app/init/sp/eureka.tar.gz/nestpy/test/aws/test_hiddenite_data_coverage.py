import unittest

from nestpy.aws.hiddenite_data_coverage import HiddeniteDataCoverage

from nestpy.test.utils import requires_s3


class TestHiddeniteDataCoverage(unittest.TestCase):

    @requires_s3()
    def test_data_coverage(self):

        limit = 5
        coverage = HiddeniteDataCoverage().data_coverage(limit=limit)
        self.assertEquals(limit, len(coverage))

        for col in ["device_id", "date"]:
            self.assertTrue(col in coverage.columns)


if __name__ == '__main__':
    unittest.main()
