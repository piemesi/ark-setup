import datetime
import logging
import pandas as pd

from ..converters import get_tz_aware_datetime
from ..groups.function_applicators import device_history_loader
from ..sql import lookup_device
from ..structures import Diamond

logger = logging.getLogger(__name__)


class EventSummarizer(object):
    """
    Summarizes events for a specified device. Currently only supports Diamond devices.

    Can be called with a list of options like the sample time, summarization method (mean, min, max, last) and number
    of decimals. Furthermore, one can select which events should be included in the summarization.

    >>> import nestpy

    Example:

    >>> event_summarizer = nestpy.EventSummarizer('18b4300a02d9', start_date='2014-07-01', end_date='2014-07-02')

    >>> event_summarizer
    <nestpy.EventSummarizer for '18b4300a02d9'>

    >>> summarized_events = event_summarizer.summarize_events(sample_time_seconds=60,
    >>>                                                       summarization_method=nestpy.EventSummarizer.MEAN)

    >>> summary_data = [{nestpy.EventSummarizer.TITLE: 'IndoorTemperature',
    >>>                  nestpy.EventSummarizer.EVENT: 'BufferedTemperature',
    >>>                  nestpy.EventSummarizer.FIELD: 'temperature',
    >>>                  nestpy.EventSummarizer.DECIMALS: 2,
    >>>                  nestpy.EventSummarizer.INTERPOLATION_METHOD: nestpy.EventSummarizer.TIME,
    >>>                  nestpy.EventSummarizer.SUMMARIZATION_METHOD: nestpy.EventSummarizer.MEAN}]

    >>> summarized_events = event_summarizer.summarize_custom_events(sample_time_seconds=60,
    >>>                                                              summary_data)
    """

    EVENT_TYPES = ['BufferedTemperature',
                   'CurrentState',
                   'UpdateStateResults',
                   'NewSetPoint',
                   'Weather']

    INDOOR_TEMPERATURE = 'IndoorTemperature'
    INDOOR_HUMIDITY = 'IndoorHumidity'
    OUTDOOR_TEMPERATURE = 'OutdoorTemperature'
    OUTDOOR_HUMIDITY = 'OutdoorHumidity'
    COOLING_TARGET_TEMPERATURE = 'CoolingTargetTemperature'
    HEATING_TARGET_TEMPERATURE = 'HeatingTargetTemperature'
    TARGET_TEMPERATURE_TITLE_CONVERTER = {'Cooling': COOLING_TARGET_TEMPERATURE,
                                          'Heating': HEATING_TARGET_TEMPERATURE}

    TIMESTAMP = 'Timestamp'

    TITLE = 'title'
    EVENT = 'event'
    FIELD = 'field'
    DECIMALS = 'decimals'
    INTERPOLATION_METHOD = 'interpolation_method'
    SUMMARIZATION_METHOD = 'summarization_method'

    ZERO = 'zero'
    TIME = 'time'
    INTERPOLATION_METHODS = [ZERO, TIME]

    MAX = 'max'
    MIN = 'min'
    MEAN = 'mean'
    LAST = 'last'
    SUMMARIZATION_METHODS = [MAX, MIN, MEAN, LAST]

    BUFFER_DAYS = 1

    def __init__(self,
                 device,
                 start_date,
                 end_date):

        if isinstance(device, pd.Series):
            self.device = device
        else:
            self.device = lookup_device(device)
        if self.device.device_type not in Diamond.DEVICE_TYPES:
            raise ValueError('EventSummarizer currently only supports Diamond devices')
        self.start_date = start_date
        if self.start_date is not None:
            self.start_date = get_tz_aware_datetime(self.start_date)
        self.end_date = end_date
        if self.end_date is not None:
            self.end_date = get_tz_aware_datetime(self.end_date)

        logger.info('{}: Loading device history'.format(self.device.mac_address))

        self.device_history = device_history_loader(self.device,
                                                    start_date=(self.start_date -
                                                                datetime.timedelta(days=self.BUFFER_DAYS)),
                                                    end_date=(self.end_date +
                                                              datetime.timedelta(days=self.BUFFER_DAYS)),
                                                    event_types=self.EVENT_TYPES,
                                                    index_by_sample_time=True,
                                                    to_local_time=True)

    def __repr__(self):
        return "<nestpy.EventSummarizer for '{}'>".format(self.device.mac_address)

    @staticmethod
    def resample_and_summarize(data, sample_time_seconds, interpolation_method, summarization_method):

        if interpolation_method not in EventSummarizer.INTERPOLATION_METHODS:
            raise ValueError("Invalid interpolation method '{}'".format(interpolation_method))

        if summarization_method not in EventSummarizer.SUMMARIZATION_METHODS:
            raise ValueError("Invalid summarization method '{}'".format(summarization_method))

        downsampled_data = data.resample('1S').interpolate(method=interpolation_method)

        if summarization_method == EventSummarizer.LAST:
            resampled_data = downsampled_data.resample('{}S'.format(sample_time_seconds),
                                                       how=EventSummarizer.LAST,
                                                       closed='right').shift(1)[1:]
        else:
            resampled_data = downsampled_data.resample('{}S'.format(sample_time_seconds),
                                                       how=summarization_method,
                                                       closed='right')

        return resampled_data

    def _get_active_hvac_stages(self):

        return self.device_history.UpdateStateResults.columns[self.device_history.UpdateStateResults.any()].tolist()

    def _get_active_target_temperatures(self):

        target_temperatures = self.device_history.TargetTemperature[self.TARGET_TEMPERATURE_TITLE_CONVERTER.keys()]

        return target_temperatures.columns[~target_temperatures.isnull().all()].tolist()

    def _summarize_custom_event(self,
                                title,
                                event,
                                field,
                                sample_time_seconds,
                                decimals=3,
                                interpolation_method=TIME,
                                summarization_method=MEAN):

        logger.debug('{}: Extracting and summarizing event {}.{}'.format(self.device.mac_address, event, field))

        series = self.resample_and_summarize(
            self.device_history[event][field],
            sample_time_seconds=sample_time_seconds,
            interpolation_method=interpolation_method,
            summarization_method=summarization_method).round(decimals=decimals)

        series.index.name = self.TIMESTAMP
        series.name = title

        return series[(series.index >= self.start_date.replace(tzinfo=self.device_history.get_timezone())) &
                      (series.index < self.end_date.replace(tzinfo=self.device_history.get_timezone()))]

    def summarize_custom_events(self,
                                sample_time_seconds,
                                summary_data):

        if self.device_history is not None:

            logger.info('{}: Extracting and summarizing custom events'.format(self.device.mac_address))

            data = []

            for summary_dict in summary_data:
                data += [self._summarize_custom_event(summary_dict[self.TITLE],
                                                      event=summary_dict[self.EVENT],
                                                      field=summary_dict[self.FIELD],
                                                      sample_time_seconds=sample_time_seconds,
                                                      decimals=summary_dict[self.DECIMALS],
                                                      interpolation_method=summary_dict[self.INTERPOLATION_METHOD],
                                                      summarization_method=summary_dict[self.SUMMARIZATION_METHOD])]

            if data:
                return pd.concat(data, axis=1)

    def summarize_events(self,
                         sample_time_seconds,
                         decimals=3,
                         summarization_method=MEAN,
                         indoor_temperature=True,
                         indoor_humidity=True,
                         outdoor_temperature=True,
                         outdoor_humidity=True,
                         target_temperatures=True,
                         hvac_stages=True):

        if self.device_history is not None:

            logger.info('{}: Extracting and summarizing events'.format(self.device.mac_address))

            summary_data = []

            if indoor_temperature:
                summary_data.append({self.TITLE: self.INDOOR_TEMPERATURE,
                                     self.EVENT: 'BufferedTemperature',
                                     self.FIELD: 'temperature',
                                     self.DECIMALS: decimals,
                                     self.INTERPOLATION_METHOD: EventSummarizer.TIME,
                                     self.SUMMARIZATION_METHOD: summarization_method})

            if indoor_humidity:
                summary_data.append({self.TITLE: self.INDOOR_HUMIDITY,
                                     self.EVENT: 'BufferedTemperature',
                                     self.FIELD: 'humidity',
                                     self.DECIMALS: decimals,
                                     self.INTERPOLATION_METHOD: EventSummarizer.TIME,
                                     self.SUMMARIZATION_METHOD: summarization_method})

            if outdoor_temperature:
                summary_data.append({self.TITLE: self.OUTDOOR_TEMPERATURE,
                                     self.EVENT: 'Weather',
                                     self.FIELD: 'Temperature',
                                     self.DECIMALS: decimals,
                                     self.INTERPOLATION_METHOD: EventSummarizer.TIME,
                                     self.SUMMARIZATION_METHOD: summarization_method})

            if outdoor_humidity:
                summary_data.append({self.TITLE: self.OUTDOOR_HUMIDITY,
                                     self.EVENT: 'Weather',
                                     self.FIELD: 'RelativeHumidity',
                                     self.DECIMALS: decimals,
                                     self.INTERPOLATION_METHOD: EventSummarizer.TIME,
                                     self.SUMMARIZATION_METHOD: summarization_method})

            if target_temperatures:
                for active_target_temperature in self._get_active_target_temperatures():
                    summary_data.append({self.TITLE: self.TARGET_TEMPERATURE_TITLE_CONVERTER[active_target_temperature],
                                         self.EVENT: 'TargetTemperature',
                                         self.FIELD: active_target_temperature,
                                         self.DECIMALS: decimals,
                                         self.INTERPOLATION_METHOD: EventSummarizer.ZERO,
                                         self.SUMMARIZATION_METHOD: summarization_method})

            if hvac_stages:
                for active_hvac_stage in self._get_active_hvac_stages():
                    summary_data.append({self.TITLE: active_hvac_stage,
                                         self.EVENT: 'UpdateStateResults',
                                         self.FIELD: active_hvac_stage,
                                         self.DECIMALS: decimals,
                                         self.INTERPOLATION_METHOD: EventSummarizer.ZERO,
                                         self.SUMMARIZATION_METHOD: summarization_method})

            return self.summarize_custom_events(sample_time_seconds, summary_data)