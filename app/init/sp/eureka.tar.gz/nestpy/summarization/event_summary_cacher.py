import logging

from . import EventSummarizer
from ..cache import Cache

logger = logging.getLogger(__name__)


class EventSummaryCacher(EventSummarizer):
    """
    Summarizes and caches events for a specified device. Currently only supports Diamond devices.

    Can be called with a list of options like the sample time, summarization method (mean, min, max, last) and number
    of decimals. Furthermore, one can select which events should be included in the summarization.

    >>> import nestpy

    Example:

    >>> event_summary_cacher = nestpy.EventSummaryCacher('18b4300a02d9', start_date='2014-07-01', end_date='2014-07-02')

    >>> event_summary_cacher
    <nestpy.EventSummaryCacher for '18b4300a02d9'>

    >>> event_summary_cacher.summarize_and_cache_events(sample_time=60,
    >>>                                                 summarization_method=nestpy.EventSummarizer.MEAN)

    >>> summary_data = [{nestpy.EventSummarizer.TITLE: 'IndoorTemperature',
    >>>                  nestpy.EventSummarizer.EVENT: 'BufferedTemperature',
    >>>                  nestpy.EventSummarizer.FIELD: 'temperature',
    >>>                  nestpy.EventSummarizer.DECIMALS: 2,
    >>>                  nestpy.EventSummarizer.INTERPOLATION_METHOD: nestpy.EventSummarizer.TIME,
    >>>                  nestpy.EventSummarizer.SUMMARIZATION_METHOD: nestpy.EventSummarizer.MEAN}]

    >>> event_summary_cacher.summarize_and_cache_custom_events(sample_time_seconds=60,
    >>>                                                        summary_data)
    """

    def __init__(self,
                 device,
                 start_date,
                 end_date,
                 cache_id=None,
                 cache_destination=None,
                 cache_backend=None):

        super(EventSummaryCacher, self).__init__(device, start_date, end_date)

        if cache_id is None:
            cache_id = self.device.mac_address
        self.cache = Cache(cache_id=cache_id,
                           cache_destination=cache_destination,
                           cache_backend=cache_backend)

    def __repr__(self):
        return "<nestpy.EventSummaryCacher for '{}'>".format(self.device.mac_address)

    def summarize_and_cache_events(self, *args, **kwargs):

        summarized_events = self.summarize_events(*args, **kwargs)

        if summarized_events is not None:

            logger.info('{}: Caching summarized events'.format(self.device.mac_address))

            self.cache[self.device.mac_address] = summarized_events

    def summarize_and_cache_custom_events(self, *args, **kwargs):

        summarized_events = self.summarize_custom_events(*args, **kwargs)

        if summarized_events is not None:

            logger.info('{}: Caching summarized custom events'.format(self.device.mac_address))

            self.cache[self.device.mac_address] = summarized_events