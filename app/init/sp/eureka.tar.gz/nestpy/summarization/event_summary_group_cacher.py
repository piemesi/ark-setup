import functools
import logging
import pandas as pd

from . import EventSummaryCacher
from ..groups import DeviceGroup, DeviceGroupLookup
from ..groups.function_applicators import parallel_device_group_function_applicator

logger = logging.getLogger(__name__)


class EventSummaryGroupCacher(object):
    """
    Summarizes and caches events for a group of devices. Currently only supports Diamond devices.

    Can be called with a list of options like the sample time, summarization method (mean, min, max, last) and number
    of decimals. Furthermore, one can select which events should be included in the summarization.

    >>> import nestpy

    Example:

    >>> event_summary_group_cacher = nestpy.EventSummaryGroupCacher(['18b4300a02d9', '18b4300a02df'],
    >>>                                                             start_date='2014-07-01',
    >>>                                                             end_date='2014-07-02')

    >>> event_summary_group_cacher
    <nestpy.EventSummaryGroupCacher for 2 devices (2 j49)>

    >>> event_summary_group_cacher.parallel_summarize_and_cache_events(sample_time=60,
    >>>                                                                summarization_method=nestpy.EventSummarizer.MEAN)

    >>> summary_data = [{nestpy.EventSummarizer.TITLE: 'IndoorTemperature',
    >>>                  nestpy.EventSummarizer.EVENT: 'BufferedTemperature',
    >>>                  nestpy.EventSummarizer.FIELD: 'temperature',
    >>>                  nestpy.EventSummarizer.DECIMALS: 2,
    >>>                  nestpy.EventSummarizer.INTERPOLATION_METHOD: nestpy.EventSummarizer.TIME,
    >>>                  nestpy.EventSummarizer.SUMMARIZATION_METHOD: nestpy.EventSummarizer.MEAN}]

    >>> event_summary_group_cacher.parallel_summarize_and_cache_custom_events(sample_time_seconds=60,
    >>>                                                                       summary_data)
    """

    EVENT_SUMMARIES = 'event_summaries'

    def __init__(self,
                 devices,
                 start_date,
                 end_date,
                 cache_destination=None,
                 cache_backend=None):

        if isinstance(devices, pd.DataFrame):
            self.dg = DeviceGroup(devices)
        else:
            self.dg = DeviceGroupLookup(devices)
        self.start_date = start_date
        self.end_date = end_date
        self.cache_destination = cache_destination
        self.cache_backend = cache_backend

    def __repr__(self):

        if not self.dg.devices.empty:
            device_type_counts = self.dg.devices.device_type.value_counts()
            device_type_counts_str = ", ".join(["{} {}".format(device_type_counts[device_type], device_type)
                                                for device_type in device_type_counts.index.values])
            output = "<nestpy.EventSummaryGroupCacher for {} devices ({})>".format(len(self.dg.devices),
                                                                                   device_type_counts_str)
        else:
            output = "<nestpy.EventSummaryGroupCacher>"

        return output

    def _summarize_and_cache_events(self, device, *args, **kwargs):

        logger.info('{}: Caching and summarizing events'.format(device.mac_address))

        try:
            event_summary_cacher = EventSummaryCacher(device,
                                                      self.start_date,
                                                      self.end_date,
                                                      cache_id=device.mac_address,
                                                      cache_destination=self.cache_destination,
                                                      cache_backend=self.cache_backend)

            event_summary_cacher.summarize_and_cache_events(*args, **kwargs)

        except Exception, e:
            logger.exception(e)

    def _summarize_and_cache_custom_events(self, device, *args, **kwargs):

        logger.info('{}: Caching and summarizing custom events'.format(device.mac_address))

        try:
            event_summary_cacher = EventSummaryCacher(device,
                                                      self.start_date,
                                                      self.end_date,
                                                      cache_id=device.mac_address,
                                                      cache_destination=self.cache_destination,
                                                      cache_backend=self.cache_backend)

            event_summary_cacher.summarize_and_cache_custom_events(*args, **kwargs)

        except Exception, e:
            logger.exception(e)

    def parallel_summarize_and_cache_events(self, threads=10, *args, **kwargs):

        logger.info('Caching and summarizing events for {} devices'.format(len(self.dg)))

        parallel_device_group_function_applicator(self.dg,
                                                  functools.partial(self._summarize_and_cache_events, *args, **kwargs),
                                                  threads=threads)

    def parallel_summarize_and_cache_custom_events(self, threads=10, *args, **kwargs):

        logger.info('Caching and summarizing custom events for {} devices'.format(len(self.dg)))

        parallel_device_group_function_applicator(self.dg,
                                                  functools.partial(self._summarize_and_cache_custom_events,
                                                                    *args,
                                                                    **kwargs),
                                                  threads=threads)