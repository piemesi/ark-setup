import glob
import logging
import numpy as np
import os
import pandas as pd
import shutil

from .. import env
from ..scriptutils import create_hexadecimal_str

logger = logging.getLogger(__name__)


class Cache(object):
    """
    Manages the caching of data structures. Supports both a CSV and HDF storage backend.

    List of data structures that is currently supported is limited, but could be expanded in the future.

    >>> import nestpy
    >>> import pandas as pd

    Example:

    >>> cache = nestpy.Cache(cache_id='test')

    >>> cache
    <nestpy.Cache for 'test' containing 0 data structures>

    >>> cache['data_frame'] = pd.DataFrame([[1, 2], [3, 4]])

    >>> cache
    <nestpy.Cache for 'test' containing 1 data structures>

    >>> cache['data_frame']
       0  1
    0  1  2
    1  3  4

    >>> cache.keys()
    ['data_frame']
    """

    HDF = 'hdf'
    CSV = 'csv'
    CACHE_BACKENDS = [HDF, CSV]

    def __init__(self,
                 cache_id=None,
                 cache_destination=None,
                 cache_backend=None):

        self.cache_id = cache_id
        if self.cache_id is None:
            self.cache_id = create_hexadecimal_str()
        self.cache_destination = cache_destination
        if self.cache_destination is None:
            self.cache_destination = env.cache_destination()
        self.cache_backend = cache_backend
        if self.cache_backend is None:
            if env.hdf5_enabled():
                self.cache_backend = self.HDF
            else:
                self.cache_backend = self.CSV
        if self.cache_backend not in self.CACHE_BACKENDS:
            raise ValueError("Cache backend '{}' is not supported".format(self.cache_backend))

        if not os.path.exists(self.cache_destination):
            os.makedirs(self.cache_destination)

    def __repr__(self):
        return "<nestpy.Cache for '{}' containing {} data structures>".format(self.cache_id, len(self.keys()))

    def __getitem__(self, key):
        return self.get(key)

    def __setitem__(self, key, data_structure):
        self.set(key, data_structure)

    def __delitem__(self, key):
        self.delete(key)

    def __iter__(self):
        return iter(self.keys())

    def __len__(self):
        return len(self.keys())

    def _get_csv_directory_path(self):

        directory_path = os.path.join(self.cache_destination, self.cache_id)

        if not os.path.exists(directory_path):
            os.makedirs(directory_path)

        return directory_path

    def _get_csv_file_path(self, key):
        return os.path.join(self._get_csv_directory_path(), "{}.csv".format(key))

    def _get_hdf_file_path(self):
        return os.path.join(self.cache_destination, "{}.h5".format(self.cache_id))

    def _exists(self, key):

        if self.cache_backend == self.HDF:
            file_path = self._get_hdf_file_path()
            if os.path.isfile(file_path):
                with pd.get_store(file_path) as store:
                    return os.path.join("/", key) in store.keys()
            else:
                return False
        elif self.cache_backend == self.CSV:
            return os.path.isfile(self._get_csv_file_path(key))

    def _preprocess(self, data_structure):

        if self.cache_backend == self.HDF:
            if type(data_structure) in [pd.Series, pd.DataFrame, pd.Panel]:
                return data_structure
        elif self.cache_backend == self.CSV:
            if isinstance(data_structure, pd.DataFrame):
                return data_structure

        raise NotImplementedError("Data structure {} currently not supported".format(type(data_structure)))

    def keys(self):

        keys = []

        if self.cache_backend == self.HDF:
            file_path = self._get_hdf_file_path()
            if os.path.isfile(file_path):
                with pd.get_store(file_path) as store:
                    keys += [key[1:] for key in store.keys()]
        elif self.cache_backend == self.CSV:
            directory_path = self._get_csv_directory_path()
            if os.path.exists(directory_path):
                keys += [os.path.split(file_path)[-1].split('.')[0]
                         for file_path in glob.glob(os.path.join(directory_path, "*.csv"))]

        return keys

    def set(self, key, data_structure):

        data_structure = self._preprocess(data_structure)

        if self.cache_backend == self.HDF:
            data_structure.to_hdf(self._get_hdf_file_path(), key)
        elif self.cache_backend == self.CSV:
            data_structure.to_csv(self._get_csv_file_path(key))

    def update(self, key, data_structure):

        existing_data_structure = self.get(key)

        if existing_data_structure is not None:
            new_data_structure = self._preprocess(data_structure)
            if type(existing_data_structure) == type(new_data_structure):
                self.set(key, new_data_structure.combine_first(existing_data_structure))
            else:
                raise TypeError("Data structures must have the same type (got {} and {} instead)"
                                .format(type(existing_data_structure), type(new_data_structure)))
        else:
            self.set(key, data_structure)

    def get(self, key):

        if self._exists(key):
            if self.cache_backend == self.HDF:
                return pd.read_hdf(self._get_hdf_file_path(), key)
            elif self.cache_backend == self.CSV:
                return pd.read_csv(self._get_csv_file_path(key), index_col=0)

    def delete(self, key):

        if self._exists(key):
            if self.cache_backend == self.HDF:
                with pd.get_store(self._get_hdf_file_path()) as store:
                    del store[key]
            elif self.cache_backend == self.CSV:
                os.remove(self._get_csv_file_path(key))

    def clear(self):

        if self.cache_backend == self.HDF:
            file_path = self._get_hdf_file_path()            
            if os.path.isfile(file_path):
                os.remove(file_path)
        elif self.cache_backend == self.CSV:
            directory_path = self._get_csv_directory_path()
            if os.path.exists(directory_path):
                shutil.rmtree(directory_path)