"""
Provides access to Metropolitan area information, such as which devices and structures belong to each metropolitan area.
"""
import json
import pandas as pd

from ..fileutils import resource_path
from .. import sql


import logging
logger = logging.getLogger(__name__)


class MetropolitanAreas(object):
    """Loads metropolitan areas and counties from various data sources.

    Metropolitan areas are configured in a static file. In the future, they might be loaded from census data, in order
    to provide a more robust data set. See http://www.census.gov/population/metro/data/def.html

    Counties are loaded from postal code data. They are used to validate the metropolitan area configuration.
    """

    def __init__(self):
        areas_json_data = open(resource_path('geo', 'metropolitan_areas.json')).read()

        self.areas = json.loads(areas_json_data)
        self.areas_df = self.get_areas_data_frame()

        self.db = sql.ProductionAnalyticsDatabase()
        self.counties = self.get_unique_state_counties()
        self.validate_area_counties()

    def get_areas_data_frame(self):
        area_records = []
        for area_name in self.areas:
            area = self.areas[area_name]
            for state_counties in area:
                state = state_counties['state']
                counties = state_counties['counties']
                for county in counties:
                    area_records.append({u'state_code': unicode(state), u'county': unicode(county)})

        return pd.DataFrame(area_records)

    def get_unique_state_counties(self):
        """
        Find the set of unique state-county records.
        """
        query = "select state_code, county from postal_codes group by state_code, county"
        query_result = self.db.query(query)

        def to_unicode(x):
            try:
                return unicode(x, 'utf-8')
            except UnicodeDecodeError:
                logger.debug("Skipping undecodable string: %s" % x)

        query_result = query_result.applymap(to_unicode)
        return query_result

    def validate_area_counties(self):
        """
        Runs a check to see if the manually configured county/state pairs are actually in the database.
        """

        counties_records = self.counties.to_dict('records')
        for item in self.areas_df.to_dict('records'):
            if item not in counties_records:
                logger.error("Found state/county mismatch with the database: %s", item)
                raise Exception("State/county mismatch")
