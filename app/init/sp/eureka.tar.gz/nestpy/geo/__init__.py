'''
This module contains functions that are useful for geographical calculations and for adding markers and shapes to a
map.  For example, the distance_between_points function computes the distance in meters between two GPS coordinates.
Other examples allow for the generation of a new set of coordinates in the middle two input coordinates or a given
distance from input coordinates given an initial bearing.  Examples of mapping capabilities include drawing circles,
paths, rectangles, and simple markers.
'''
from .geo_calculations import convert_point_to_degrees, convert_point_to_radians, distance_between_points
from .geo_calculations import find_midpoint, get_initial_bearing, get_initial_bearing_degrees
from .geo_calculations import get_square_edge_coordinates, get_terminal_coordinates, is_same_location, is_within_bound
from .geo_calculations import is_within_circle, is_within_rectangle, scale_timedelta
from .nest_gmaps import NestGMaps
from metropolitan_areas import MetropolitanAreas
