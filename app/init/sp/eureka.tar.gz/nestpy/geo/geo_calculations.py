#!/usr/bin/env python
"""
    This is a collection of functions that can be used to do a variety of geoloacation calculations.
"""
from datetime import timedelta
from math import atan2, sqrt, pi, sin, cos, asin, radians, degrees

# units are km
MEAN_EARTH_RADIUS = 6371.01


def convert_point_to_radians(point):
    """
    This function dates a gps point and converts both the latitude and longitude from degrees to radians.

    :param point: A tuple containing the latitude and longitude of the gps point.
    :type point: tuple of floats

    :return: A tuple containing the latitude and longitude of the point in radians.
    :rtype: tuple of floats
    """
    return (radians(point[0]), radians(point[1]))


def convert_point_to_degrees(point):
    """
    This function dates a gps point and converts both the latitude and longitude from radians to degrees.

    :param point: A tuple containing the latitude and longitude of the gps point.
    :type point: tuple of floats

    :return: A tuple containing the latitude and longitude of the point in degrees.
    :rtype: tuple of floats
    """
    return (round(degrees(point[0]), 6), round(degrees(point[1]), 6))


def scale_timedelta(time_delta, multiplier):
    """
    Scales a time delta by the multiplier.

    :param time_delta: Incremental time to be scaled.
    :type time_delta: datetime.timedelta

    :param multiplier: The amount by which time_delta is to be scaled. Must be nonnegative.
    :type multiplier: float

    :return: Product of time_delta and multiplier or False if multiplier is negative.
    :rtype: datetime.timedelta or boolean
    """
    if multiplier < 0:
        return False
    # convert time_delta to seconds as float
    total_seconds = (time_delta.microseconds + (time_delta.seconds + time_delta.days * 24. * 3600.) * 1e6) / 1e6
    # scale time_delta by multiplier
    multiplied_seconds = total_seconds * float(multiplier)
    return timedelta(seconds=multiplied_seconds)


def distance_between_points(point_a, point_b):
    """
    Given the latitude and longitude of two points, a and b, this function returns the as-the-crow-flies
    distance between them using the haversine formula.  The following reference was used to develop this
    function: http://www.movable-type.co.uk/scripts/latlong.html.

    :param point_a: Tuple containing the latitude and longitude (in degrees) of one of the points.
    :type point_a: tuple of floats, i.e., (lat, long), where lat and long are floats

    :param point_b: Tuple containing the latitude and longitude (in degrees) of the other point.
    :type point_b: tuple of floats, i.e., (lat, long), where lat and long are floats

    :return: distance between a and b in meters
    :rtype: float
    """
    # convert radius to meters to ensure proper unit conversion
    rad = MEAN_EARTH_RADIUS * 1000
    (lat_a, lng_a) = convert_point_to_radians(point_a)
    (lat_b, lng_b) = convert_point_to_radians(point_b)
    # the haversine formula
    return round(2*rad*asin(sqrt(sin(0.5*(lat_b - lat_a))**2+cos(lat_a)*cos(lat_b)*sin(0.5*(lng_b - lng_a))**2)), 6)


def is_same_location(point_a, point_b, threshold=5):
    """
    Indicates whether or not to consider two points, a and b, the same.  That is, returns True if the distance
    between the points is below the threshold, e.

    :param point_a: Tuple containing the latitude and longitude (in degrees) of one of the points.
    :type point_a: tuple of floats, i.e., (lat, long), where lat and long are floats

    :param point_b: Tuple containing the latitude and longitude (in degrees) of the other point.
    :type point_b: tuple of floats, i.e., (lat, long), where lat and long are floats

    :param threshold: (optional) Distance threshold in meters,
                      i.e., points are considered different if distance between them exceeds threshold.
    :type threshold: float

    :return: Indicator if points are the same.
    :rtype: bool
    """
    if point_a is None or point_b is None or distance_between_points(point_a, point_b) > threshold:
        return False
    return True


def is_within_rectangle(lat, lng, rectangle):
    """
    Indicates whether or not the location (lat, lng) is within or on the border of a rectangle.
    The rectangle is specified by coordinates of the bottom left and top right corners.

    :param lat: Latitude of the location being evaluated in degrees.
    :type lat: float

    :param lng: Longitude of location being evaluated in degrees.
    :type lng: float

    :param rectangle: Representation of the bounding rectangle.
    :type rectangle: Dictionary of floats
                     - bottom left corner latitude and longitude have keys sw_lat and sw_lng, respectively, in degrees
                     - top right corner latitude and longitude have keys ne_lat and ne_lng, respectively, in degrees

    :return: Indicator if location is within rectangle.
    :rtype: bool
    """
    if ((lat >= rectangle['sw_lat']) and
        (lng >= rectangle['sw_lng']) and
        (lat <= rectangle['ne_lat']) and
        (lng <= rectangle['ne_lng'])):
        return True
    else:
        return False


def is_within_circle(lat, lng, center_lat, center_lng, radius):
    """
    Indicates whether or not the location (lat, lng) is within or on the border of a circlular region.
    The circle is specified by coordinates of the center and a radius.

    :param lat: Latitude of the location being evaluated in degrees.
    :type lat: float

    :param lng: Longitude of location being evaluated in degrees.
    :type lng: float

    :param center_lat: Latitude of the center of the circle.
    :type center_lat: float

    :param center_lng: Longitude of the center of the circle.
    :type center_lng: float

    :param radius: Radius of the circular region.
    :type radius: float

    :return: Indicator if location is within circular region.
    :rtype: bool
    """
    if distance_between_points((lat, lng), (center_lat, center_lng)) <= radius:
        return True
    else:
        return False


def is_within_bound(lat, lng, center_lat, center_lng, radius, use_square=False, square_multiplier=1.5):
    """
    Indicates whether or not the location (lat, lng) is within or on the border of some boundary.
    This is an abstraction of the is_within_rectangle and is_within_circle functions.  The default
    configuration is to utilize the is_within_circle function, but if use_square is set to True,
    a square will be generated that has edges of length rectangle_multipler * radius and is centered
    at (center_lat, center_lng).

    :param lat: Latitude of the location being evaluated.
    :type lat: float

    :param lng: Longitude of location being evaluated.
    :type lng: float

    :param center_lat: Latitude of the center of the region in degrees.
    :type center_lat: float

    :param center_lng: Longitude of the center of the region in degrees.
    :type center_lng: float

    :param radius: Radius of the region.
    :type radius: float

    :param use_square: (optional) Selects using a square region instead of a circular region (default).
                       If this option is used, a square region will be generated which has edges of length
                       radius * square_multiplier.  More specifically, the square will be generated such that
                       a circle of radius (radius * square_multipler) can be inscribed within it.
    :type use_square: bool

    :param square_multiplier: (optional) Amount by which to scale the rectangle, default is 1.5.
    :type square_multiplier: float

    :return: Indicator if location is within region.
    :rtype: bool
    """
    if use_square is True:
        box_coords = get_square_edge_coordinates(center_lat, center_lng, (radius * square_multiplier))
        return is_within_rectangle(lat, lng, box_coords)
    else:
        return is_within_circle(lat, lng, center_lat, center_lng, radius)


def get_square_edge_coordinates(center_lat, center_lng, edge_length):
    """
    Computes the coordinates of the southwest and northeast corners of a square with a given edge length
    centered at (center_lat, center_lng) in degrees.

    :param center_lat: Latitude (in degrees) of the center of the square to be generated.
    :type center_lat: float

    :param center_lng: Longitude (in degrees) of the center of the square to be generated.
    :type center_lng: float

    :param edge_length: Length (in meters) of the edge of the square to be generated.
    :type edge_length: float

    :return: Coordinates (in degrees) of the southwest and northeast corners of the generated square.
    :rtype: Dictionary of floats
            - bottom left corner latitude and longitude have keys sw_lat and sw_lng, respectively, in degrees
            - top right corner latitude and longitude have keys ne_lat and ne_lng, respectively, in degrees
    """
    # convert from meters to kilometers so units all match
    edge_length /= 1000.

    min_lat = -0.5*pi
    max_lat = 0.5*pi
    min_lng = -pi
    max_lng = pi

    center_lat = radians(center_lat)
    center_lng = radians(center_lng)

    # angular edge length in radians on a great circle
    edge_length_rad = edge_length / MEAN_EARTH_RADIUS

    sw_lat = center_lat - edge_length_rad
    ne_lat = center_lat + edge_length_rad

    # not near a pole
    if (sw_lat > min_lat) and (ne_lat < max_lat):
        delta_lng = asin(sin(edge_length_rad) / cos(center_lat))

        sw_lng = center_lng - delta_lng
        if sw_lng < min_lng:
            sw_lng += 2*pi

        ne_lng = center_lng + delta_lng
        if ne_lng > max_lng:
            ne_lng -= 2*pi

    # a pole is within the edge length
    else:
        sw_lat = max(sw_lat, min_lat)
        ne_lat = min(ne_lat, max_lat)
        sw_lng = min_lng
        ne_lng = max_lng

    # convert from radians to degrees and put into dictionary
    bound_coords = {}
    bound_coords['sw_lat'] = round(degrees(sw_lat), 6)
    bound_coords['ne_lat'] = round(degrees(ne_lat), 6)
    bound_coords['sw_lng'] = round(degrees(sw_lng), 6)
    bound_coords['ne_lng'] = round(degrees(ne_lng), 6)

    return bound_coords


def get_initial_bearing(point_a, point_b):
    """
    Given the GPS coordinates of two locations, point_a and point_b, this function returns the``
    initial bearing, or forward azimuth, (in radians) of travel given that movement is from point_a to point_b.
    The following reference was used to develop this function: http://www.movable-type.co.uk/scripts/latlong.html.

    :param point_a: Tuple containing the latitude and longitude (in degrees) of the earliest point.
    :type point_a: tuple of floats, i.e., (lat, long), where lat and long are floats

    :param point_b: Tuple containing the latitude and longitude (in degrees) of the later point.
    :type point_b: tuple of floats, i.e., (lat, long), where lat and long are floats

    :return: Angle of initial bearing in radians.
    :rtype: float
    """
    (lat_a, lng_a) = convert_point_to_radians(point_a)
    (lat_b, lng_b) = convert_point_to_radians(point_b)
    return round(atan2(sin(lng_b - lng_a)*cos(lat_b),
                       cos(lat_a)*sin(lat_b)-sin(lat_a)*cos(lat_b)*cos(lng_b - lng_a)), 6)


def get_initial_bearing_degrees(point_a, point_b):
    """
    Given the GPS coordinates of two locations, point_a and point_b, this function returns the
    initial bearing, or forward azimuth, (in degrees) of travel given that movement is from point_a to point_b.
    This is a simple wrapper around the initial_bearing() function.

    :param point_a: Tuple containing the latitude and longitude (in degrees) of the earliest point.
    :type point_a: tuple of floats, i.e., (lat, long), where lat and long are floats

    :param point_b: Tuple containing the latitude and longitude (in degrees) of the later point.
    :type point_b: tuple of floats, i.e., (lat, long), where lat and long are floats

    :return: Angle of initial bearing in degrees.
    :rtype: float
    """
    return degrees(get_initial_bearing(point_a, point_b))


def get_terminal_coordinates(start_point, initial_bearing, distance):
    """
    Given a starting point and an initial bearing, this function returns the coordinates of a point that
    is a specified distance away assuming travel is along a great circle arc.

    :param start_point: Tuple containing the latitude and longitude (in degrees) of the starting point.
    :type point_a: tuple of floats, i.e., (lat, long), where lat and long are floats

    :param initial_bearing: Angle of initial direction of travel in radians.
    :type initial_bearing: float

    :param distance: Separation (in meters) between starting point and coordinates to be generated assuming
                     travel along a great circle arc.
    :type distance: float

    :return: Tuple containing the latitude and longitude (in degrees) of the terminal point.
    :rtype: tuple of floats, i.e., (lat, long), where lat and long are floats
    """
    (lat, lng) = convert_point_to_radians(start_point)
    # convert distance to meters to ensure proper unit conversion
    distance /= 1000.
    dist_ratio = distance / MEAN_EARTH_RADIUS
    dist_ratio_sin = sin(dist_ratio)
    dist_ratio_cos = cos(dist_ratio)

    start_lat_cos = cos(lat)
    start_lat_sin = sin(lat)
    end_lat = asin((start_lat_sin * dist_ratio_cos) + (start_lat_cos * dist_ratio_sin * cos(initial_bearing)))
    end_lng = lng + atan2(sin(initial_bearing) * dist_ratio_sin * start_lat_cos,
                          dist_ratio_cos - start_lat_sin * sin(end_lat))
    # return lat and long of terminal point in degrees
    return convert_point_to_degrees((end_lat, end_lng))


def find_midpoint(point_a, point_b):
    """
    Given two input locations, point_a and point_b, this function returns the coordinates of the point that
    is midway between the inputs.  It is assumed that travel is along a great circle path.

    :param point_a: Tuple containing the latitude and longitude (in degrees) of the earliest point.
    :type point_a: tuple of floats, i.e., (lat, long), where lat and long are floats

    :param point_b: Tuple containing the latitude and longitude (in degrees) of the later point.
    :type point_b: tuple of floats, i.e., (lat, long), where lat and long are floats

    :return: Tuple containing the latitude and longitude (in degrees) of the midpoint.
    :rtype: tuple of floats, i.e., (lat, long), where lat and long are floats
    """
    (lat_a, lng_a) = convert_point_to_radians(point_a)
    (lat_b, lng_b) = convert_point_to_radians(point_b)
    tmp_x = cos(lat_b) * cos(lat_b - lat_a)
    tmp_y = cos(lat_b) * sin(lng_b - lng_a)
    lat_m = atan2(sin(lat_a) + sin(lat_b), sqrt((cos(lat_a) + tmp_x)**2 + tmp_y**2))
    lng_m = lng_a + atan2(tmp_y, cos(lat_a) + tmp_x)
    return convert_point_to_degrees((lat_m, lng_m))
