from math import pi
from md5 import md5
from random import uniform

from nestpy.env import cache_destination
from nestpy.geo.geo_calculations import get_terminal_coordinates


class NestGMaps:
    """
    This class contains methods for adding shapes (e.g., markers, circles, rectangles) to a map generated using the
    Google Maps API which is outputted locally as an HTML file.
    """

    def __init__(self, center_lat, center_lng, zoom):
        self.center = (float(center_lat), float(center_lng))
        self.zoom = int(zoom)
        self.paths = []
        self.markers_to_draw = []
        self.drawn_marker_locations = []
        self.markers_md5 = []
        self.info_windows = []
        self.num_info_windows = 0
        self.circles = []
        self.num_circles = 0
        self.rectangles = []
        self.num_markers = 0
        self.legend_style = None
        self.legend_content = []
        self.markers = {}
        self.coloricon = 'http://chart.apis.google.com/chart?cht=mm&chs=12x16&chco=FFFFFF,XXXXXX,000000&ext=.png'
        self.html_overlays = []
        self.num_html_overlays = 0
        self.js = []
        self.js_md5 = []
        self.output_compress = False
        self.auto_zoom_coords = []
        self.html = []
        self.css = []
        self.head = []
        self.body = []

        self.MAX_INFO_WINDOW_HEIGHT = 300
        self.JAVASCRIPT_ESCAPE_CHARS = [',', ' ', '-']


    def add_css(self, css):
        """
        This function should be used to add extra css to the resultant html.

        :param css: A list of css lines to be added to the map html.  Each element of the list should contain a
                   dictionary where the key is the indent level and the value is the css line.
        :type css: list of dictionaries

        :return: True if there are no errors, False otherwise.
        :rtype: boolean
        """
        if type(css) is list:
            self.css.extend(css)
            return True
        return False


    def add_circle(self,
                   lat,
                   lng,
                   rad,
                   stroke_color='000000',
                   stroke_width=2,
                   fill_color='000000',
                   fill_opacity=0.0):
        """
        A method for adding a circle to the map.  The circle can be just an outline (the default), or filled in with a
        specified color.

        :param lat: The latitude of the center of the circle.
        :type lat: float

        :param lng: The longitude of the center of the circle.
        :type lng: float

        :param rad: The radius of the circle.
        :type rad: float

        :param stroke_color: (optional) The hexadecimal color code of the color to make the outline of the circle.  The
                             default is black.  Note that there is no checking to verify that the color is a valid
                             hexadecimal string.
        :type stroke_color: string

        :param stroke_width: (optional) The width in pixels of the boundary of the circle.  The default is 2.
        :type stroke_width: integer

        :param fill_color: (optional) The hexadecimal color code of the color to make the interior of the circle.  The
                           default is black.  Note that there is no checking to verify that the color is a valid
                           hexadecimal string.
        :type fill_color: string

        :param fill_opacity: (optional) The opacity of the interior color of the circle where 0 is not visible, and 1
                             is maximum opacity. The default is 0.

        :return: False if there is an error, the number of the circle otherwise.
        :rtype: boolean or integer
        """
        stroke_color = stroke_color.lstrip("#")
        if len(stroke_color) != 6:
            return False
        stroke_color = '#' + stroke_color
        fill_color = fill_color.lstrip("#")
        if len(fill_color) != 6:
            return False
        fill_color = '#' + fill_color
        circle_num = self.num_circles
        self.circles.append((lat, lng, rad, stroke_color, stroke_width, fill_color, fill_opacity, circle_num))
        self.num_circles += 1
        return circle_num


    def add_html_overlay(self, content, location):
        """
        This method allows for adding an html overlay atop the map.  A word of caution: don't make the overlay too big
        or it will cover the entire map area!

        :param content: The html content to be included in the overlay.  Should be formatted as a list of dictionaries
                        where each element in the list is a line of the HTML, and the key of the dictionary is the
                        indent level and the value is the HTML of the line.
        :type content: list of dictionaries

        :param location: A magic string specifying where the map overlay should be. Options are: TOP_CENTER, TOP_LEFT,
                         TOP_RIGHT, LEFT_TOP, RIGHT_TOP, LEFT_CENTER, RIGHT_CENTER, LEFT_BOTTOM, RIGHT_BOTTOM,
                         BOTTOM_CENTER, BOTTOM_LEFT, BOTTOM_RIGHT.
        :type location: string

        :return: Nothing
        """
        self.html_overlays.append((content, location, self.num_html_overlays))
        self.num_html_overlays += 1


    def add_js(self, js):
        """
        This function is used to add javascript code that will be added to the map inside of the initialize() function.

        The parameter is expected to be a list of dictionaries where each item in the list is a javascript line, the
        key of the dictionary is the indent level (0 being the lowest), and the value of the dictionary is the js code.

        To compress the js code (i.e., eliminate whitespace), use set_output_compress(), with input of True.  Note that
        each block of js added is hashed against previously-added blocks and only added if it does not yet exist.

        :param js: A list of javascript lines to be added to the map html.  Each element of the list should contain a
                   dictionary where the key is the indent level and the value is the javascript line.
        :type js: list of dictionaries

        :return: True if there are no errors, False otherwise.
        :rtype: boolean
        """
        if type(js) is list:
            js_md5 = md5(''.join([[v for k,v in line.iteritems()][0] for line in js])).hexdigest()
            if js_md5 not in self.js_md5:
                self.js.extend(js)
                self.js_md5.append(js_md5)
            return True
        return False


    def add_legend(self):
        """
        A method for adding a blank legend to the map.  The position is in the bottom right.

        :return: Nothing
        """
        self.css.append({0 : '#legend { background: #fff; padding: 10px; margin: 10px; border: 2px solid #000; }'})
        self.css.append({0 : '#legend h2 { margin-top: 0; text-align: center; }'})
        self.css.append({0 : '#legend img { vertical-align: middle; }'})
        self.css.append({0 : '#legend #hide_link_box { text-align: center; margin: 10px 0; }'})


    def add_marker(self, lat, lng, color='FF0000', title=None, info=None, group=None):
        """
        This function is used to add a marker to the output map.  While other settings are configurable, only the
        latitude and longitude of the map are needed.

        :param lat: The latitude of the location to place the marker.
        :type lat: float

        :param lng: The longitude of the location to place the marker.
        :type lng: float

        :param color: (optional) The hexadecimal color code of the color to make the marker.  The default is red.  Note
                      that there is no checking to verify that the color is a valid hexadecimal string.
        :type color: string

        :param title: (optional) The title of the marker.  Default is None.
        :type title: string

        :param info: (optional) Text to be included as an infowindow above the marker.  Valid HTML is okay.  The info
                     window will be hidden by default, but will appear upon clicking the marker.
        :type info: string

        :param group: (optional) A string containing a group name.  Groups are used to connect each class of marker to
                      a legend (if added). Default is None.
        :type group: string

        :return: False if there is an error, the number of the marker otherwise.
        :rtype: boolean or integer
        """
        # strip leading pound sign so that it can be appended and handle the parameter having the # or not
        color = color.lstrip("#")
        if len(color) != 6:
            return False
        color = '#' + color
        # save marker number (first marker was number 0)
        marker_num = self.num_markers
        # make sure invalid js characters are escaped
        if group is not None:
            group = self._escape_js_vars(group)
        # compute md5 has of string-concatentated copy of lat and long
        marker_md5 = md5('%.5f_%.5f' % (lat, lng)).hexdigest()
        # if we haven't seen this marker yet, add it to the list
        if marker_md5 not in self.markers_md5:
            self.markers_md5.append(marker_md5)
        else:
            # if this marker has been added to the map, generate a random bearing on the unit circle
            rand_bearing = uniform(0, 2*pi)
            # using the randomly-generated bearing, move the coordinates in this direction by 1 meter
            (lat, lng) = get_terminal_coordinates((lat, lng), rand_bearing, 1)
        # add marker to list of markers to draw on map
        self.markers_to_draw.append((lat, lng, color[1:], title, info, group, marker_num))
        # add the number of this marker to the group to which it is assigned
        if group in self.markers:
            (self.markers[group]).append(marker_num)
        # increment the marker number for the next marker to be added
        self.num_markers += 1
        return marker_num


    def add_marker_legend_entry(self, color, group_id, text):
        """
        A method for adding an entry to the legend. Only entries with a unique group id will be added.

        :param color: The color of the marker to be shown in the legend.
        :type color: string

        :param group_id: The group identifier for the legend entry.  All markers with the same group identifier will be
                         associated with this entry in the legend and will be able to have visibility toggled upon
                         clicking the text of the legend entry.
        :type group_id: string

        :param text: The text title of legend entry.
        :type text: string
        """
        group_id = self._escape_js_vars(group_id)
        color = color.lstrip('#')
        self.legend_content.append({0 : '<div>'})
        self.legend_content.append({1 : '<img src="%s">' % (self.coloricon.replace('XXXXXX', color))})
        self.legend_content.append({1 : ' <a href="javascript:;" id="v_%s" ' % (group_id) +
                                        'title="Click to hide %s markers" ' % (text) +
                                        'style="font-weight: bold;">%s</a>' % (text)})
        self.legend_content.append({0 : '</div>'})
        if group_id not in self.markers:
            self.markers[group_id] = []


    def add_path(self, path, color='FF0000', opacity=1.0):
        """
        A method for adding a path to the map.  The path should be a list of latitude and longitude tuples.

        :param path: A list of tuples of latitudes and longitudes representing the waypoints of the path.
        :type path: list of tuples of floats

        :param color: (optional) The hexadecimal color code of the color to make the plot line.  The default is red.
                      Note that there is no checking to verify that the color is a valid hexadecimal string.
        :type color: string

        :param opacity: (optional) The opacity of the path where 0 is not visible, and 1 is maximum opacity.
        :type opacity: float

        :return: False on error, nothing otherwise.
        :rtype: boolean
        """
        # strip leading pound sign so that it can be appended and handle the parameter having the # or not
        color = color.lstrip("#")
        if len(color) != 6:
            return False
        color = '#' + color
        path.append(color)
        path.append(opacity)
        self.paths.append(path)


    def add_rectangle(self,
                      sw_lat,
                      sw_lng,
                      ne_lat,
                      ne_lng,
                      stroke_color='#000000',
                      stroke_width=2,
                      fill_color='#000000',
                      fill_opacity=0.0):
        """
        A method for adding a rectangle to the map.  The rectangle can be just an outline (the default), or filled in
        with a specified color.  Note that the corners must be the southwest and northeast edges, other corners may
        yield unexpected behavior.

        :param sw_lat: The latitude of the southwest corner of the rectangle.
        :type lat: float

        :param sw_lng: The longitude of the southwest corner of the rectangle.
        :type lng: float

        :param ne_lat: The latitude of the northeast corner of the rectangle.
        :type lat: float

        :param ne_lng: The longitude of the northeast corner of the rectangle.
        :type lng: float

        :param stroke_color: (optional) The hexadecimal color code of the color to make the outline of the rectangle.
                             The default is black.  Note that there is no checking to verify that the color is a valid
                             hexadecimal string.
        :type stroke_color: string

        :param stroke_width: (optional) The width in pixels of the boundary of the rectangle.  The default is 2.
        :type stroke_width: integer

        :param fill_color: (optional) The hexadecimal color code of the color to make the interior of the rectangle.
                           The default is black.  Note that there is no checking to verify that the color is a valid
                           hexadecimal string.
        :type fill_color: string

        :param fill_opacity: (optional) The opacity of the interior color of the circle where 0 is not visible, and 1
                             is maximum opacity. The default is 0.

        :return: False if there is an error, nothing otherwise
        :rtype: boolean
        """
        stroke_color = stroke_color.lstrip("#")
        if len(stroke_color) != 6:
            return False
        stroke_color = '#' + stroke_color
        fill_color = fill_color.lstrip("#")
        if len(fill_color) != 6:
            return False
        fill_color = '#' + fill_color
        self.rectangles.append((sw_lat, sw_lng, ne_lat, ne_lng, stroke_color, stroke_width, fill_color, fill_opacity))


    def draw_map(self, html_filename, title='Google Maps'):
        """
        This function generates the output HTML map including all added elements added using the public methods of this
        class.

        :param html_filename: The filename (including path) of the output HTML file.
        :type html_file: string

        :param title: The HTML title of the output map.
        :type title: string
        """
        f = open(html_filename,'w')

        self._add_head_to_html()
        self._add_body_to_html()
        self.html = [{0 : '<html>'}] + \
                    [[{(k+1):v} for k,v in line.iteritems()][0] for line in self.html] +\
                    [{0 : '</html>'}]
        # print out html
        if self.output_compress == True:
            # include no white space if we want to compress the output html
            f.write(''.join([['' + v for k,v in line.iteritems()][0] for line in self.html]))
        else:
            # include new lines and tabs to make the html more readable
            f.write('\n'.join([['\t'*(k) + v for k,v in line.iteritems()][0] for line in self.html]))

        f.close()


    def set_auto_zoom(self, sw_lat, sw_lng, ne_lat, ne_lng):
        """
        This function leverages the auto zoom functionality built into the Google Maps API.  Setting the southwest
        and northeast coordinates causes the map to auto zoom so that everything in the rectangular area outlined by
        those coordiantes will be visible and centered upon first loading the map.  If plotting a collection of
        markers or plot lines, it is recommended to find the minimum and maximum latitudes and longtitudes to use as
        the southwest and northeast coordinates, respectively.

        :param sw_lat: The latitude of the southwest point of the rectangular area to which to zoom.
        :type sw_lat: float

        :param sw_lng: The longitude of the southwest point of the rectangular area to which to zoom.
        :type sw_lng: float

        :param ne_lat: The latitude of the northeast point of the rectangular area to which to zoom.
        :type ne_lat: float

        :param ne_lng: The longitude of the northeast point of the rectangular area to which to zoom.
        :type ne_lng: float
        """
        self.auto_zoom_coords.append(sw_lat)
        self.auto_zoom_coords.append(sw_lng)
        self.auto_zoom_coords.append(ne_lat)
        self.auto_zoom_coords.append(ne_lng)


    def set_max_info_window_height(self, height):
        """
        This function can be used to change the default (300 px) maximum info window height.

        :param height: The maximum desired height in pixels.
        :type height: integer
        """
        self.MAX_INFO_WINDOW_HEIGHT = height


    def set_output_compress(self, compress_value):
        """
        This function toggles the configuration setting to compress the resultant html file.  If the input parameter is
        True, the resultant html file will contain no whitespace.  If the input is False, white space to make the
        output easier to read will be included.

        :param compress_value: The value of the compression setting to be set.
        :type compress_value: boolean
        """
        if compress_value is True or compress_value is False:
            self.output_compress = compress_value



    def _add_auto_zoom_js(self):
        if self.auto_zoom_coords != []:
            sw_lat = self.auto_zoom_coords[0]
            sw_lng = self.auto_zoom_coords[1]
            ne_lat = self.auto_zoom_coords[2]
            ne_lng = self.auto_zoom_coords[3]
            self.js.append({0 : 'var sw = new google.maps.LatLng (%f,%f);' % (sw_lat, sw_lng)})
            self.js.append({0 : 'var ne = new google.maps.LatLng (%f,%f);' % (ne_lat, ne_lng)})
            self.js.append({0 : 'var bounds = new google.maps.LatLngBounds();'})
            self.js.append({0 : 'bounds.extend (sw);'})
            self.js.append({0 : 'bounds.extend (ne);'})
            self.js.append({0 : 'map.fitBounds(bounds);'})


    def _add_legend_js(self):
        if self.legend_content == []:
            return False
        self.js.append({0 : 'map.controls[google.maps.ControlPosition.RIGHT_BOTTOM].' +
                            'push(document.getElementById(\'legend\'));'})
        self.js.append({0 : 'document.getElementById(\'collapse_legend\').addEventListener(\'click\',function() {'})
        self.js.append({1 :     'if(this.style.fontWeight == \'bold\') {'})
        self.js.append({2 :         'document.getElementById(\'legend_entries\').style.display = \'none\';'})
        self.js.append({2 :         'this.style.fontWeight = \'normal\';'})
        self.js.append({2 :         'this.title = \'Click to expand legend\';'})
        self.js.append({1 :     '} else {'})
        self.js.append({2 :         'document.getElementById(\'legend_entries\').style.display = \'block\';'})
        self.js.append({2 :         'this.style.fontWeight = \'bold\';'})
        self.js.append({2 :         'this.title = \'Click to collapse legend\';'})
        self.js.append({1 :     '}'})
        self.js.append({0 : '}, false);'})


    def _add_html_overlays_js(self):
        if self.html_overlays == []:
            return False
        for html_overlay in self.html_overlays:
            html_overlay_id = 'html_overlay_%i' % html_overlay[2]
            self.js.append({0 : 'map.controls[google.maps.ControlPosition.%s].' % (html_overlay[1]) +
                                'push(document.getElementById(\'%s\'));' % (html_overlay_id)})


    def _add_marker_toggle_js(self):
        if self.markers == {}:
            return False
        marker_list = []
        for marker in self.markers:
            var_name = 'v_%s' % (self._escape_js_vars(marker))
            marker_list.append(var_name)
            self.js.append({0 : 'var %s = %s;' % (var_name,self.markers[marker])})
            self.js.append({0 : 'document.getElementById(\'%s\').' % (var_name) +
                                'addEventListener(\'click\',function() { toggle_markers(this); }, false);'})
        self.js.append({0 : 'document.getElementById(\'hide_link\').addEventListener(\'click\',function() {'})
        self.js.append({1 : 'for (i in devices) {'})
        self.js.append({2 : 'toggle_markers(document.getElementById(devices[i]));'})
        self.js.append({1 : '}'})
        self.js.append({1 : 'if (this.style.fontWeight == \'bold\') {'})
        self.js.append({2 : 'this.style.fontWeight = \'normal\';'})
        self.js.append({2 : 'this.innerHTML = \'Show All\';'})
        self.js.append({1 : '} else {'})
        self.js.append({2 : 'this.style.fontWeight = \'bold\';'})
        self.js.append({2 : 'this.innerHTML = \'Hide All\';'})
        self.js.append({1 : '}'})
        self.js.append({0 : '}, false);'})
        self.js.append({0 : 'var devices = %s;' % (marker_list)})
        self.js.append({0 : 'function toggle_markers(element) {'})
        self.js.append({1 : 'var group = eval(element.id);'})
        self.js.append({1 : 'if(element.style.fontWeight==\'normal\') {'})
        self.js.append({2 : 'for(i in group) { eval(\'m_\' + group[i]).setVisible(true); }'})
        self.js.append({2 : 'element.style.fontWeight = \'bold\';'})
        self.js.append({2 : 'element.title = "Click to hide %s markers";' % (marker)})
        self.js.append({1 : '} else {'})
        self.js.append({2 : 'for(i in group) { eval(\'m_\' + group[i]).' +
                            'setVisible(false); eval(\'miw_\' + group[i]).close();}'})
        self.js.append({2 : 'element.style.fontWeight = \'normal\';'})
        self.js.append({2 : 'element.title = \'Click to show %s markers\';' % (marker)})
        self.js.append({1 : '}'})
        self.js.append({0 : '}'})


    def _escape_js_vars(self, text):
        for escape_char in self.JAVASCRIPT_ESCAPE_CHARS:
            text = text.replace(escape_char, '_')
        return text


    def _add_map_js(self):
        map_js = []
        map_js.append({0 : 'var centerlatlng = new google.maps.LatLng(%f, %f);' % (self.center[0], self.center[1])})
        map_js.append({0 :     'var myOptions = {'})
        map_js.append({1 :         'zoom: %d,' % (self.zoom)})
        map_js.append({1 :         'center: centerlatlng,'})
        map_js.append({1 :         'mapTypeId: google.maps.MapTypeId.ROADMAP,'})
        map_js.append({1 :         'scaleControl: true'})
        map_js.append({0 : '};'})
        map_js.append({0 : 'var map = new google.maps.Map(document.getElementById("map_canvas"), myOptions);'})
        self.js = map_js + self.js


    def _add_paths_js(self):
        if self.paths != []:
            for path in self.paths:
                self._add_path_js(path[:-2], strokeColor = path[-2], strokeOpacity = path[-1])


    def _add_path_js(self, path,
            clickable = False,
            geodesic = True,
            strokeColor = "#FF0000",
            strokeOpacity = 1.0,
            strokeWeight = 2
            ):
        self.js.append({0 : 'var PolylineCoordinates = ['})
        for coordinate in path:
            # latlng = 'new google.maps.LatLng(%f, %f),' % (coordinate[0], coordinate[1])
            self.js.append({1 : 'new google.maps.LatLng(%f, %f),' % (coordinate[0], coordinate[1])})
            # f.write('new google.maps.LatLng(%f, %f),' % (coordinate[0],coordinate[1]))
        self.js.append({0 : '];'})
        self.js.append({0 : 'var Path = new google.maps.Polyline({'})
        self.js.append({1 : 'clickable: %s,' % (str(clickable).lower())})
        self.js.append({1 : 'geodesic: %s,' % (str(geodesic).lower())})
        self.js.append({1 : 'path: PolylineCoordinates,'})
        self.js.append({1 : 'strokeColor: "%s",' %(strokeColor)})
        self.js.append({1 : 'strokeOpacity: %f,' % (strokeOpacity)})
        self.js.append({1 : 'strokeWeight: %d' % (strokeWeight)})
        self.js.append({0 : '});'})
        self.js.append({0 : 'Path.setMap(map);'})


    def _add_markers_js(self):
        if self.markers_to_draw != []:
            for marker in  self.markers_to_draw:
                # lat, long, color, title, info, group, marker number
                self._add_marker_js(marker[0], marker[1], marker[2], marker[3], marker[4], marker[5], marker[6])


    def _add_marker_js(self, lat, lng, color, title, info, group, marker_num):
        self.drawn_marker_locations.append((lat, lng))
        if title == None:
            title = "no implementation"
        if info != None or title != None:
            if info == None:
                info = ''
            else:
                info = '<div class="infowindow">' + info + '</div>'
            self.js.append({0 : 'var miw_%i = new google.maps.InfoWindow({content: \'%s\'});' % (marker_num, info)})
        self.js.append({0 : 'var latlng = new google.maps.LatLng(%f, %f);' % (lat, lng)})
        marker_url = self.coloricon.replace('XXXXXX', color)
        self.js.append({0 : 'var img = new google.maps.MarkerImage(\'%s\');' % (marker_url)})
        self.js.append({0 : 'var m_%i = new google.maps.Marker({' % (marker_num)})
        self.js.append({1 : 'title: "%s",' % (title)})
        self.js.append({1 : 'icon: img,'})
        self.js.append({1 : 'position: latlng'})
        self.js.append({0 : '});'})
        self.js.append({0 : 'm_%i.setMap(map);' % (marker_num)})
        if info != None or title != None:
            self.js.append({0 : 'google.maps.event.addListener(m_%i, ' % (marker_num) +
                                '"click", function() {miw_%i.open(map,m_%i);});'% (marker_num, marker_num)})


    def _add_circles_js(self):
        if self.circles != []:
            for circle in self.circles:
                self._add_circle_js(circle[0],
                                    circle[1],
                                    circle[2],
                                    circle[3],
                                    circle[4],
                                    circle[5],
                                    circle[6],
                                    circle[7])


    def _add_circle_js(self, lat, lng, rad, stroke_color, stroke_weight, fill_color, fill_opacity, circle_num):
        self.js.append({0 : 'var circle_center = new google.maps.LatLng(%f, %f);' % (lat, lng)})
        self.js.append({0 : 'var circleOptions = {'})
        self.js.append({1 : 'strokeColor: "%s",' % (stroke_color)})
        self.js.append({1 : 'strokeOpacity: 0.8,'})
        self.js.append({1 : 'strokeWeight: %d,' % (stroke_weight)})
        self.js.append({1 : 'fillColor: "%s",' % (fill_color)})
        self.js.append({1 : 'fillOpacity: %f,' % (fill_opacity)})
        self.js.append({1 : 'map: map,'})
        self.js.append({1 : 'center: circle_center,'})
        self.js.append({1 : 'radius: %d' % (rad)})
        self.js.append({0 : '};'})
        self.js.append({0 : 'circle_%i = new google.maps.Circle(circleOptions);' % (circle_num)})


    def _add_rectangles_js(self):
        for rect in self.rectangles:
            self._add_rectangle_js(rect[0], rect[1], rect[2], rect[3], rect[4], rect[5], rect[6], rect[7])


    def _add_rectangle_js(self, sw_lat, sw_lng, ne_lat, ne_lng, stroke_color, stroke_weight, fill_color, fill_opacity):

        self.js.append({0 : 'var rect_bounds = new google.maps.LatLngBounds(' +
                                                'new google.maps.LatLng(%f, %f),' % (sw_lat, sw_lng) +
                                                'new google.maps.LatLng(%f, %f));' % (ne_lat, ne_lng)})
        self.js.append({0 : 'var rectOptions = {'})
        self.js.append({1 : 'strokeColor: "%s",' % (stroke_color)})
        self.js.append({1 : 'strokeOpacity: 0.8,'})
        self.js.append({1 : 'strokeWeight: %d, '% (stroke_weight)})
        self.js.append({1 : 'fillColor: "%s",' % (fill_color)})
        self.js.append({1 : 'fillOpacity: %d,' % (fill_opacity)})
        self.js.append({1 : 'map: map,'})
        self.js.append({1 : 'bounds: rect_bounds'})
        self.js.append({0 : '};'})
        self.js.append({0 : 'rectangle = new google.maps.Rectangle(rectOptions);'})


    def _add_html_overlay_css(self):
        if self.html_overlays == []:
            return False
        self.css.append({0 : '.html_overlay {'})
        self.css.append({1 : 'background: #fff;'})
        self.css.append({1 : 'padding: 10px;'})
        self.css.append({1 : 'margin: 10px 10px 10px 75px; border: 2px solid #000;'})
        self.css.append({1 : 'max-height: 500px;'})
        self.css.append({1 : 'overflow: auto;'})
        self.css.append({1 : 'max-width: 500px;'})
        self.css.append({0 : '}'})


    def _add_js_to_head(self):
        self._add_auto_zoom_js()
        self._add_paths_js()
        self._add_legend_js()
        self._add_circles_js()
        self._add_rectangles_js()
        self._add_markers_js()
        self._add_html_overlays_js()
        self._add_marker_toggle_js()
        self._add_map_js()
        self.js = [{-1 : 'function initialize() {'}] + self.js + [{-1 : '}'}]
        self.head.append({0 : '<script type="text/javascript"' +
                              'src="http://maps.google.com/maps/api/js?sensor=false"></script>'})
        self.head.append({0 : '<script type="text/javascript">'})
        self.head.extend([[{(k+2):v} for k,v in line.iteritems()][0] for line in self.js])
        self.head.append({0 : '</script>'})


    def _add_css_to_head(self):
        self._add_html_overlay_css()
        # constrain info window size
        self.css.append({0 : 'div.infowindow { max-height: %ipx; overflow-y:auto; }' % (self.MAX_INFO_WINDOW_HEIGHT)})
        self.head.append({0 : '<style>'})
        self.head.extend([[{(k+1):v} for k,v in line.iteritems()][0] for line in self.css])
        self.head.append({0 : '</style>'})


    def _add_html_overlays_to_body(self):
        if self.html_overlays == []:
            return False
        for html_overlay in self.html_overlays:
            html_overlay_id = 'html_overlay_%i' % html_overlay[2]
            self.body.append({0 : '<div class=\'html_overlay\' id =\'%s\'>' % (html_overlay_id)})
            self.body.extend([[{(k+1):v} for k,v in line.iteritems()][0] for line in html_overlay[0]])
            self.body.append({0 : '</div>'})


    def _add_legend_html_to_body(self):
        if self.legend_content == []:
            return False
        self.body.append({0 : '<div id="legend">'})
        self.body.append({1 : '<h2>Legend</h2>'})
        self.body.append({1 : '<div id="hide_link_box">'})
        self.body.append({2 : '<a id="hide_link" href="javascript:;" style="font-weight: bold;">Hide All</a>'})
        self.body.append({2 : ' | <a id="collapse_legend" href="javascript:;" style="font-weight: bold;" ' +
                              'title="Click to collapse legend">Collapse</a>'})
        self.body.append({1 : '</div>'})
        self.body.append({1 : '<div id="legend_entries">'})
        self.body.extend([[{(k+2):v} for k,v in line.iteritems()][0] for line in self.legend_content])
        self.body.append({1 : '</div>'})
        self.body.append({0 : '</div>'})


    def _add_head_to_html(self):
        self._add_js_to_head()
        self._add_css_to_head()
        self.head = [{0 : '<head>'}] + \
                    [{1 : '<meta name="viewport" content="initial-scale=1.0, user-scalable=no" />'}] + \
                    [{1 : '<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>'}] + \
                    [{1 : '<title>Google Maps - pygmaps </title>'}] + \
                    [[{(k+1):v} for k,v in line.iteritems()][0] for line in self.head] + \
                    [{0 : '</head>'}]
        self.html.extend(self.head)


    def _add_body_to_html(self):
        self._add_html_overlays_to_body()
        self._add_legend_html_to_body()
        self.body = [{0 : '<body style="margin:0px; padding:0px;" onload="initialize()">'}] + \
                    [{1 : '<div id="map_canvas" style="width: 100%; height: 100%;"></div>'}] + \
                    [[{(k+1):v} for k,v in line.iteritems()][0] for line in self.body] + \
                    [{0 : '</body>'}]
        self.html.extend(self.body)


if __name__ == "__main__":

    mymap = NestGMaps(37.428, -122.145, 16)


    # 900 Hansen
    mymap.add_marker(37.418033, -122.140983, "#0000FF")
    # 850 Hansen
    mymap.add_marker(37.418606, -122.140651, "#FF0000")
    # 700 Hansen
    mymap.add_marker(37.419045, -122.140353, "#00FF00")

    # path around Hansen Way, Page Mill Rd, and El Camino Real
    path = [(37.417308, -122.141043),
            (37.417187, -122.142392),
            (37.418806, -122.145504),
            (37.422649, -122.142146),
            (37.422734, -122.141534),
            (37.420954, -122.138240),
            (37.420709, -122.138219),
            (37.418546, -122.140005),
            (37.418958, -122.140814)]

    mymap.add_path(path, color="#000000", opacity=0.5)

    # circle around CineArts
    mymap.add_circle(lat=37.420478,
                     lng=-122.141540,
                     rad=50,
                     stroke_color='#FFFFFF',
                     stroke_width=4,
                     fill_color='#000000',
                     fill_opacity=0.25)

    # Rectangle around nearby building
    mymap.add_rectangle(sw_lat=37.418773,
                        sw_lng=-122.139034,
                        ne_lat=37.419255,
                        ne_lng=-122.138458,
                        stroke_color='#2BB1D6',
                        stroke_width=2,
                        fill_color='#000000',
                        fill_opacity=0.0)

    # auto zoom to include all elements on the map
    mymap.set_auto_zoom(sw_lat=37.417169, sw_lng=-122.146944, ne_lat=37.423918, ne_lng=-122.132824)

    mymap.draw_map(cache_destination() + 'example_map.html')

