import logging
import os
import threading
import Queue
from functools import partial

from boto3 import session
from botocore.client import ClientError
from nestpy import env, converters

logger = logging.getLogger(__name__)

EUREKA_S3_BUCKETS = {
    'production': 'nest.device-logs',
    'ft': 'nest.ft.device-logs',
    'qa': 'nest-qa-c1-device-server',
    'integration': 'nest-qa-c1-device-server',
    'stable': 'nest-qa-c1-device-server',
}

class DownloadStrategy(object):
    """
    Base class to define strategy for:

    1. Construct prefix from a 'params' dictionary attribute. Set params['prefix'] to a prefix string, or
    override with custom params key-value pairs and define usage.
    e.g. setting params['prefix'] = topaz/weury9853490580.tvd", will be used in an S3Downloader to ultimately query S3
    as following : get s3://<bucket_name>/<prefix>

    2. mapping of an object name in S3 to destination filename. override to provide custom implementation.
    e.g. prefix = 'topaz/21312312312fwewef.tvd' can be mapped to 'topaz/21312312312fwewef.tvd.tmp"
    """

    def __init__(self, **kwargs):
        self.params = kwargs

    # Based on custom parameters, get an s3 prefix. Different devices should have different strategies.
    def get_prefix(self):
        if 'prefix' in self.params.keys():
            return self.params['prefix']
        return None

    # Mapping function to map an S3 object name to the destination file name
    def key_to_file(self, key, destination_dir):
        if not key.endswith('/'):
            filename = key.split('/')[-1]
            return os.path.join(destination_dir, filename)


class LogDownloadStrategy(DownloadStrategy):
    """
    Defines behavior for date based s3 objects.
    e.g. prefix = clientevent/c0/2014/10/30/clientevent_18b43029fec0 is constructed has following params:
        - start_date = '2014/10/30'
        - mac_address = '18b43029fec0'
        - log_type = 'clientevent'
    """

    def get_prefix(self):

        prefix = None
        try:
            start_date = converters.convert_to_utc(self.params['start_date'])
            prefix = "%s/%s/%d/%02d/%02d/%s_%s" % (self.params['log_type'],
                                                   self.params['mac_address'][-2:],
                                                   start_date.year,
                                                   start_date.month,
                                                   start_date.day,
                                                   self.params['log_type'],
                                                   self.params['mac_address'])
        except Exception as e:
            raise e('Unable to get prefix, check arguments: ' + str(e))

        return prefix

class TvdLogDownloadStrategy(DownloadStrategy):

    """
    Defines strategy for downloading tvd files:
    e.g. prefix = topaz/05c5508dabb1e19dc39533d7f1c3cc40199db3b6.tvd has params:
        - tvd_directory = 'topaz'
        - uri_filename = '05c5508dabb1e19dc39533d7f1c3cc40199db3b6.tvd'
    """

    def key_to_file(self, key, destination_dir):
        if not key.endswith('/'):
            filename = key.split('/')[-1] +'.tmp'
            return os.path.join(destination_dir, filename)

    def get_prefix(self):

        prefix = None
        try:
            prefix = os.path.join(self.params['tvd_directory'],
                                  self.params['uri_filename'])
        except Exception as e:
             raise e('Unable to get prefix, check arguments: ' + str(e))

        return prefix


class LogDownloadStrategyFactory():
    """
    Factory Class to generate new instances of download strategies based on bucket name.
    'kwargs' needs to be passed based on type of instance required, else an error will be thrown.
    """
    """ Create new type for a new strategy and insert here."""
    DEVICE_STRATEGIES = { 'tvd.nestlabs.com' : TvdLogDownloadStrategy }

    @classmethod
    def load_instance(cls, bucket_name, **kwargs):
        strategy_type = cls.DEVICE_STRATEGIES.get(bucket_name, LogDownloadStrategy)
        return strategy_type(**kwargs)


class S3Downloader(object):

    def __init__(self, bucket_name=None, tier='ft', destination=env.cache_destination()):

        self.__client = None
        self.tier = tier
        self.destination = destination
        self.bucket_name = bucket_name if bucket_name else EUREKA_S3_BUCKETS.get(self.tier, '')
        self.download_strategy = None
        self.errors = {}
        self._connect()

    def set_download_strategy_from_bucket(self, **kwargs):
        """ Load a strategy based on bucket name as defined in DEVICE_STRATEGIES """
        self.download_strategy = LogDownloadStrategyFactory.load_instance(self.bucket_name, **kwargs)

    def set_download_strategy(self, strategy_type):
        """ Set a strategy explicitly, by instantiating the strategy class externally with params. """
        if isinstance(strategy_type, DownloadStrategy):
            self.download_strategy = strategy_type
        else:
            raise Exception('Invalid strategy type found')

    def set_destination(self, destination):
        self.destination = destination

    def get_s3_prefix(self, prefix_override=None):
        if prefix_override:
            return prefix_override

        return self.download_strategy.get_prefix()

    def _connect(self):

        try:
            if self.__client:
                logger.info('Already connected, skipping connection ....')

            s3_resource = session.Session().resource('s3')
            self.__client = s3_resource.meta.client
            self.__client.head_bucket(Bucket=self.bucket_name)

        except ClientError as cle:
            logger.error('Invalid bucket specified, connection failed : %s' % str(cle))
            raise
        except Exception as ex:
            logger.error('Error in connection to AWS S3 bucket: %s' % str(ex))
            raise

    def get_key_list(self, prefix_override=None):

        """ Get S3 object list based on a prefix, prefix is constructed by using appropriate strategy """

        keys = []
        if self.__client:
            s3_prefix = self.get_s3_prefix(prefix_override)
            logger.debug('Getting Key List for bucket %s and prefix %s from tier %s' % (self.bucket_name,
                                                                                        s3_prefix,
                                                                                        self.tier,))

            response = self.__client.list_objects(Bucket=self.bucket_name, Prefix=s3_prefix)
            while response.get('Contents'):
                for content in response.get('Contents'):
                    keys.append(content.get('Key'))
                if not response.get('IsTruncated'):
                    break
                response = self.__client.list_objects(Bucket=self.bucket_name, Prefix=s3_prefix, Marker=keys[-1])

            return keys

        raise Exception("Could not find active connection to S3, try reconnecting..")

    def get_log_files(self, skip_existing=True, parallel=False, max_threads=30, prefix_overide=None):
        """
        :param skip_existing: skip downloading the file if it exists at the destination directory.
        :param parallel: download files in parallel, asynchronously.
        :param max_threads: maximum processes to run in parallel to download files
        :param prefix_overide: override with a prefix string to download
        :return: list of "results" with success marked as "True" or error message along with the file name
        """

        object_list = self.get_key_list(prefix_overide)
        file_names = None

        try:
            key_to_file_func = partial(self.download_strategy.key_to_file, destination_dir=self.destination)
            file_names = map(key_to_file_func, object_list)

            mapped_params = zip(object_list, file_names, [skip_existing]*len(file_names))
            logger.debug('Input params to file transfer : %s' % str(mapped_params))

            if parallel:
                params_queue = Queue.Queue()

                for params in mapped_params:
                    params_queue.put(params)

                for i in range(max_threads):
                    t = threading.Thread(target=self.transfer_data, args=(params_queue, ))
                    t.setDaemon(True)
                    t.start()

                params_queue.join()

            else:
                logger.warning('Initiating non-parallelized download, maybe slow.')
                for params in mapped_params:
                    self.transfer_data_params(params)

        except Exception as e:
            logger.error('Error during download :  %s' % str(e))
            raise e

        return file_names

    def transfer_data(self, params_queue):
        """
        Calls transfer_data_params with parameters and completes queue execution, use only while multi-threading
        :param params_queue: synchronized queue instance to hold a list of parameters
        :return:
        """
        while True:
            try:
                params = params_queue.get_nowait()
            except Queue.Empty:
                return

            self.transfer_data_params(params)
            params_queue.task_done()

    def transfer_data_params(self, params):
        """
        :param params: tuple representing S3 key, corresponding filename and skip existing file flag
        :return:
        """

        try:
            key, filename, skip_existing = params
            if skip_existing and os.path.exists(filename):
                return
            self.__client.download_file(self.bucket_name, key, filename)

        except Exception as e:
            self.errors[params[0]] = str(e)
