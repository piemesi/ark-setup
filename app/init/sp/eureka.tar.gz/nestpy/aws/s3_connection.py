from boto.s3.connection import S3Connection

from .credentials import AWSCredentials


def get_s3_connection():
    """
    :return: a boto S3 connection (see http://boto.readthedocs.org/en/latest/ref/s3.html#module-boto.s3.connection)
    """
    aws_credentials = AWSCredentials()
    return S3Connection(aws_credentials.access_key, aws_credentials.secret_key)
