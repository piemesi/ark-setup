PRODUCTION_DEVICE_LOGS = "nest.device-logs"
FT_DEVICE_LOGS = "nest.ft.device-logs"
TVD_SCHEMAS = "tvd.nestlabs.com"
GOOSE_PROTOTYPE = "goose-prototype.nestlabs.com"

REQUIRED_S3_BUCKETS = [PRODUCTION_DEVICE_LOGS, FT_DEVICE_LOGS, TVD_SCHEMAS]

