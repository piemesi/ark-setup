import os
import subprocess
import logging
from ..decorators import requires_s3, deprecated

logger = logging.getLogger(__name__)

LOCAL_DIRECTORY = os.path.dirname(__file__)
S3CMD_EXEC = 'python "{}"'.format(os.path.join(LOCAL_DIRECTORY, "s3cmd.py"))


@requires_s3
@deprecated("s3cmd is deprecated and replaced with boto3..")
def s3cmd_subprocess_get(s3_path,
                         destination,
                         recursive=True,
                         parallel=False,
                         num_workers=1,
                         skip_existing=True,
                         verbose=False):

    cmd = [S3CMD_EXEC, "get", s3_path, destination]

    if recursive:
        cmd.append("--recursive")

    if parallel:
        cmd.append("--parallel")
        cmd.append("--workers=%d" % num_workers)

    if skip_existing:
        cmd.append("--skip-existing")

    if not verbose:
        cmd.append("> /dev/null 2>&1")

    command = " ".join(cmd)
    logger.debug("Running S3 command: [%s]", command)
    subprocess.call(command, shell=True, close_fds=True)

