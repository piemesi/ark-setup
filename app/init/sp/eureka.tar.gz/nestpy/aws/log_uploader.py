import logging
import requests

logger = logging.getLogger(__name__)


def upload_file_via_logsink(filename,
                            mac_address,
                            type,
                            version=1,
                            sequence_number=0,
                            endpoint='https://log-rts02-iad01.devices.nest.com/upload'):

    contents = None
    with open(filename, 'rb') as file:
        contents = file.read()

    if contents is None:
        raise Exception('Unable to read from file %s' % filename)

    headers = {'Authorization': 'foo',
               'x-nl-mac-address': mac_address,
               'x-nl-log-file-type': type,
               'x-nl-log-file-version': version,
               'x-nl-log-file-sequence-number': sequence_number
              }
    r = requests.post(endpoint,
                      headers=headers,
                      data=contents,
                      verify=False)
    success = (r.status_code == 200)
    if not success:
        logger.warn('Error uploading file %s. Response=%d' % (filename, r.status_code))
    return success
