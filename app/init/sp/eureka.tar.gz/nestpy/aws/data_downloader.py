import copy_reg
import datetime
import hashlib
import logging
import faulthandler
import os
import pytz
import types
import Queue
import threading

from .. import converters

from nestpy.aws.s3_data_downloader import S3Downloader

logger = logging.getLogger(__name__)


HASH_SCHEME_BEGIN = pytz.utc.localize(datetime.datetime(2013, 03, 01))

DT_FORMAT = '%Y-%m-%dT%H:%M:%SZ'
VALID_MAC_ADDRESS = '18b'


def md5_checksum(filepath):
    with open(filepath, 'rb') as fh:
        m = hashlib.md5()
        while True:
            data = fh.read(8192)
            if not data:
                break
            m.update(data)
        return m.hexdigest()

# To allow multiprocess call of a member function, we have to override the
# pickler method.
#
# This solution is based on a post by Steven Bethard:
# http://bytes.com/topic/python/answers/552476-why-cant-you-pickle-instancemethods


def _pickle_method(method):
    func_name = method.im_func.__name__
    obj = method.im_self
    cls = method.im_class
    cls_name = ''
    if func_name.startswith('__') and not func_name.endswith('__'):
        cls_name = cls.__name__.lstrip('_')
    if cls_name:
        func_name = '_' + cls_name + func_name
    return _unpickle_method, (func_name, obj, cls)


def _unpickle_method(func_name, obj, cls):
    for cls in cls.mro():
        try:
            func = cls.__dict__[func_name]
        except KeyError:
            pass
        else:
            break
    return func.__get__(obj, cls)

# This call to copy_reg.pickle allows you to pass methods as the first arg to
# mp.Pool methods. If you comment out this line, `pool.map(self.foo, ...)`
# results in PicklingError: Can't pickle <type 'instancemethod'>: attribute
# lookup __builtin__.instancemethod failed
copy_reg.pickle(types.MethodType, _pickle_method, _unpickle_method)


class DataDownloader(object):
    """
    Fetches device logs from S3 and merges all files for each device.

    .. note:: This utility assumes a file hashing scheme that the service
       adopted in March 2013. Logs older than 3/1/2013 cannot be downloaded
       using this utility.
    """

    def __init__(self, tier,
                 log_type,
                 start_date=None,
                 end_date=None,
                 method='s3',
                 threads=10,
                 concatenate_individual_logs=False,
                 destination=None,
                 remove_duplicates=True):
        """
        :param tier: the tier to get devices from.

        :param log_type:
            the type of logs to retrieve
        :type log_type:
            str

        :param start_date:
            the earliest date to get logs for.
        :type start_date:
            timezone-aware datetime or timezone-naive UTC datetime

        :param end_date:
            the latest date to get logs for.
        :type end_date:
            timezone-aware datetime or timezone-naive UTC datetime

        :param method:
            the method for downloading logs. 's3' is the optimal method for logs stored
            with the new hashing scheme (around 3/2013 to 4/2013). 'analytics' uses
            bin/dump-metric-data on the analytics server to retrieve older logs
        :type method:
            str

        :param threads:
            the number of threads to use while downloading.
        :type threads:
            int

        :param concatenate_individual_logs:
            whether to concatenate the individual files. If set to false,
            delete_intermediate_files will be forced to false.
            Typical users should leave this set to ``True``.
        :type concatenate_individual_logs:
            boolean

        :param destination:
            the destination folder or filename for the downloaded data.

        :param remove_duplicates:
            whether to remove files with duplicate md5 checksums
        :type remove_duplicates:
            boolean
        """

        self.set_tier(tier)
        self.method = method
        self.log_type = log_type

        if start_date is not None:
            self.set_start_date(start_date)
        else:
            self.start_date = start_date

        if end_date is not None:
            self.set_end_date(end_date)
        else:
            self.end_date = end_date

        if self.method == 's3':
            self.threads = threads
        else:
            self.threads = min(threads, 10)

        self.concatenate_individual_logs = concatenate_individual_logs
        self.remove_duplicates = remove_duplicates
        self.destination = destination

    def set_start_date(self, start_date):
        """
        Sets the start date for subsequent data downloads.
        """

        start_date = converters.get_tz_aware_datetime(start_date)
        if start_date < HASH_SCHEME_BEGIN and self.method == 's3':
            logger.debug(('start date [%s] is before the new hashing scheme began [%s]. '
                          'Forcing the use of analytics for log fetching.'),
                         str(start_date), str(HASH_SCHEME_BEGIN))
            self.method = 'analytics'

        self.start_date = start_date

    def set_end_date(self, end_date):
        """
        Sets the end date for subsequent data downloads.
        """

        end_date = converters.get_tz_aware_datetime(end_date)
        if self.start_date > end_date:
            raise ValueError('start date [%s] is after end date [%s]' %
                             (str(self.start_date), str(end_date)))

        self.end_date = end_date

    def set_tier(self, tier):
        """
        Sets the device tier to pull data from.

        :param tier:
            the tier to pull from ('ft', 'qa', 'integration', 'production', or 'all')
        :type tier:
            str
        """

        if tier not in ['ft', 'qa', 'integration', 'production', 'stable', 'all']:
            raise ValueError('tier [%s] is not valid' % tier)

        self.tier = tier

    def concurrent_device_download(self, params_q):
        """
        :param params_q: synchronized multiprocessing Queue object containing list of devices
        """

        logger = logging.getLogger(__name__)
        while True:
            try:
                params = params_q.get_nowait()
                logger.info("Processing device: " + str(params))

            except Queue.Empty:
                return

            self.single_device_download(params)
            params_q.task_done()
            logger.info("Device download completed : " + str(params))


    def single_device_download(self,
                               mac_address,
                               tier=None,
                               log_type=None,
                               destination=None,
                               start_date=None,
                               end_date=None,
                               method=None):
        """
        Downloads data for a single device.

        :param log_type:
            the type of logs to retrieve
        :type log_type:
            str

        :param mac_address:
            the MAC address of the device to download.
        :type mac_address:
            str

        :param destination:
            the parent folder into which logs will be stored. If not
            provided, defaults to the current directory.
        :type destination:
            str

        :param start_date:
            the earliest date to get logs for. If not provided, the existing
            start date will be used.
        :type start_date:
            timezone-aware datetime or timezone-naive UTC datetime

        :param end_date:
            the latest date to get logs for. If not provided, the existing end
            date will be used.
        :type end_date:
            timezone-aware datetime or timezone-naive UTC datetime

        :param method:
            the method for downloading logs. 's3' is the optimal method for logs stored
            with the new hashing scheme (around 3/2013 to 4/2013). 'analytics' uses
            bin/dump-metric-data on the analytics server to retrieve older logs
        :type method:
            str

        :return: the result of the download operation.
        :rtype: string
        """

        retval = 'Error'

        #Allow class properties to be overridden locally
        if not method:
            method = self.method

        if not tier:
            tier = self.tier

        if not log_type:
            log_type = self.log_type

        if not start_date:
            start_date = self.start_date
        else:
            start_date = converters.get_tz_aware_datetime(start_date)
        if start_date <= HASH_SCHEME_BEGIN and method == 's3':
            logger.debug(('start date [%s] is before the new hashing scheme began [%s].'
                          'Forcing the use of analytics for log fetching.'),
                         str(start_date), str(HASH_SCHEME_BEGIN))
            method = 'analytics'

        if not end_date:
            end_date = self.end_date
        else:
            end_date = converters.get_tz_aware_datetime(end_date)
        if not destination:
            destination = self.destination
        if not destination:
            destination = os.path.join(os.getcwd())
        if not os.path.isdir(destination):
            os.mkdir(destination)

        if method == 's3':
            logger.debug("Downloading data for %s to %s using s3", mac_address, destination)
            retval = self.s3_download(mac_address=mac_address,
                                      tier=tier,
                                      log_type=log_type,
                                      destination=destination,
                                      start_date=start_date,
                                      end_date=end_date)

        return retval

    @staticmethod
    def list_logfiles_in_folder(folder,
                                log_type):
        """
        This function returns a list of paths to all files in the specified folder that match the specified log type.
        :param folder: folder name
        :type folder: string
        :param log_type: name of log type - must be found in the filename
        :type log_type: string
        :return: list of all filepaths
        :rtype: list(strings)
        """
        return sorted([os.path.join(folder, filename) for filename in os.listdir(folder) if log_type in filename])

    def s3_download(self,
                    mac_address,
                    tier,
                    log_type,
                    destination,
                    start_date,
                    end_date):
        """
        This function runs s3cmd as a separate process.
        """
        retval = 'Error'
        device_folder = os.path.join(destination, mac_address)
        if not os.path.isdir(device_folder):
            os.mkdir(device_folder)

        num_files_before_fetching = len(self.list_logfiles_in_folder(folder=device_folder,
                                                                     log_type=log_type))

        # iterating through days, as these are the lowest level folders on S3
        # this could be parallelized to speed up, for instance, pulling a year's data for one device
        if tier == 'all':
            tiers = ['production', 'ft', 'qa']
        else:
            tiers = [tier]

        for tier in tiers:
            kwargs = {}
            kwargs['mac_address'] = mac_address
            kwargs['log_type'] = log_type
            kwargs['start_date'] = start_date
            downloader = S3Downloader(tier=tier, destination=device_folder)
            while kwargs['start_date'] <= end_date:
                downloader.set_download_strategy_from_bucket(**kwargs)
                downloader.get_log_files(parallel=True)
                kwargs['start_date'] = kwargs['start_date'] + datetime.timedelta(days=1)

        # examine the individual logs uploaded by the device
        intermediate_files = self.list_logfiles_in_folder(folder=device_folder,
                                                          log_type=log_type)

        if num_files_before_fetching > 0:
            logger.debug("Downloaded %d new files for device %s.",
                         len(intermediate_files) - num_files_before_fetching,
                         mac_address)
        else:
            logger.debug("Downloaded %d files for device %s.",
                         len(intermediate_files),
                         mac_address)

        if len(intermediate_files) > 0:
            if self.remove_duplicates:
                # check for any duplicate logs
                checksum_to_filename = {}
                for intermediate_file in intermediate_files:
                    checksum = md5_checksum(intermediate_file)
                    if checksum in checksum_to_filename:
                        logger.debug('Detected duplicate md5 checksum. Removing file: %s' % intermediate_file)
                        os.remove(intermediate_file)
                    else:
                        checksum_to_filename[checksum] = intermediate_file
                intermediate_files = self.list_logfiles_in_folder(folder=device_folder,
                                                                  log_type=log_type)

            zero_byte_files = [intermediate_file for intermediate_file in intermediate_files
                               if os.path.getsize(intermediate_file) == 0]

            for zero_byte_file in zero_byte_files:
                logger.warn("Detected zero byte file: %s", zero_byte_file)

            # If requested, concatenate individual files into a single event log file
            # Note: individual files are assumed to be gzipped, so the concatenated file is as well
            if self.concatenate_individual_logs:
                destination_filename = os.path.join(destination, "%s_%s.log.gz" % (log_type, mac_address))
                with open(destination_filename, 'w') as outfile:
                    for intermediate_file in intermediate_files:
                        with open(intermediate_file) as infile:
                            outfile.write(infile.read())
                logger.debug("%d files combined to %s", len(intermediate_files), destination_filename)

            retval = 'Success'
        else:
            logger.warn("No files downloaded for device %s." % mac_address)

        return retval


    def parallelized_download(self, device_list):

        """
        :param device_list: list of mac ids of devices for which logs are required
        """

        params_q = Queue.Queue()

        try:
            for device_id in device_list:
                params_q.put(device_id)

            if len(device_list) < self.threads:
                self.threads = len(device_list)

            for i in range(self.threads):
                main_thread = threading.Thread(target=self.concurrent_device_download, args=(params_q, ))
                main_thread.setDaemon(True)
                main_thread.start()

            params_q.join()

        except KeyboardInterrupt as ke:
            faulthandler.dump_traceback()

