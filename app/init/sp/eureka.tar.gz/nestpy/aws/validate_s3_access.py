import logging

from .buckets import REQUIRED_S3_BUCKETS
from .s3_connection import get_s3_connection

logger = logging.getLogger(__name__)


def validate_s3_access():

    logger.info("Validating S3 access.")

    connection = get_s3_connection()

    for bucket in REQUIRED_S3_BUCKETS:
        logger.info("Testing access to S3 bucket: %s", bucket)
        connection.get_bucket(bucket)

    logger.info("S3 access validation complete.")

