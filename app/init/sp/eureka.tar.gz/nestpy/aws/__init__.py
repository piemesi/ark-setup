from .credentials import AWSCredentials
from .adhoc_analysis_manager import AdHocAnalysisManager
from .data_downloader import DataDownloader
from . import curated_event_manager
from . import data_uploader
from . import log_uploader

from . import hiddenite_data_coverage
from . import validate_s3_access
from . import buckets

#TODO: Temporarily placed here pending the refactor in EUREKA-129
import pandas as pd
import ConfigParser
import os
import logging

logger = logging.getLogger(__name__)

TIERS = pd.DataFrame.from_records({"tier": ["production", "ft", "integration", "qa"],
                                   "analytics_database": ["production", "ft", "ft", "ft"],
                                   "service_environment": ["production", "ft", "integration", "qa"],
                                   "s3_environment": ["production", "ft", "qa", "qa"]}, index="tier")

S3CFG_FILE = ".s3cfg"
AWS_CREDS = ".aws/credentials"


def generate_boto_config():
    """
    Auto configuration function:
    Copies aws keys from S3 Config file (created for s3cmd) over to aws credentials file, required by boto3
    """
    logger.debug("Generating boto3 config file...")
    try :
        home_dir = os.path.expanduser("~")
        boto_creds_f = os.path.join(home_dir, AWS_CREDS)
        if os.path.exists(boto_creds_f):
            logger.info("Boto S3 configured...")
            return

        # Read .s3cfg if it exists
        s3cmd_cfg_f = os.path.join(home_dir, S3CFG_FILE)
        if os.path.exists(s3cmd_cfg_f):
            config = ConfigParser.ConfigParser()
            config.read(s3cmd_cfg_f)
            for section in config.sections():
                access_key = config.get(section, "access_key")
                secret_key = config.get(section, "secret_key")
                if access_key and secret_key:
                    create_boto_cfg(access_key, secret_key, boto_creds_f)
                    return

        logger.warn("No Boto S3 credentials found, check configuration options at this link or contact Eureka admin: "
                    "https://images.nestlabs.com/images/Eureka/builds/latest/doc/html/getting_started.html#data-access-configuration")
    except Exception as e:
        logger.error("Error generating boto configuration: " + str(e))


def create_boto_cfg(access_key, secret_key, boto_creds_f):

    try:
        config = ConfigParser.ConfigParser()
        ORIG_DEFAULT_SECT = ConfigParser.DEFAULTSECT
        ConfigParser.DEFAULTSECT = 'default'

        os.mkdir(os.path.join(os.path.expanduser("~"), AWS_CREDS.split('/')[0]))
        boto_cfg_f = open(boto_creds_f, "w")
        config.set(ConfigParser.DEFAULTSECT, "aws_access_key_id", access_key)
        config.set(ConfigParser.DEFAULTSECT, "aws_secret_access_key", secret_key)
        config.write(boto_cfg_f)
        boto_cfg_f.close()

        ConfigParser.DEFAULTSECT = ORIG_DEFAULT_SECT
    except Exception as e:
        logger.error("error creating boto3 configuration file" + str(e))

generate_boto_config()
