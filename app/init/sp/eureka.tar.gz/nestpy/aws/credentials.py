import ConfigParser

from ..credentials import S3_CONFIG_FILE


class AWSCredentials(object):

    def __init__(self):
        config = ConfigParser.ConfigParser()
        config.read([S3_CONFIG_FILE])
        self.access_key = config.get('default', 'aws_access_key_id')
        self.secret_key = config.get('default', 'aws_secret_access_key')
