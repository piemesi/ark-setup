"""
Downloads data which is a result of an ad-hoc data request.

See https://wiki.nestlabs.com/display/ALGO/Accessing+Data
"""
import os

from ..avrosupport.convert_to_delimited import convert_to_delimited
from .s3_data_manager import S3DataManager

S3_ADHOC_ANALYSIS_PREFIX = "s3://data.nestlabs.com/adhoc-analysis"

import logging
logger = logging.getLogger(__name__)


class AdHocAnalysisManager(S3DataManager):

    def __init__(self, issue, subdir='data', **kwargs):
        super(AdHocAnalysisManager, self).__init__(**kwargs)
        self.issue = issue
        self.subdir = subdir
        self.prefix = os.path.join('adhoc-analysis', issue, subdir)

    def events(self):
        """Lists events for which ad-hoc data have been loaded to S3 for this issue.

        :return: list of events for which data have been loaded to S3
        """
        keys = self.list_names(prefix=self.prefix + '/')
        raw_events = [os.path.basename(key).split('.')[0] for key in keys]
        return list(set([event for event in raw_events if event]))  # De-dupe and remove empty strings

    def event_keys(self, event):
        return self.list(prefix='%s/%s' % (self.prefix, event))

    def cache(self, event, parallel):
        logger.info("Caching data. (parallel: [%s])", parallel)
        keys = self.event_keys(event)
        local_files = super(AdHocAnalysisManager, self).cache(keys, parallel)
        return local_files

    def load(self, event, parallel):
        local_files = self.cache(event, parallel)
        return super(AdHocAnalysisManager, self).load(event, local_files)

    def to_delimited(self, event, parallel, combine):
        """
        Dumps all data for a given issue and event into a single or multiple delimited files.

        :param issue: issue for which to dump data
        :param event: event for which to dump data
        :param parallel: whether to run operations in parallel
        :param combine: whether to combine data into a single delimited file
        """
        if combine:
            return [self._to_combined_delimited(event, parallel)]
        else:
            return self._to_individual_delimited(event, parallel)

    def upload_to_s3(self, file_names, overwrite=True):
        """
        Uploads the given files to the issue's adhoc-analysis directory.

        :param issue: issue under which to upload data
        :param file_names: names of files to upload
        :param overwrite: whether to overwrite existing files in S3
        """
        super(AdHocAnalysisManager, self).upload_to_s3(
            os.path.join('adhoc-analysis', self.issue), file_names, overwrite)

    def _cache_path(self):
        return os.path.join(self.cache_destination, 'adhoc-analysis', self.issue)

    def _to_combined_delimited(self, event, parallel):
        """
        Dumps all data for a given issue and event into a single delimited file.

        :param event: event for which to dump data
        :param parallel: whether to run operations in parallel
        """
        logger.info("Writing delimited event data to a single file.")
        data_frame = self.load(event, parallel)
        destination_path = os.path.join(self._cache_path(), "%s.txt" % event)
        logger.info("Writing delimited event data to [%s]", destination_path)
        data_frame.to_csv(destination_path, sep=chr(9), index=False)
        return destination_path

    def _to_individual_delimited(self, event, parallel):
        """
        Dumps all data for a given issue and event into individual delimited files - one for each original Avro file.

        :param event: event for which to dump data
        :param parallel: whether to run operations in parallel
        """
        delimited_files = []
        logger.info("Writing delimited event data to individual files.")
        local_files = self.cache(event, parallel)

        for local_file in local_files:

            destination_filename = "%s.txt" % os.path.splitext(local_file)[0]
            destination_path = os.path.join(self._cache_path(), destination_filename)
            delimited_files.append(destination_path)

            if os.path.exists(destination_path):
                logger.info("Skipping existing delimited file: [%s]", destination_path)
                continue

            logger.info("Writing delimited event data to [%s]", destination_path)
            convert_to_delimited(local_file, destination_path, readers_schema=self.get_event_readers_schema(event))

        return delimited_files

    @staticmethod
    def issues():
        return [key.name.split('/')[1] for key in S3DataManager().list(prefix='adhoc-analysis/dyna')]

