import logging
import pandas
import re
from ..decorators.cache import day_cache
from .buckets import PRODUCTION_DEVICE_LOGS
from .s3_connection import get_s3_connection


logger = logging.getLogger(__name__)


class HiddeniteDataCoverage(object):

    HIDDENITE_LOG_PATTERN = re.compile(
        "hiddenitelog/.*/\d+/\d+/\d+/hiddenitelog_(.*)-(\d+-\d+-\d+T\d+-\d+-\d+\.\d+Z)-v.*-.*.log"
    )
    HIDDENITE_LOG_DATE_FORMAT = "%Y-%m-%dT%H-%M-%S.%fZ"

    @day_cache()
    def data_coverage(self, limit=None):
        """
        :param limit: limit the number of files parsed. Used for testing only.
        :return: device data coverage DataFrame
        """
        logger.info('Determining Hiddenite data coverage. This might take a few minutes.')

        connection = get_s3_connection()
        bucket = connection.get_bucket(PRODUCTION_DEVICE_LOGS)
        device_date_records = []
        result_set = bucket.list("hiddenitelog")

        i = 0
        for key in result_set:

            if limit is not None and i >= limit:
                break

            i += 1

            groups = re.match(self.HIDDENITE_LOG_PATTERN, key.name)
            device_id = groups.group(1)
            log_date = groups.group(2)
            device_date_records.append({"device_id": device_id, "date": log_date})

        device_dates = pandas.DataFrame(device_date_records)
        device_dates.date = pandas.to_datetime(device_dates.date, format=self.HIDDENITE_LOG_DATE_FORMAT)
        logger.debug('Hiddenite data coverage: %s', device_dates)

        return device_dates

