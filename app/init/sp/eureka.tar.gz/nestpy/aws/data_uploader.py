import os
import subprocess

LOCAL_DIRECTORY = os.path.dirname(__file__)
S3CMD_EXEC = os.path.join(LOCAL_DIRECTORY, "s3cmd.py")


def put_file_to_s3(filename,
                   destination):
    cmd = "\"%s\" put \"%s\" \"%s\"" % (S3CMD_EXEC, filename, destination)
    subprocess.call(cmd, close_fds=True)


def is_file_on_s3(s3_location):
    cmd_string = "\"%s\" ls \"%s\"" % (S3CMD_EXEC, s3_location)
    cmd = subprocess.Popen(cmd_string, shell=True, stdout=subprocess.PIPE, close_fds=True)
    cmd_out, _ = cmd.communicate()
    return len(cmd_out) > 0
