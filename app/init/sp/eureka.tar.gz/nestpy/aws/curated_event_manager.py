"""
This module is responsible for downloading curated Avro files from S3 storage to a local directory (e.g. Eureka cache).
"""
# pylint: disable=unused-variable
from datetime import timedelta
import logging
import os
import re

from .credentials import AWSCredentials
from .s3_data_manager import S3DataManager
from .s3_cmd_subprocess import s3cmd_subprocess_get
from ..scriptutils import parallelize


logger = logging.getLogger(__name__)

S3_CURATED_PREFIX = "s3://data.nestlabs.com/curated"


class CuratedEventManager(S3DataManager):

    def download_event(self,
                       event,
                       destination,
                       start_date,
                       end_date):
        """
        Downloads data for a single event, for the given dates.

        :param event: the event for which to download data
        :param destination: the parent folder into which event Avro files will be stored
        :type destination: str

        :param start_date: the earliest date for which to get logs.
        :type start_date: timezone-aware datetime or timezone-naive UTC datetime

        :param end_date: the latest date for which to get logs.
        :type end_date: timezone-aware datetime or timezone-naive UTC datetime

        :return: the result of the download operation.
        :rtype: string
        """
        if not os.path.exists(destination):
            os.mkdir(destination)

        logger.info("Downloading curated S3 data for event type [%s] to path [%s]",
                    event, destination)

        return self.s3_download(event,
                                destination=destination,
                                start_date=start_date,
                                end_date=end_date)

    def download_for_date(self, args):

        event, event_folder, date = args
        s3_directory_to_fetch = os.path.join(S3_CURATED_PREFIX, event, date)

        logger.info("Downloading data from S3 directory: [%s]", s3_directory_to_fetch)

        event_date_path = os.path.join(event_folder, date)
        if not os.path.exists(event_date_path):
            os.mkdir(event_date_path)

        s3cmd_subprocess_get(s3_directory_to_fetch,
                             event_folder,
                             recursive=True,
                             parallel=True,
                             num_workers=30,
                             skip_existing=True)

        return event_date_path

    def s3_download(self,
                    event,
                    destination,
                    start_date,
                    end_date,
                    threads=5):
        """
        This function runs s3cmd as a separate process.
        """
        event_folder = os.path.join(destination, event)

        if not os.path.isdir(event_folder):
            os.mkdir(event_folder)

        delta = end_date - start_date
        dates = [(start_date + timedelta(day)).isoformat() for day in range(delta.days + 1)]
        args = [(event, event_folder, date) for date in dates]
        logger.info("Downloading with args: %s", args)

        results = parallelize(args, threads, self.download_for_date)
        return [path for params, path in results]

    def event_types(self):
        """
        :return: the list of event types that are available in the curated event path in S3.
        """
        events = [key.name.split('/')[-2] for key in super(CuratedEventManager, self).list('curated/')]
        events.remove('curated')
        return events

    def create_table_statement(self, event, database, table, file_system):
        """
        :param event: event for which to generate a create table statement.
        :param database: name of the database in which to create the table.
        :param table: name of the table to create.
        :param file_system: s3 or hdfs. if s3, the will use the s3 configuration keys for the table URL.
        :return: generated create table statement
        """
        avro_schema_json = self.get_event_readers_schema_json(event)

        if avro_schema_json is None:
            raise NotImplementedError("An Avro schema has not been created for event [%s]" % event)

        avro_schema = re.sub(r"\s+", "", avro_schema_json)  # Remove all whitespace from the Avro schema.
        location = self.location(event, file_system)

        template = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                '..', '..', 'resources', 'aws', 'curated_table.sql')
        create_table_statement = open(template).read().format(location=location,
                                                              table=table,
                                                              event=event,
                                                              avro_schema=avro_schema,
                                                              database=database)

        logger.info("Length of create table statement is: %s", len(create_table_statement))

        return create_table_statement

    def location(self, event, file_system):
        """
        :param event: event for which to generate a create table statement.
        :param file_system: s3 or hdfs. if s3, the will use the s3 configuration keys for the table URL.
        :return: generated create table statement
        """
        if file_system == "s3":
            credentials = AWSCredentials()
            return "s3n://{access_key}:{secret_key}@data.nestlabs.com/curated/{event}".format(
                access_key=credentials.access_key,
                secret_key=credentials.secret_key,
                event=event)
        elif file_system == "hdfs":
            return "hdfs:///data/curated/{event}".format(event=event)
        else:
            raise ValueError("Invalid file system [%s]. Valid options are: [s3, hdfs].", file_system)

    def create_partition_statements(self, table, start_date, end_date):
        dates = self.date_range(start_date, end_date)
        return self._create_partition_statements(table, dates)

    def create_partition_statements_from_s3_directories(self, event, table):
        """
        Dynamically generates partition statements based on curated S3 data.
        :param event: event type. E.g. EnergySummary
        :param table: the name of the target table
        """
        event_keys = super(CuratedEventManager, self).list(os.path.join('curated', "%s/" % event))
        key_names = [key.name for key in event_keys]
        partition_dates = [key.split("/")[2] for key in key_names]
        return self._create_partition_statements(table, partition_dates)

    def _create_partition_statements(self, table, dates):
        return "\n".join([self.alter_table_add_partition_statement(table, date) for date in dates])

    @staticmethod
    def date_range(start_date, end_date):
        delta = end_date - start_date
        return [(start_date + timedelta(day)).strftime("%Y-%m-%d") for day in range(delta.days + 1)]

    @staticmethod
    def alter_table_add_partition_statement(table, date):
        return "ALTER TABLE {table} ADD PARTITION (day = '{date}') location '{date}';".format(table=table, date=date)

