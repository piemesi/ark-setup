"""
Utility class for managing S3 data.
"""
import os
from boto.s3.key import Key

from .. import env
from .. import avrosupport
import avro
from .s3_connection import get_s3_connection
from .. scriptutils import parallelize

S3_BUCKET = "data.nestlabs.com"

import logging
logger = logging.getLogger(__name__)


def download_key(params):
    key, cache_destination = params
    local_file = os.path.join(cache_destination, key.name)
    destination_directory = os.path.dirname(local_file)

    if os.path.exists(local_file):
        logger.info("Skipping previously downloaded file [%s]" % local_file)
        return local_file

    if not os.path.exists(destination_directory):
        os.makedirs(destination_directory)

    logger.info("Downloading file [%s]" % local_file)
    key.get_contents_to_filename(local_file)

    return local_file


class S3DataManager(object):

    def __init__(self, cache_destination=env.cache_destination(), threads=20, use_event_readers_schema=False):
        self.cache_destination = cache_destination
        self.threads = threads
        self.connection = get_s3_connection()
        self.data_bucket = self.connection.get_bucket(S3_BUCKET)
        self.use_event_readers_schema = use_event_readers_schema

    def get_event_readers_schema_json(self, event):
        schema_json = None

        schema_s3_key = self.data_bucket.get_key('schemas/generic/%s.avsc' % event)
        if schema_s3_key is not None:
            schema_json = schema_s3_key.get_contents_as_string()
        else:
            logger.warning("No generic Avro schema found for event: %s", event)

        return schema_json

    def get_event_readers_schema(self, event):
        schema = None

        if self.use_event_readers_schema:
            schema_json = self.get_event_readers_schema_json(event)
            if schema_json is not None:
                schema = avro.schema.parse(schema_json)

        return schema

    def list(self, prefix):
        return self.data_bucket.list(prefix=prefix, delimiter='/')

    def list_names(self, prefix):
        return (key.name for key in self.list(prefix=prefix))

    def cache(self, keys, parallel):
        logger.info("Caching data. (parallel: [%s])", parallel)

        if parallel:
            params = [(key, self.cache_destination) for key in keys]
            results = parallelize(params, self.threads, download_key)
            local_files = [local_file for params, local_file in results]
        else:
            local_files = []
            for key in keys:
                local_file = download_key((key, self.cache_destination))
                local_files.append(local_file)

        return local_files

    def load(self, event, local_files):
        return avrosupport.Reader(self.get_event_readers_schema(event)).read_files(local_files)

    def upload_to_s3(self, path, file_names, overwrite=True):
        """
        Uploads the given files to the issue's adhoc-analysis directory.

        :param path: S3 destination path
        :param file_names: local files to upload
        """
        for file_name in file_names:
            base_name = os.path.basename(file_name)
            s3_key = os.path.join(path, 'delimited', base_name)
            logger.info("Uploading file to S3: [%s]", s3_key)

            if self.data_bucket.get_key(s3_key) is not None:
                if not overwrite:
                    raise Exception("File already exists in S3, and overwrite is not enabled.")
                else:
                    logger.debug("Overwriting file for S3 key: [%s]", s3_key)

            k = Key(self.data_bucket)
            k.key = s3_key
            k.set_contents_from_filename(file_name)

