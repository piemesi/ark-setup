"""
Manages multi-faceted device data in a single data frame.

Useful for working with several device characteristics in a single context. For example, combining keyvalue data
with transport data and device history.
"""

from .diamond_frame import DiamondFrame
