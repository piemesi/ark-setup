# pylint: disable=no-member

import json
import pandas
import re
from datetime import datetime, timedelta

from .. import sql
from .. import scriptutils
from .. structures import Diamond

import logging
logger = logging.getLogger(__name__)


class DiamondFrame(object):
    """Loads Diamond device data from many sources into a usable pandas DataFrame.

    Generates a 360 view of a set of devices, by loading disparate data into a single pandas DataFrame. This enables
    multivariate analysis by leveraging native pandas, scipy, and matplotlib programming paradigms, reducing the
    overhead for simple analyses across a variety of data.

    Leverages data from:
        * analytics database
        * report database
        * device logs

    TODO: Remove all Diamond-specific logic and language, and make this work for any device.
    TODO: Make mac_address-based loading tier-agnostic.
    """

    def __init__(self,
                 tier,
                 mac_addresses,
                 start_date=None,
                 end_date=None,
                 event_types=[],
                 include_history=False,
                 threads=30):
        """Creates a new DiamondFrame, loading device characteristics, keyvalues, and history.
        :param tier: the tier of the analytics database to use
        :param mac_addresses: the mac addresses to load
        :param start_date: the start date for loading device history. Defaults to one week prior to end date.
        :param end_date: the end date for loading device history. Defaults to today.
        :param event_types: the event types to load for device history
        :param include_history: whether to include device history
        :param threads: the number of threads to use in parallel data loading
        :return:
        """
        date_format = "%Y-%m-%d"
        if end_date is None:
            end_date = datetime.today().strftime(date_format)

        if start_date is None:
            start_date = (datetime.strptime(end_date, date_format) + timedelta(days=-7)).strftime(date_format)

        self.tier = tier
        self.mac_addresses = mac_addresses
        self.start_date = start_date
        self.end_date = end_date
        self.event_types = event_types
        self.threads = threads
        self.report_db = sql.get_db(tier, 'report')
        self.analytics_db = sql.get_db(tier, 'analytics')
        logger.debug("Loading basic device data.")
        self.devices = self._load_devices_with_keyvalues()

        if include_history:
            logger.debug("Loading device history data.")
            self.devices_with_history = self._load_device_histories()

    def _load_report_device_keyvalues(self, serial_numbers):
        """
        Loads key values for a series of devices
        :param serial_numbers: the device serial numbers. Used to look up devices in the report database.
        :return: DataFrame of device characteristics, drawn from the keyvalue JSON blobs in the stvalue column
        """
        comma_delimited_serial_numbers = ", ".join(["'device.%s'" % serial for serial in serial_numbers])
        kv_query = "select * from nestlabs_devices.keyvalues where stkey in %s" % "(%s)" % comma_delimited_serial_numbers
        keyvalues = self.report_db().query(kv_query)

        def parse_keyvalues(row):
            try:
                return pandas.Series(json.loads(row.stvalue))
            except ValueError:
                logger.warn("Could not parse keyvalues from JSON string: %s", row.stvalue)
                return None

        return keyvalues.apply(parse_keyvalues, axis=1)

    def _load_analytics_devices(self):
        """Loads all devices from the Analytics database

        :return: DataFrame of device data from the analytics.etl_cz_devices table
        """
        comma_delimited_mac_addresses = ", ".join(["'%s'" % mac_address for mac_address in self.mac_addresses])
        query = 'select * from etl_cz_devices where mac_address in %s' % "(%s)" % comma_delimited_mac_addresses
        return self.analytics_db().query(query)

    def _load_devices_with_keyvalues(self):
        """
        Loads device data from the analytics database and combines it with the keyvalues from the report database.
        :return: DataFrame of device data
        """
        devices = self._load_analytics_devices()
        keyvalues = self._load_report_device_keyvalues(devices.serial_number)

        # For common columns in both data frames, use the report data, since it's the system of record.
        merged = devices.merge(keyvalues, on='serial_number', suffixes=('', '_analytics'))
        regex = re.compile(r'.*_analytics$')
        columns_to_keep = [col for col in merged.columns if not regex.match(col)]

        return merged[columns_to_keep]

    def _parallel_load_device_histories(self):
        """
        Loads device histories into a Data Frame
        :return: DataFrame of device histories, with mac_address and device_history columns
        """
        argument_list = scriptutils.expand_device_arguments(
            self.mac_addresses,
            start_date=self.start_date,
            end_date=self.end_date,
            tier=self.tier,
            sort_by_time=True,
            to_local_time=True,
            celsius_to_fahrenheit=True,
            index_by_sample_time=True,
            event_types=self.event_types
        )
        logger.debug("Loading Diamond data in parallel, using %s threads." % self.threads)

        return Diamond.parallel_load(threads=self.threads, parameter_list=argument_list)

    def _parallel_load_device_histories_frame(self):
        """
        Loads a DataFrame of device histories.
        :return: DataFrame of device histories, where each row has the mac address and device history
        """
        device_histories = self._parallel_load_device_histories()
        device_histories_dict = {}

        for key, device_history in device_histories:
            mac_address = key['device_id']
            device_histories_dict[mac_address] = device_history

        return pandas.DataFrame(device_histories_dict.items(), columns=['mac_address', 'device_history'])

    def _load_device_histories(self):
        """
        Loads device histories into a Data Frame
        :return: DataFrame of device histories, with mac_address and device_history columns
        """
        logger.debug("Loading device event histories.")
        device_histories = self._parallel_load_device_histories_frame()
        return self.devices.merge(device_histories, on='mac_address')


