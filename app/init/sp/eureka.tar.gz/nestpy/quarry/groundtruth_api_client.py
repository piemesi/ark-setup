"""
API library for accessing the GroundTruth Database. This API follows the specification linked here:
https://docs.google.com/a/nestlabs.com/document/d/1FK0ET_unhSOhWC8Dd60y5CjL_zXAh1A6G68rcuKWGXE/edit?usp=sharing
"""

import logging

import requests

logger = logging.getLogger(__name__)


DEFAULT_PAGE_SIZE = 20


class GroundtruthAPI(object):

    SECRET_KEY = 'Do6rGAJ7muE3OeLS5BDW8h7Ntp9UvtOOMbtWdzLq'
    AUTH_HEADER = 'X-Groundtruth-Auth'
    GROUND_TRUTH_URL = 'https://nest-algo.appspot.com/groundtruth/'
    BATCH_SIZE = DEFAULT_PAGE_SIZE

    def _add_secure_header(self, header=None):
        if header is None:
            header = {}
        header.update({self.AUTH_HEADER: self.SECRET_KEY})

        return header

    def _call_api(self, parameters, headers=None):
        headers = self._add_secure_header(headers)

        request = requests.get(self.GROUND_TRUTH_URL, params=parameters, headers=headers)
        request.raise_for_status()
        return request.json()

    def get_by_key(self, key):
        """
        Get a groundtruth entry from the datastore by key

        :param key: A datastore key. Obtained via a query or as the output of a put request
        :type key: basestring
        :return: A single groundtruth entry
        :rtype: dict
        """
        return self._call_api(parameters={'key': key})

    def query(self, parameters=None, max_results=None):
        """
        Get groundtruth entries that match desired parameters.

        :param parameters: query parameters the entries should match
        :type parameters: dict
        :param max_results: maximum number of results to return
        :type max_results: int
        :return: results from the query
        :rtype: list
        """
        results = []
        for result in self.iter_query(parameters, max_results):
            results.append(result)

        return results

    def iter_query(self, parameters, max_results):
        """
        Get groundtruth entries that match desired parameters.

        :param parameters: query parameters the entries should match
        :type parameters: dict
        :param max_results: maximum number of results to return
        :type max_results: int
        :return: results from the query
        :rtype: iterable
        """
        if parameters is None:
            parameters = {}
        else:
            parameters = parameters.copy()

        cursor = None
        page_size = max_results

        while True:
            # Access the datastore in batches, to avoid a request for every entry
            results = self._query_with_cursor(parameters, cursor, page_size)

            # Update query length
            if page_size is not None:
                page_size -= len(results['results'])

            for result in results['results']:
                yield result

            if results['next'] is None:
                break
            else:
                cursor = results['next']

            if page_size is not None and page_size <= 0:
                break

    def _query_with_cursor(self, parameters=None, cursor=None, page_size=None):

        if parameters is None:
            parameters = {}

        if cursor is not None:
            parameters['cursor'] = cursor
        if page_size is not None:
            parameters['page_size'] = page_size

        return self._call_api(parameters)

    def query_keys_only(self):
        raise NotImplementedError

    def query_metadata_only(self):
        raise NotImplementedError

    def upload_entry(self, sensor_data, parameters):
        headers = self._add_secure_header()
        files = {'file': ('', sensor_data)}

        response = requests.put(self.GROUND_TRUTH_URL,
                                headers=headers,
                                files=files,
                                params=parameters)

        return response

    def update_entry(self, key, parameters, annotations=None):
        """
        Update an entry in the datastore. This requires passing in the key of the entry you wish to update.
        It also follows the same rules as creating a query for restricted keys.
        Any other key can be changed through this method, although empty fields (len=0) will be skipped.
        """
        headers = self._add_secure_header()
        parameters.update({'key': key})
        if annotations is not None:
            files = {'annotations': ('', annotations)}
        else:
            files = None

        response = requests.put(self.GROUND_TRUTH_URL,
                                headers=headers,
                                params=parameters,
                                files=files)

        return response

    def delete_entry(self, key):
        headers = self._add_secure_header()
        parameters = {'key': key}

        response = requests.delete(self.GROUND_TRUTH_URL,
                                   headers=headers,
                                   params=parameters)

        return response

    def get_version(self):
        """
        Returns the current version of the GroundTruthGUI.
        """
        return None
